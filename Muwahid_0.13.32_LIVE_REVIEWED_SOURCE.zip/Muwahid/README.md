# Muwahid 0.13.32 — LIVE creation and rooms

Current application build: **0.13.32** (`versionCode 67`). This repository is the Android source project, **not** an already compiled APK.

## Approved LIVE behavior

1. Press **LIVE**: stage 1 offers **Аудиокомната** (4–12 seats) or **Видеоэфир** (4–9 seats), with an explicit seat-count selection. No room is created until confirmation.
2. Press **Далее**: stage 2 lets the creator review seats, set a title and choose **Открытый** / **Закрытый**. The creator can select theme, seat layout, seat decoration, and voice-wave effect before launching.
3. Press **Создать эфир** (with mic/camera icon): only then call server RPC `mw_live_room_create`. The selected seat count is enforced by migration `backend/032_live_two_stage_capacity.sql`.
4. Each chosen seat is displayed inside the running room; owner-selected room decoration is transmitted to participants through authenticated room messages. Participants can share invitations within Muwahid and via installed Android applications. The native share panel follows the video example with tabs; fan/group categories are shown as unavailable rather than pretending nonexistent Muwahid data exists.
5. The live-room message composer remains visible above a horizontal bottom toolbar, with the soft keyboard resizing the room, so participants can write without opening a tools menu. The room owner can end the session for everyone via `mw_room_end`. The backend rejects subsequent `mw_room_join` for an inactive room.
6. The owner can upload a photo or a 15–60-second silent looping video as a room background, subject to the previous private storage rules. Server migration `backend/031_live_background_restore.sql` is required for full history-independent background restoration.

## Deployment dependencies

* Before testing on real users, verify the existing server has `backend/031_live_background_restore.sql` and `backend/032_live_two_stage_capacity.sql` applied. Additionally, deploy `backend/033_live_theme_restore.sql` to let late joiners recover the last decoration after extensive chat history; without it, recent decoration events still flow through room messages.
* Build with `.github/workflows/build-apk.yml` and stable release signing secrets. Never treat the ZIP as an APK.
* Verify installation, entry with two devices, both modes, audio/video transmission, invitations, background syncing, and invalidity of closed-room links before publishing `updates/latest.json`.
* The historical version labels preserved in numbered backend migration paths are immutable migration identifiers, **not** the Android release version.

## Verification boundaries

* Source, Node/JavaScript and mobile browser mock checks confirm the control flow, seat counts, visible chat and appearance switching. These checks do **not** prove Android compilation or two-phone media quality.
* `github` must build **`Muwahid_0.13.32_LIVE_REVIEWED_SOURCE.zip`**, not any previous ZIP. The `updates/latest.json` manifest must only be published after signed APK verification; do not publish ZIPs as APKs.
* Exact BITMAP artwork in the reference recording belongs to the reference app, and is **not** bundled or claimed as replicated. The implemented backgrounds are gradients; the user's own image/video backgrounds use the previous authenticated media flow.
