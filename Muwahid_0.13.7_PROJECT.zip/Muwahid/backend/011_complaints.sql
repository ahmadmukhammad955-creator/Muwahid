begin;

create table if not exists public.mw_complaints (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 4000),
  status text not null default 'open' check (status in ('open','reviewing','resolved')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.mw_complaints enable row level security;
revoke all on table public.mw_complaints from public, anon;
grant select, insert on table public.mw_complaints to authenticated;

drop policy if exists "mw_complaints_insert_own" on public.mw_complaints;
create policy "mw_complaints_insert_own"
on public.mw_complaints for insert
to authenticated
with check ((select auth.uid()) is not null and (select auth.uid()) = reporter_id);

drop policy if exists "mw_complaints_select_own" on public.mw_complaints;
create policy "mw_complaints_select_own"
on public.mw_complaints for select
to authenticated
using ((select auth.uid()) = reporter_id);

create or replace function public.mw_owner_complaints()
returns table(
  id uuid,
  reporter_id uuid,
  reporter_name text,
  reporter_username text,
  body text,
  status text,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform mw_private.require_owner();

  return query
    select c.id, c.reporter_id, p.display_name, p.username, c.body, c.status, c.created_at
    from public.mw_complaints c
    left join public.mw_profiles p on p.id = c.reporter_id
    order by c.created_at desc;
end;
$$;

revoke execute on function public.mw_owner_complaints() from public, anon;
grant execute on function public.mw_owner_complaints() to authenticated;

create or replace function public.mw_owner_overview()
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform mw_private.require_owner();

  return jsonb_build_object(
    'users', (select count(*) from public.mw_profiles),
    'chats', (select count(*) from public.mw_chats),
    'messages', (select count(*) from public.mw_messages),
    'open_complaints', (select count(*) from public.mw_complaints where status='open')
  );
end;
$$;

revoke execute on function public.mw_owner_overview() from public, anon;
grant execute on function public.mw_owner_overview() to authenticated;

commit;
