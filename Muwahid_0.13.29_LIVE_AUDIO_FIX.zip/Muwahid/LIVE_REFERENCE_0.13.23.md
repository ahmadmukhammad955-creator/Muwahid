# Muwahid LIVE — reference implementation (0.13.23)

Implemented to match the supplied LIVE reference flow while preserving the existing Muwahid room features.

- Five-item bottom navigation: Чаты / Звонки / LIVE / Контакты / Настройки.
- Large center LIVE control with mint/cyan normal/pressed styling and red active-LIVE state.
- One “Создать эфир” sheet instead of separate setup screens.
- Аудиоэфир: 4 or 8 participants.
- Видеоэфир: 4, 8 or 12 participants.
- Открытый / Закрытый access selection.
- Room title and one “Начать эфир” action.
- Active LIVE header: LIVE badge, room title, participant count, access state and timer.
- Active controls: microphone, camera (video rooms), speaker route, participants, leave.
- WebRTC video tracks are enabled for video rooms; audio rooms remain audio-only.
- Existing room chat, moderation, shared PDF reading, mixer/music, soundboard and recording are retained.
- Backend migration adds room mode, dynamic capacity, access mode and `mw_live_room_create` RPC.
