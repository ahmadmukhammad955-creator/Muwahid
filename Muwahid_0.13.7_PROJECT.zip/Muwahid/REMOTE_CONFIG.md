# Muwahid Remote Config (Supabase)

Version 0.12.6 reads `public.mw_app_remote_config` through `public.mw_app_config()`.

Remote-controlled without rebuilding the APK:
- registration/login titles and explanatory text;
- phone field labels and SMS/OTP button labels;
- default country;
- Google button visibility;
- groups/channels visibility;
- voice rooms/admin section visibility;
- owner chat/Premium/Business/Gifts visibility;
- main tab labels, app label/subtitle, announcement banner;
- country/calling-code list via `mw_phone_country_list()`.

The client caches the last valid config so temporary network failures do not break startup.

Security boundary: Supabase remote config cannot safely add Android permissions, native libraries, a new WebView capability, a new cryptographic primitive, or arbitrary executable code. Those changes require a signed APK update.

## 0.12.7 phone screen

The video-matched native phone form uses fixed Russian screen copy and starts with an explicit country choice. Legacy `auth.intro`, `auth.default_country`, `auth.registration_title`, `auth.login_title`, `auth.country_button`, `auth.phone_hint`, `auth.sms_button`, and login/register switching labels do not control this new form. The `auth.enabled` and `auth.phone_enabled` gates still apply, and `auth.google_enabled` controls the alternate sign-in menu. OTP and welcome copy remain remotely configured. Country data augments the bundled 245-country directory. Active phone entry is never reset by a remote-config refresh.
