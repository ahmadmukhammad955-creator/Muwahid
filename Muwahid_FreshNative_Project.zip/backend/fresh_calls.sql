-- Independent 1-to-1 WebRTC signaling for Muwahid Fresh.
-- STUN enables common direct connections; a TURN service is required for reliable calls across restrictive networks.
create table public.mfresh_calls (
 id uuid primary key default gen_random_uuid(),
 caller_id uuid not null references public.mfresh_profiles(id) on delete cascade,
 receiver_id uuid not null references public.mfresh_profiles(id) on delete cascade,
 kind text not null check (kind in ('audio','video')),
 status text not null default 'ringing' check(status in ('ringing','accepted','declined','ended')),
 offer_sdp text, answer_sdp text,
 created_at timestamptz not null default now(),
 check(caller_id<>receiver_id)
);
create index mfresh_calls_receiver_status on public.mfresh_calls(receiver_id,status,created_at desc);
create table public.mfresh_call_ice (
 id bigint generated always as identity primary key,
 call_id uuid not null references public.mfresh_calls(id) on delete cascade,
 sender_id uuid not null references public.mfresh_profiles(id) on delete cascade,
 sdp_mid text,
 sdp_mline_index integer not null,
 candidate text not null,
 created_at timestamptz not null default now()
);
create index mfresh_ice_lookup on public.mfresh_call_ice(call_id,id);
alter table public.mfresh_calls enable row level security;
alter table public.mfresh_call_ice enable row level security;
create policy "mfresh calls participant read" on public.mfresh_calls for select to authenticated using(caller_id=(select auth.uid()) or receiver_id=(select auth.uid()));
create policy "mfresh calls caller insert" on public.mfresh_calls for insert to authenticated with check(caller_id=(select auth.uid()) and status='ringing' and offer_sdp is null and answer_sdp is null);
create policy "mfresh calls participant update" on public.mfresh_calls for update to authenticated using(caller_id=(select auth.uid()) or receiver_id=(select auth.uid())) with check(caller_id=(select auth.uid()) or receiver_id=(select auth.uid()));
create policy "mfresh call ice participants read" on public.mfresh_call_ice for select to authenticated using(exists(select 1 from public.mfresh_calls c where c.id=call_id and (c.caller_id=(select auth.uid()) or c.receiver_id=(select auth.uid()))));
create policy "mfresh call ice participant insert" on public.mfresh_call_ice for insert to authenticated with check(sender_id=(select auth.uid()) and exists(select 1 from public.mfresh_calls c where c.id=call_id and (c.caller_id=(select auth.uid()) or c.receiver_id=(select auth.uid()))));
grant select,insert on public.mfresh_calls to authenticated;
grant update(status,offer_sdp,answer_sdp) on public.mfresh_calls to authenticated;
grant select,insert on public.mfresh_call_ice to authenticated;
