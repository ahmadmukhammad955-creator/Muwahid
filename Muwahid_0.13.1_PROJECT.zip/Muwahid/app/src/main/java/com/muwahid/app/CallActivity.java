package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class CallActivity extends Activity {
    private static final int REQ_PERMS=7201;
    private WebView web;
    private Api api;
    private ExecutorService worker=Executors.newSingleThreadExecutor();
    private String kind,chatId,callId,peerName;
    private boolean incoming,loaded;

    @Override public void onCreate(Bundle b){super.onCreate(b);if(AppLock.guard(this))return;getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        api=new Api(new SecureStore(this));Intent i=getIntent();kind=i.getStringExtra("kind");if(!"video".equals(kind))kind="audio";chatId=i.getStringExtra("chat_id");callId=i.getStringExtra("call_id");peerName=i.getStringExtra("peer_name");incoming=i.getBooleanExtra("incoming",false);if(peerName==null)peerName="Muwahid";
        if(!api.signedIn()){finish();return;}ensurePermissions();
    }
    private void ensurePermissions(){ArrayList<String> need=new ArrayList<>();if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)need.add(android.Manifest.permission.RECORD_AUDIO);if("video".equals(kind)&&checkSelfPermission(android.Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)need.add(android.Manifest.permission.CAMERA);if(need.isEmpty())setup();else requestPermissions(need.toArray(new String[0]),REQ_PERMS);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_PERMS){for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED){new AlertDialog.Builder(this).setMessage("Для звонка нужен доступ к "+("video".equals(kind)?"микрофону и камере":"микрофону")+".").setPositiveButton("Закрыть",(d,w)->finish()).show();return;}setup();}}
    @SuppressWarnings("SetJavaScriptEnabled") private void setup(){if(loaded)return;loaded=true;FrameLayout stage=new FrameLayout(this);ImageView callBackground=new ImageView(this);callBackground.setImageResource(R.drawable.muwahid_call_medina);callBackground.setScaleType(ImageView.ScaleType.CENTER_CROP);callBackground.setContentDescription("Фон звонка Muwahid — Медина");stage.addView(callBackground,new FrameLayout.LayoutParams(-1,-1));WebView.setWebContentsDebuggingEnabled(false);web=new WebView(this);web.setBackgroundColor(Color.TRANSPARENT);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setDomStorageEnabled(false);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest r){runOnUiThread(()->{if(!trustedOrigin(r.getOrigin())){r.deny();return;}ArrayList<String> allow=new ArrayList<>();for(String x:r.getResources()){if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x)&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)allow.add(x);if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x)&&checkSelfPermission(android.Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)allow.add(x);}if(allow.isEmpty())r.deny();else r.grant(allow.toArray(new String[0]));});}});
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return request==null||!trustedPage(request.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){try{return !trustedPage(Uri.parse(url));}catch(Exception e){return true;}}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return blockExternal(request==null?null:request.getUrl());}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,String url){try{return blockExternal(url==null?null:Uri.parse(url));}catch(Exception e){return blocked();}}
        });
        web.addJavascriptInterface(new Bridge(),"MuwahidNative");stage.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(stage);web.loadDataWithBaseURL("https://muwahid.local/",html(),"text/html","UTF-8",null);
    }
    private boolean trustedOrigin(Uri u){return u!=null&&"https".equalsIgnoreCase(u.getScheme())&&"muwahid.local".equalsIgnoreCase(u.getHost());}
    private boolean trustedPage(Uri u){return u!=null&&(("about".equalsIgnoreCase(u.getScheme())&&"blank".equalsIgnoreCase(u.getSchemeSpecificPart()))||trustedOrigin(u));}
    private WebResourceResponse blockExternal(Uri u){if(u==null)return blocked();String scheme=u.getScheme();if("https".equalsIgnoreCase(scheme)||"http".equalsIgnoreCase(scheme))return trustedOrigin(u)?null:blocked();return null;}
    private WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));}
    private final class Bridge {
        private final Set<String> allowed=new HashSet<>(Arrays.asList("mw_call_start","mw_call_get","mw_call_answer","mw_call_ice","mw_call_end"));
        @JavascriptInterface public void rpc(String requestId,String function,String argsJson){if(!allowed.contains(function)){deliver(requestId,null,"Недоступная операция");return;}worker.execute(()->{try{Object result=api.rpc(function,new JSONObject(argsJson));deliver(requestId,result==null?"null":result.toString(),null);}catch(Exception e){deliver(requestId,null,e.getMessage()==null?"Ошибка связи":e.getMessage());}});}
        @JavascriptInterface public void close(){runOnUiThread(CallActivity.this::finish);}
    }
    private void deliver(String requestId,String json,String error){runOnUiThread(()->{if(web==null)return;String js="window.mwResult("+JSONObject.quote(requestId)+","+(json==null?"null":JSONObject.quote(json))+","+(error==null?"null":JSONObject.quote(error))+");";web.evaluateJavascript(js,null);});}
    @Override protected void onResume(){super.onResume();if(!isFinishing())AppLock.guard(this);}
    @Override public void onDestroy(){if(web!=null){web.loadUrl("about:blank");web.destroy();web=null;}worker.shutdownNow();super.onDestroy();}
    @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("window.hangup && window.hangup();",null);else super.onBackPressed();}

    private String html(){String init="window.MW={kind:"+JSONObject.quote(kind)+",incoming:"+incoming+",chatId:"+JSONObject.quote(chatId==null?"":chatId)+",callId:"+JSONObject.quote(callId==null?"":callId)+",peer:"+JSONObject.quote(peerName)+"};";
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'><style>html,body{margin:0;background:transparent;color:white;font-family:system-ui;height:100%;overflow:hidden}#remote{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:transparent}#local{position:absolute;right:16px;top:52px;width:110px;height:160px;object-fit:cover;border-radius:14px;background:#122238;border:1px solid #334}#top{position:absolute;left:0;right:0;top:0;padding:18px;text-align:center;background:linear-gradient(#0009,transparent)}#name{font-size:22px;font-weight:700}#state{font-size:14px;color:#b6c6d8;margin-top:4px}#buttons{position:absolute;left:0;right:0;bottom:34px;display:flex;justify-content:center;gap:18px}.b{border:0;border-radius:30px;padding:16px 20px;font-size:16px;color:white;background:#26435d}.end{background:#d63c50}.answer{background:#10b981}#incoming{position:absolute;inset:0;background:#07111dbd;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px}.hide{display:none!important}</style></head><body><video id='remote' autoplay playsinline></video><video id='local' autoplay playsinline muted></video><div id='top'><div id='name'></div><div id='state'>Подготовка…</div></div><div id='buttons'><button class='b' id='mute'>Микрофон</button><button class='b' id='cam'>Камера</button><button class='b end' id='end'>Завершить</button></div><div id='incoming' class='hide'><div style='font-size:26px;font-weight:700' id='incName'></div><div id='incKind'></div><div><button class='b answer' id='answer'>Ответить</button> <button class='b end' id='decline'>Отклонить</button></div></div><script>"+init+JS+"</script></body></html>";
    }
    private static final String JS=""+
"const S=window.MW;document.getElementById('name').textContent=S.peer;document.getElementById('cam').style.display=S.kind==='video'?'block':'none';document.getElementById('local').style.display=S.kind==='video'?'block':'none';document.getElementById('remote').style.display=S.kind==='video'?'block':'none';\n"+
"let pc,local,callId=S.callId||'',remoteSet=false,iceSent=[],remoteIce=0,pollTimer,ended=false;const pending={};\n"+
"window.mwResult=(id,json,err)=>{const p=pending[id];if(!p)return;delete pending[id];err?p.reject(new Error(err)):p.resolve(json===null?null:JSON.parse(json));};\n"+
"function rpc(fn,args){return new Promise((resolve,reject)=>{const id=Math.random().toString(36).slice(2);pending[id]={resolve,reject};MuwahidNative.rpc(id,fn,JSON.stringify(args));});}\n"+
"function state(x){document.getElementById('state').textContent=x;}\n"+
"async function media(){local=await navigator.mediaDevices.getUserMedia({audio:true,video:S.kind==='video'?{facingMode:'user'}:false});document.getElementById('local').srcObject=local;}\n"+
"function makePc(){pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});local.getTracks().forEach(t=>pc.addTrack(t,local));pc.ontrack=e=>{document.getElementById('remote').srcObject=e.streams[0];state('Соединено');};pc.onicecandidate=e=>{if(e.candidate){const c={sdpMid:e.candidate.sdpMid,sdpMLineIndex:e.candidate.sdpMLineIndex,sdp:e.candidate.candidate};if(callId)rpc('mw_call_ice',{p_call:callId,p_candidate:c}).catch(()=>{});else iceSent.push(c);}};pc.onconnectionstatechange=()=>{if(['failed','closed','disconnected'].includes(pc.connectionState))state('Связь прервана');};}\n"+
"async function flushIce(){for(const c of iceSent)await rpc('mw_call_ice',{p_call:callId,p_candidate:c});iceSent=[];}\n"+
"async function outgoing(){try{state('Вызов…');await media();makePc();const offer=await pc.createOffer();await pc.setLocalDescription(offer);const c=await rpc('mw_call_start',{p_chat:S.chatId,p_kind:S.kind,p_offer:offer.sdp});callId=c.id;await flushIce();poll();}catch(e){state(e.message||'Не удалось позвонить');}}\n"+
"async function acceptIncoming(){document.getElementById('incoming').classList.add('hide');try{state('Соединяем…');await media();makePc();const c=await rpc('mw_call_get',{p_call:callId});await pc.setRemoteDescription({type:'offer',sdp:c.offer});remoteSet=true;const ans=await pc.createAnswer();await pc.setLocalDescription(ans);await rpc('mw_call_answer',{p_call:callId,p_answer:ans.sdp});await flushIce();poll();}catch(e){state(e.message||'Не удалось принять звонок');}}\n"+
"async function addRemote(list){if(!list||!pc||!remoteSet)return;for(let i=remoteIce;i<list.length;i++){const c=list[i];try{await pc.addIceCandidate({sdpMid:c.sdpMid,sdpMLineIndex:c.sdpMLineIndex,candidate:c.sdp});}catch(e){}}remoteIce=list.length;}\n"+
"async function poll(){if(ended)return;try{const c=await rpc('mw_call_get',{p_call:callId});if(['ended','rejected','missed'].includes(c.status)){state(c.status==='rejected'?'Звонок отклонён':'Звонок завершён');return finishSoon();}if(!S.incoming&&c.status==='accepted'&&c.answer&&!remoteSet){await pc.setRemoteDescription({type:'answer',sdp:c.answer});remoteSet=true;}await addRemote(S.incoming?c.caller_ice:c.callee_ice);}catch(e){}pollTimer=setTimeout(poll,1200);}\n"+
"function finishSoon(){ended=true;clearTimeout(pollTimer);setTimeout(()=>MuwahidNative.close(),1000);}\n"+
"window.hangup=async function(status='ended'){if(ended)return;ended=true;clearTimeout(pollTimer);try{if(callId)await rpc('mw_call_end',{p_call:callId,p_status:status});}catch(e){}if(local)local.getTracks().forEach(t=>t.stop());if(pc)pc.close();MuwahidNative.close();};\n"+
"document.getElementById('end').onclick=()=>hangup();document.getElementById('decline').onclick=()=>hangup('rejected');document.getElementById('answer').onclick=acceptIncoming;document.getElementById('mute').onclick=()=>{if(!local)return;const a=local.getAudioTracks()[0];if(a){a.enabled=!a.enabled;document.getElementById('mute').textContent=a.enabled?'Микрофон':'Без звука';}};document.getElementById('cam').onclick=()=>{if(!local)return;const v=local.getVideoTracks()[0];if(v){v.enabled=!v.enabled;document.getElementById('cam').textContent=v.enabled?'Камера':'Камера выкл.';}};\n"+
"if(S.incoming){document.getElementById('incoming').classList.remove('hide');document.getElementById('incName').textContent=S.peer;document.getElementById('incKind').textContent=S.kind==='video'?'Входящий видеозвонок':'Входящий аудиозвонок';state('Входящий звонок');}else outgoing();";
}
