-- Muwahid 0.5: end-to-end encryption identity keys for direct text messages.
-- Run AFTER 001..006 in the same dedicated Supabase project.
begin;

create table if not exists public.mw_e2ee_keys (
 user_id uuid primary key references public.mw_profiles(id) on delete cascade,
 public_key text not null check (char_length(public_key) between 80 and 1000),
 updated_at timestamptz not null default now()
);
alter table public.mw_e2ee_keys enable row level security;
revoke all on public.mw_e2ee_keys from anon,authenticated;

create or replace function public.mw_e2ee_set_key(p_public_key text) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
 perform mw_private.require_mfa();
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 if char_length(btrim(p_public_key)) not between 80 and 1000 or btrim(p_public_key) !~ '^[A-Za-z0-9+/=]+$' then
  raise exception 'MW:Некорректный открытый ключ шифрования';
 end if;
 insert into public.mw_e2ee_keys(user_id,public_key,updated_at)
 values(auth.uid(),btrim(p_public_key),now())
 on conflict(user_id) do update set public_key=excluded.public_key,updated_at=now();
 return jsonb_build_object('ok',true);
end $$;

create or replace function public.mw_e2ee_peer_key(p_chat uuid) returns text
language plpgsql security definer set search_path='' as $$
declare peer uuid; result text;
begin
 perform mw_private.require_mfa();
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 select case when member_a=auth.uid() then member_b else member_a end into peer
 from public.mw_chats where id=p_chat and auth.uid() in(member_a,member_b);
 if peer is null then raise exception 'MW:Нет доступа к этому чату'; end if;
 select public_key into result from public.mw_e2ee_keys where user_id=peer;
 return result;
end $$;

-- AES-GCM + Base64 is larger than the original plaintext. Keep the user-facing
-- plaintext limit at 4000 while allowing room for the encrypted envelope.
alter table public.mw_messages drop constraint if exists mw_messages_body_check;
alter table public.mw_messages add constraint mw_messages_body_check
 check (char_length(btrim(body)) between 1 and 16000);

create or replace function public.mw_send(p_chat uuid,p_body text,p_nonce uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 perform mw_private.require_mfa();
 if auth.uid() is null or not exists(select 1 from public.mw_chats where id=p_chat and auth.uid() in(member_a,member_b)) then raise exception 'MW:Нет доступа к этому чату'; end if;
 if char_length(btrim(p_body)) not between 1 and 16000 then raise exception 'MW:Сообщение слишком большое'; end if;
 if p_nonce is null then raise exception 'MW:Некорректный идентификатор сообщения'; end if;
 select to_jsonb(m) into result from public.mw_messages m where sender_id=auth.uid() and client_nonce=p_nonce;
 if result is not null then
  if result->>'chat_id' <> p_chat::text or result->>'body' <> btrim(p_body) then raise exception 'MW:Конфликт повторной отправки'; end if;
  return result;
 end if;
 if (select count(*) from public.mw_messages where sender_id=auth.uid() and created_at>now()-interval '1 minute')>=60 then raise exception 'MW:Слишком много сообщений. Подождите минуту.'; end if;
 insert into public.mw_messages(chat_id,sender_id,client_nonce,body) values(p_chat,auth.uid(),p_nonce,btrim(p_body)) on conflict(sender_id,client_nonce) do nothing;
 select to_jsonb(m) into result from public.mw_messages m where sender_id=auth.uid() and client_nonce=p_nonce;
 if result->>'chat_id' <> p_chat::text or result->>'body' <> btrim(p_body) then raise exception 'MW:Конфликт повторной отправки'; end if;
 return result;
end $$;

-- Do not leak ciphertext in the chat-list preview.
create or replace function public.mw_chat_list() returns jsonb
language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 perform mw_private.require_mfa();
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 select coalesce(jsonb_agg(to_jsonb(x) order by x.updated_at desc),'[]'::jsonb) into result from (
  select c.id,p.display_name,p.username,p.id as person_id,
   case when m.body like 'mw1:%' then '🔒 Зашифрованное сообщение' else m.body end as last_message,
   coalesce(m.created_at,c.created_at) as updated_at
  from public.mw_chats c
  join public.mw_profiles p on p.id=case when c.member_a=auth.uid() then c.member_b else c.member_a end
  left join lateral(select body,created_at from public.mw_messages where chat_id=c.id order by id desc limit 1) m on true
  where auth.uid() in(c.member_a,c.member_b)
 ) x;
 return result;
end $$;

revoke all on function public.mw_e2ee_set_key(text),public.mw_e2ee_peer_key(uuid) from public,anon,authenticated;
grant execute on function public.mw_e2ee_set_key(text),public.mw_e2ee_peer_key(uuid) to authenticated;
-- Existing authenticated grants for mw_send/mw_chat_list survive CREATE OR REPLACE,
-- but state them explicitly for auditability.
grant execute on function public.mw_send(uuid,text,uuid),public.mw_chat_list() to authenticated;

commit;
