package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;

public final class MuwahidDocumentActivity extends Activity {
    private static final int REQ_PICK=1;
    private String mime="*/*";
    private LinearLayout chips;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.parseColor("#071827"));getWindow().setNavigationBarColor(Color.parseColor("#071827"));build();}
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.parseColor("#071827"));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(10),dp(8),dp(10),dp(8));TextView back=text("‹",38,Color.WHITE);back.setGravity(Gravity.CENTER);bar.addView(back,new LinearLayout.LayoutParams(dp(46),dp(50)));back.setOnClickListener(v->finish());TextView title=text("Документы",18,Color.WHITE);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);bar.addView(title,new LinearLayout.LayoutParams(0,dp(50),1));TextView more=text("⋮",28,Color.rgb(28,210,194));more.setGravity(Gravity.CENTER);bar.addView(more,new LinearLayout.LayoutParams(dp(46),dp(50)));root.addView(bar);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);chips=new LinearLayout(this);chips.setPadding(dp(8),dp(5),dp(8),dp(5));String[] names={"Все","PDF","Word","Excel","Другие"};String[] types={"*/*","application/pdf","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","*/*"};for(int i=0;i<names.length;i++){final String type=types[i];TextView c=text(names[i],13,Color.WHITE);c.setGravity(Gravity.CENTER);c.setBackground(shape(i==0?Color.rgb(21,196,205):Color.parseColor("#14283B"),16));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(72),dp(34));cp.setMargins(dp(3),0,dp(3),0);chips.addView(c,cp);c.setOnClickListener(v->{mime=type;for(int j=0;j<chips.getChildCount();j++)chips.getChildAt(j).setBackground(shape(chips.getChildAt(j)==v?Color.rgb(21,196,205):Color.parseColor("#14283B"),16));openPicker();});}hsv.addView(chips);root.addView(hsv,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);body.setPadding(dp(22),dp(22),dp(22),dp(22));TextView icon=text("▤",58,Color.rgb(44,132,238));icon.setGravity(Gravity.CENTER);body.addView(icon,new LinearLayout.LayoutParams(-1,dp(88)));TextView info=text("Выберите тип файла, затем откройте список документов на телефоне.",15,Color.parseColor("#A8B8C8"));info.setGravity(Gravity.CENTER);info.setLineSpacing(dp(3),1f);body.addView(info);Button open=new Button(this);open.setText("Открыть список файлов");open.setAllCaps(false);open.setTextColor(Color.WHITE);open.setTextSize(16);open.setBackground(shape(Color.rgb(31,139,241),18));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(54));op.topMargin=dp(26);body.addView(open,op);open.setOnClickListener(v->openPicker());root.addView(body,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    private void openPicker(){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);if("*/*".equals(mime))i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-powerpoint","application/vnd.openxmlformats-officedocument.presentationml.presentation","text/plain","application/zip"});i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_PICK);}catch(Exception e){Toast.makeText(this,"Не удалось открыть список файлов",Toast.LENGTH_SHORT).show();}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_PICK&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();Intent out=new Intent();out.setData(u);out.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);setResult(RESULT_OK,out);finish();}}
}
