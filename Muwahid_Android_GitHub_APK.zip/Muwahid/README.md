# Muwahid 0.3.0

Native Android messenger. Supabase schema deployed 2026-09-27.
Public publishable key is intentionally included; no service-role key.

Implemented: email/password UI, exact username search, direct messages, foreground polling, local notes/profile/theme.
Database verification (transaction rolled back): send/receive, idempotence, outsider read/write denial, direct-table denial, anonymous denial.
Email confirmation delivery requires project SMTP configuration. Full Android network flow still needs device verification.
No calls, groups, media, push notifications or end-to-end encryption yet.

Build: Gradle 8.7, Java 17, Android SDK 35.
Debug APKs use development signing; release signing is not configured.
