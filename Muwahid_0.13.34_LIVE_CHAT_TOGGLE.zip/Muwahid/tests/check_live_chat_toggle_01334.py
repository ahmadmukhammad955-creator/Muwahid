"""LIVE chat: real click toggle in embedded WebView source and release version guard."""
from pathlib import Path
import re
import subprocess
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/voice_room.html').read_text(encoding='utf-8')
assert re.search(r'id="chatAction"[^>]*aria-expanded="false"[^>]*onclick="toolComments\(\)"',html)
assert 'function syncChatAction()' in html
assert 'function toolComments()' in html
assert "if(!chat.classList.contains('hidden'))" in html
assert "chat.classList.add('hidden')" in html
assert "button.classList.toggle('on',visible)" in html
assert "button.setAttribute('aria-expanded',String(visible))" in html
# Verify execution against minimal simulated DOM, including native Back and other panels.
node=r"""
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(process.argv[1],'utf8');
function between(a,b){const i=html.indexOf(a),j=html.indexOf(b,i+1);assert(i>=0&&j>i);return html.slice(i,j);}
const source=between('function syncChatAction(){','function closeBookPanel(){')+
             between('function handleLiveBack(){','function toolBook(){');
class ClassList{
  constructor(v){this.s=new Set(v)} contains(x){return this.s.has(x)}
  add(x){this.s.add(x)} remove(x){this.s.delete(x)}
  toggle(x,v){if(v)this.add(x);else this.remove(x)}
}
const elem=(id,classes=[])=>({id,classList:new ClassList(classes),attrs:{},setAttribute(k,v){this.attrs[k]=v},style:{display:'none'},scrollIntoView(){}});
const chat=elem('chatSection',['auxiliary','hidden']),book=elem('bookSection',['auxiliary','hidden']);
const users=elem('usersSection',['auxiliary','hidden']),button=elem('chatAction');
const inp=elem('chatInput');inp.blur=()=>{document.activeElement=null};
const tool=elem('toolWrap'),sheet=elem('sheetWrap');
const all={chatSection:chat,bookSection:book,usersSection:users,chatAction:button,chatInput:inp,toolWrap:tool,sheetWrap:sheet};
const document={activeElement:null,getElementById(id){return all[id]},querySelectorAll(s){assert.equal(s,'.auxiliary');return [chat,book,users]},querySelector(s){if(s==='.auxiliary:not(.hidden)')return [chat,book,users].find(e=>!e.classList.contains('hidden'))||null;throw Error(s)}};
const sandbox={document,closeTools(){tool.style.display='none'},closeSheet(){sheet.style.display='none'},setTimeout(fn){fn()}};
vm.createContext(sandbox);vm.runInContext(source,sandbox);
// First tap shows chat without focusing input/triggering mobile keyboard.
sandbox.toolComments();assert(!chat.classList.contains('hidden'));assert(button.classList.contains('on'));
assert.equal(button.attrs['aria-expanded'],'true');assert.equal(button.attrs['aria-pressed'],'true');assert.equal(document.activeElement,null);
// Second tap hides and updates active state.
sandbox.toolComments();assert(chat.classList.contains('hidden'));assert(!button.classList.contains('on'));
assert.equal(button.attrs['aria-expanded'],'false');
// Chat opened via More -> Comments can be collapsed by bottom Chat button.
sandbox.toolComments();document.activeElement=inp;sandbox.toolComments();assert(chat.classList.contains('hidden'));assert.equal(document.activeElement,null);
// A different auxiliary panel closes the chat and updates button.
sandbox.toolComments();sandbox.revealAux('usersSection');assert(chat.classList.contains('hidden'));assert.equal(button.attrs['aria-expanded'],'false');
// Android back closes chat and clears control state.
sandbox.toolComments();assert.equal(sandbox.handleLiveBack(),true);assert(chat.classList.contains('hidden'));assert.equal(button.attrs['aria-expanded'],'false');
console.log('MW_CHAT_TOGGLE_INTERACTION_OK');
"""
process=subprocess.run(['node','-e',node,str(root/'app/src/main/assets/voice_room.html')],capture_output=True,text=True)
assert process.returncode==0,process.stderr
assert 'MW_CHAT_TOGGLE_INTERACTION_OK' in process.stdout
print('MW_CHAT_TOGGLE_CONTRACT_OK 0.13.34')
