package com.muwahid.app;

import android.content.SharedPreferences;
import org.json.*;

final class RemoteConfig {
    private static final String CACHE_KEY = "remote_config_json";
    private static final String CACHE_TIME_KEY = "remote_config_loaded_at";
    private final SharedPreferences prefs;
    private JSONObject config = new JSONObject();

    RemoteConfig(SharedPreferences prefs) {
        this.prefs = prefs;
        try {
            String raw = prefs.getString(CACHE_KEY, "{}");
            if (raw != null && !raw.trim().isEmpty()) config = new JSONObject(raw);
        } catch (Exception ignored) {
            config = new JSONObject();
        }
    }

    synchronized boolean replace(JSONObject next) {
        if (next == null) return false;
        String before = config.toString();
        config = next;
        prefs.edit()
                .putString(CACHE_KEY, next.toString())
                .putLong(CACHE_TIME_KEY, System.currentTimeMillis())
                .apply();
        return !before.equals(next.toString());
    }

    long loadedAt() { return prefs.getLong(CACHE_TIME_KEY, 0L); }

    synchronized JSONObject raw() {
        try { return new JSONObject(config.toString()); }
        catch (Exception e) { return new JSONObject(); }
    }

    private synchronized Object value(String path) {
        if (path == null || path.trim().isEmpty()) return null;
        Object current = config;
        for (String part : path.split("\\.")) {
            if (!(current instanceof JSONObject)) return null;
            JSONObject obj = (JSONObject) current;
            if (!obj.has(part) || obj.isNull(part)) return null;
            current = obj.opt(part);
        }
        return current;
    }

    String text(String path, String fallback) {
        Object v = value(path);
        return v instanceof String && !((String) v).trim().isEmpty() ? (String) v : fallback;
    }

    boolean bool(String path, boolean fallback) {
        Object v = value(path);
        return v instanceof Boolean ? (Boolean) v : fallback;
    }

    int integer(String path, int fallback, int min, int max) {
        Object v = value(path);
        int out = fallback;
        if (v instanceof Number) out = ((Number) v).intValue();
        else if (v instanceof String) try { out = Integer.parseInt((String) v); } catch (Exception ignored) {}
        return Math.max(min, Math.min(max, out));
    }
}
