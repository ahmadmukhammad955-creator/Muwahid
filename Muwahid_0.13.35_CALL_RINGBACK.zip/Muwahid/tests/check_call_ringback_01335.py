"""Muwahid 0.13.35 outgoing ringback regression checks (source + JS syntax)."""
from pathlib import Path
import re
import subprocess
import tempfile
import json

root=Path(__file__).resolve().parents[1]
app=(root/'app/src/main/java/com/muwahid/app/CallActivity.java').read_text()
audio=(root/'app/src/main/java/com/muwahid/app/CallRingback.java').read_text()
incoming=(root/'app/src/main/java/com/muwahid/app/CallRingtone.java').read_text()
notifications=(root/'app/src/main/java/com/muwahid/app/CallNotifications.java').read_text()
build=(root/'app/build.gradle').read_text()
assert "versionName '0.13.35'" in build and 'versionCode 70' in build
assert 'TONE_SAMPLES=RATE' in audio and 'CYCLE_SECONDS=5' in audio
assert '425.0*i/RATE' in audio and 'setLoopPoints(0,samples.length,-1)' in audio
assert 'USAGE_VOICE_COMMUNICATION' in audio
assert 'void stop()' in audio and '.release()' in audio
assert 'MuwahidNative.ringback(true)' in app
assert 'MuwahidNative.ringback(false)' in app
assert "if(c.status==='accepted'){MuwahidNative.ringback(false)" in app
assert "if(['ended','rejected','missed'].includes(c.status)){MuwahidNative.ringback(false)" in app
assert "window.hangup=async function(status='ended'){if(ended)return;ended=true;MuwahidNative.ringback(false)" in app
assert 'if(playing&&!incoming&&!isFinishing()&&!isDestroyed())outgoingRingback.start();' in app
assert '@Override public void onDestroy(){outgoingRingback.stop();' in app
assert 'if(!"ringing".equals(status))runOnUiThread(outgoingRingback::stop);' in app
assert 'CallRingtone.start(context,id)' in notifications
assert 'USAGE_NOTIFICATION_RINGTONE' in incoming
# The inline WebView JavaScript must be syntactically valid after edits.
start=app.index('private static final String JS=""+')
chunk=app[start:]
lines=chunk.splitlines()[1:]
fragments=[]
for line in lines:
    line=line.strip()
    if line=='}':break
    assert line.startswith('"') and (line.endswith('"+') or line.endswith('";')), line[:100]
    fragments.append(json.loads(line[:-1] if line.endswith('+') else line[:-1]))
js=''.join(fragments)
assert 'function outgoing()' in js and "window.hangup=async" in js
with tempfile.NamedTemporaryFile(mode='w',suffix='.js') as f:
    f.write(js);f.flush()
    subprocess.run(['node','--check',f.name],check=True,capture_output=True)
print('MW_CALL_RINGBACK_OK 0.13.35 (caller cadence, lifecycle, JS syntax, incoming preserved)')
