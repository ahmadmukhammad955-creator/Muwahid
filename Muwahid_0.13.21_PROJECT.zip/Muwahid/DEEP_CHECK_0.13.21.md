# Muwahid 0.13.21 — deep check

- versionName: 0.13.21
- versionCode: 54
- Supabase sticker catalog bridge: `mw_sticker_catalog`
- create pack: `mw_sticker_create_pack`
- import/register asset: `mw_sticker_register_asset` + `mw_sticker_add_to_pack`
- favorites / recents: `mw_sticker_set_favorite`, `mw_sticker_mark_recent`
- Android share import: ACTION_SEND / ACTION_SEND_MULTIPLE
- existing 12 built-in animated stickers remain available offline
- active-call resume and visible open voice rooms from 0.13.19 remain intact
