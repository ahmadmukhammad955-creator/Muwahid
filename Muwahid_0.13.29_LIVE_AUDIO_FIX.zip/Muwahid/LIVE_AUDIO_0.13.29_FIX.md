# Muwahid 0.13.29 — LIVE audio recovery (source patch)

Changes in `app/src/main/assets/voice_room.html`:
- Explicit "Включить звук" action in the LIVE UI for Android WebView user-activation requirements.
- Resume Web Audio context and retry remote audio playback when user taps the action or microphone.
- Clear audio/peer connection status, including when mic is muted and when no remote connection is established.
- Surface signaling and SDP/WebRTC connection failures instead of silently swallowing them.
- Guard asynchronous local stream initialization against concurrent getUserMedia requests.
- Recreate stalled peer connections on a 25-second timeout; handle RTC ontrack without e.streams[0].

Unchanged: authentication, E2EE, contacts, invitation flow, messaging, database, calls and signing configuration.

Important limitations:
1. Real cross-network reliable WebRTC media requires server-provided TURN relay credentials. This build includes STUN only; some NAT/mobile network combinations cannot connect until TURN is configured securely.
2. Microphones are muted by default on joining a room for privacy. Each speaker must explicitly enable the microphone by tapping it. Check Android microphone permission too.
3. A green GitHub Actions build/emulator smoke test does not prove audio between two distinct phones. Test with two accounts on two devices and two different networks (Wi-Fi/mobile), ensuring both hear each other.
4. Do not publish as a production update until 2-device functional tests and signing-key continuity are confirmed.
5. Current project file is a prepared source ZIP, not a compiled APK.

Publish flow: upload `Muwahid_0.13.29_LIVE_AUDIO_FIX.zip` to the repository root and replace `.github/workflows/build-apk.yml` with the separately supplied workflow. Then trigger manual workflow (publish unchecked). Only publish after real audio tests, using the signed APK from Artifacts.
