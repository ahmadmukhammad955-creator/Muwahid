# Muwahid 0.13.32 – LIVE Studio visual update

This source package changes the embedded `app/src/main/assets/voice_room.html`.
The former 12-seat / three-column LIVE room UI has been changed to a responsive
purple-theme, two-column LIVE Studio with bottom microphone, camera, participants,
chat and more controls, and an explicit end/leave button. These buttons reuse
existing real JavaScript/native bridge handlers. Speaker selection, invite,
moderation, recording, reading and effects remain accessible in the More menu.

New room creation via the Android UI now offers 4–8 seats. Existing previously
created rooms with 9–12 seats are not forcibly truncated: every member continues
to be rendered on a scrollable stage. Backend SQL was not migrated: it still
supports legacy capacity. This package does NOT implement an SFU or LiveKit;
existing P2P WebRTC remains unchanged, as does Android's background lifecycle.

Validation: `bash VERIFY_PROJECT.sh`, `python tests/check_live_01332.py`,
`python tests/check_live_01332_two_stage.py`, `python tests/check_live_studio_ui.py`,
`node tests/live_rpc_test.js`, `sha256sum -c PROJECT_CHECKSUMS.sha256`.
Local browser DOM-preview checks verify 8 seats, 2 columns, buttons opening
participants, chat and tools, and absence of browser JS errors in that mock.
This is not an actual Android/internet/media integration test. A successful APK
build and Android emulator/device validation are still required.
