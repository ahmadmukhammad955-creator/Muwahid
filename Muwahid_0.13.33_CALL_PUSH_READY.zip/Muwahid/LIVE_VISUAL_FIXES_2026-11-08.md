# Muwahid 0.13.32 — LIVE and video-call display corrections

## Observed issues from screenshots
- Eight-seat LIVE studio still seen as large empty tiles in installed build 186. A round-eight UI is already present in this source package but needs a new APK to reach devices.
- Occupied members in the round-eight renderer did not receive `data-seat`, causing all occupied tiles to lose their circular positions. This package assigns the position to occupied as well as empty seats.
- Full-screen call `<video>` was visible before any remote video frame, potentially allowing Android WebView to show its default oversized playback glyph. This package hides that element until video playback is confirmed and shows a neutral waiting message instead.
- Previous shared-reading close button and server-controlled remote theme settings are preserved.

## Verification performed
- Python / Node source checks including `tests/check_live_visual_defects.py` and `VERIFY_PROJECT.sh`.
- File checksum validation and ZIP structure validation.
- NOT device-tested: calling another phone, LiveKit / WebRTC connection, microphone permissions, camera behavior, and actual remote video rendering must be tested on real Android devices after APK rebuild.
- NO binary Android APK is included in this archive.
