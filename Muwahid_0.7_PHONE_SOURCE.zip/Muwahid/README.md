# Muwahid 0.6.1

Android prototype of the Muwahid messenger.

## Added in 0.6

- Encrypted photo, video and audio/file attachments in direct chats.
  - media bytes are AES-GCM encrypted on the sender device before upload;
  - the private Supabase Storage bucket stores only encrypted bytes;
  - attachment metadata is carried inside the existing E2EE text envelope;
  - the recipient downloads and decrypts the file locally before opening it.
- Audio and video calls using WebRTC in Android WebView.
  - Supabase is used only for offer/answer/ICE signalling;
  - media transport uses WebRTC DTLS-SRTP;
  - Google STUN is configured for the prototype; a TURN server is still needed for reliable connectivity on all NAT/mobile networks.
- Background notifications for:
  - new direct messages;
  - incoming audio calls;
  - incoming video calls.
- A foreground notification service polls the protected RPC endpoint every 5 seconds while the user is signed in. This avoids adding Firebase credentials to this prototype, but production should move to true push notifications (FCM/APNs equivalent) to reduce battery/network usage.

## Existing security

- Email/password auth through Supabase Auth.
- TOTP second factor and MFA-gated messaging/owner functions.
- E2EE v1 for new direct text messages using P-256 ECDH + HKDF-SHA256 + AES-256-GCM.
- Device private key is encrypted at rest with an Android Keystore AES-GCM wrapping key.
- Legacy plaintext messages remain readable, while plaintext downgrade is blocked for new E2EE chats.

## Required server migrations

Apply the existing migrations in order:

`001_messenger.sql` → `002_verify.sql` → `003_owner.sql` → `004_enforce_mfa.sql` → `005_verify_owner.sql` → `006_verify_mfa.sql` → `007_e2ee.sql` → **`008_media_calls_notifications.sql`**

The 0.6 migration creates the private media bucket policies, call signalling table/RPCs and the notification polling RPC.

## Current limitations

- Direct chats only; groups/channels/bots are still separate work.
- E2EE v1 is not yet a Signal Double Ratchet and does not provide full forward secrecy or multi-device key sync.
- WebRTC calls currently use STUN only. Some carrier/enterprise NATs require TURN, so calls may fail until a TURN service is configured.
- Background notifications use a foreground polling service, not Firebase Cloud Messaging. Android may still stop background work under aggressive battery-management settings.
- Media files are capped at 20 MB in the client and 25 MB in the storage bucket.

## Build

The GitHub workflow extracts the project ZIP and builds the debug APK with Gradle / Android SDK 35.

## Muwahid 0.7 server activation
After migrations 001..007, run `backend/000_RUN_AFTER_007_FULL_0.7.sql` in the Supabase SQL editor.
Then enable **Authentication -> Providers -> Phone** and configure an SMS provider in Supabase. Without this provider, phone OTP cannot send SMS. The SQL migration creates the media bucket, call signalling RPCs, notification polling RPC, and exact phone-number profile lookup.
