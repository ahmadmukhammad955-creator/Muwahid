'use strict';
const assert=require('assert');const fs=require('fs');const vm=require('vm');
const text=fs.readFileSync('app/src/main/assets/voice_room.html','utf8');
const main=[...text.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]).find(s=>s.includes('// LIVE themes are shared Supabase room state'));
assert(main,'LIVE Studio JavaScript was not found');new vm.Script(main);
const start=main.indexOf('// LIVE themes are shared Supabase room state');const end=main.indexOf('function openRoomStatus()',start);
const values=[],elements={};
function element(id){return elements[id] ||= {textContent:'',style:{setProperty:(...args)=>values.push([id,...args])},classList:{add(){},toggle(x,y){values.push([id,x,y]);}},pause(){}};}
const input={
  live:{theme_controls_enabled:true,theme_refresh_seconds:12,notice:'Эфир управляется сервером',theme_titles:{ocean:'Морской'},theme_colors:{ocean:{top:'#135790',mid:'#276aaa',bottom:'#090d22',seat:'#123456'}}}
};
const s={document:{body:element('body'),documentElement:element('html'),getElementById:element,querySelectorAll:()=>[]},
  stateData:{created_by:'user',self_id:'user',can_moderate:true,waiting:false},S:{roomId:'r'},closed:false,
  rpc:async (fn)=>{values.push(['rpc',fn]);return input;},banner:x=>values.push(['notice',x]),
  setInterval:(fn,time)=>{values.push(['interval',time]);return 4;},clearInterval:()=>values.push(['clearInterval']),
  setToolPanel:(title,html)=>values.push(['panel',title,html])};
vm.runInNewContext(main.slice(start,end)+'\nthis.remoteApi={ROOM_THEMES,applyLiveConfig,refreshLiveConfig,setRoomTheme,openThemePanel,applyRoomTheme};',s);
(async()=>{
  await s.remoteApi.refreshLiveConfig();
  assert(values.some(x=>x[0]==='rpc'&&x[1]==='mw_app_config'));
  assert.equal(s.remoteApi.ROOM_THEMES.ocean.name,'Морской');
  assert(s.remoteApi.ROOM_THEMES.ocean.bg.includes('#135790'));
  assert.equal(element('serverNotice').textContent,'Эфир управляется сервером');
  s.remoteApi.applyRoomTheme('ocean');
  assert(values.some(x=>x[0]==='liveBackground'&&x[2]?.includes('#135790')));
  s.remoteApi.applyLiveConfig({live:{notice:'',theme_colors:{ocean:{top:'url(javascript:alert(1))',mid:'#000000',bottom:'#000000',seat:'#123456'}},theme_titles:{ocean:'A'.repeat(80)},theme_controls_enabled:false}});
  assert(!s.remoteApi.ROOM_THEMES.ocean.bg.includes('javascript:'));
  assert.equal(s.remoteApi.ROOM_THEMES.ocean.name,'Океан');
  assert.equal(element('serverNotice').textContent,'');
  const before=values.filter(x=>x[0]==='rpc'&&x[1]==='mw_room_theme_set').length;
  await s.remoteApi.setRoomTheme('ocean');
  assert.equal(values.filter(x=>x[0]==='rpc'&&x[1]==='mw_room_theme_set').length,before);
  assert(values.some(x=>x[0]==='notice'&&x[1].includes('отключён')));
  const java=fs.readFileSync('app/src/main/java/com/muwahid/app/VoiceRoomActivity.java','utf8');
  assert(java.includes('"mw_room_theme_set","mw_app_config"'));
  assert(text.includes('setInterval(refreshLiveConfig,45000)'));
  assert(text.includes('if(liveConfigTimer){clearInterval(liveConfigTimer)'));
  console.log('MW_LIVE_REMOTE_CONFIG_OK: server fetch, palette, labels, notice, toggle, injection rejection, cleanup');
})().catch(e=>{console.error(e);process.exit(1)});
