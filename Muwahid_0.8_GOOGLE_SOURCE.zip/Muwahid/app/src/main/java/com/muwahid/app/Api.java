package com.muwahid.app;

import org.json.*;
import java.net.*;
import java.io.*;
import javax.net.ssl.HttpsURLConnection;
import java.util.*;

final class Api {
    private final SecureStore store;
    private volatile JSONObject session = new JSONObject();
    Api(SecureStore store) {
        this.store = store;
        try { session = new JSONObject(store.load()); } catch (Exception ignored) {}
    }
    boolean configured() { return BuildConfig.SERVER_URL.startsWith("https://") && !BuildConfig.PUBLIC_KEY.isEmpty(); }
    boolean signedIn() { return !session.optString("refresh_token").isEmpty(); }
    String uid() { JSONObject u = session.optJSONObject("user"); return u == null ? "" : u.optString("id"); }
    String googleOAuthUrl() throws Exception {
        return BuildConfig.SERVER_URL+"/auth/v1/authorize?provider=google&redirect_to="+URLEncoder.encode("muwahid://auth-callback","UTF-8");
    }
    synchronized void acceptOAuthCallback(String fragment) throws Exception {
        if(fragment==null||fragment.trim().isEmpty())throw new Exception("Google не вернул данные входа. Проверьте Redirect URL в Supabase.");
        Map<String,String> values=new HashMap<>();
        for(String part:fragment.split("&")){
            int p=part.indexOf('=');if(p<0)continue;
            values.put(URLDecoder.decode(part.substring(0,p),"UTF-8"),URLDecoder.decode(part.substring(p+1),"UTF-8"));
        }
        String err=values.get("error_description");if(err==null)err=values.get("error");
        if(err!=null&&!err.isEmpty())throw new Exception("Вход через Google не выполнен: "+err);
        String access=values.get("access_token"),refresh=values.get("refresh_token");
        if(access==null||access.isEmpty()||refresh==null||refresh.isEmpty())throw new Exception("Не удалось получить сессию Google.");
        long expires=3600;try{expires=Long.parseLong(values.get("expires_in"));}catch(Exception ignored){}
        JSONObject result=new JSONObject().put("access_token",access).put("refresh_token",refresh).put("expires_in",expires).put("token_type","bearer");
        acceptSession(result);
    }
    private JSONObject object(String text) throws Exception { return new JSONObject(text); }
    private String request(String path, JSONObject data, String token) throws Exception { return request(path,data,token,"POST"); }
    private String request(String path, JSONObject data, String token,String method) throws Exception {
        if (!configured()) throw new Exception("Сервер ещё не подключён. Пока доступны личные заметки.");
        HttpsURLConnection c = (HttpsURLConnection) new URL(BuildConfig.SERVER_URL + path).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(false);
        c.setRequestMethod(method); c.setRequestProperty("apikey", BuildConfig.PUBLIC_KEY);
        if (!token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); c.setDoOutput(!method.equals("GET"));
        try {
            if (!method.equals("GET")) try (OutputStream out = c.getOutputStream()) { out.write(data.toString().getBytes("UTF-8")); }
            int status = c.getResponseCode(); InputStream source = status >= 400 ? c.getErrorStream() : c.getInputStream();
            StringBuilder text = new StringBuilder();
            if (source != null) try (BufferedReader in = new BufferedReader(new InputStreamReader(source, "UTF-8"))) {
                String line; while ((line = in.readLine()) != null) { text.append(line); if (text.length() > 2000000) throw new IOException("Ответ сервера слишком большой"); }
            }
            if (status >= 400) {
                String msg = "Не удалось выполнить запрос (" + status + "). Попробуйте ещё раз.";
                try { JSONObject err = new JSONObject(text.toString());
                    String code = err.optString("error_code", err.optString("code"));
                    String detail = err.optString("msg", err.optString("message", err.optString("error_description")));
                    if (code.equals("invalid_credentials")) msg = "Неверные данные для входа.";
                    else if (code.equals("email_not_confirmed")) msg = "Подтвердите почту по ссылке в письме, затем войдите.";
                    else if (code.equals("user_already_exists")) msg = "Аккаунт уже существует. Нажмите «Войти».";
                    else if (code.equals("phone_provider_disabled")) msg = "Вход по телефону ещё не включён на сервере Muwahid.";
                    else if (code.equals("sms_send_failed")) msg = "Не удалось отправить SMS-код. Проверьте настройки SMS на сервере.";
                    else if (code.equals("otp_expired")) msg = "Код истёк или введён неверно. Запросите новый код.";
                    else if (status == 429) msg = "Слишком много попыток. Подождите немного.";
                    else if (code.equals("23505")) msg = "Это имя пользователя уже занято.";
                    else if (code.equals("mfa_verification_failed")) msg = "Неверный код. Проверьте время на телефоне и попробуйте снова.";
                    else if (status==404 && path.startsWith("/rest/v1/rpc/")) msg = "Сервер Muwahid ещё не обновлён для этой функции. Нужно применить серверное обновление 0.7.";
                    else if (detail.equals("MW:MFA_REQUIRED")) throw new MfaRequiredException();
                    else if (detail.startsWith("MW:")) msg = detail.substring(3);
                } catch (JSONException ignored) {}
                if (status == 401) throw new AuthException(msg);
                throw new Exception(msg);
            }
            if (status >= 300) throw new IOException("Сервер вернул перенаправление");
            return text.toString();
        } finally { c.disconnect(); }
    }
    synchronized boolean register(String email, String password, String name) throws Exception {
        JSONObject result = object(request("/auth/v1/signup", new JSONObject().put("email", email).put("password", password)
                .put("data", new JSONObject().put("display_name", name)), ""));
        if (result.optString("access_token").isEmpty()) return false;
        acceptSession(result); return true;
    }
    synchronized void login(String email, String password) throws Exception {
        acceptSession(object(request("/auth/v1/token?grant_type=password", new JSONObject().put("email", email).put("password", password), "")));
    }
    synchronized void sendPhoneOtp(String phone, String name, boolean createUser) throws Exception {
        JSONObject body=new JSONObject().put("phone",phone).put("create_user",createUser);
        if(createUser && name!=null && !name.trim().isEmpty()) body.put("data",new JSONObject().put("display_name",name.trim()));
        request("/auth/v1/otp",body,"");
    }
    synchronized void verifyPhoneOtp(String phone,String code) throws Exception {
        JSONObject result=object(request("/auth/v1/verify",new JSONObject().put("phone",phone).put("token",code).put("type","sms"),""));
        acceptSession(result);
    }
    private void acceptSession(JSONObject result) throws Exception {
        if (result.optString("access_token").isEmpty() || result.optString("refresh_token").isEmpty()) throw new Exception("Не удалось войти");
        result.put("expires_at", System.currentTimeMillis()/1000 + result.optLong("expires_in", 3600));
        if(result.optJSONObject("user")==null){
            JSONObject user=object(request("/auth/v1/user",new JSONObject(),result.optString("access_token"),"GET"));
            result.put("user",user);
        }
        store.save(result.toString()); session = result;
    }
    private void refresh() throws Exception {
        try { acceptSession(object(request("/auth/v1/token?grant_type=refresh_token", new JSONObject().put("refresh_token", session.optString("refresh_token")), ""))); }
        catch (AuthException e) { clear(); throw new Exception("Сессия истекла. Войдите снова."); }
    }
    synchronized Object rpc(String function, JSONObject args) throws Exception {
        if (!signedIn()) throw new Exception("Войдите в аккаунт");
        if (session.optLong("expires_at") < System.currentTimeMillis()/1000 + 60) refresh();
        String result;
        try { result = request("/rest/v1/rpc/" + function, args, session.optString("access_token")); }
        catch (AuthException e) { refresh(); result = request("/rest/v1/rpc/" + function, args, session.optString("access_token")); }
        return new JSONTokener(result).nextValue();
    }
    private void ensureFresh() throws Exception {
        if(!signedIn()) throw new Exception("Войдите в аккаунт");
        if(session.optLong("expires_at")<System.currentTimeMillis()/1000+60) refresh();
    }

    synchronized void uploadMedia(String objectPath, byte[] data) throws Exception {
        ensureFresh();
        String encoded=encodeObjectPath(objectPath);
        HttpsURLConnection c=(HttpsURLConnection)new URL(BuildConfig.SERVER_URL+"/storage/v1/object/mw-media/"+encoded).openConnection();
        c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setInstanceFollowRedirects(false);c.setRequestMethod("POST");
        c.setRequestProperty("apikey",BuildConfig.PUBLIC_KEY);c.setRequestProperty("Authorization","Bearer "+session.optString("access_token"));
        c.setRequestProperty("Content-Type","application/octet-stream");c.setRequestProperty("x-upsert","false");c.setDoOutput(true);
        try{try(OutputStream out=c.getOutputStream()){out.write(data);}int status=c.getResponseCode();if(status>=300){String msg=readError(c);if(status==401){refresh();uploadMedia(objectPath,data);return;}if(status==404)throw new Exception("Хранилище медиа на сервере ещё не создано. Примените серверное обновление 0.7.");throw new Exception("Не удалось загрузить файл ("+status+")"+(msg.isEmpty()?"":". "+msg));}}finally{c.disconnect();}
    }

    synchronized byte[] downloadMedia(String objectPath) throws Exception {
        ensureFresh();
        HttpsURLConnection c=(HttpsURLConnection)new URL(BuildConfig.SERVER_URL+"/storage/v1/object/authenticated/mw-media/"+encodeObjectPath(objectPath)).openConnection();
        c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setInstanceFollowRedirects(false);c.setRequestMethod("GET");
        c.setRequestProperty("apikey",BuildConfig.PUBLIC_KEY);c.setRequestProperty("Authorization","Bearer "+session.optString("access_token"));
        try{int status=c.getResponseCode();if(status==401){c.disconnect();refresh();return downloadMedia(objectPath);}if(status>=300){if(status==404)throw new Exception("Хранилище медиа на сервере ещё не создано. Примените серверное обновление 0.7.");throw new Exception("Не удалось скачать файл ("+status+")");}
            ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buf=new byte[16384];int n;int total=0;while((n=in.read(buf))!=-1){total+=n;if(total>27000000)throw new IOException("Файл слишком большой");out.write(buf,0,n);}}return out.toByteArray();
        }finally{c.disconnect();}
    }

    private String encodeObjectPath(String path) throws Exception {
        StringBuilder out=new StringBuilder();String[] parts=path.split("/");for(int i=0;i<parts.length;i++){if(i>0)out.append('/');out.append(URLEncoder.encode(parts[i],"UTF-8").replace("+","%20"));}return out.toString();
    }
    private String readError(HttpsURLConnection c){try{InputStream in=c.getErrorStream();if(in==null)return "";BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null&&b.length()<500)b.append(line);return b.toString();}catch(Exception e){return "";}}

    synchronized JSONArray factors() throws Exception {
        ensureFresh(); JSONObject user=object(request("/auth/v1/user",new JSONObject(),session.optString("access_token"),"GET"));
        JSONArray factors=user.optJSONArray("factors"); return factors==null?new JSONArray():factors;
    }
    synchronized JSONObject enrollTotp() throws Exception {
        ensureFresh();
        JSONArray existing=factors();
        for(int i=0;i<existing.length();i++) {JSONObject f=existing.getJSONObject(i);
            if("totp".equals(f.optString("factor_type")) && "verified".equals(f.optString("status"))) throw new Exception("Второй фактор уже подключён. Откройте экран защиты заново.");
        }
        // An abandoned, unverified enrollment does not protect the account yet.
        for(int i=0;i<existing.length();i++) {JSONObject f=existing.getJSONObject(i);
            if("totp".equals(f.optString("factor_type")) && "unverified".equals(f.optString("status"))) request("/auth/v1/factors/"+f.getString("id"),new JSONObject(),session.optString("access_token"),"DELETE");
        }
        return object(request("/auth/v1/factors",new JSONObject().put("factor_type","totp").put("friendly_name","Muwahid Authenticator").put("issuer","Muwahid"),session.optString("access_token")));
    }
    synchronized void verifyTotp(String factor,String code) throws Exception {
        ensureFresh();
        if(!factor.matches("[a-fA-F0-9-]{36}") || !code.matches("[0-9]{6}")) throw new Exception("Введите шестизначный код");
        JSONObject challenge=object(request("/auth/v1/factors/"+factor+"/challenge",new JSONObject(),session.optString("access_token")));
        JSONObject result=object(request("/auth/v1/factors/"+factor+"/verify",new JSONObject().put("challenge_id",challenge.getString("id")).put("code",code),session.optString("access_token")));
        acceptSession(result);
    }
    static class MfaRequiredException extends Exception { MfaRequiredException(){super("Подтвердите вход кодом второго фактора");} }
    synchronized void logout() throws Exception {
        String token = session.optString("access_token");
        try { if (!token.isEmpty()) request("/auth/v1/logout?scope=local", new JSONObject(), token); }
        finally { clear(); }
    }
    synchronized void clear() { session = new JSONObject(); store.clear(); }
    static class AuthException extends Exception { AuthException(String msg) { super(msg); } }
}
