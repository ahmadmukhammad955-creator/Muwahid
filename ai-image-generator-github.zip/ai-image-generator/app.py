import os
import re
import time
import torch
import gradio as gr
from diffusers import FluxPipeline

MODEL_ID = os.getenv("MODEL_ID", "black-forest-labs/FLUX.1-schnell")

# Safety guard: this project is not intended to bypass content safeguards.
BLOCKED_PATTERNS = [
    # explicit sexual content
    r"\b(nude|naked|porn|pornographic|explicit sex|sexual act|genitals|intercourse)\b",
    r"\b(нюд|обнаженн\w*|порно|порнограф\w*|половой акт|генитал\w*)\b",
    # minors + sexualized context
    r"\b(child|kid|minor|underage|teen)\b.*\b(sexy|nude|naked|sexual|porn)\b",
    r"\b(ребен\w*|дет\w*|несовершеннолет\w*|подрост\w*)\b.*\b(сексуаль\w*|обнажен\w*|порно)\b",
    # self-harm instructions / graphic requests
    r"\b(self[- ]?harm|suicide method|how to kill myself)\b",
    r"\b(самоповрежден\w*|способ самоубийства|как покончить с собой)\b",
]


def is_safe_prompt(prompt: str) -> bool:
    text = (prompt or "").lower().strip()
    return not any(re.search(pattern, text, flags=re.I) for pattern in BLOCKED_PATTERNS)


pipe = None


def get_pipe():
    global pipe
    if pipe is not None:
        return pipe

    if torch.cuda.is_available():
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        pipe = FluxPipeline.from_pretrained(MODEL_ID, torch_dtype=dtype)
        pipe.to("cuda")
    else:
        # CPU fallback. It works, but generation can be very slow.
        pipe = FluxPipeline.from_pretrained(MODEL_ID, torch_dtype=torch.float32)
        pipe.enable_model_cpu_offload()

    return pipe


def generate(prompt, width, height, steps, seed):
    prompt = (prompt or "").strip()
    if not prompt:
        raise gr.Error("Напиши описание изображения.")

    if not is_safe_prompt(prompt):
        raise gr.Error("Этот запрос не поддерживается правилами безопасности.")

    width = int(width)
    height = int(height)
    steps = int(steps)
    seed = int(seed) if seed is not None else 0

    # FLUX works best when dimensions are multiples of 16.
    width = max(256, min(1536, (width // 16) * 16))
    height = max(256, min(1536, (height // 16) * 16))
    steps = max(1, min(12, steps))

    generator_device = "cuda" if torch.cuda.is_available() else "cpu"
    generator = torch.Generator(generator_device).manual_seed(seed)

    model = get_pipe()
    started = time.time()
    image = model(
        prompt=prompt,
        width=width,
        height=height,
        num_inference_steps=steps,
        guidance_scale=0.0,
        max_sequence_length=256,
        generator=generator,
    ).images[0]

    elapsed = round(time.time() - started, 1)
    return image, f"Готово за {elapsed} сек. Seed: {seed}"


with gr.Blocks(title="AI Image Generator") as demo:
    gr.Markdown("# AI Image Generator\nFLUX.1-schnell • без искусственного дневного лимита")

    prompt = gr.Textbox(
        label="Описание",
        placeholder="Например: cinematic portrait of an astronaut in a neon city...",
        lines=4,
    )

    with gr.Row():
        width = gr.Slider(256, 1536, value=768, step=16, label="Ширина")
        height = gr.Slider(256, 1536, value=1024, step=16, label="Высота")

    with gr.Row():
        steps = gr.Slider(1, 12, value=4, step=1, label="Шаги")
        seed = gr.Number(value=42, precision=0, label="Seed")

    button = gr.Button("Сгенерировать", variant="primary")
    output = gr.Image(label="Результат", type="pil")
    status = gr.Textbox(label="Статус", interactive=False)

    button.click(
        fn=generate,
        inputs=[prompt, width, height, steps, seed],
        outputs=[output, status],
    )

if __name__ == "__main__":
    demo.queue(max_size=20).launch(server_name="0.0.0.0", server_port=int(os.getenv("PORT", "7860")))
