"""Release-contract tests: verify actual LIVE 0.13.31 behavior, not filename alone."""
from pathlib import Path
import re
import subprocess

root=Path(__file__).resolve().parents[1]
voice=(root/'app/src/main/java/com/muwahid/app/VoiceRoomActivity.java').read_text()
html=(root/'app/src/main/assets/voice_room.html').read_text()
main=(root/'app/src/main/java/com/muwahid/app/MainActivity.java').read_text()
sql=(root/'backend/031_live_background_restore.sql').read_text()
wf=(root/'.github/workflows/build-apk.yml').read_text()
build=(root/'app/build.gradle').read_text()

assert "versionCode 66" in build and "versionName '0.13.31'" in build
assert "EXPECTED_VERSION_CODE: '66'" in wf and "EXPECTED_VERSION_NAME: '0.13.31'" in wf
assert "Muwahid_0.13.31_LIVE_COMPLETE.zip" in wf
assert 'MW_SMOKE_OK: 0.13.31' in (root/'app/src/androidTest/java/com/muwahid/app/SmokeInstrumentation.java').read_text()

# Invite via in-app E2EE chats or any Android share target, not just one app.
assert '@JavascriptInterface public void invite()' in voice
assert 'showInviteContacts(invitation)' in voice
assert 'Intent.createChooser(send,"Отправить приглашение через")' in voice
assert 'new String[]{"Контактам Muwahid","Через другие приложения","Скопировать ссылку"}' in voice
assert 'api.rpc("mw_send"' in voice and 'crypto.encryptText(' in voice
assert 'if(contacts.length()==0)' in voice and 'shareToOtherApps(invitation)' in voice

# Owner closes server-side; users leaving must not terminate the room for everyone.
assert 'function requestExitRoom()' in html and 'created_by===stateData.self_id' in html
assert 'Завершить эфир для всех' in html and 'mw_room_end' in html
assert "if(!result?.closed)throw new Error('Сервер не подтвердил завершение')" in html
assert 'async function confirmCloseRoom()' in html
assert 'window.leaveRoom=async function' in html
assert 'mw_room_leave' in html and 'mw_room_join' in html
assert 'if(room_title is null then' not in sql # SQL is separate read-only restore
assert 'where r.id=p_room and r.active=true' in sql

# Real photo + video media selection, duration enforcement, transfer, and rendering.
assert 'REQ_BACKGROUND_IMAGE' in voice and 'REQ_BACKGROUND_VIDEO' in voice
assert 'MediaMetadataRetriever' in voice and 'if(ms<15000||ms>60000)' in voice
assert 'api.uploadRoomMedia(path,data)' in voice
assert '.put("live_background",true)' in voice
assert 'window.mwBackgroundReady' in voice and '"/live-background".equals(uri.getPath())' in voice
assert 'Content-Range' in voice and 'Partial Content' in voice
assert 'video.play().catch' in html and 'video.src=url' in html
assert 'applyBackgroundMessage(m)' in html and 'm.sender_id!==stateData.created_by' in html
assert "mw_room_background_get" in voice and 'mw_room_background_get' in html
assert 'MuwahidNative.pickBackground' in html and 'openLiveBackgroundPanel' in html
assert "video.pause();video.removeAttribute('src')" in html
assert "if(!path||!['image','video'].includes(kind)" in html
assert 'm.media @>' in sql and 'r.created_by=m.sender_id' in sql

# JS syntax compiled by Node, independent of WebView runtime availability.
match=re.search(r'<script>(.*?)</script>',html,re.S)
assert match
proc=subprocess.run(['node','--check','-'],input=match.group(1),text=True,capture_output=True)
assert proc.returncode==0,proc.stderr
print('MW_LIVE_01331_SOURCE_CONTRACT_OK')
