package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.WindowManager;

/** Device credential stays in Android; Muwahid never stores the PIN. */
public final class AppLock extends Application implements Application.ActivityLifecycleCallbacks {
    private static boolean unlocked;
    private static int started;
    private static long stoppedAt;
    static boolean enabled(Context c){return c.getSharedPreferences("muwahid",MODE_PRIVATE).getBoolean("app_lock",false);}
    static void unlock(){unlocked=true;stoppedAt=SystemClock.elapsedRealtime();}
    static boolean guard(Activity a){
        if(!enabled(a))return false;
        a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        if(started==0 && SystemClock.elapsedRealtime()-stoppedAt>=60000)unlocked=false;
        if(unlocked)return false;
        Intent next=new Intent(a.getIntent());next.setComponent(new ComponentName(a,a.getClass()));
        a.startActivity(new Intent(a,UnlockActivity.class).putExtra("next",next));a.finish();return true;
    }
    @Override public void onCreate(){super.onCreate();registerActivityLifecycleCallbacks(this);}
    public void onActivityCreated(Activity a,Bundle b){}
    public void onActivityStarted(Activity a){if(a instanceof UnlockActivity)return;if(started==0 && SystemClock.elapsedRealtime()-stoppedAt>=60000)unlocked=false;started++;}
    public void onActivityStopped(Activity a){if(a instanceof UnlockActivity)return;started=Math.max(0,started-1);if(started==0)stoppedAt=SystemClock.elapsedRealtime();}
    public void onActivityResumed(Activity a){}
    public void onActivityPaused(Activity a){}
    public void onActivitySaveInstanceState(Activity a,Bundle b){}
    public void onActivityDestroyed(Activity a){}
}
