package com.muwahid.fresh;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.text.*;
import org.json.*;
import java.io.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;

/** Fresh native implementation of the two screenshot screens; no WebView. */
public final class MainActivity extends Activity {
    private static final int BG=0xff0a131e,PANEL=0xff1c2733,FG=0xfff5f8fb,SUB=0xffaebac8,BLUE=0xff0872a3,GREEN=0xff08da83;
    private static final int PICK_AVATAR=11,PICK_COVER=12,PICK_STORY=13;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Map<String,Bitmap> imageCache=new ConcurrentHashMap<>();
    private Backend api;
    private LinearLayout root;
    private JSONObject profile=new JSONObject(),shownProfile=new JSONObject();
    private JSONArray shownStories=new JSONArray();
    private boolean archiveMode=false,archivedTab=false,loading=false;
    private String screen="login",shownUser="",dialogUser="";
    private final Handler main=new Handler(Looper.getMainLooper());
    private int generation=0;
    private final Runnable poll=new Runnable(){public void run(){if("chat".equals(screen)&&!dialogUser.isEmpty()){refreshChat(dialogUser,false);main.postDelayed(this,6000);}}};

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        api=new Backend(this);if(api.signedIn())openProfile(api.uid());else showAuth(false);
    }
    @Override protected void onDestroy(){main.removeCallbacks(poll);worker.shutdownNow();super.onDestroy();}
    @Override public void onBackPressed(){
        if("archive".equals(screen)||"settings".equals(screen)||"contacts".equals(screen)||"chat".equals(screen))openProfile(api.uid());
        else if("profile".equals(screen)&&!shownUser.equals(api.uid()))openProfile(api.uid());
        else if("profile".equals(screen))new AlertDialog.Builder(this).setMessage("Закрыть Muwahid?").setPositiveButton("Да",(d,w)->finish()).setNegativeButton("Отмена",null).show();
        else super.onBackPressed();
    }
    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable gradient(int top,int bottom,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{top,bottom});d.setCornerRadius(dp(radius));return d;}
    private TextView text(String value,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(color);t.setIncludeFontPadding(false);if(bold)t.setTypeface(null,1);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private TextView center(String value,int sp,int color,boolean bold){TextView t=text(value,sp,color,bold);t.setGravity(Gravity.CENTER);return t;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private FrameLayout.LayoutParams fp(int w,int h,int gravity){return new FrameLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h),gravity);}
    private void blank(LinearLayout l,int h){l.addView(new View(this),lp(1,h));}
    private TextView pill(String label){TextView b=center(label,15,FG,true);b.setPadding(dp(12),dp(10),dp(12),dp(10));b.setBackground(bg(BLUE,15));return b;}
    private ImageView image(int radius){ImageView v=new ImageView(this);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(gradient(0xff18344b,0xff07111c,radius));v.setClipToOutline(true);return v;}
    private void setup(String page,boolean scroll){screen=page;generation++;
        if(root!=null)root.removeAllViews();
        LinearLayout viewport=vertical();viewport.setBackgroundColor(BG);
        root=vertical();root.setBackgroundColor(BG);
        if(scroll){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setVerticalScrollBarEnabled(false);s.addView(root,new ScrollView.LayoutParams(-1,-2));viewport.addView(s,new LinearLayout.LayoutParams(-1,0,1));}
        else viewport.addView(root,new LinearLayout.LayoutParams(-1,-1));
        setContentView(viewport);
    }
    private void work(Throwing task){worker.execute(()->{try{task.run();}catch(Exception ex){error(ex);}});}
    private interface Throwing{void run() throws Exception;}
    private void ui(Runnable runnable){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())runnable.run();});}
    private void error(Exception e){ui(()->{String msg=e.getMessage();if(msg==null||msg.trim().isEmpty())msg="Не удалось выполнить запрос";Toast.makeText(this,msg,Toast.LENGTH_LONG).show();});}
    private boolean isSelf(){return shownUser.equals(api.uid());}
    private String name(JSONObject p){return p.optString("display_name","Пользователь");}

    private void showAuth(boolean register){
        setup("login",true);root.setPadding(dp(28),dp(60),dp(28),0);
        TextView logo=center("MUWAHID",30,FG,true);root.addView(logo,lp(-1,62));
        TextView desc=center("Профиль · Истории · Архив",15,SUB,false);root.addView(desc,lp(-1,30));blank(root,34);
        TextView title=text(register?"Регистрация":"Вход в аккаунт",24,FG,true);root.addView(title,lp(-1,52));
        EditText email=entry("Электронная почта",false);root.addView(email,lp(-1,56));blank(root,12);
        EditText password=entry("Пароль (от 6 символов)",true);root.addView(password,lp(-1,56));blank(root,20);
        TextView submit=pill(register?"Зарегистрироваться":"Войти");root.addView(submit,lp(-1,54));
        TextView toggle=center(register?"Уже есть аккаунт? Войти":"Нет аккаунта? Зарегистрироваться",15,0xff88ccef,false);
        root.addView(toggle,lp(-1,64));toggle.setOnClickListener(v->showAuth(!register));
        submit.setOnClickListener(v->{String e=email.getText().toString().trim(),p=password.getText().toString();
            if(!e.contains("@")||p.length()<6){Toast.makeText(this,"Проверьте почту и пароль",Toast.LENGTH_LONG).show();return;}
            submit.setEnabled(false);submit.setText("Соединяемся…");
            work(()->{try{boolean ready=!register||api.signUp(e,p);if(!register)api.logIn(e,p);
                if(!ready){ui(()->{showAuth(false);new AlertDialog.Builder(this).setMessage("Проверьте почту и подтвердите регистрацию. Затем войдите.").setPositiveButton("OK",null).show();});}
                else {api.ownProfile();ui(()->openProfile(api.uid()));}
            }finally{ui(()->{submit.setEnabled(true);submit.setText(register?"Зарегистрироваться":"Войти");});}});
        });
    }
    private EditText entry(String hint,boolean secret){EditText t=new EditText(this);t.setSingleLine(true);t.setTextSize(16);t.setTextColor(FG);t.setHintTextColor(SUB);
        t.setHint(hint);t.setPadding(dp(16),0,dp(16),0);t.setBackground(bg(PANEL,14));
        if(secret)t.setInputType(129);else t.setInputType(33);return t;}

    private void openProfile(String id){
        shownUser=id;shownProfile=new JSONObject();shownStories=new JSONArray();archiveMode=false;archivedTab=false;
        renderProfile();
        work(()->{JSONObject p=id.equals(api.uid())?api.ownProfile():getProfile(id);JSONArray stories=api.stories(id);
            if(id.equals(api.uid())){try{api.patch("mfresh_profiles","id=eq."+Backend.enc(id),new JSONObject().put("last_seen",java.time.Instant.now().toString()));}catch(Exception ignored){}}
            ui(()->{if("profile".equals(screen)&&shownUser.equals(id)){shownProfile=p;shownStories=stories;if(id.equals(api.uid()))profile=p;renderProfile();}});
        });
    }
    private JSONObject getProfile(String id)throws Exception{JSONArray a=api.list("mfresh_profiles","id=eq."+Backend.enc(id)+"&select=*");
        return a.length()==0?new JSONObject():a.getJSONObject(0);}
    private boolean active(JSONObject story){try{return Instant.parse(story.optString("expires_at")).isAfter(Instant.now());}catch(Exception e){return false;}}
    private String age(JSONObject story){try{long sec=Duration.between(Instant.now(),Instant.parse(story.optString("expires_at"))).getSeconds();
        return sec>0?(sec>=3600?(sec/3600+" ч"):(Math.max(1,sec/60)+" мин")):"Архив";}catch(Exception e){return "";}}
    private int intViews(String id){try{JSONArray result=api.views(id);return result.length();}catch(Exception e){return 0;}}
    private void renderProfile(){
        setup("profile",true);
        JSONObject p=shownProfile;
        LinearLayout toolbar=horizontal();toolbar.setPadding(dp(15),dp(18),dp(15),dp(6));root.addView(toolbar,lp(-1,62));
        TextView back=center("‹",34,FG,false);toolbar.addView(back,lp(48,48));back.setOnClickListener(v->{if(!isSelf())openProfile(api.uid());else finish();});
        TextView title=text("Профиль",21,FG,true);toolbar.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        TextView qr=center("▦",29,FG,false);toolbar.addView(qr,lp(44,48));qr.setOnClickListener(v->showQr());
        TextView edit=center("✎",28,FG,false);toolbar.addView(edit,lp(44,48));edit.setOnClickListener(v->{if(isSelf())showSettings();else Toast.makeText(this,"Редактировать можно только свой профиль",Toast.LENGTH_SHORT).show();});
        TextView menu=center("⋮",29,FG,false);toolbar.addView(menu,lp(34,48));menu.setOnClickListener(v->{PopupMenu pop=new PopupMenu(this,menu);
            pop.getMenu().add("Архив историй").setOnMenuItemClickListener(x->{openArchive();return true;});
            pop.getMenu().add("Настройки").setOnMenuItemClickListener(x->{showSettings();return true;});pop.show();});
        FrameLayout hero=new FrameLayout(this);LinearLayout.LayoutParams hparam=lp(-1,290);hparam.setMargins(dp(13),0,dp(13),0);root.addView(hero,hparam);
        ImageView cover=image(18);hero.addView(cover,fp(-1,215,Gravity.TOP));
        loadImage(cover,"mfresh-profile",p.optString("cover_path",""));
        View fade=new View(this);fade.setBackground(gradient(0x00000000,BG,0));hero.addView(fade,fp(-1,212,Gravity.TOP));
        FrameLayout avatarWrap=new FrameLayout(this);FrameLayout.LayoutParams avfp=fp(136,136,Gravity.TOP|Gravity.CENTER_HORIZONTAL);avfp.topMargin=dp(46);hero.addView(avatarWrap,avfp);
        ImageView avatar=image(75);avatar.setBackground(bg(0xff1a344b,75));avatarWrap.addView(avatar,fp(132,132,Gravity.TOP|Gravity.CENTER_HORIZONTAL));
        if(p.optString("avatar_path","").isEmpty()){
            TextView person=center("◯",78,0xffb9ccd8,false);avatarWrap.addView(person,fp(-1,-1,Gravity.CENTER));
        }else loadImage(avatar,"mfresh-profile",p.optString("avatar_path",""));
        TextView dot=center("●",23,GREEN,true);FrameLayout.LayoutParams dotp=fp(32,32,Gravity.BOTTOM|Gravity.RIGHT);dotp.rightMargin=dp(3);avatarWrap.addView(dot,dotp);
        TextView name=center(name(p),27,FG,true);FrameLayout.LayoutParams np=fp(-1,40,Gravity.TOP);np.topMargin=dp(191);hero.addView(name,np);
        TextView handle=center("@"+p.optString("username","muwahid"),15,SUB,false);FrameLayout.LayoutParams hp=fp(-1,30,Gravity.TOP);hp.topMargin=dp(231);hero.addView(handle,hp);
        TextView online=center(isSelf()?"●  Онлайн":"●  Профиль",12,isSelf()?GREEN:SUB,false);
        FrameLayout.LayoutParams op=fp(-1,24,Gravity.TOP);op.topMargin=dp(262);hero.addView(online,op);
        if(isSelf()){
            TextView camera=center("📷",17,FG,true);camera.setBackground(bg(0xaa0a131e,20));FrameLayout.LayoutParams cp=fp(43,38,Gravity.RIGHT|Gravity.TOP);
            cp.topMargin=dp(18);cp.rightMargin=dp(18);hero.addView(camera,cp);camera.setOnClickListener(v->pick(PICK_COVER,"image/*"));
            avatarWrap.setOnClickListener(v->pick(PICK_AVATAR,"image/*"));
        }
        blank(root,9);
        LinearLayout acts=horizontal();acts.setPadding(dp(17),0,dp(17),0);root.addView(acts,lp(-1,83));
        action(acts,"☏","Чат",()->showContacts("chat"));
        action(acts,"♧","Звонок",()->callInfo(false));
        action(acts,"▣","Видео",()->callInfo(true));
        action(acts,"➤","Поделиться",this::shareProfile);
        blank(root,20);
        LinearLayout row=horizontal();row.setPadding(dp(23),0,dp(23),0);root.addView(row,lp(-1,36));
        row.addView(text("Истории",22,FG,true),new LinearLayout.LayoutParams(0,-1,1));
        TextView arch=text("◷  Архив",16,SUB,false);row.addView(arch,lp(-2,-1));arch.setOnClickListener(v->openArchive());
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);root.addView(hsv,lp(-1,154));
        LinearLayout storyStrip=horizontal();storyStrip.setPadding(dp(16),dp(8),dp(16),dp(3));hsv.addView(storyStrip);
        if(isSelf()){
            LinearLayout add=vertical();add.setGravity(Gravity.CENTER);add.setBackground(bg(PANEL,19));
            LinearLayout.LayoutParams ap=lp(100,142);ap.rightMargin=dp(9);storyStrip.addView(add,ap);
            TextView plus=center("+",36,FG,false);add.addView(plus,lp(-1,70));
            TextView caption=center("Добавить\nисторию",14,FG,false);add.addView(caption,lp(-1,50));
            add.setOnClickListener(v->pick(PICK_STORY,"image/* video/mp4"));
        }
        int n=0;
        for(int i=0;i<shownStories.length();i++){
            JSONObject s=shownStories.optJSONObject(i);if(s==null||!active(s))continue;
            storyStrip.addView(storyTile(s,102,142,false),lp(102,142));n++;
        }
        if(n==0){TextView empty=center("Пока нет опубликованных историй",13,SUB,false);storyStrip.addView(empty,lp(208,100));}
        blank(root,21);
        LinearLayout details=vertical();details.setBackground(bg(0xff17232f,19));LinearLayout.LayoutParams dlp=lp(-1,-2);
        dlp.setMargins(dp(17),0,dp(17),dp(29));root.addView(details,dlp);
        info(details,"♙","О себе",p.optString("bio","").isEmpty()?"Добавьте информацию о себе":p.optString("bio"),()->{if(isSelf())showSettings();});
        info(details,"▧","Медиа, файлы и ссылки","Фотографии и опубликованные истории",()->openArchive());
        info(details,"♧","Общие контакты","Найти контакт по имени",()->showContacts("chat"));
        info(details,"⬡","Конфиденциальность","Настройки доступа к историям",()->new AlertDialog.Builder(this).setMessage("Новые истории видимы авторизованным пользователям в течение 24 часов. Архив доступен только владельцу.").setPositiveButton("Понятно",null).show());
        info(details,"⚙","Настройки профиля","Имя, описание, фотографии",()->showSettings());
    }
    private void action(LinearLayout parent,String icon,String label,Runnable r){
        LinearLayout box=vertical();box.setBackground(bg(PANEL,17));box.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(77),1);p.setMargins(dp(3),0,dp(3),0);parent.addView(box,p);
        box.addView(center(icon,27,FG,false),lp(-1,37));box.addView(center(label,12,FG,false),lp(-1,29));box.setOnClickListener(v->r.run());
    }
    private void info(LinearLayout list,String icon,String label,String sub,Runnable r){LinearLayout row=horizontal();row.setPadding(dp(13),dp(6),dp(10),dp(6));list.addView(row,lp(-1,69));
        TextView glyph=center(icon,23,FG,false);glyph.setBackground(bg(0xff243541,30));row.addView(glyph,lp(44,44));
        LinearLayout t=vertical();t.setPadding(dp(13),0,dp(2),0);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        t.addView(text(label,16,FG,false),lp(-1,27));TextView secondary=text(sub,12,SUB,false);secondary.setMaxLines(1);secondary.setEllipsize(TextUtils.TruncateAt.END);t.addView(secondary,lp(-1,22));
        row.addView(center("›",29,SUB,false),lp(24,44));row.setOnClickListener(v->r.run());
        View line=new View(this);line.setBackgroundColor(0xff273441);list.addView(line,lp(-1,1));
    }
    private void loadImage(ImageView view,String bucket,String path){
        if(path.isEmpty())return;String key=bucket+":"+path;Bitmap cached=imageCache.get(key);
        if(cached!=null){view.setImageBitmap(cached);return;}
        final int gen=generation;
        work(()->{byte[] bytes=api.download(bucket,path);Bitmap bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
            if(bitmap==null)throw new IOException("Недопустимое изображение");imageCache.put(key,bitmap);
            ui(()->{if(generation==gen)view.setImageBitmap(bitmap);});
        });
    }
    private View storyTile(JSONObject story,int width,int height,boolean full){
        FrameLayout frame=new FrameLayout(this);frame.setBackground(bg(PANEL,16));frame.setClipToOutline(true);
        String path=story.optString("object_path","");
        if("image".equals(story.optString("kind"))){ImageView art=image(16);frame.addView(art,fp(-1,-1,Gravity.CENTER));loadImage(art,"mfresh-stories",path);}
        else {TextView video=center("▶",37,FG,true);video.setBackground(gradient(0xff386683,0xff111a27,16));frame.addView(video,fp(-1,-1,Gravity.CENTER));}
        View tint=new View(this);tint.setBackground(gradient(0x00000000,0x99000000,16));frame.addView(tint,fp(-1,-1,Gravity.CENTER));
        TextView hours=text(age(story),11,FG,true);FrameLayout.LayoutParams hr=fp(-2,25,Gravity.RIGHT|Gravity.TOP);hr.setMargins(0,dp(7),dp(9),0);frame.addView(hours,hr);
        TextView views=text("◉ …",12,FG,true);FrameLayout.LayoutParams vp=fp(-2,28,Gravity.LEFT|Gravity.BOTTOM);vp.leftMargin=dp(10);frame.addView(views,vp);
        String sid=story.optString("id");int gen=generation;work(()->{int total=intViews(sid);ui(()->{if(generation==gen)views.setText("◉ "+total);});});
        frame.setOnClickListener(v->viewStory(story));return frame;
    }
    private void openArchive(){if(!api.signedIn())return;archiveMode=true;archivedTab=false;
        if(!shownUser.equals(api.uid())){shownUser=api.uid();shownStories=new JSONArray();work(()->{JSONArray a=api.stories(api.uid());ui(()->{shownStories=a;renderArchive();});});}
        renderArchive();
    }
    private void renderArchive(){setup("archive",true);
        LinearLayout bar=horizontal();bar.setPadding(dp(16),dp(16),dp(15),0);root.addView(bar,lp(-1,67));
        TextView back=center("‹",32,FG,false);bar.addView(back,lp(48,47));back.setOnClickListener(v->openProfile(api.uid()));
        bar.addView(text("Архив историй",21,FG,true),new LinearLayout.LayoutParams(0,dp(48),1));
        TextView more=center("⋮",28,FG,false);bar.addView(more,lp(35,48));more.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Истории сохраняются в личном архиве после 24 часов. Старые истории других пользователей недоступны.").setPositiveButton("OK",null).show());
        LinearLayout tabs=horizontal();tabs.setBackground(bg(PANEL,18));tabs.setPadding(dp(5),dp(5),dp(5),dp(5));
        LinearLayout.LayoutParams tp=lp(-1,61);tp.setMargins(dp(19),dp(12),dp(19),dp(27));root.addView(tabs,tp);
        archiveTab(tabs,"▣  Мои истории",!archivedTab,()->{archivedTab=false;renderArchive();});
        archiveTab(tabs,"▤  Архив",archivedTab,()->{archivedTab=true;renderArchive();});
        LinearLayout grid=vertical();grid.setPadding(dp(16),0,dp(16),dp(40));root.addView(grid,lp(-1,-2));
        java.util.ArrayList<JSONObject> matching=new java.util.ArrayList<>();
        for(int i=0;i<shownStories.length();i++){JSONObject s=shownStories.optJSONObject(i);if(s!=null&&active(s)!=archivedTab)matching.add(s);}
        if(matching.isEmpty()){TextView blank=center(archivedTab?"Архив пока пуст":"Активных историй пока нет",16,SUB,false);grid.addView(blank,lp(-1,170));return;}
        int usable=getResources().getDisplayMetrics().widthPixels-dp(32),w=(usable-dp(16))/3;
        for(int i=0;i<matching.size();i+=3){LinearLayout row=horizontal();grid.addView(row,lp(-1,(int)(w/getResources().getDisplayMetrics().density*1.47f)+8));
            for(int k=0;k<3;k++){int index=i+k;LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.setMargins(dp(3),0,dp(3),dp(7));
                if(index<matching.size())row.addView(storyTile(matching.get(index),w,(int)(w*1.45f),true),p);else row.addView(new View(this),p);
            }
        }
    }
    private void archiveTab(LinearLayout parent,String label,boolean selected,Runnable action){TextView t=center(label,16,selected?0xff7bd5fb:FG,selected);if(selected)t.setBackground(bg(0xff064f76,15));
        parent.addView(t,new LinearLayout.LayoutParams(0,-1,1));t.setOnClickListener(v->action.run());}

    private void viewStory(JSONObject story){
        if(!api.signedIn())return;
        String path=story.optString("object_path"),kind=story.optString("kind"),id=story.optString("id");
        FrameLayout overlay=new FrameLayout(this);overlay.setBackgroundColor(0xff02050b);setContentView(overlay);screen="viewer";
        ProgressBar progress=new ProgressBar(this);overlay.addView(progress,fp(50,50,Gravity.CENTER));
        TextView back=center("‹ Назад",17,FG,true);FrameLayout.LayoutParams bp=fp(100,50,Gravity.TOP|Gravity.LEFT);bp.leftMargin=dp(13);bp.topMargin=dp(6);overlay.addView(back,bp);
        back.setOnClickListener(v->{if(archiveMode)renderArchive();else openProfile(shownUser);});
        work(()->{api.markView(id);byte[] bytes=api.download("mfresh-stories",path);ui(()->{
            if(!"viewer".equals(screen))return;overlay.removeView(progress);
            if("video".equals(kind)){
                try{File f=new File(getCacheDir(),"mfresh_story_preview.mp4");try(FileOutputStream o=new FileOutputStream(f)){o.write(bytes);}
                    VideoView player=new VideoView(this);overlay.addView(player,0,fp(-1,-1,Gravity.CENTER));player.setVideoPath(f.getAbsolutePath());player.setOnPreparedListener(mp->{mp.setLooping(false);player.start();});
                    player.setOnCompletionListener(mp->{if(archiveMode)renderArchive();else openProfile(shownUser);});
                }catch(Exception ex){error(ex);}
            }else{
                Bitmap bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(bitmap==null){error(new IOException("Не удалось декодировать фото"));return;}
                ImageView full=image(0);full.setScaleType(ImageView.ScaleType.FIT_CENTER);full.setImageBitmap(bitmap);overlay.addView(full,0,fp(-1,-1,Gravity.CENTER));
            }
        });});
    }
    private void pick(int code,String type){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        if(code==PICK_STORY){i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/jpeg","image/png","image/webp","video/mp4"});}
        else i.setType("image/*");
        try{startActivityForResult(i,code);}catch(Exception e){error(e);}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();if(request!=PICK_AVATAR&&request!=PICK_COVER&&request!=PICK_STORY)return;
        Toast.makeText(this,"Загружаем выбранный файл…",Toast.LENGTH_SHORT).show();
        work(()->{
            boolean isVideo=request==PICK_STORY&&"video/mp4".equals(getContentResolver().getType(uri));
            int max=isVideo?25*1024*1024:8*1024*1024;
            byte[] bytes=isVideo?readPicked(uri,max):prepareJpeg(uri,request==PICK_COVER?1600:request==PICK_AVATAR?700:1400);
            if(bytes.length>max)throw new IOException("Файл слишком большой");
            String random=UUID.randomUUID().toString();
            if(request==PICK_STORY){String path=api.uid()+"/stories/"+random+(isVideo?".mp4":".jpg");
                api.upload("mfresh-stories",path,bytes,isVideo?"video/mp4":"image/jpeg");
                try{api.insert("mfresh_stories",new JSONObject().put("user_id",api.uid()).put("object_path",path).put("kind",isVideo?"video":"image"),false);}
                catch(Exception ex){try{api.deleteUpload("mfresh-stories",path);}catch(Exception ignored){}throw ex;}
            }else{
                String key=request==PICK_AVATAR?"avatar_path":"cover_path";
                String path=api.uid()+"/"+key+"/"+random+".jpg";
                api.upload("mfresh-profile",path,bytes,"image/jpeg");
                api.patch("mfresh_profiles","id=eq."+Backend.enc(api.uid()),new JSONObject().put(key,path));
            }
            imageCache.clear();ui(()->{Toast.makeText(this,"Сохранено на сервере",Toast.LENGTH_SHORT).show();openProfile(api.uid());});
        });
    }
    private byte[] readPicked(Uri uri,int limit)throws Exception{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream o=new ByteArrayOutputStream()){
        if(in==null)throw new IOException("Не удалось открыть файл");byte[] b=new byte[8192];int n,total=0;
        while((n=in.read(b))!=-1){total+=n;if(total>limit)throw new IOException("Максимальный размер: "+limit/1024/1024+" МБ");o.write(b,0,n);}return o.toByteArray();}}
    private byte[] prepareJpeg(Uri uri,int maxDim)throws Exception{
        Bitmap b;try(InputStream input=getContentResolver().openInputStream(uri)){b=BitmapFactory.decodeStream(input);}
        if(b==null)throw new IOException("Файл не является фотографией");
        int w=b.getWidth(),h=b.getHeight();float scale=Math.min(1f,(float)maxDim/Math.max(w,h));
        if(scale<1f){Bitmap small=Bitmap.createScaledBitmap(b,Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)),true);b.recycle();b=small;}
        ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.JPEG,86,out);b.recycle();return out.toByteArray();
    }
    private void shareProfile(){String handle=shownProfile.optString("username","");if(handle.isEmpty())return;
        Intent i=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,"Мой профиль Muwahid: @"+handle);
        startActivity(Intent.createChooser(i,"Поделиться профилем"));
    }
    private void showQr(){
        String username=shownProfile.optString("username","");
        if(username.isEmpty()){Toast.makeText(this,"Профиль загружается",Toast.LENGTH_SHORT).show();return;}
        try{
            com.google.zxing.common.BitMatrix code=new com.google.zxing.qrcode.QRCodeWriter()
                .encode("muwahid://profile/"+username,com.google.zxing.BarcodeFormat.QR_CODE,512,512);
            Bitmap b=Bitmap.createBitmap(512,512,Bitmap.Config.ARGB_8888);
            for(int y=0;y<512;y++)for(int x=0;x<512;x++)b.setPixel(x,y,code.get(x,y)?0xff07111b:0xffffffff);
            ImageView img=new ImageView(this);img.setImageBitmap(b);img.setPadding(dp(22),dp(22),dp(22),dp(22));
            img.setBackgroundColor(0xffffffff);
            new AlertDialog.Builder(this).setTitle("QR-код @"+username).setView(img)
                .setPositiveButton("Поделиться",(d,w)->shareProfile()).setNegativeButton("Закрыть",null).show();
        }catch(Exception ex){error(ex);}
    }
    private void callInfo(boolean video){new AlertDialog.Builder(this)
        .setTitle(video?"Видеозвонок":"Голосовой звонок")
        .setMessage("Звонки требуют отдельного работающего WebRTC-сервера и проверки связи между двумя телефонами. Эта функция пока не подключена. Демонстрационный вызов не запускается.")
        .setPositiveButton("Понятно",null).show();}

    private void showSettings(){if(!api.signedIn())return;setup("settings",true);
        TextView title=text("‹  Настройки профиля",23,FG,true);title.setPadding(dp(15),dp(20),0,0);root.addView(title,lp(-1,86));title.setOnClickListener(v->openProfile(api.uid()));
        TextView label=text("Имя пользователя",16,SUB,false);label.setPadding(dp(18),0,0,0);root.addView(label,lp(-1,42));
        EditText name=entry("Имя",false);name.setText(profile.optString("display_name",""));LinearLayout.LayoutParams p=lp(-1,55);p.setMargins(dp(17),0,dp(17),0);root.addView(name,p);
        TextView labelBio=text("О себе",16,SUB,false);labelBio.setPadding(dp(18),0,0,0);root.addView(labelBio,lp(-1,52));
        EditText bio=entry("Описание профиля",false);bio.setSingleLine(false);bio.setMinLines(3);bio.setGravity(Gravity.TOP);bio.setText(profile.optString("bio",""));
        LinearLayout.LayoutParams bp=lp(-1,120);bp.setMargins(dp(17),0,dp(17),0);root.addView(bio,bp);blank(root,24);
        TextView save=pill("Сохранить изменения");LinearLayout.LayoutParams sp=lp(-1,53);sp.setMargins(dp(17),0,dp(17),0);root.addView(save,sp);
        save.setOnClickListener(v->{String n=name.getText().toString().trim(),b=bio.getText().toString().trim();if(n.isEmpty()||n.length()>80||b.length()>500){error(new Exception("Проверьте имя и описание"));return;}
            work(()->{api.patch("mfresh_profiles","id=eq."+Backend.enc(api.uid()),new JSONObject().put("display_name",n).put("bio",b));ui(()->openProfile(api.uid()));});
        });blank(root,21);
        TextView avatar=pill("Изменить фотографию профиля");LinearLayout.LayoutParams ap=lp(-1,52);ap.setMargins(dp(17),0,dp(17),dp(9));root.addView(avatar,ap);avatar.setOnClickListener(v->pick(PICK_AVATAR,"image/*"));
        TextView cover=pill("Изменить обложку");LinearLayout.LayoutParams cp=lp(-1,52);cp.setMargins(dp(17),0,dp(17),dp(12));root.addView(cover,cp);cover.setOnClickListener(v->pick(PICK_COVER,"image/*"));
        TextView logout=center("Выйти из аккаунта",16,0xffff8e8e,true);root.addView(logout,lp(-1,65));logout.setOnClickListener(v->{api.signOut();showAuth(false);});
    }
    private void showContacts(String mode){setup("contacts",true);LinearLayout bar=horizontal();bar.setPadding(dp(18),dp(14),0,dp(14));root.addView(bar,lp(-1,69));
        TextView back=center("‹",31,FG,false);bar.addView(back,lp(40,40));back.setOnClickListener(v->openProfile(api.uid()));
        bar.addView(text("Выберите контакт",22,FG,true),lp(-1,-1));
        EditText search=entry("Поиск по имени @username",false);LinearLayout.LayoutParams sp=lp(-1,58);sp.setMargins(dp(16),0,dp(16),dp(15));root.addView(search,sp);
        LinearLayout results=vertical();root.addView(results,lp(-1,-2));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}
            public void onTextChanged(CharSequence s,int a,int b,int c){String q=s.toString().trim();if(q.length()<2){results.removeAllViews();return;}int g=++generation;
                work(()->{JSONArray profiles=api.otherProfiles(q);ui(()->{if(g!=generation||!"contacts".equals(screen))return;results.removeAllViews();
                    for(int i=0;i<profiles.length();i++){JSONObject p=profiles.optJSONObject(i);if(p==null||p.optString("id").equals(api.uid()))continue;
                        LinearLayout row=horizontal();row.setPadding(dp(19),0,dp(19),0);results.addView(row,lp(-1,66));
                        TextView t=text(name(p)+"  @"+p.optString("username"),16,FG,false);row.addView(t,new LinearLayout.LayoutParams(0,-1,1));
                        row.addView(center("›",28,SUB,false),lp(33,50));
                        row.setOnClickListener(v->openChat(p.optString("id"),name(p)));}
                });});
            }
            public void afterTextChanged(Editable s){}
        });
        TextView hint=center("Найдите собеседника, чтобы открыть настоящий чат.",14,SUB,false);results.addView(hint,lp(-1,100));
    }
    private void openChat(String other,String title){dialogUser=other;main.removeCallbacks(poll);setup("chat",false);renderChatHeader(title);
        LinearLayout messages=vertical();ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(messages);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout composer=horizontal();composer.setPadding(dp(10),dp(8),dp(10),dp(9));composer.setBackground(bg(PANEL,15));root.addView(composer,lp(-1,69));
        EditText input=entry("Сообщение",false);composer.addView(input,new LinearLayout.LayoutParams(0,dp(52),1));
        TextView send=center("➤",23,FG,true);send.setBackground(bg(BLUE,13));LinearLayout.LayoutParams se=lp(52,52);se.leftMargin=dp(8);composer.addView(send,se);
        send.setOnClickListener(v->{String t=input.getText().toString().trim();if(t.isEmpty())return;send.setEnabled(false);
            work(()->{try{api.sendMessage(other,t);ui(()->{input.setText("");refreshChat(other,true);});}finally{ui(()->send.setEnabled(true));}});});
        chatHolder=messages;chatScroller=scroll;chatTitle=title;refreshChat(other,true);main.postDelayed(poll,6000);
    }
    private LinearLayout chatHolder;private ScrollView chatScroller;private String chatTitle="";
    private void renderChatHeader(String title){LinearLayout top=horizontal();top.setPadding(dp(14),dp(7),dp(14),dp(7));root.addView(top,lp(-1,62));
        TextView back=center("‹",29,FG,false);top.addView(back,lp(46,50));back.setOnClickListener(v->{main.removeCallbacks(poll);openProfile(api.uid());});
        TextView heading=text(title,21,FG,true);top.addView(heading,new LinearLayout.LayoutParams(0,-1,1));
        TextView more=center("⋮",25,FG,false);top.addView(more,lp(40,50));more.setOnClickListener(v->openProfile(dialogUser));}
    private void refreshChat(String other,boolean scrollBottom){
        int g=generation;
        work(()->{JSONArray list=api.messages(other);ui(()->{if(g!=generation||!"chat".equals(screen)||!dialogUser.equals(other))return;
            chatHolder.removeAllViews();for(int i=0;i<list.length();i++){
                JSONObject item=list.optJSONObject(i);if(item==null)continue;
                boolean self=item.optString("sender_id").equals(api.uid());
                LinearLayout line=horizontal();line.setGravity(self?Gravity.RIGHT:Gravity.LEFT);
                LinearLayout.LayoutParams lp=lp(-1,-2);lp.setMargins(dp(13),dp(7),dp(13),dp(3));chatHolder.addView(line,lp);
                TextView bubble=text(item.optString("body"),16,FG,false);bubble.setPadding(dp(14),dp(11),dp(14),dp(11));bubble.setBackground(bg(self?0xff086d9e:PANEL,17));
                bubble.setMaxWidth(dp(305));line.addView(bubble,lp(-2,-2));
            }
            if(scrollBottom)chatScroller.post(()->chatScroller.fullScroll(View.FOCUS_DOWN));
        });});
    }
}
