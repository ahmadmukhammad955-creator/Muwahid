begin;

-- Muwahid 0.13.22: audio-room parity improvements.
-- Room creator/owner is rendered separately and no longer consumes one of the 8 stage seats.
-- Adds synchronized room settings, free-mic mode, program list and shared YouTube link state.

create table if not exists public.mw_voice_room_settings (
  room_id uuid primary key references public.mw_voice_rooms(id) on delete cascade,
  free_mode boolean not null default false,
  theme text not null default 'violet' check(theme in ('violet','midnight','ocean','emerald','sunset','graphite')),
  newcomers_enabled boolean not null default true,
  youtube_url text,
  youtube_title text,
  youtube_position_seconds numeric(12,3) not null default 0 check(youtube_position_seconds >= 0),
  youtube_playing boolean not null default false,
  youtube_updated_at timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists public.mw_voice_room_programs (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.mw_voice_rooms(id) on delete cascade,
  title text not null check(char_length(btrim(title)) between 1 and 120),
  starts_at timestamptz,
  created_by uuid not null references public.mw_profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);
create index if not exists mw_voice_room_programs_room_idx
  on public.mw_voice_room_programs(room_id,starts_at nulls last,id);

alter table public.mw_voice_room_settings enable row level security;
alter table public.mw_voice_room_settings force row level security;
alter table public.mw_voice_room_programs enable row level security;
alter table public.mw_voice_room_programs force row level security;
revoke all on public.mw_voice_room_settings,public.mw_voice_room_programs from public,anon,authenticated;
revoke all on sequence public.mw_voice_room_programs_id_seq from public,anon,authenticated;

-- Existing active room creators become the separate host card and free their old stage seat.
update public.mw_voice_room_members m
   set seat=null,
       mic_allowed=true,
       mic_updated_at=now()
  from public.mw_voice_rooms r
 where r.id=m.room_id
   and r.created_by=m.user_id
   and r.active=true;

insert into public.mw_voice_room_settings(room_id)
select r.id from public.mw_voice_rooms r
where r.active=true
on conflict(room_id) do nothing;

create or replace function public.mw_room_create(p_title text)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare rid uuid;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if char_length(btrim(coalesce(p_title,''))) not between 1 and 80 then
    raise exception 'MW:Название комнаты должно содержать 1–80 символов';
  end if;
  insert into public.mw_voice_rooms(title,created_by)
    values(btrim(p_title),auth.uid()) returning id into rid;
  insert into public.mw_voice_room_members(room_id,user_id,seat,mic_allowed,mic_enabled,last_seen,mic_updated_at)
    values(rid,auth.uid(),null,true,false,now(),now());
  insert into public.mw_voice_room_settings(room_id) values(rid) on conflict do nothing;
  return jsonb_build_object('id',rid,'title',btrim(p_title));
end
$$;

create or replace function public.mw_room_join(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare s integer; room_title text; my_rank integer; allowed boolean;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  perform mw_private.room_cleanup(p_room);

  select title into room_title from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта или не существует'; end if;
  if exists(select 1 from public.mw_voice_room_bans where room_id=p_room and user_id=auth.uid()) then
    raise exception 'MW:Вы заблокированы в этой комнате';
  end if;

  update public.mw_voice_room_members set last_seen=now()
   where room_id=p_room and user_id=auth.uid();
  if found then
    delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
    return jsonb_build_object(
      'room_id',p_room,'title',room_title,
      'status',case
        when exists(select 1 from public.mw_voice_rooms r where r.id=p_room and r.created_by=auth.uid()) then 'host'
        when exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid() and seat is not null) then 'speaker'
        else 'listener' end
    );
  end if;

  my_rank:=mw_private.room_rank(auth.uid(),p_room);
  allowed:=my_rank>=30;

  -- The room host/owner stays separate. Moderators may occupy one of the 8 seats.
  if my_rank=20 then
    select g into s
      from generate_series(1,8) g
     where not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=g)
     order by g limit 1;
    allowed:=s is not null;
  end if;

  delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
  insert into public.mw_voice_room_members(room_id,user_id,seat,mic_allowed,mic_enabled,last_seen,mic_updated_at)
  values(p_room,auth.uid(),case when my_rank=20 then s else null end,allowed,false,now(),now())
  on conflict(room_id,user_id) do update
    set seat=excluded.seat,last_seen=now(),mic_allowed=excluded.mic_allowed,mic_enabled=false,mic_updated_at=now();

  insert into public.mw_voice_room_settings(room_id) values(p_room) on conflict do nothing;
  return jsonb_build_object(
    'room_id',p_room,'title',room_title,
    'status',case when my_rank>=30 then 'host' when s is not null then 'speaker' else 'listener' end,
    'seat',case when my_rank=20 then s else null end
  );
end
$$;

create or replace function public.mw_room_state(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  result jsonb; my_rank integer; can_mod boolean; room_title text; room_creator uuid; room_created_at timestamptz;
  wait_pos integer; waiting_count integer; seated boolean; queued boolean; visible_members jsonb; member_rows jsonb; room_settings jsonb;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;

  select title,created_by,created_at into room_title,room_creator,room_created_at
    from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта'; end if;

  insert into public.mw_voice_room_settings(room_id) values(p_room) on conflict do nothing;
  select jsonb_build_object(
    'free_mode',s.free_mode,'theme',s.theme,'newcomers_enabled',s.newcomers_enabled,
    'youtube_url',s.youtube_url,'youtube_title',s.youtube_title,
    'youtube_position_seconds',s.youtube_position_seconds,'youtube_playing',s.youtube_playing,
    'youtube_updated_at',s.youtube_updated_at,'updated_at',s.updated_at
  ) into room_settings from public.mw_voice_room_settings s where s.room_id=p_room;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',p.id,'display_name',p.display_name,'username',p.username,'seat',m.seat,
    'mic_allowed',m.mic_allowed,'mic_enabled',m.mic_enabled,'joined_at',m.joined_at,
    'is_host',(p.id=room_creator),
    'hand_raised',exists(select 1 from public.mw_voice_room_hands h where h.room_id=m.room_id and h.user_id=m.user_id),
    'role',case when mw_private.room_rank(p.id,p_room)=40 then 'owner' when mw_private.room_rank(p.id,p_room)=30 then 'host' when mw_private.room_rank(p.id,p_room)=20 then 'moderator' else 'user' end
  ) order by (p.id=room_creator) desc,m.seat nulls last,m.joined_at),'[]'::jsonb)
  into visible_members
  from public.mw_voice_room_members m join public.mw_profiles p on p.id=m.user_id
  where m.room_id=p_room;

  select exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) into seated;
  if seated then
    update public.mw_voice_room_members set last_seen=now()
      where room_id=p_room and user_id=auth.uid() and last_seen < now()-interval '10 seconds';
    if found then perform mw_private.room_cleanup(p_room); end if;
    member_rows:=visible_members;
  else
    select exists(select 1 from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid()) into queued;
    if not queued then raise exception 'MW:Вы больше не участник комнаты'; end if;
    update public.mw_voice_room_waiting set last_seen=now()
      where room_id=p_room and user_id=auth.uid() and last_seen < now()-interval '10 seconds';
    if found then perform mw_private.room_cleanup(p_room); end if;
    select 1+count(*) into wait_pos from public.mw_voice_room_waiting w where w.room_id=p_room and w.requested_at < (
      select requested_at from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid());
    select count(*) into waiting_count from public.mw_voice_room_waiting where room_id=p_room;
    return jsonb_build_object(
      'id',p_room,'title',room_title,'self_id',auth.uid(),'created_by',room_creator,'created_at',room_created_at,
      'waiting',true,'waiting_position',wait_pos,'waiting_count',waiting_count,'members','[]'::jsonb,
      'visible_members',visible_members,'participant_count',jsonb_array_length(visible_members),
      'can_moderate',false,'role','waiting','settings',room_settings
    );
  end if;

  my_rank:=mw_private.room_rank(auth.uid(),p_room); can_mod:=my_rank>=20;
  select count(*) into waiting_count from public.mw_voice_room_waiting where room_id=p_room;
  select jsonb_build_object(
    'id',p_room,'title',room_title,'self_id',auth.uid(),'created_by',room_creator,'created_at',room_created_at,
    'waiting',false,'waiting_count',waiting_count,
    'role',case when my_rank=40 then 'owner' when my_rank=30 then 'host' when my_rank=20 then 'moderator' else 'user' end,
    'can_moderate',can_mod,'can_assign_moderator',my_rank>=30,
    'members',member_rows,'visible_members',visible_members,'participant_count',jsonb_array_length(visible_members),
    'settings',room_settings,
    'waiting_users',case when can_mod then coalesce((
      select jsonb_agg(jsonb_build_object('id',p.id,'display_name',p.display_name,'username',p.username,'requested_at',w.requested_at) order by w.requested_at)
      from public.mw_voice_room_waiting w join public.mw_profiles p on p.id=w.user_id where w.room_id=p_room
    ),'[]'::jsonb) else '[]'::jsonb end
  ) into result;
  return result;
end
$$;

create or replace function public.mw_room_mic_moderate(p_room uuid,p_user uuid,p_allowed boolean)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare caller_rank integer; target_rank integer; new_seat integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  caller_rank:=mw_private.room_rank(auth.uid(),p_room); target_rank:=mw_private.room_rank(p_user,p_room);
  if caller_rank<20 then raise exception 'MW:Нет прав модератора'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_user) then raise exception 'MW:Участник уже вышел'; end if;
  if caller_rank<=target_rank and auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then raise exception 'MW:Нельзя управлять участником с равной или более высокой ролью'; end if;

  if p_allowed then
    if target_rank>=30 then
      update public.mw_voice_room_members set seat=null,mic_allowed=true,mic_enabled=false,mic_updated_at=now(),last_seen=now()
       where room_id=p_room and user_id=p_user;
    else
      select seat into new_seat from public.mw_voice_room_members where room_id=p_room and user_id=p_user;
      if new_seat is null then
        select g into new_seat from generate_series(1,8) g
         where not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=g)
         order by g limit 1;
        if new_seat is null then raise exception 'MW:Все 8 мест заняты'; end if;
      end if;
      update public.mw_voice_room_members set seat=new_seat,mic_allowed=true,mic_enabled=false,mic_updated_at=now(),last_seen=now()
       where room_id=p_room and user_id=p_user;
    end if;
    delete from public.mw_voice_room_hands where room_id=p_room and user_id=p_user;
  else
    update public.mw_voice_room_members set seat=null,mic_allowed=false,mic_enabled=false,mic_updated_at=now(),last_seen=now()
     where room_id=p_room and user_id=p_user;
  end if;
  return jsonb_build_object('user_id',p_user,'mic_allowed',p_allowed,'seat',case when p_allowed and target_rank<30 then new_seat else null end);
end
$$;

create or replace function public.mw_room_settings_get(p_room uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare s public.mw_voice_room_settings%rowtype;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.user_id=auth.uid()) then raise exception 'MW:Вы не участник комнаты'; end if;
  insert into public.mw_voice_room_settings(room_id) values(p_room) on conflict do nothing;
  select * into s from public.mw_voice_room_settings where room_id=p_room;
  return jsonb_build_object('free_mode',s.free_mode,'theme',s.theme,'newcomers_enabled',s.newcomers_enabled,
    'youtube_url',s.youtube_url,'youtube_title',s.youtube_title,'youtube_position_seconds',s.youtube_position_seconds,
    'youtube_playing',s.youtube_playing,'youtube_updated_at',s.youtube_updated_at,'updated_at',s.updated_at);
end $$;

create or replace function public.mw_room_settings_set(p_room uuid,p_free_mode boolean default null,p_theme text default null,p_newcomers_enabled boolean default null)
returns jsonb language plpgsql security definer set search_path='' as $$
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if mw_private.room_rank(auth.uid(),p_room)<20 then raise exception 'MW:Нет прав модератора'; end if;
  if p_theme is not null and p_theme not in ('violet','midnight','ocean','emerald','sunset','graphite') then raise exception 'MW:Неизвестная тема'; end if;
  insert into public.mw_voice_room_settings(room_id) values(p_room) on conflict do nothing;
  update public.mw_voice_room_settings
     set free_mode=coalesce(p_free_mode,free_mode),theme=coalesce(p_theme,theme),newcomers_enabled=coalesce(p_newcomers_enabled,newcomers_enabled),updated_at=now()
   where room_id=p_room;
  return public.mw_room_settings_get(p_room);
end $$;

create or replace function public.mw_room_claim_seat(p_room uuid,p_seat smallint)
returns jsonb language plpgsql security definer set search_path='' as $$
declare free_mode boolean; my_rank integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if p_seat not between 1 and 8 then raise exception 'MW:Место должно быть от 1 до 8'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) then raise exception 'MW:Вы не участник комнаты'; end if;
  my_rank:=mw_private.room_rank(auth.uid(),p_room);
  if my_rank>=30 then raise exception 'MW:Ведущий находится отдельно от 8 мест'; end if;
  insert into public.mw_voice_room_settings(room_id) values(p_room) on conflict do nothing;
  select s.free_mode into free_mode from public.mw_voice_room_settings s where s.room_id=p_room;
  if not coalesce(free_mode,false) and my_rank<20 then raise exception 'MW:Свободный режим выключен'; end if;
  if exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=p_seat and m.user_id<>auth.uid()) then raise exception 'MW:Это место уже занято'; end if;
  update public.mw_voice_room_members set seat=p_seat,mic_allowed=true,mic_enabled=false,mic_updated_at=now(),last_seen=now()
   where room_id=p_room and user_id=auth.uid();
  delete from public.mw_voice_room_hands where room_id=p_room and user_id=auth.uid();
  return jsonb_build_object('seat',p_seat,'mic_allowed',true);
end $$;

create or replace function public.mw_room_leave_seat(p_room uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare my_rank integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  my_rank:=mw_private.room_rank(auth.uid(),p_room);
  if my_rank>=30 then
    update public.mw_voice_room_members set seat=null,mic_enabled=false,last_seen=now(),mic_updated_at=now() where room_id=p_room and user_id=auth.uid();
    return jsonb_build_object('seat',null,'mic_allowed',true);
  end if;
  update public.mw_voice_room_members set seat=null,mic_allowed=false,mic_enabled=false,last_seen=now(),mic_updated_at=now() where room_id=p_room and user_id=auth.uid();
  return jsonb_build_object('seat',null,'mic_allowed',false);
end $$;

create or replace function public.mw_room_program_list(p_room uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) then raise exception 'MW:Вы не участник комнаты'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',x.id,'title',x.title,'starts_at',x.starts_at,'created_at',x.created_at) order by x.starts_at nulls last,x.id),'[]'::jsonb)
    into result from public.mw_voice_room_programs x where x.room_id=p_room;
  return result;
end $$;

create or replace function public.mw_room_program_add(p_room uuid,p_title text,p_starts_at timestamptz default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare row_id bigint;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if mw_private.room_rank(auth.uid(),p_room)<20 then raise exception 'MW:Нет прав модератора'; end if;
  if char_length(btrim(coalesce(p_title,''))) not between 1 and 120 then raise exception 'MW:Название программы должно содержать 1–120 символов'; end if;
  insert into public.mw_voice_room_programs(room_id,title,starts_at,created_by) values(p_room,btrim(p_title),p_starts_at,auth.uid()) returning id into row_id;
  return jsonb_build_object('id',row_id,'title',btrim(p_title),'starts_at',p_starts_at);
end $$;

create or replace function public.mw_room_program_delete(p_room uuid,p_program bigint)
returns jsonb language plpgsql security definer set search_path='' as $$
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if mw_private.room_rank(auth.uid(),p_room)<20 then raise exception 'MW:Нет прав модератора'; end if;
  delete from public.mw_voice_room_programs where room_id=p_room and id=p_program;
  return jsonb_build_object('deleted',found);
end $$;

create or replace function public.mw_room_youtube_set(p_room uuid,p_url text,p_title text default null,p_position_seconds numeric default 0,p_playing boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if mw_private.room_rank(auth.uid(),p_room)<20 then raise exception 'MW:Нет прав модератора'; end if;
  if p_url is not null and char_length(p_url)>500 then raise exception 'MW:Ссылка слишком длинная'; end if;
  insert into public.mw_voice_room_settings(room_id) values(p_room) on conflict do nothing;
  update public.mw_voice_room_settings
     set youtube_url=nullif(btrim(coalesce(p_url,'')),''),youtube_title=nullif(btrim(coalesce(p_title,'')),''),
         youtube_position_seconds=greatest(coalesce(p_position_seconds,0),0),youtube_playing=coalesce(p_playing,false),youtube_updated_at=now(),updated_at=now()
   where room_id=p_room;
  return public.mw_room_settings_get(p_room);
end $$;

revoke all on function public.mw_room_settings_get(uuid),public.mw_room_settings_set(uuid,boolean,text,boolean),
  public.mw_room_claim_seat(uuid,smallint),public.mw_room_leave_seat(uuid),public.mw_room_program_list(uuid),
  public.mw_room_program_add(uuid,text,timestamptz),public.mw_room_program_delete(uuid,bigint),
  public.mw_room_youtube_set(uuid,text,text,numeric,boolean) from public,anon;

grant execute on function public.mw_room_settings_get(uuid),public.mw_room_settings_set(uuid,boolean,text,boolean),
  public.mw_room_claim_seat(uuid,smallint),public.mw_room_leave_seat(uuid),public.mw_room_program_list(uuid),
  public.mw_room_program_add(uuid,text,timestamptz),public.mw_room_program_delete(uuid,bigint),
  public.mw_room_youtube_set(uuid,text,text,numeric,boolean) to authenticated;

commit;
