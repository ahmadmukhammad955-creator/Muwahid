package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.os.*;
import org.json.*;
import java.io.*;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

public final class UpdateManager {
    private static final String CHANNEL_ID="muwahid_updates";
    private static final int NOTIFICATION_ID=410001;
    private static final String PREFS="muwahid_update";
    private static final String MANIFEST_URL="https://raw.githubusercontent.com/ahmadmukhammad955-creator/Muwahid/main/updates/latest.json";
    private static final long CHECK_INTERVAL_MS=6L*60L*60L*1000L;
    private static final AtomicBoolean checking=new AtomicBoolean(false);

    private UpdateManager(){}

    public static void checkAndNotify(Context context, boolean force){
        Context app=context.getApplicationContext();
        android.content.SharedPreferences p=app.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        long now=System.currentTimeMillis();
        if(!force && now-p.getLong("last_check",0)<CHECK_INTERVAL_MS)return;
        if(!checking.compareAndSet(false,true))return;
        p.edit().putLong("last_check",now).apply();
        new Thread(()->{
            try{
                Release release=fetchRelease();
                if(release.versionCode>BuildConfig.VERSION_CODE){
                    p.edit().putInt("available_code",release.versionCode).putString("available_name",release.versionName).apply();
                    notifyUpdate(app,release);
                }else if(force){
                    Intent i=new Intent("com.muwahid.app.UPDATE_CHECK_RESULT").setPackage(app.getPackageName()).putExtra("up_to_date",true);
                    app.sendBroadcast(i);
                }
            }catch(Exception e){
                if(force){
                    Intent i=new Intent("com.muwahid.app.UPDATE_CHECK_RESULT").setPackage(app.getPackageName()).putExtra("error",true);
                    app.sendBroadcast(i);
                }
            }finally{checking.set(false);}
        },"muwahid-update-check").start();
    }

    private static Release fetchRelease() throws Exception{
        HttpsURLConnection c=(HttpsURLConnection)new URL(MANIFEST_URL).openConnection();
        c.setConnectTimeout(12000);c.setReadTimeout(12000);c.setRequestMethod("GET");c.setUseCaches(false);
        c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","Muwahid-Android/"+BuildConfig.VERSION_NAME);
        try{
            if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            try(InputStream in=c.getInputStream()){
                byte[] buf=new byte[8192];int n,total=0;
                while((n=in.read(buf))!=-1){total+=n;if(total>65536)throw new IOException("Update manifest too large");out.write(buf,0,n);}
            }
            JSONObject j=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
            Release r=new Release();
            r.versionCode=j.getInt("versionCode");
            r.versionName=j.optString("versionName",String.valueOf(r.versionCode));
            r.apkUrl=j.getString("apkUrl");
            r.sha256=j.optString("sha256","").toLowerCase(java.util.Locale.ROOT);
            r.notes=j.optString("notes","Исправления и улучшения Muwahid.");
            if(!r.apkUrl.startsWith("https://github.com/ahmadmukhammad955-creator/Muwahid/releases/download/"))throw new SecurityException("Bad update URL");
            if(!r.sha256.matches("[0-9a-f]{64}"))throw new SecurityException("Bad SHA-256");
            return r;
        }finally{c.disconnect();}
    }

    private static void notifyUpdate(Context context,Release r){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"Обновления Muwahid",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Новые версии Muwahid");
            context.getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        Intent open=new Intent(context,UpdateActivity.class)
                .putExtra("version_name",r.versionName)
                .putExtra("apk_url",r.apkUrl)
                .putExtra("sha256",r.sha256)
                .putExtra("notes",r.notes)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(context,NOTIFICATION_ID,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL_ID):new Notification.Builder(context);
        b.setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Доступно обновление Muwahid "+r.versionName)
                .setContentText("Нажмите, чтобы обновить приложение без удаления")
                .setStyle(new Notification.BigTextStyle().bigText(r.notes))
                .setAutoCancel(true).setContentIntent(pi).setCategory(Notification.CATEGORY_STATUS);
        if(Build.VERSION.SDK_INT<26)b.setPriority(Notification.PRIORITY_DEFAULT);
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,b.build());
    }

    private static final class Release{
        int versionCode;String versionName,apkUrl,sha256,notes;
    }
}
