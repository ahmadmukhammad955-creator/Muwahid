package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.*;
import android.media.*;
import android.net.Uri;
import android.util.Size;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.*;

public final class MuwahidCameraActivity extends Activity {
    private TextureView preview;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader imageReader;
    private MediaRecorder recorder;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraManager manager;
    private String cameraId;
    private Size previewSize=new Size(1280,720), videoSize=new Size(1280,720);
    private boolean front=false, flashOn=false, videoMode=false, recording=false;
    private TextView photoMode, videoModeLabel, capture, flash, flip;
    private File pendingPhoto, pendingVideo;

    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);return t;}
    private GradientDrawable circle(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setShape(GradientDrawable.OVAL);return d;}

    @Override public void onCreate(Bundle b){
        super.onCreate(b);getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        videoMode="video".equals(getIntent().getStringExtra("mode"));
        manager=(CameraManager)getSystemService(CAMERA_SERVICE);buildUi();
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO},7301);}else startCameraThread();
    }

    private void buildUi(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);
        preview=new TextureView(this);root.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(12),dp(8),dp(12),dp(8));top.setBackgroundColor(Color.argb(120,0,0,0));
        TextView close=text("×",36,Color.WHITE);close.setContentDescription("Закрыть камеру");top.addView(close,new LinearLayout.LayoutParams(dp(48),dp(48)));close.setOnClickListener(v->{if(recording)stopVideo(false);finish();});
        Space spacer=new Space(this);top.addView(spacer,new LinearLayout.LayoutParams(0,1,1));
        flash=text("⚡",24,Color.WHITE);flash.setContentDescription("Вспышка");top.addView(flash,new LinearLayout.LayoutParams(dp(48),dp(48)));flash.setOnClickListener(v->{flashOn=!flashOn;flash.setTextColor(flashOn?Color.YELLOW:Color.WHITE);restartPreview();});
        flip=text("↻",28,Color.WHITE);flip.setContentDescription("Переключить камеру");top.addView(flip,new LinearLayout.LayoutParams(dp(48),dp(48)));flip.setOnClickListener(v->{if(recording)return;front=!front;reopenCamera();});
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,dp(64),Gravity.TOP);root.addView(top,tp);

        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);bottom.setGravity(Gravity.CENTER);bottom.setPadding(dp(14),dp(8),dp(14),dp(22));bottom.setBackgroundColor(Color.argb(150,0,0,0));
        LinearLayout modes=new LinearLayout(this);modes.setGravity(Gravity.CENTER);videoModeLabel=text("Видео",16,Color.WHITE);photoMode=text("Фото",16,Color.WHITE);modes.addView(videoModeLabel,new LinearLayout.LayoutParams(dp(92),dp(38)));modes.addView(photoMode,new LinearLayout.LayoutParams(dp(92),dp(38)));bottom.addView(modes);
        LinearLayout actionRow=new LinearLayout(this);actionRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView thumb=text("▧",24,Color.WHITE);thumb.setBackground(circle(Color.rgb(26,43,58)));actionRow.addView(thumb,new LinearLayout.LayoutParams(dp(50),dp(50)));
        Space s1=new Space(this);actionRow.addView(s1,new LinearLayout.LayoutParams(0,1,1));
        capture=text("",24,Color.WHITE);capture.setContentDescription("Снять");capture.setBackground(circle(Color.WHITE));actionRow.addView(capture,new LinearLayout.LayoutParams(dp(76),dp(76)));capture.setOnClickListener(v->{if(videoMode){if(recording)stopVideo(true);else startVideo();}else capturePhoto();});
        Space s2=new Space(this);actionRow.addView(s2,new LinearLayout.LayoutParams(0,1,1));
        TextView rotate=text("↻",27,Color.WHITE);rotate.setBackground(circle(Color.rgb(26,43,58)));actionRow.addView(rotate,new LinearLayout.LayoutParams(dp(50),dp(50)));rotate.setOnClickListener(v->{if(!recording){front=!front;reopenCamera();}});
        LinearLayout.LayoutParams arp=new LinearLayout.LayoutParams(-1,dp(94));arp.topMargin=dp(4);bottom.addView(actionRow,arp);
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,dp(158),Gravity.BOTTOM);root.addView(bottom,bp);
        videoModeLabel.setOnClickListener(v->{if(!recording){videoMode=true;updateModeUi();}});photoMode.setOnClickListener(v->{if(!recording){videoMode=false;updateModeUi();}});updateModeUi();setContentView(root);
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){if(cameraHandler!=null)openCamera();}public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){}public boolean onSurfaceTextureDestroyed(SurfaceTexture s){return true;}public void onSurfaceTextureUpdated(SurfaceTexture s){}});
    }
    private void updateModeUi(){photoMode.setTextColor(videoMode?Color.LTGRAY:Color.WHITE);videoModeLabel.setTextColor(videoMode?Color.WHITE:Color.LTGRAY);photoMode.setTypeface(null,videoMode?0:1);videoModeLabel.setTypeface(null,videoMode?1:0);capture.setBackground(circle(videoMode?Color.rgb(239,65,77):Color.WHITE));}

    private void startCameraThread(){cameraThread=new HandlerThread("MuwahidCamera");cameraThread.start();cameraHandler=new Handler(cameraThread.getLooper());if(preview.isAvailable())openCamera();}
    private String selectCameraId() throws CameraAccessException{
        String fallback=null;for(String id:manager.getCameraIdList()){CameraCharacteristics c=manager.getCameraCharacteristics(id);Integer f=c.get(CameraCharacteristics.LENS_FACING);if(fallback==null)fallback=id;if(front&&f!=null&&f==CameraCharacteristics.LENS_FACING_FRONT)return id;if(!front&&f!=null&&f==CameraCharacteristics.LENS_FACING_BACK)return id;}return fallback;
    }
    private Size choose(Size[] sizes){if(sizes==null||sizes.length==0)return new Size(1280,720);Size best=sizes[0];long bestScore=Long.MAX_VALUE;for(Size s:sizes){if(s.getWidth()>1920||s.getHeight()>1080)continue;long score=Math.abs((long)s.getWidth()*9-(long)s.getHeight()*16)+Math.abs(s.getWidth()-1280);if(score<bestScore){bestScore=score;best=s;}}return best;}
    @SuppressWarnings("MissingPermission") private void openCamera(){
        if(isFinishing()||camera!=null||manager==null||checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        try{cameraId=selectCameraId();if(cameraId==null)return;CameraCharacteristics cc=manager.getCameraCharacteristics(cameraId);android.hardware.camera2.params.StreamConfigurationMap map=cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);if(map!=null){previewSize=choose(map.getOutputSizes(SurfaceTexture.class));videoSize=choose(map.getOutputSizes(MediaRecorder.class));Size jpg=choose(map.getOutputSizes(android.graphics.ImageFormat.JPEG));if(imageReader!=null)imageReader.close();imageReader=ImageReader.newInstance(jpg.getWidth(),jpg.getHeight(),android.graphics.ImageFormat.JPEG,2);imageReader.setOnImageAvailableListener(this::savePhoto,cameraHandler);}manager.openCamera(cameraId,new CameraDevice.StateCallback(){public void onOpened(CameraDevice c){camera=c;createPreviewSession();}public void onDisconnected(CameraDevice c){c.close();camera=null;}public void onError(CameraDevice c,int e){c.close();camera=null;runOnUiThread(()->Toast.makeText(MuwahidCameraActivity.this,"Камера недоступна",Toast.LENGTH_SHORT).show());}},cameraHandler);}catch(Exception e){Toast.makeText(this,"Не удалось открыть камеру",Toast.LENGTH_SHORT).show();}
    }
    private void createPreviewSession(){
        if(camera==null||!preview.isAvailable())return;try{SurfaceTexture st=preview.getSurfaceTexture();st.setDefaultBufferSize(previewSize.getWidth(),previewSize.getHeight());Surface surface=new Surface(st);CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(surface);b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);if(flashOn)b.set(CaptureRequest.FLASH_MODE,CaptureRequest.FLASH_MODE_TORCH);List<Surface> surfaces=new ArrayList<>();surfaces.add(surface);if(imageReader!=null)surfaces.add(imageReader.getSurface());camera.createCaptureSession(surfaces,new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession s){if(camera==null)return;session=s;try{session.setRepeatingRequest(b.build(),null,cameraHandler);}catch(Exception ignored){}}public void onConfigureFailed(CameraCaptureSession s){}},cameraHandler);}catch(Exception e){Toast.makeText(this,"Не удалось запустить предпросмотр",Toast.LENGTH_SHORT).show();}
    }
    private void restartPreview(){if(!recording){closeSession();createPreviewSession();}}
    private void reopenCamera(){closeCamera();cameraHandler.postDelayed(this::openCamera,180);}
    private void capturePhoto(){
        if(camera==null||session==null||imageReader==null)return;try{File dir=new File(getCacheDir(),"media");dir.mkdirs();pendingPhoto=new File(dir,"camera_"+UUID.randomUUID()+".jpg");CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);b.addTarget(imageReader.getSurface());b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);if(flashOn)b.set(CaptureRequest.FLASH_MODE,CaptureRequest.FLASH_MODE_SINGLE);session.capture(b.build(),null,cameraHandler);}catch(Exception e){Toast.makeText(this,"Не удалось сделать фото",Toast.LENGTH_SHORT).show();}
    }
    private void savePhoto(ImageReader r){Image image=null;try{image=r.acquireNextImage();if(image==null||pendingPhoto==null)return;ByteBuffer buf=image.getPlanes()[0].getBuffer();byte[] data=new byte[buf.remaining()];buf.get(data);File f=pendingPhoto;pendingPhoto=null;try(FileOutputStream out=new FileOutputStream(f)){out.write(data);}runOnUiThread(()->returnFile(f,"image"));}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Не удалось сохранить фото",Toast.LENGTH_SHORT).show());}finally{if(image!=null)image.close();}}

    private void startVideo(){
        if(camera==null||recording)return;if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},7302);return;}
        try{closeSession();File dir=new File(getCacheDir(),"media");dir.mkdirs();pendingVideo=new File(dir,"camera_"+UUID.randomUUID()+".mp4");recorder=new MediaRecorder();recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setOutputFile(pendingVideo.getAbsolutePath());recorder.setVideoEncodingBitRate(4_000_000);recorder.setVideoFrameRate(30);recorder.setVideoSize(videoSize.getWidth(),videoSize.getHeight());recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setOrientationHint(90);recorder.prepare();SurfaceTexture st=preview.getSurfaceTexture();st.setDefaultBufferSize(videoSize.getWidth(),videoSize.getHeight());Surface ps=new Surface(st);Surface rs=recorder.getSurface();CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);b.addTarget(ps);b.addTarget(rs);b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);camera.createCaptureSession(Arrays.asList(ps,rs),new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession s){session=s;try{session.setRepeatingRequest(b.build(),null,cameraHandler);runOnUiThread(()->{recorder.start();recording=true;capture.setText("■");capture.setTextColor(Color.WHITE);});}catch(Exception e){runOnUiThread(()->Toast.makeText(MuwahidCameraActivity.this,"Не удалось начать видео",Toast.LENGTH_SHORT).show());}}public void onConfigureFailed(CameraCaptureSession s){}},cameraHandler);}catch(Exception e){cleanupRecorder();Toast.makeText(this,"Не удалось запустить видеокамеру",Toast.LENGTH_SHORT).show();}
    }
    private void stopVideo(boolean deliver){if(!recording){return;}recording=false;File f=pendingVideo;pendingVideo=null;try{recorder.stop();}catch(Exception e){if(f!=null)f.delete();f=null;}cleanupRecorder();capture.setText("");updateModeUi();if(deliver&&f!=null&&f.exists()&&f.length()>0)returnFile(f,"video");else restartPreview();}
    private void cleanupRecorder(){if(recorder!=null){try{recorder.reset();}catch(Exception ignored){}try{recorder.release();}catch(Exception ignored){}recorder=null;}}
    private void returnFile(File f,String type){try{Uri uri=FileProvider.getUriForFile(this,getPackageName()+".files",f);Intent data=new Intent();data.setData(uri);data.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);data.putExtra("media_type",type);setResult(RESULT_OK,data);finish();}catch(Exception e){Toast.makeText(this,"Не удалось подготовить файл",Toast.LENGTH_SHORT).show();}}
    private void closeSession(){if(session!=null){try{session.close();}catch(Exception ignored){}session=null;}}
    private void closeCamera(){closeSession();if(camera!=null){try{camera.close();}catch(Exception ignored){}camera=null;}if(imageReader!=null){try{imageReader.close();}catch(Exception ignored){}imageReader=null;}cleanupRecorder();}
    @Override protected void onDestroy(){if(recording)stopVideo(false);closeCamera();if(cameraThread!=null){cameraThread.quitSafely();try{cameraThread.join(500);}catch(Exception ignored){}cameraThread=null;}super.onDestroy();}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);boolean ok=true;for(int g:grantResults)ok&=g==PackageManager.PERMISSION_GRANTED;if(requestCode==7301){if(ok)startCameraThread();else finish();}else if(requestCode==7302){if(ok)startVideo();else Toast.makeText(this,"Для видео нужен микрофон",Toast.LENGTH_SHORT).show();}}
}
