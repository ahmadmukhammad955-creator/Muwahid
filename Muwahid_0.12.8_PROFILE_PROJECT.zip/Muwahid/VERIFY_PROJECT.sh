#!/usr/bin/env bash
set -euo pipefail
grep -Fq "versionCode 32" app/build.gradle
grep -Fq "versionName '0.12.8'" app/build.gradle
grep -Fq 'debuggable false' app/build.gradle
grep -Fq 'minifyEnabled true' app/build.gradle
grep -Fq 'shrinkResources true' app/build.gradle
grep -Fq 'assembleRelease' .github/workflows/build-apk.yml
grep -Fq 'outputs/apk/release/app-release.apk' .github/workflows/build-apk.yml
grep -Fq 'android:name=".VoiceRoomActivity"' app/src/main/AndroidManifest.xml
grep -Fq 'private void showVoiceRooms()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void showAdminManagement()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'WebView.setWebContentsDebuggingEnabled(false)' app/src/main/java/com/muwahid/app/CallActivity.java
grep -Fq 'shouldOverrideUrlLoading' app/src/main/java/com/muwahid/app/CallActivity.java
grep -Fq 'WebView.setWebContentsDebuggingEnabled(false)' app/src/main/java/com/muwahid/app/VoiceRoomActivity.java
grep -Fq 'shouldOverrideUrlLoading' app/src/main/java/com/muwahid/app/VoiceRoomActivity.java
grep -Fq 'mw_room_raise_hand' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_kick' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_mic_set_self' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_mic_moderate' app/src/main/assets/voice_room.html
grep -Fq 'create or replace function public.mw_owner_admin_set' backend/012_voice_rooms_admins.sql
grep -Fq 'create or replace function public.mw_room_signal_poll' backend/015_voice_room_performance.sql
test -f backend/016_shared_reading.sql
test -f backend/017_room_close.sql
test -f backend/018_security_hardening.sql
test -f backend/019_phone_country_auth.sql
test -f backend/020_remote_config.sql
test -f app/src/main/java/com/muwahid/app/RemoteConfig.java
grep -Fq 'mw_app_config' app/src/main/java/com/muwahid/app/MainActivity.java
! grep -RIEq 'service[_-]?role|ghp_[A-Za-z0-9]{20,}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----' app backend .github --exclude='*.png'
echo 'MW_SOURCE_OK 0.12.8 SERVER_DRIVEN'
