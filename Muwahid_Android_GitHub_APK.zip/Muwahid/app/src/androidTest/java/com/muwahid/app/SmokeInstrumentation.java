package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.graphics.Bitmap;
import java.io.*;

public class SmokeInstrumentation extends Instrumentation {
    private Activity activity;
    @Override public void onCreate(Bundle args){super.onCreate(args);start();}
    private View find(View view,String text){
        if(view instanceof TextView && ((TextView)view).getText().toString().equals(text))return view;
        if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++){View result=find(group.getChildAt(i),text);if(result!=null)return result;}}
        return null;
    }
    private void tap(String text){runOnMainSync(()->{View v=find(activity.getWindow().getDecorView(),text);if(v==null)throw new AssertionError("Missing "+text);v.performClick();});waitForIdleSync();}
    private void capture(String name)throws Exception{waitForIdleSync();Bitmap b=getUiAutomation().takeScreenshot();if(b==null)throw new Exception("No screenshot");File f=new File(getTargetContext().getExternalFilesDir(null),name);try(FileOutputStream out=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.PNG,100,out);}}
    private Activity launch(){Intent i=new Intent(getTargetContext(),MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);return startActivitySync(i);}
    @Override public void onStart(){Bundle result=new Bundle();try{
        getTargetContext().getSharedPreferences("muwahid",0).edit().clear().commit();
        activity=launch();capture("welcome.png");tap("Открыть личные заметки");
        runOnMainSync(()->{ViewGroup root=(ViewGroup)activity.findViewById(android.R.id.content);setComposer(root,"Проверка сохранения Muwahid");});tap("↑");capture("notes.png");
        runOnMainSync(()->activity.finish());waitForIdleSync();activity=launch();tap("Открыть личные заметки");
        runOnMainSync(()->{String notes=getTargetContext().getSharedPreferences("muwahid",0).getString("notes","");if(!notes.contains("Проверка сохранения Muwahid"))throw new AssertionError("Note not persisted");activity.onBackPressed();});waitForIdleSync();
        tap("☰\nПрофиль");capture("profile.png");tap("Тёмная тема");capture("light-profile.png");
        runOnMainSync(()->{if(getTargetContext().getSharedPreferences("muwahid",0).getBoolean("dark",true))throw new AssertionError("Theme not persisted");});
        result.putString("stream","MW_SMOKE_OK: note persistence, Back navigation, profile, theme");finish(Activity.RESULT_OK,result);
    }catch(Throwable e){result.putString("stream","MW_SMOKE_FAILED: "+e.toString());finish(Activity.RESULT_CANCELED,result);}}
    private void setComposer(View view,String value){if(view instanceof EditText && "Сообщение".contentEquals(((EditText)view).getHint())){((EditText)view).setText(value);return;}if(view instanceof ViewGroup){ViewGroup g=(ViewGroup)view;for(int i=0;i<g.getChildCount();i++)setComposer(g.getChildAt(i),value);}}
}
