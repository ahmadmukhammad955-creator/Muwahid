package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.Geocoder;
import android.location.Address;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public final class LocationShareActivity extends Activity {
    private double lat,lon;
    private TextView address,coords;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.parseColor("#071827"));getWindow().setNavigationBarColor(Color.parseColor("#071827"));lat=getIntent().getDoubleExtra("lat",0);lon=getIntent().getDoubleExtra("lon",0);build();resolveAddress();}
    @SuppressWarnings("SetJavaScriptEnabled") private void build(){
        final int bg=Color.parseColor("#071827"), cyan=Color.parseColor("#18C7D7"), muted=Color.parseColor("#8EA3B7");
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(7),dp(5),dp(7),dp(4));
        ImageButton back=new ImageButton(this);back.setImageDrawable(new UiIconDrawable("back",Color.WHITE));back.setBackgroundColor(Color.TRANSPARENT);back.setScaleType(ImageView.ScaleType.FIT_CENTER);back.setPadding(dp(10),dp(10),dp(10),dp(10));back.setContentDescription("Назад");bar.addView(back,new LinearLayout.LayoutParams(dp(44),dp(50)));back.setOnClickListener(v->finish());
        TextView title=text("Местоположение",17,Color.WHITE);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);bar.addView(title,new LinearLayout.LayoutParams(0,dp(50),1));bar.addView(new Space(this),new LinearLayout.LayoutParams(dp(44),dp(50)));root.addView(bar,new LinearLayout.LayoutParams(-1,dp(60)));
        EditText search=new EditText(this);search.setHint("Поиск места...");search.setHintTextColor(Color.parseColor("#8398AD"));search.setTextColor(Color.WHITE);search.setSingleLine(true);search.setEnabled(false);search.setTextSize(14);search.setPadding(dp(13),0,dp(13),0);search.setBackground(shape(Color.parseColor("#102337"),18));UiIconDrawable sd=new UiIconDrawable("search",Color.parseColor("#8398AD"));sd.setBounds(0,0,dp(18),dp(18));search.setCompoundDrawables(sd,null,null,null);search.setCompoundDrawablePadding(dp(7));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(42));sp.setMargins(dp(14),0,dp(14),dp(8));root.addView(search,sp);
        WebView map=new WebView(this);map.setBackgroundColor(Color.parseColor("#DDE7DD"));map.getSettings().setJavaScriptEnabled(false);double d=.006;String url="https://www.openstreetmap.org/export/embed.html?bbox="+(lon-d)+"%2C"+(lat-d)+"%2C"+(lon+d)+"%2C"+(lat+d)+"&layer=mapnik&marker="+lat+"%2C"+lon;map.loadUrl(url);root.addView(map,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(11),dp(12),dp(12));card.setBackground(shape(Color.parseColor("#102337"),20));
        LinearLayout summary=new LinearLayout(this);summary.setGravity(Gravity.CENTER_VERTICAL);MiniMapView mini=new MiniMapView(this);mini.setBackground(shape(Color.parseColor("#DDE7DD"),9));summary.addView(mini,new LinearLayout.LayoutParams(dp(62),dp(50)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(10),0,0,0);address=text("Определяем адрес…",15,Color.WHITE);address.setTypeface(null,1);address.setMaxLines(1);address.setEllipsize(android.text.TextUtils.TruncateAt.END);words.addView(address);coords=text(String.format(Locale.US,"%.5f, %.5f",lat,lon),12,muted);coords.setPadding(0,dp(3),0,0);words.addView(coords);summary.addView(words,new LinearLayout.LayoutParams(0,dp(52),1));card.addView(summary,new LinearLayout.LayoutParams(-1,dp(58)));
        Button send=new Button(this);send.setText("Отправить это место");send.setTextSize(15);send.setTextColor(Color.WHITE);send.setAllCaps(false);send.setBackground(shape(Color.parseColor("#168BFF"),17));LinearLayout.LayoutParams sb=new LinearLayout.LayoutParams(-1,dp(50));sb.topMargin=dp(9);card.addView(send,sb);send.setOnClickListener(v->{Intent out=new Intent();out.putExtra("lat",lat);out.putExtra("lon",lon);out.putExtra("address",address.getText().toString());setResult(RESULT_OK,out);finish();});
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(dp(10),dp(8),dp(10),dp(10));root.addView(card,cp);setContentView(root);
    }
    private void resolveAddress(){worker.execute(()->{String result="Выбранная точка";try{Geocoder g=new Geocoder(this,Locale.getDefault());List<Address> list=g.getFromLocation(lat,lon,1);if(list!=null&&!list.isEmpty()){Address a=list.get(0);String line=a.getAddressLine(0);if(line!=null&&!line.trim().isEmpty())result=line;}}catch(Exception ignored){}final String value=result;runOnUiThread(()->address.setText(value));});}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
