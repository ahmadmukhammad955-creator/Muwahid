-- Resolve a shared profile ID using the same authentication requirement as people search.
create or replace function mw_private.find_person_by_qr(p_person uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
    actor uuid := auth.uid();
    result jsonb;
begin
    perform mw_private.require_mfa();

    select jsonb_build_object('id', p.id, 'display_name', p.display_name, 'username', p.username)
      into result
      from public.mw_profiles p
     where p.id = p_person
       and p.id <> actor
       and not exists (
           select 1 from public.mw_blocks b
            where (b.user_id = actor and b.person_id = p.id)
               or (b.user_id = p.id and b.person_id = actor)
       );
    return result;
end;
$$;

create or replace function public.mw_find_person_by_qr(p_person uuid)
returns jsonb
language sql
stable
security invoker
set search_path = ''
as $$
    select mw_private.find_person_by_qr(p_person);
$$;

revoke all on function mw_private.find_person_by_qr(uuid), public.mw_find_person_by_qr(uuid)
    from public, anon, authenticated;
grant execute on function mw_private.find_person_by_qr(uuid), public.mw_find_person_by_qr(uuid)
    to authenticated;

notify pgrst, 'reload schema';
