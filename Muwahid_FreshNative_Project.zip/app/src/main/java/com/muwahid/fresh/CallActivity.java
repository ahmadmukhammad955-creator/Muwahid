package com.muwahid.fresh;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import org.webrtc.*;
import java.util.*;
import java.util.concurrent.*;

/** Native peer-to-peer voice/video call. REST is used only for authenticated signaling.
 *  Audio and video travel over WebRTC SRTP, not through the application database.
 *  TURN relay needed for full mobile-network reliability; this build uses STUN.
 */
public final class CallActivity extends Activity {
    private static final int BG=0xff09131e,WHITE=0xffeef7ff,BLUE=0xff066b98;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService transport=Executors.newSingleThreadExecutor();
    private final ArrayDeque<IceCandidate> waitingIce=new ArrayDeque<>();
    private Backend api;
    private String callId,kind;
    private boolean caller,closed=false,remoteReady=false,offered=false,answered=false,checking=false,muted=false,camOff=false;
    private long iceId=0;
    private TextView status,muteButton,cameraButton;
    private EglBase egl;
    private SurfaceViewRenderer remoteView,localView;
    private PeerConnectionFactory factory;
    private PeerConnection pc;
    private AudioSource audioSource;
    private AudioTrack audioTrack;
    private VideoSource videoSource;
    private VideoTrack videoTrack;
    private VideoCapturer capturer;
    private SurfaceTextureHelper helper;
    private AudioManager audioManager;
    private boolean audioSpeakerBefore=false;
    private final Runnable polling=new Runnable(){@Override public void run(){if(closed)return;
        if(!checking){checking=true;transport.execute(()->{
            try{sync();}catch(Exception ex){message("Ожидаем связь с сервером: "+ex.getMessage());}
            finally{checking=false;}
        });}
        ui.postDelayed(this,1700);
    }};

    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        callId=getIntent().getStringExtra("call_id");kind=getIntent().getStringExtra("kind");caller=getIntent().getBooleanExtra("caller",false);
        if(callId==null||callId.isEmpty()||(!"video".equals(kind)&&!"audio".equals(kind))){finish();return;}
        api=new Backend(this);if(!api.signedIn()){finish();return;}
        draw();
        String[] perms="video".equals(kind)?new String[]{Manifest.permission.RECORD_AUDIO,Manifest.permission.CAMERA}:new String[]{Manifest.permission.RECORD_AUDIO};
        boolean missing=false;for(String p:perms)if(checkSelfPermission(p)!=PackageManager.PERMISSION_GRANTED)missing=true;
        if(missing)requestPermissions(perms,711);else initializeRtc();
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(22));return d;}
    private TextView button(String label,int color){TextView t=new TextView(this);t.setText(label);t.setGravity(Gravity.CENTER);t.setTextColor(WHITE);t.setTextSize(16);t.setBackground(shape(color));return t;}
    private void draw(){
        FrameLayout page=new FrameLayout(this);page.setBackgroundColor(BG);setContentView(page);
        if("video".equals(kind)){
            egl=EglBase.create();
            remoteView=new SurfaceViewRenderer(this);remoteView.init(egl.getEglBaseContext(),null);remoteView.setEnableHardwareScaler(true);page.addView(remoteView,new FrameLayout.LayoutParams(-1,-1));
            localView=new SurfaceViewRenderer(this);localView.init(egl.getEglBaseContext(),null);localView.setZOrderMediaOverlay(true);localView.setMirror(true);
            FrameLayout.LayoutParams local=new FrameLayout.LayoutParams(dp(125),dp(185),Gravity.RIGHT|Gravity.TOP);local.setMargins(0,dp(40),dp(16),0);page.addView(localView,local);
        }
        LinearLayout overlay=new LinearLayout(this);overlay.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);op.setMargins(dp(19),dp(22),dp(19),0);page.addView(overlay,op);
        TextView title=new TextView(this);title.setText("MUWAHID · "+("video".equals(kind)?"Видеозвонок":"Голосовой звонок"));title.setTextSize(23);title.setTypeface(null,1);title.setTextColor(WHITE);overlay.addView(title);
        status=new TextView(this);status.setText(caller?"Вызываем собеседника…":"Подключаемся к вызову…");status.setTextSize(14);status.setTextColor(0xffa4bed1);status.setPadding(0,dp(9),0,0);overlay.addView(status);
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);controls.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,dp(76),Gravity.BOTTOM);cp.setMargins(dp(12),0,dp(12),dp(25));page.addView(controls,cp);
        muteButton=button("🎙 Микрофон",0xff20354c);controls.addView(muteButton,new LinearLayout.LayoutParams(0,-1,1));
        muteButton.setOnClickListener(v->{muted=!muted;if(audioTrack!=null)audioTrack.setEnabled(!muted);muteButton.setText(muted?"🔇 Выключен":"🎙 Микрофон");});
        if("video".equals(kind)){
            cameraButton=button("📷 Камера",0xff20354c);
            LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(0,-1,1);vp.leftMargin=dp(7);controls.addView(cameraButton,vp);
            cameraButton.setOnClickListener(v->{camOff=!camOff;if(videoTrack!=null)videoTrack.setEnabled(!camOff);cameraButton.setText(camOff?"Камера выкл.":"📷 Камера");});
        }
        TextView end=button("✕ Завершить",0xffa12f47);
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,-1,1);ep.leftMargin=dp(7);controls.addView(end,ep);
        end.setOnClickListener(v->endCall(true));
    }
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] grants){super.onRequestPermissionsResult(code,perms,grants);
        if(code!=711)return;
        for(int grant:grants)if(grant!=PackageManager.PERMISSION_GRANTED){new AlertDialog.Builder(this).setMessage("Для настоящего звонка необходим доступ к микрофону и, для видео, камере.")
            .setPositiveButton("Закрыть",(d,w)->endCall(true)).setCancelable(false).show();return;}
        initializeRtc();
    }
    private void initializeRtc(){try{
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions());
        PeerConnectionFactory.Options options=new PeerConnectionFactory.Options();
        DefaultVideoEncoderFactory encoder=new DefaultVideoEncoderFactory(egl!=null?egl.getEglBaseContext():EglBase.create().getEglBaseContext(),true,true);
        DefaultVideoDecoderFactory decoder=new DefaultVideoDecoderFactory(egl!=null?egl.getEglBaseContext():EglBase.create().getEglBaseContext());
        factory=PeerConnectionFactory.builder().setOptions(options).setVideoEncoderFactory(encoder).setVideoDecoderFactory(decoder).createPeerConnectionFactory();
        ArrayList<PeerConnection.IceServer> servers=new ArrayList<>();
        servers.add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer());
        servers.add(PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer());
        PeerConnection.RTCConfiguration config=new PeerConnection.RTCConfiguration(servers);
        config.sdpSemantics=PeerConnection.SdpSemantics.UNIFIED_PLAN;
        pc=factory.createPeerConnection(config,new PeerConnection.Observer(){
            @Override public void onSignalingChange(PeerConnection.SignalingState state){}
            @Override public void onIceConnectionChange(PeerConnection.IceConnectionState state){message("Соединение: "+state.name());}
            @Override public void onIceConnectionReceivingChange(boolean receiving){}
            @Override public void onIceGatheringChange(PeerConnection.IceGatheringState state){}
            @Override public void onIceCandidate(IceCandidate candidate){if(closed)return;transport.execute(()->{
                try{api.sendIce(callId,candidate.sdpMid,candidate.sdpMLineIndex,candidate.sdp);}catch(Exception ex){message("Ошибка отправки ICE: "+ex.getMessage());}
            });}
            @Override public void onIceCandidatesRemoved(IceCandidate[] candidates){}
            @Override public void onAddStream(MediaStream stream){if(!stream.videoTracks.isEmpty())showRemoteVideo(stream.videoTracks.get(0));}
            @Override public void onRemoveStream(MediaStream stream){}
            @Override public void onDataChannel(DataChannel channel){}
            @Override public void onRenegotiationNeeded(){}
            @Override public void onTrack(RtpTransceiver transceiver){MediaStreamTrack track=transceiver.getReceiver().track();if(track instanceof VideoTrack)showRemoteVideo((VideoTrack)track);}
            @Override public void onConnectionChange(PeerConnection.PeerConnectionState state){if(state==PeerConnection.PeerConnectionState.CONNECTED)message("Связь установлена");else if(state==PeerConnection.PeerConnectionState.FAILED)message("Не удалось установить соединение. Возможно, нужен TURN-сервер.");}
        });
        if(pc==null)throw new IllegalStateException("Устройство не поддерживает WebRTC");
        audioSource=factory.createAudioSource(new MediaConstraints());audioTrack=factory.createAudioTrack("muwahid-audio",audioSource);audioTrack.setEnabled(true);
        pc.addTrack(audioTrack,Collections.singletonList("muwahid"));
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);if(audioManager!=null){audioSpeakerBefore=audioManager.isSpeakerphoneOn();audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);audioManager.setSpeakerphoneOn("video".equals(kind));}
        if("video".equals(kind))startVideo();
        if(caller)makeOffer();
        ui.post(polling);
    }catch(Exception e){message("Ошибка подключения: "+e.getMessage());new AlertDialog.Builder(this).setMessage("Не удалось начать звонок: "+e.getMessage()).setPositiveButton("Закрыть",(d,w)->endCall(true)).show();}}
    private void startVideo(){
        CameraEnumerator cams=new Camera2Enumerator(this);if(cams.getDeviceNames().length==0)cams=new Camera1Enumerator(true);
        String chosen=null;for(String name:cams.getDeviceNames())if(cams.isFrontFacing(name)){chosen=name;break;}
        if(chosen==null&&cams.getDeviceNames().length>0)chosen=cams.getDeviceNames()[0];
        if(chosen==null)throw new IllegalStateException("Камера не обнаружена");
        capturer=cams.createCapturer(chosen,null);if(capturer==null)throw new IllegalStateException("Не удалось включить камеру");
        helper=SurfaceTextureHelper.create("MuwahidCapture",egl.getEglBaseContext());
        videoSource=factory.createVideoSource(false);capturer.initialize(helper,this,videoSource.getCapturerObserver());capturer.startCapture(640,480,24);
        videoTrack=factory.createVideoTrack("muwahid-video",videoSource);videoTrack.addSink(localView);
        pc.addTrack(videoTrack,Collections.singletonList("muwahid"));
    }
    private void showRemoteVideo(VideoTrack track){if(remoteView!=null)ui.post(()->{if(!closed){track.addSink(remoteView);}});}
    private abstract class DescriptionCreate implements SdpObserver {
        @Override public void onSetSuccess(){} @Override public void onSetFailure(String err){message("Ошибка настройки связи: "+err);}
        @Override public void onCreateFailure(String err){message("Ошибка SDP: "+err);}
    }
    private void makeOffer(){MediaConstraints constraints=new MediaConstraints();
        pc.createOffer(new DescriptionCreate(){
            @Override public void onCreateSuccess(SessionDescription sdp){
                if(closed)return;
                pc.setLocalDescription(new DescriptionCreate(){@Override public void onCreateSuccess(SessionDescription unused){}
                    @Override public void onSetSuccess(){transport.execute(()->{try{api.changeCall(callId,new JSONObject().put("offer_sdp",sdp.description));offered=true;message("Звоним…");}catch(Exception e){message(e.getMessage());}});}},sdp);
            }
        },constraints);
    }
    private void makeAnswer(){pc.createAnswer(new DescriptionCreate(){
        @Override public void onCreateSuccess(SessionDescription sdp){
            if(closed)return;
            pc.setLocalDescription(new DescriptionCreate(){@Override public void onCreateSuccess(SessionDescription unused){}
                @Override public void onSetSuccess(){transport.execute(()->{try{api.changeCall(callId,new JSONObject().put("answer_sdp",sdp.description));answered=true;message("Соединяемся…");}catch(Exception e){message(e.getMessage());}});}},sdp);
        }
    },new MediaConstraints());}
    private void setRemote(SessionDescription.Type type,String description){
        if(pc==null||closed)return;
        pc.setRemoteDescription(new DescriptionCreate(){@Override public void onCreateSuccess(SessionDescription unused){}
            @Override public void onSetSuccess(){remoteReady=true;
                while(!waitingIce.isEmpty()){IceCandidate c=waitingIce.pollFirst();if(c!=null)pc.addIceCandidate(c);}
                if(!caller)makeAnswer();
            }
        },new SessionDescription(type,description));
    }
    private void sync() throws Exception{
        if(closed||pc==null)return;
        JSONObject call=api.getCall(callId);if(call.length()==0){ui.post(()->endCall(false));return;}
        String state=call.optString("status");if("declined".equals(state)||"ended".equals(state)){message("Вызов завершён");ui.post(()->endCall(false));return;}
        if(!caller){String offer=call.optString("offer_sdp","");if(!offer.isEmpty()&&!remoteReady&&!answered){ui.post(()->{if(!remoteReady)setRemote(SessionDescription.Type.OFFER,offer);});}}
        else {String answer=call.optString("answer_sdp","");if(!answer.isEmpty()&&!remoteReady){ui.post(()->{if(!remoteReady)setRemote(SessionDescription.Type.ANSWER,answer);});}}
        JSONArray ice=api.iceSince(callId,iceId);
        for(int i=0;i<ice.length();i++){
            JSONObject item=ice.getJSONObject(i);iceId=Math.max(iceId,item.optLong("id"));if(item.optString("sender_id").equals(api.uid()))continue;
            IceCandidate candidate=new IceCandidate(item.optString("sdp_mid",null),item.getInt("sdp_mline_index"),item.getString("candidate"));
            ui.post(()->{if(closed||pc==null)return;if(remoteReady)pc.addIceCandidate(candidate);else waitingIce.offerLast(candidate);});
        }
    }
    private void message(String message){ui.post(()->{if(!closed&&status!=null)status.setText(message);});}
    private void endCall(boolean notify){if(closed)return;closed=true;ui.removeCallbacks(polling);
        if(notify)transport.execute(()->{try{api.changeCall(callId,new JSONObject().put("status","ended"));}catch(Exception ignored){} });
        if(capturer!=null){try{capturer.stopCapture();}catch(Exception ignored){}capturer.dispose();capturer=null;}
        if(pc!=null){pc.close();pc.dispose();pc=null;}
        if(audioTrack!=null){audioTrack.dispose();audioTrack=null;}
        if(audioSource!=null){audioSource.dispose();audioSource=null;}
        if(videoTrack!=null){videoTrack.dispose();videoTrack=null;}
        if(videoSource!=null){videoSource.dispose();videoSource=null;}
        if(helper!=null){helper.dispose();helper=null;}
        if(factory!=null){factory.dispose();factory=null;}
        if(localView!=null){localView.release();localView=null;}
        if(remoteView!=null){remoteView.release();remoteView=null;}
        if(egl!=null){egl.release();egl=null;}
        if(audioManager!=null){audioManager.setSpeakerphoneOn(audioSpeakerBefore);audioManager.setMode(AudioManager.MODE_NORMAL);}
        transport.shutdown();finish();
    }
    @Override public void onBackPressed(){endCall(true);}
    @Override protected void onDestroy(){if(!closed)endCall(true);super.onDestroy();}
}
