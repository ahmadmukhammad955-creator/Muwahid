// Supabase Database Webhook (INSERT public.mw_calls) -> FCM HTTP v1.
// MUST set MUWAHID_PUSH_WEBHOOK_SECRET and MUWAHID_FCM_SERVICE_ACCOUNT_JSON
// as Supabase Edge Function secrets. NEVER place these secrets in Android or GitHub source.
import { JWT } from 'npm:google-auth-library@9.15.1';

type Target={token:string;call_id:string;callee_id:string;caller_name:string;kind:string;created_ms:number};
const json=(data:unknown,status=200)=>new Response(JSON.stringify(data),{
  status,headers:{'content-type':'application/json; charset=utf-8'}
});
Deno.serve(async request=>{
  if(request.method!== 'POST')return json({error:'method'},405);
  const hookSecret=Deno.env.get('MUWAHID_PUSH_WEBHOOK_SECRET');
  if(!hookSecret || hookSecret.length<24 || request.headers.get('x-muwahid-hook')!==hookSecret)
    return json({error:'unauthorized'},401);
  const rawAccount=Deno.env.get('MUWAHID_FCM_SERVICE_ACCOUNT_JSON');
  const serviceKey=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const base=Deno.env.get('SUPABASE_URL');
  if(!rawAccount||!serviceKey||!base)return json({error:'push-not-configured'},503);
  try{
    const payload=await request.json();
    const record=payload?.record;
    if(payload?.type!=='INSERT'||payload?.schema!=='public'||payload?.table!=='mw_calls'
      ||typeof record?.id!=='string'||!/^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(record.id))
      return json({error:'invalid-webhook'},400);
    const lookup=await fetch(`${base}/rest/v1/rpc/mw_push_targets`,{
      method:'POST',headers:{'apikey':serviceKey,'Authorization':`Bearer ${serviceKey}`,'Content-Type':'application/json'},
      body:JSON.stringify({p_call:record.id})
    });
    if(!lookup.ok)return json({error:'lookup-failed',status:lookup.status},502);
    const targets=await lookup.json() as Target[];
    if(targets.length===0)return json({ok:true,sent:0});
    const account=JSON.parse(rawAccount);
    if(!account?.client_email||!account?.private_key||!account?.project_id)return json({error:'bad-service-account'},503);
    const client=new JWT({email:account.client_email,key:account.private_key,
      scopes:['https://www.googleapis.com/auth/firebase.messaging']});
    const tokens=await client.authorize();
    if(!tokens.access_token)return json({error:'firebase-auth-failed'},502);
    const endpoint=`https://fcm.googleapis.com/v1/projects/${encodeURIComponent(account.project_id)}/messages:send`;
    let sent=0,failed=0;
    for(const t of targets){
      const message={message:{token:t.token,
        android:{priority:'HIGH',ttl:'90s'},
        data:{type:'incoming_call',call_id:t.call_id,callee_id:t.callee_id,
          kind:t.kind,caller_name:t.caller_name,created_ms:String(t.created_ms)}}};
      const result=await fetch(endpoint,{method:'POST',
        headers:{'Authorization':`Bearer ${tokens.access_token}`,'Content-Type':'application/json'},
        body:JSON.stringify(message)});
      if(result.ok)sent++;else{failed++;console.warn('FCM rejected a device message',result.status);}
    }
    return json({ok:failed===0,sent,failed},failed===0?200:502);
  }catch(error){console.error('Call push delivery error',String(error));return json({error:'delivery-failed'},500);}
});
