-- Muwahid 0.12.9 privacy controls.
-- Direct table access remains closed; authenticated clients use narrow RPCs.
begin;

create table if not exists public.mw_privacy(
  user_id uuid primary key references public.mw_profiles(id) on delete cascade,
  phone_search text not null default 'everyone' check(phone_search in ('everyone','contacts','nobody')),
  messages text not null default 'everyone' check(messages in ('everyone','contacts','nobody')),
  calls text not null default 'everyone' check(calls in ('everyone','contacts','nobody'))
);
create table if not exists public.mw_privacy_contacts(
  user_id uuid not null references public.mw_profiles(id) on delete cascade,
  person_id uuid not null references public.mw_profiles(id) on delete cascade,
  primary key(user_id,person_id),
  check(user_id<>person_id)
);
create table if not exists public.mw_blocks(
  user_id uuid not null references public.mw_profiles(id) on delete cascade,
  person_id uuid not null references public.mw_profiles(id) on delete cascade,
  primary key(user_id,person_id),
  check(user_id<>person_id)
);

alter table public.mw_privacy enable row level security;
alter table public.mw_privacy_contacts enable row level security;
alter table public.mw_blocks enable row level security;
revoke all on public.mw_privacy,public.mw_privacy_contacts,public.mw_blocks from public,anon,authenticated;

create or replace function mw_private.privacy_allows(p_owner uuid,p_actor uuid,p_kind text)
returns boolean language sql stable security definer set search_path='' as $$
 select p_owner=p_actor or (
  not exists(select 1 from public.mw_blocks b where (b.user_id=p_owner and b.person_id=p_actor) or (b.user_id=p_actor and b.person_id=p_owner))
  and case coalesce((select case p_kind when 'messages' then v.messages when 'calls' then v.calls when 'phone_search' then v.phone_search else 'nobody' end from public.mw_privacy v where v.user_id=p_owner),'everyone')
   when 'everyone' then true
   when 'contacts' then exists(select 1 from public.mw_privacy_contacts c where c.user_id=p_owner and c.person_id=p_actor)
   else false end
 );
$$;
revoke all on function mw_private.privacy_allows(uuid,uuid,text) from public,anon,authenticated;

create or replace function public.mw_privacy_get() returns jsonb
language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 perform mw_private.require_mfa();
 select jsonb_build_object('phone_search',v.phone_search,'messages',v.messages,'calls',v.calls) into result
 from public.mw_privacy v where user_id=auth.uid();
 return coalesce(result,'{"phone_search":"everyone","messages":"everyone","calls":"everyone"}'::jsonb)
  || jsonb_build_object(
    'blocked_count',(select count(*) from public.mw_blocks where user_id=auth.uid()),
    'contacts_count',(select count(*) from public.mw_privacy_contacts where user_id=auth.uid())
  );
end $$;

create or replace function public.mw_privacy_set(p_key text,p_value text) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
 perform mw_private.require_mfa();
 if p_key is null or p_key not in ('phone_search','messages','calls') or p_value is null or p_value not in ('everyone','contacts','nobody') then
  raise exception 'MW:Некорректная настройка';
 end if;
 insert into public.mw_privacy(user_id) values(auth.uid()) on conflict do nothing;
 update public.mw_privacy set
  phone_search=case when p_key='phone_search' then p_value else phone_search end,
  messages=case when p_key='messages' then p_value else messages end,
  calls=case when p_key='calls' then p_value else calls end
 where user_id=auth.uid();
 return public.mw_privacy_get();
end $$;

create or replace function public.mw_privacy_people(p_list text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 perform mw_private.require_mfa();
 if p_list is null or p_list not in ('blocks','contacts') then raise exception 'MW:Некорректный список'; end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',p.id,'display_name',p.display_name,'username',p.username) order by p.display_name),'[]'::jsonb) into result
 from public.mw_profiles p
 where (p_list='blocks' and exists(select 1 from public.mw_blocks b where b.user_id=auth.uid() and b.person_id=p.id))
 or (p_list='contacts' and exists(select 1 from public.mw_privacy_contacts c where c.user_id=auth.uid() and c.person_id=p.id));
 return result;
end $$;

create or replace function public.mw_privacy_person_set(p_list text,p_person uuid,p_enabled boolean) returns void
language plpgsql security definer set search_path='' as $$
begin
 perform mw_private.require_mfa();
 if p_list is null or p_list not in ('blocks','contacts') or p_enabled is null or p_person is null or p_person=auth.uid()
    or not exists(select 1 from public.mw_profiles where id=p_person) then
  raise exception 'MW:Некорректный пользователь';
 end if;
 if p_list='blocks' then
  if p_enabled then
   insert into public.mw_blocks values(auth.uid(),p_person) on conflict do nothing;
   update public.mw_calls set status='ended',updated_at=now()
    where status in ('ringing','accepted') and ((caller_id=auth.uid() and callee_id=p_person) or (caller_id=p_person and callee_id=auth.uid()));
  else
   delete from public.mw_blocks where user_id=auth.uid() and person_id=p_person;
  end if;
 else
  if p_enabled then insert into public.mw_privacy_contacts values(auth.uid(),p_person) on conflict do nothing;
  else delete from public.mw_privacy_contacts where user_id=auth.uid() and person_id=p_person;
  end if;
 end if;
end $$;

create or replace function public.mw_sessions_list() returns jsonb
language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 perform mw_private.require_mfa();
 select coalesce(jsonb_agg(jsonb_build_object(
   'created_at',s.created_at,
   'last_active',coalesce(s.refreshed_at::timestamptz,s.updated_at,s.created_at),
   'current',s.id::text=auth.jwt()->>'session_id'
 ) order by s.created_at desc),'[]'::jsonb) into result
 from auth.sessions s
 where s.user_id=auth.uid() and (s.not_after is null or s.not_after>now());
 return result;
end $$;

-- Enforce the three privacy decisions in the relevant entry points.
create or replace function public.mw_find_person_any(p_query text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare q text; normalized_phone text; result jsonb;
begin
 perform mw_private.require_mfa();
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 q:=btrim(coalesce(p_query,''));
 if char_length(q)<4 or char_length(q)>40 then raise exception 'MW:Введите номер телефона или имя пользователя'; end if;
 normalized_phone:=regexp_replace(q,'[[:space:]()\-]','','g');
 if normalized_phone ~ '^\+[1-9][0-9]{7,14}$' then
  select jsonb_build_object('id',p.id,'display_name',p.display_name,'username',p.username) into result
  from public.mw_profiles p
  where p.phone_e164=normalized_phone and p.id<>auth.uid() and mw_private.privacy_allows(p.id,auth.uid(),'phone_search');
 else
  q:=lower(regexp_replace(q,'^@','',''));
  select jsonb_build_object('id',p.id,'display_name',p.display_name,'username',p.username) into result
  from public.mw_profiles p where p.username=q and p.id<>auth.uid();
 end if;
 return result;
end $$;

create or replace function public.mw_start_chat(p_person uuid) returns uuid
language plpgsql security definer set search_path='' as $$
declare result uuid; a uuid; b uuid;
begin
 perform mw_private.require_mfa();
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 if p_person=auth.uid() or not exists(select 1 from public.mw_profiles where id=p_person) then raise exception 'MW:Пользователь не найден'; end if;
 if not mw_private.privacy_allows(p_person,auth.uid(),'messages') then raise exception 'MW:Пользователь ограничил сообщения'; end if;
 a:=least(auth.uid(),p_person); b:=greatest(auth.uid(),p_person);
 insert into public.mw_chats(member_a,member_b) values(a,b) on conflict(member_a,member_b) do nothing;
 select id into result from public.mw_chats where member_a=a and member_b=b;
 return result;
end $$;

create or replace function public.mw_call_start(p_chat uuid,p_kind text,p_offer text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare peer uuid; new_id uuid; result jsonb;
begin
 perform mw_private.require_mfa();
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 if p_kind not in ('audio','video') then raise exception 'MW:Некорректный тип звонка'; end if;
 if char_length(p_offer) not between 20 and 100000 then raise exception 'MW:Некорректное описание звонка'; end if;
 select case when member_a=auth.uid() then member_b else member_a end into peer
 from public.mw_chats where id=p_chat and auth.uid() in(member_a,member_b);
 if peer is null then raise exception 'MW:Нет доступа к этому чату'; end if;
 if not mw_private.privacy_allows(peer,auth.uid(),'calls') then raise exception 'MW:Пользователь ограничил звонки'; end if;
 update public.mw_calls set status='missed',updated_at=now()
  where callee_id=peer and status='ringing' and created_at<now()-interval '90 seconds';
 insert into public.mw_calls(chat_id,caller_id,callee_id,kind,offer)
 values(p_chat,auth.uid(),peer,p_kind,p_offer) returning id into new_id;
 select to_jsonb(c) into result from public.mw_calls c where c.id=new_id;
 return result;
end $$;

revoke all on function public.mw_privacy_get(),public.mw_privacy_set(text,text),public.mw_privacy_people(text),public.mw_privacy_person_set(text,uuid,boolean),public.mw_sessions_list(),public.mw_find_person_any(text),public.mw_start_chat(uuid),public.mw_call_start(uuid,text,text) from public,anon,authenticated;
grant execute on function public.mw_privacy_get(),public.mw_privacy_set(text,text),public.mw_privacy_people(text),public.mw_privacy_person_set(text,uuid,boolean),public.mw_sessions_list(),public.mw_find_person_any(text),public.mw_start_chat(uuid),public.mw_call_start(uuid,text,text) to authenticated;

commit;
