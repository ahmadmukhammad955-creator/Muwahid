# Muwahid 0.13.32 — source release verification

**This is an Android source bundle, not a compiled APK.** It preserves the requested versionName `0.13.32` and versionCode `67`.

## Changed code (not labels alone)

- Retained two-stage LIVE creation; audio 4–12 and video 4–9 seats.
- Added creator-selected themes, seating layouts, seat decorations and microphone voice-wave visual feedback; the creator's configuration is sent through the existing authenticated room-message RPC and accepted only from the room owner.
- Added optional `backend/033_live_theme_restore.sql` so late joiners can retrieve the last theme after many messages (not applied to live Supabase by this bundle).
- Restored the visible live chat composer and message list. Fixed the phone-width bottom LIVE toolbar so controls are horizontal and cannot push the chat to an unusable left sidebar. Enabled keyboard resize.
- Replaced a three-option invitation alert with a share panel modeled on the supplied reference: Share, Recent, Friends, Fans, Groups tabs, installed-app shortcuts, Android share chooser, copy-link and encrypted in-app invitations. **Fans and Groups are visibly marked unavailable** because Muwahid has no underlying fan/group contacts API; no fabricated data.
- Retained photo / 15–60-second video background, owner-only room termination, invalidating ended room links, and existing messenger/call functions.
- Kept GitHub Actions pointed exclusively at this exact source archive, with version 0.13.32 and code 67, and retained Android SDK correction.

## Verification and limitations

- Source checks via `bash VERIFY_PROJECT.sh`: completed.
- JavaScript `node --check`: completed.
- Browser-based functional mock at 390×844: 12 audio seats in a ring; 9 video seats; visible and clickable composer; send-message DOM update; correct bottom toolbar; theme switching. **Mock requests, not a live Supabase or device test.**
- Java grammar sanity check with `javac`: no Java syntax diagnostics, but Android classes are not available in this local runtime; that is **not** a build success.
- No Android SDK or Gradle available here; a **new APK has not been compiled** from these revised sources, and real voice/video links, native invitation UI, file selection and room expiration have **not** been re-tested on two phones.
- The live server's 4–12 audio / 4–9 video capacity rules were checked previously; no server changes are performed by building this ZIP.
- APK automatic updating **cannot distribute a changed app with the same versionCode to an already-installed v67 as a newer update**. Keep v67 for current source validation as requested; assign a new code only after the APK is actually verified and approved for release.

## Integration

Upload this exact ZIP as a file in the GitHub repo root, then use the included `.github/workflows/build-apk.yml` (or the standalone companion). A successful CI run is required before calling the APK ready. Apply `backend/033_live_theme_restore.sql` in Supabase only as a separate server deployment after review; it is not silently applied.
