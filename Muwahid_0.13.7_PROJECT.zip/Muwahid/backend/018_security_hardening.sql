begin;

-- Keep complaints accessible only for the operations used by the client.
revoke all on table public.mw_complaints from public, anon, authenticated;
grant select, insert on table public.mw_complaints to authenticated;

commit;
