# Muwahid 0.13.16 deep-check scope

Stage 1 implements the highest-priority defects from the two-phone test:

- updater downloads the public release APK inside Muwahid and verifies SHA-256 before opening Android installer; no browser/GitHub login flow
- no `REQUEST_INSTALL_PACKAGES` permission is added
- incoming-call ringtone is started by the background notification service and stops on answer/end or when the call disappears
- ringtone can be system/default, silent, or a user-selected audio document with persisted read access
- voice recording supports pause/resume, cancel, completion preview, replay, re-record and send
- presence RPC, 20-second foreground heartbeat, and chat-list online/last-seen fields are provided in backend migration 023
- open voice rooms admit everyone immediately as listeners; raised-hand promotion assigns one of eight microphone seats
