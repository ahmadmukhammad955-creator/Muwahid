package com.muwahid.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecureStore {
    private final SharedPreferences prefs;
    SecureStore(Context context) { prefs = context.getSharedPreferences("session", Context.MODE_PRIVATE); }
    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias("muwahid.session")) {
            KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            gen.init(new KeyGenParameterSpec.Builder("muwahid.session", KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            gen.generateKey();
        }
        return (SecretKey) store.getKey("muwahid.session", null);
    }
    synchronized void save(String text) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key());
        String iv = Base64.encodeToString(c.getIV(), Base64.NO_WRAP);
        String data = Base64.encodeToString(c.doFinal(text.getBytes("UTF-8")), Base64.NO_WRAP);
        if (!prefs.edit().putString("iv", iv).putString("data", data).commit()) throw new Exception("Не удалось сохранить вход на устройстве");
    }
    synchronized String load() {
        try {
            if (!prefs.contains("data")) return "";
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(prefs.getString("iv", ""), Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(prefs.getString("data", ""), Base64.NO_WRAP)), "UTF-8");
        } catch (Exception e) { clear(); return ""; }
    }
    synchronized void clear() { prefs.edit().clear().commit(); }
}
