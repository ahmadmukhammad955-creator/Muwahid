# Muwahid 0.13.19 — deep check

This release fixes two regressions without removing prior features.

## Active calls
- Main screen renders a persistent `Вернуться к звонку` banner.
- Banner state is confirmed against Supabase RPC `mw_active_call`.
- `CallActivity` stores current call metadata locally while the call UI is in the task.
- Accepted/outgoing calls publish an ongoing Android notification that returns to the existing call activity.
- Leaving the call screen for chat/contacts does not clear the active-call state.
- Ending/rejecting/missing a call clears the banner/notification.

## Voice rooms
- Voice rooms are visible directly on the main messenger screen.
- Ordinary users enter immediately as listeners.
- Listeners may raise a hand.
- Moderator/host promotes a listener to one of 8 microphone seats.
- Moving a speaker back to listeners frees the microphone seat.
- Existing room chat, moderation, books and signaling remain present.

## Supabase live backend
- `mw_active_call()` deployed.
- Voice-room listener/8-seat promotion logic deployed.
- Presence/last-seen columns and `mw_presence_set()` deployed.
- Extended profile bio/status RPCs deployed.

## Version
- versionName: 0.13.19
- versionCode: 53
