-- TEMPLATE: replace owner UUID/email after checking the real confirmed account.
begin;
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-000000000000","aal":"aal1"}',true);
do $$ begin
 if not (public.mw_owner_status()->>'is_owner')::boolean then raise exception 'FAIL owner identity'; end if;
 begin perform public.mw_owner_overview();raise exception 'FAIL password-only owner';
 exception when raise_exception then if SQLERRM not like 'MW:Подтвердите%' then raise;end if;end;
end $$;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-000000000000","aal":"aal2"}',true);
select public.mw_owner_overview();
select set_config('request.jwt.claims','{"sub":"33333333-3333-4333-8333-333333333333","aal":"aal2"}',true);
do $$ begin
 if (public.mw_owner_status()->>'is_owner')::boolean then raise exception 'FAIL outsider identity';end if;
 begin perform public.mw_owner_overview();raise exception 'FAIL outsider owner';
 exception when raise_exception then if SQLERRM not like 'MW:Доступ только%' then raise;end if;end;
 begin perform * from mw_private.owner_account;raise exception 'FAIL owner table access';
 exception when insufficient_privilege then null;end;
end $$;
reset role;
select 'PASS: owner bound, password-only denied, MFA owner allowed, outsider denied, owner table protected' as verification;
rollback;
