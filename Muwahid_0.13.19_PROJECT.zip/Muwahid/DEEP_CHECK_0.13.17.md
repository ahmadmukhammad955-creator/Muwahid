# Muwahid 0.13.18 — stage 2

Implemented in this stage:

- Profile status presets: work, sleeping, travelling, business trip, do-not-disturb, home, or custom text.
- Status expiration: 1 hour, until tomorrow, 7 days, or until manually removed.
- Custom profile background selected through Android's system document picker (no broad storage permission).
- Profile header shows the selected background and current status.
- Supabase migration `024_profile_status.sql` adds profile bio/status fields and RPCs.
- Groups/channels creation now includes public/private type and join approval.
- Local group/channel management UI includes chat history visibility, hidden member list, granular permissions, slow mode, welcome text, invite-link regeneration, leave/delete actions.
- Existing 0.13.16 calls, voice recording, presence, updater and voice-room changes are preserved.

Important: group/channel settings in this build are still stored locally on the device. Multi-user server synchronization for communities is the next backend stage and must not be described as complete yet.
