begin;

-- Muwahid 0.10.1: one independent microphone per participant.
-- A moderator may force-mute and block/unblock a member's microphone.
-- A moderator cannot remotely turn on another person's microphone: the member must tap their own mic button.

alter table public.mw_voice_room_members
  add column if not exists mic_allowed boolean not null default true,
  add column if not exists mic_enabled boolean not null default false,
  add column if not exists mic_updated_at timestamptz not null default now();

-- Old single-floor state is intentionally no longer used by the client.
update public.mw_voice_room_members set mic_enabled=false;

create or replace function public.mw_room_list()
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  delete from public.mw_voice_room_members m where m.last_seen < now()-interval '90 seconds';
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',r.id,'title',r.title,'created_at',r.created_at,
    'participants',(select count(*) from public.mw_voice_room_members m where m.room_id=r.id),
    'speaking',(select count(*) from public.mw_voice_room_members m where m.room_id=r.id and m.mic_allowed and m.mic_enabled)
  ) order by r.created_at desc),'[]'::jsonb)
  into result from public.mw_voice_rooms r where r.active=true;
  return result;
end
$$;

create or replace function public.mw_room_state(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb; my_rank integer; can_mod boolean; room_title text; room_creator uuid;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  perform mw_private.room_cleanup(p_room);
  update public.mw_voice_room_members set last_seen=now() where room_id=p_room and user_id=auth.uid();
  if not found then raise exception 'MW:Вы больше не участник комнаты'; end if;
  select title,created_by into room_title,room_creator from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта'; end if;
  my_rank:=mw_private.role_rank(auth.uid(),p_room); can_mod:=my_rank>=10;
  select jsonb_build_object(
    'id',p_room,'title',room_title,'self_id',auth.uid(),'created_by',room_creator,
    'role',case when my_rank=30 then 'owner' when my_rank=20 then 'admin' when my_rank=10 then 'host' else 'user' end,
    'can_moderate',can_mod,
    'members',coalesce((select jsonb_agg(jsonb_build_object(
      'id',p.id,'display_name',p.display_name,'username',p.username,'seat',m.seat,
      'mic_allowed',m.mic_allowed,'mic_enabled',m.mic_enabled,
      'hand_raised',exists(select 1 from public.mw_voice_room_hands h where h.room_id=m.room_id and h.user_id=m.user_id),
      'role',case when mw_private.role_rank(p.id,p_room)=30 then 'owner' when mw_private.role_rank(p.id,p_room)=20 then 'admin' when mw_private.role_rank(p.id,p_room)=10 then 'host' else 'user' end
    ) order by m.seat)
    from public.mw_voice_room_members m join public.mw_profiles p on p.id=m.user_id where m.room_id=p_room),'[]'::jsonb)
  ) into result;
  return result;
end
$$;

create or replace function public.mw_room_mic_set_self(p_room uuid,p_enabled boolean)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare allowed boolean;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  select mic_allowed into allowed from public.mw_voice_room_members
    where room_id=p_room and user_id=auth.uid();
  if allowed is null then raise exception 'MW:Вы больше не участник комнаты'; end if;
  if p_enabled and not allowed then raise exception 'MW:Ваш микрофон заглушён модератором'; end if;
  update public.mw_voice_room_members
    set mic_enabled=p_enabled, mic_updated_at=now(), last_seen=now()
    where room_id=p_room and user_id=auth.uid();
  return jsonb_build_object('mic_allowed',allowed,'mic_enabled',p_enabled);
end
$$;

create or replace function public.mw_room_mic_moderate(p_room uuid,p_user uuid,p_allowed boolean)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare caller_rank integer; target_rank integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  caller_rank:=mw_private.role_rank(auth.uid(),p_room);
  target_rank:=mw_private.role_rank(p_user,p_room);
  if caller_rank<10 then raise exception 'MW:Нет прав модератора'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_user) then
    raise exception 'MW:Участник уже вышел';
  end if;
  if p_user='025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid and auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then
    raise exception 'MW:Микрофоном владельца управляет только владелец';
  end if;
  if auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid and caller_rank<=target_rank then
    raise exception 'MW:Нельзя управлять микрофоном участника с равной или более высокой ролью';
  end if;
  update public.mw_voice_room_members
    set mic_allowed=p_allowed,
        mic_enabled=case when p_allowed then mic_enabled else false end,
        mic_updated_at=now()
    where room_id=p_room and user_id=p_user;
  return jsonb_build_object('user_id',p_user,'mic_allowed',p_allowed);
end
$$;

-- Multi-party mesh signaling: every member can negotiate a WebRTC audio connection with every other member.
create or replace function public.mw_room_signal_send(p_room uuid,p_to uuid,p_kind text,p_payload jsonb)
returns bigint
language plpgsql
security definer
set search_path=''
as $$
declare new_id bigint;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if p_kind not in ('offer','answer','ice','bye') then raise exception 'MW:Некорректный сигнал'; end if;
  if auth.uid()=p_to then raise exception 'MW:Некорректный получатель'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid())
     or not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_to) then
    raise exception 'MW:Участник уже вышел из комнаты';
  end if;
  insert into public.mw_voice_room_signals(room_id,from_user,to_user,kind,payload)
  values(p_room,auth.uid(),p_to,p_kind,coalesce(p_payload,'{}'::jsonb)) returning id into new_id;
  return new_id;
end
$$;

revoke all on function public.mw_room_mic_set_self(uuid,boolean),public.mw_room_mic_moderate(uuid,uuid,boolean) from public,anon,authenticated;
grant execute on function public.mw_room_mic_set_self(uuid,boolean),public.mw_room_mic_moderate(uuid,uuid,boolean) to authenticated;

commit;
