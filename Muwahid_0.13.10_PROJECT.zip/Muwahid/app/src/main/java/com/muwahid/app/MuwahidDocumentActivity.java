package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class MuwahidDocumentActivity extends Activity {
    private static final int REQ_PICK=1;
    private String filter="all";
    private LinearLayout chips,list;
    private final int bg=Color.parseColor("#071827"), panel=Color.parseColor("#102337"), cyan=Color.parseColor("#18C7D7"), muted=Color.parseColor("#91A5B8");
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private ImageButton iconButton(String icon,int color,String desc){ImageButton b=new ImageButton(this);b.setImageDrawable(new UiIconDrawable(icon,color));b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(dp(10),dp(10),dp(10),dp(10));b.setContentDescription(desc);return b;}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);build();}

    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(8),dp(6),dp(8),dp(4));
        ImageButton back=iconButton("back",Color.WHITE,"Назад");bar.addView(back,new LinearLayout.LayoutParams(dp(44),dp(50)));back.setOnClickListener(v->finish());
        TextView title=text("Документы",17,Color.WHITE);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);bar.addView(title,new LinearLayout.LayoutParams(0,dp(50),1));
        ImageButton more=iconButton("more",cyan,"Ещё");bar.addView(more,new LinearLayout.LayoutParams(dp(44),dp(50)));more.setOnClickListener(v->openPicker("*/*"));root.addView(bar,new LinearLayout.LayoutParams(-1,dp(62)));

        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);chips=new LinearLayout(this);chips.setPadding(dp(9),dp(3),dp(9),dp(5));
        String[] names={"Все","PDF","Word","Excel","Другие"};String[] keys={"all","pdf","word","excel","other"};
        for(int i=0;i<names.length;i++){final String key=keys[i];TextView c=text(names[i],12,Color.WHITE);c.setGravity(Gravity.CENTER);c.setTag("chip:"+key);c.setBackground(shape(i==0?cyan:Color.parseColor("#13283B"),16));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(i==4?74:62),dp(32));cp.setMargins(dp(3),0,dp(3),0);chips.addView(c,cp);c.setOnClickListener(v->{filter=key;refreshChips();loadRecent();});}
        hsv.addView(chips);root.addView(hsv,new LinearLayout.LayoutParams(-1,dp(44)));

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(10),dp(4),dp(10),dp(90));scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        Button browse=new Button(this);browse.setText("Открыть все файлы на телефоне");browse.setTextSize(14);browse.setTextColor(Color.WHITE);browse.setAllCaps(false);browse.setBackground(shape(Color.parseColor("#168BFF"),17));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(48));bp.setMargins(dp(14),dp(8),dp(14),dp(12));root.addView(browse,bp);browse.setOnClickListener(v->openPicker(mimeForFilter()));
        setContentView(root);loadRecent();
    }

    private void refreshChips(){for(int i=0;i<chips.getChildCount();i++){View v=chips.getChildAt(i);String tag=String.valueOf(v.getTag());boolean active=tag.equals("chip:"+filter);v.setBackground(shape(active?cyan:Color.parseColor("#13283B"),16));}}
    private String mimeForFilter(){if("pdf".equals(filter))return "application/pdf";if("word".equals(filter))return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";if("excel".equals(filter))return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";return "*/*";}
    private boolean accept(String name,String mime){String n=name==null?"":name.toLowerCase(Locale.ROOT),m=mime==null?"":mime.toLowerCase(Locale.ROOT);if("all".equals(filter))return true;if("pdf".equals(filter))return n.endsWith(".pdf")||m.contains("pdf");if("word".equals(filter))return n.endsWith(".doc")||n.endsWith(".docx")||m.contains("word");if("excel".equals(filter))return n.endsWith(".xls")||n.endsWith(".xlsx")||m.contains("sheet")||m.contains("excel");return !(n.endsWith(".pdf")||n.endsWith(".doc")||n.endsWith(".docx")||n.endsWith(".xls")||n.endsWith(".xlsx"));}

    private void loadRecent(){
        list.removeAllViews();int shown=0;Cursor c=null;
        try{
            Uri collection=MediaStore.Files.getContentUri("external");String[] projection={MediaStore.Files.FileColumns._ID,MediaStore.Files.FileColumns.DISPLAY_NAME,MediaStore.Files.FileColumns.SIZE,MediaStore.Files.FileColumns.DATE_MODIFIED,MediaStore.Files.FileColumns.MIME_TYPE};
            c=getContentResolver().query(collection,projection,null,null,MediaStore.Files.FileColumns.DATE_MODIFIED+" DESC");
            if(c!=null){int idI=c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID),nameI=c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME),sizeI=c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE),dateI=c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED),mimeI=c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE);while(c.moveToNext()&&shown<40){String name=c.getString(nameI),mime=c.getString(mimeI);if(name==null||!accept(name,mime))continue;long id=c.getLong(idI),size=c.getLong(sizeI),date=c.getLong(dateI);Uri uri=ContentUris.withAppendedId(collection,id);addFileRow(uri,name,mime,size,date);shown++;}}
        }catch(Exception ignored){}finally{if(c!=null)c.close();}
        if(shown==0){LinearLayout empty=new LinearLayout(this);empty.setOrientation(LinearLayout.VERTICAL);empty.setGravity(Gravity.CENTER);ImageView icon=new ImageView(this);icon.setImageDrawable(new UiIconDrawable("document",Color.parseColor("#388CF5")));empty.addView(icon,new LinearLayout.LayoutParams(dp(64),dp(64)));TextView t=text("Недавние документы не найдены",16,Color.WHITE);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(12),0,0);empty.addView(t);TextView s=text("Нажмите «Открыть все файлы на телефоне»",13,muted);s.setGravity(Gravity.CENTER);s.setPadding(dp(20),dp(7),dp(20),0);empty.addView(s);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(240)));}
    }

    private void addFileRow(Uri uri,String name,String mime,long size,long date){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(8),dp(6),dp(8));String lower=name.toLowerCase(Locale.ROOT);int badgeColor=lower.endsWith(".pdf")?Color.parseColor("#EF4D58"):(lower.endsWith(".doc")||lower.endsWith(".docx"))?Color.parseColor("#2F83F5"):(lower.endsWith(".xls")||lower.endsWith(".xlsx"))?Color.parseColor("#2BBE62"):Color.parseColor("#F48D31");
        ImageView badge=new ImageView(this);badge.setImageDrawable(new UiIconDrawable("document",Color.WHITE));badge.setPadding(dp(10),dp(10),dp(10),dp(10));badge.setBackground(shape(badgeColor,10));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(48),dp(48));ip.rightMargin=dp(12);row.addView(badge,ip);
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);TextView n=text(name,15,Color.WHITE);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);words.addView(n,new LinearLayout.LayoutParams(-1,dp(24)));String sub=formatSize(size)+(date>0?" · "+new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new Date(date*1000L)):"");TextView d=text(sub,12,muted);words.addView(d,new LinearLayout.LayoutParams(-1,dp(22)));row.addView(words,new LinearLayout.LayoutParams(0,dp(50),1));ImageView more=new ImageView(this);more.setImageDrawable(new UiIconDrawable("more",muted));row.addView(more,new LinearLayout.LayoutParams(dp(36),dp(42)));list.addView(row,new LinearLayout.LayoutParams(-1,dp(66)));View div=new View(this);div.setBackgroundColor(Color.parseColor("#0D293E"));LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,dp(1));dl.leftMargin=dp(68);list.addView(div,dl);row.setOnClickListener(v->returnUri(uri));
    }
    private String formatSize(long bytes){if(bytes<=0)return "Файл";if(bytes>=1024*1024)return String.format(Locale.US,"%.1f МБ",bytes/(1024f*1024f));return Math.max(1,bytes/1024)+" КБ";}
    private void returnUri(Uri u){Intent out=new Intent();out.setData(u);out.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);setResult(RESULT_OK,out);finish();}
    private void openPicker(String mime){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);if("*/*".equals(mime))i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-powerpoint","application/vnd.openxmlformats-officedocument.presentationml.presentation","text/plain","application/zip"});i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_PICK);}catch(Exception e){Toast.makeText(this,"Не удалось открыть список файлов",Toast.LENGTH_SHORT).show();}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_PICK&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)returnUri(data.getData());}
}
