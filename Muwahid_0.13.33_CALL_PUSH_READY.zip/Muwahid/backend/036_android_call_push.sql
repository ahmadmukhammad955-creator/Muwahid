-- Muwahid v0.13.33: push token registry, callable only through scoped RPC.
-- The private schema isn't exposed through the Data API.
create table if not exists mw_private.mw_device_push_tokens (
  token text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint mw_push_token_length check (char_length(token) between 32 and 4096)
);
create index if not exists mw_push_user_id_idx on mw_private.mw_device_push_tokens(user_id);
alter table mw_private.mw_device_push_tokens enable row level security;
revoke all on mw_private.mw_device_push_tokens from public,anon,authenticated;

create or replace function public.mw_push_register(p_token text)
returns boolean language plpgsql security definer set search_path = '' as $$
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if p_token is null or char_length(p_token) not between 32 and 4096 then
    raise exception 'MW:Недопустимый токен устройства';
  end if;
  insert into mw_private.mw_device_push_tokens(token,user_id)
    values(p_token,auth.uid())
    on conflict (token) do update set user_id=excluded.user_id,updated_at=now();
  return true;
end $$;

create or replace function public.mw_push_unregister(p_token text)
returns boolean language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  delete from mw_private.mw_device_push_tokens where token=p_token and user_id=auth.uid();
  return true;
end $$;

-- Only a trusted Supabase service_role may resolve device tokens for a ringing call.
-- Return no tokens for calls already ended or older than 90 seconds.
create or replace function public.mw_push_targets(p_call uuid)
returns table(token text,call_id uuid,callee_id uuid,caller_name text,kind text,created_ms bigint)
language sql stable security definer set search_path = '' as $$
  select t.token,c.id,c.callee_id,p.display_name,c.kind,
         (extract(epoch from c.created_at)*1000)::bigint
  from public.mw_calls c
  join public.mw_profiles p on p.id=c.caller_id
  join mw_private.mw_device_push_tokens t on t.user_id=c.callee_id
  where c.id=p_call and c.status='ringing'
    and c.created_at >= now()-interval '90 seconds';
$$;
revoke all on function public.mw_push_register(text) from public,anon,authenticated;
revoke all on function public.mw_push_unregister(text) from public,anon,authenticated;
revoke all on function public.mw_push_targets(uuid) from public,anon,authenticated;
grant execute on function public.mw_push_register(text), public.mw_push_unregister(text) to authenticated;
grant execute on function public.mw_push_targets(uuid) to service_role;
