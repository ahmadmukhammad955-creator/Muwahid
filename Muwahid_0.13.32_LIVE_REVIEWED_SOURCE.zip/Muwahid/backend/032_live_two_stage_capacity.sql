-- Muwahid LIVE 0.13.32: approved capacity rules.
-- Audio rooms: 4..12 seats. Video rooms: 4..9 seats.
-- Apply after existing backend migrations (including 030). No data is deleted.
BEGIN;
ALTER TABLE public.mw_voice_rooms DROP CONSTRAINT IF EXISTS mw_voice_rooms_capacity_check;
ALTER TABLE public.mw_voice_rooms ADD CONSTRAINT mw_voice_rooms_capacity_check
  CHECK ((room_mode = 'audio' AND capacity BETWEEN 4 AND 12)
      OR (room_mode = 'video' AND capacity BETWEEN 4 AND 9));

create or replace function public.mw_live_room_create(
  p_title text,
  p_mode text,
  p_capacity integer,
  p_access text
) returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare rid uuid; normalized_mode text; normalized_access text; normalized_capacity integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if char_length(btrim(coalesce(p_title,''))) not between 1 and 80 then
    raise exception 'MW:Название эфира должно содержать 1–80 символов';
  end if;
  normalized_mode:=lower(coalesce(p_mode,'audio'));
  normalized_access:=lower(coalesce(p_access,'open'));
  normalized_capacity:=coalesce(p_capacity,8);
  if normalized_mode not in ('audio','video') then raise exception 'MW:Неизвестный тип эфира'; end if;
  if normalized_access not in ('open','closed') then raise exception 'MW:Неизвестный режим доступа'; end if;
  if normalized_mode='audio' and normalized_capacity not between 4 and 12 then raise exception 'MW:Аудиокомната: от 4 до 12 мест'; end if;
  if normalized_mode='video' and normalized_capacity not between 4 and 9 then raise exception 'MW:Видеоэфир: от 4 до 9 мест'; end if;

  insert into public.mw_voice_rooms(title,created_by,room_mode,capacity,access_mode)
  values(btrim(p_title),auth.uid(),normalized_mode,normalized_capacity,normalized_access)
  returning id into rid;

  insert into public.mw_voice_room_members(room_id,user_id,seat,mic_allowed,mic_enabled,last_seen,mic_updated_at)
  values(rid,auth.uid(),1,true,false,now(),now());

  return jsonb_build_object(
    'id',rid,'title',btrim(p_title),'room_mode',normalized_mode,
    'capacity',normalized_capacity,'access_mode',normalized_access
  );
end
$$;


REVOKE ALL ON FUNCTION public.mw_live_room_create(text,text,integer,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.mw_live_room_create(text,text,integer,text) TO authenticated;
COMMIT;
