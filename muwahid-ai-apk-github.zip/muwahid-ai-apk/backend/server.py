import io
import os
import re
import time
from functools import lru_cache

import torch
from diffusers import FluxPipeline
from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field

MODEL_ID = os.getenv("MODEL_ID", "black-forest-labs/FLUX.1-schnell")

BLOCKED_PATTERNS = [
    r"\b(nude|naked|porn|pornographic|explicit sex|sexual act|genitals|intercourse)\b",
    r"\b(нюд|обнаженн\w*|порно|порнограф\w*|половой акт|генитал\w*)\b",
    r"\b(child|kid|minor|underage|teen)\b.*\b(sexy|nude|naked|sexual|porn)\b",
    r"\b(ребен\w*|дет\w*|несовершеннолет\w*|подрост\w*)\b.*\b(сексуаль\w*|обнажен\w*|порно)\b",
]

app = FastAPI(title="Muwahid AI Image API", version="1.0.0")


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=2000)
    width: int = 768
    height: int = 1024
    steps: int = 4
    seed: int = 42


def is_safe_prompt(prompt: str) -> bool:
    text = (prompt or "").strip().lower()
    return not any(re.search(pattern, text, flags=re.I) for pattern in BLOCKED_PATTERNS)


@lru_cache(maxsize=1)
def get_pipe():
    if torch.cuda.is_available():
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        pipe = FluxPipeline.from_pretrained(MODEL_ID, torch_dtype=dtype)
        pipe.to("cuda")
    else:
        pipe = FluxPipeline.from_pretrained(MODEL_ID, torch_dtype=torch.float32)
        pipe.to("cpu")
    return pipe


@app.get("/health")
def health():
    return {"ok": True, "model": MODEL_ID, "cuda": torch.cuda.is_available()}


@app.post("/generate")
def generate(req: GenerateRequest):
    if not is_safe_prompt(req.prompt):
        raise HTTPException(status_code=400, detail="Этот запрос не поддерживается правилами безопасности.")

    width = max(256, min(1536, (int(req.width) // 16) * 16))
    height = max(256, min(1536, (int(req.height) // 16) * 16))
    steps = max(1, min(12, int(req.steps)))
    seed = max(0, int(req.seed))

    device = "cuda" if torch.cuda.is_available() else "cpu"
    generator = torch.Generator(device=device).manual_seed(seed)
    pipe = get_pipe()

    started = time.time()
    image = pipe(
        prompt=req.prompt,
        width=width,
        height=height,
        num_inference_steps=steps,
        guidance_scale=0.0,
        max_sequence_length=256,
        generator=generator,
    ).images[0]

    output = io.BytesIO()
    image.save(output, format="PNG")
    elapsed = round(time.time() - started, 2)
    return Response(
        content=output.getvalue(),
        media_type="image/png",
        headers={"X-Generation-Seconds": str(elapsed), "X-Seed": str(seed)},
    )
