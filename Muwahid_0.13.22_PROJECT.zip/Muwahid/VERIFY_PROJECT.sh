#!/usr/bin/env bash
set -euo pipefail
grep -Fq "versionCode 56" app/build.gradle
grep -Fq "versionName '0.13.22'" app/build.gradle
grep -Fq 'debuggable false' app/build.gradle
grep -Fq 'minifyEnabled true' app/build.gradle
grep -Fq 'shrinkResources true' app/build.gradle
grep -Fq 'assembleRelease' .github/workflows/build-apk.yml
grep -Fq 'outputs/apk/release/app-release.apk' .github/workflows/build-apk.yml
grep -Fq 'PROJECT_ZIP: Muwahid_0.13.22_PROJECT.zip' .github/workflows/build-apk.yml
grep -Fq "EXPECTED_VERSION_NAME: '0.13.22'" .github/workflows/build-apk.yml
grep -Fq "EXPECTED_VERSION_CODE: '56'" .github/workflows/build-apk.yml
grep -Fq 'test "$VERSION_NAME" = "$EXPECTED_VERSION_NAME"' .github/workflows/build-apk.yml
grep -Fq 'android:name=".VoiceRoomActivity"' app/src/main/AndroidManifest.xml
grep -Fq 'private void showVoiceRooms()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void showAdminManagement()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'WebView.setWebContentsDebuggingEnabled(false)' app/src/main/java/com/muwahid/app/CallActivity.java
grep -Fq 'shouldOverrideUrlLoading' app/src/main/java/com/muwahid/app/CallActivity.java
grep -Fq 'WebView.setWebContentsDebuggingEnabled(false)' app/src/main/java/com/muwahid/app/VoiceRoomActivity.java
grep -Fq 'shouldOverrideUrlLoading' app/src/main/java/com/muwahid/app/VoiceRoomActivity.java
grep -Fq 'mw_room_raise_hand' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_kick' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_mic_set_self' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_mic_moderate' app/src/main/assets/voice_room.html
grep -Fq 'create or replace function public.mw_owner_admin_set' backend/012_voice_rooms_admins.sql
grep -Fq 'create or replace function public.mw_room_signal_poll' backend/015_voice_room_performance.sql
test -f backend/016_shared_reading.sql
test -f backend/017_room_close.sql
test -f backend/018_security_hardening.sql
test -f backend/019_phone_country_auth.sql
test -f backend/020_remote_config.sql
test -f app/src/main/java/com/muwahid/app/RemoteConfig.java
grep -Fq 'mw_app_config' app/src/main/java/com/muwahid/app/MainActivity.java
! grep -RIEq 'service[_-]?role|ghp_[A-Za-z0-9]{20,}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----' app backend .github --exclude='*.png'
grep -Fq 'void people(String list)' app/src/main/java/com/muwahid/app/PrivacyActivity.java
grep -Fq 'mw_privacy_get' app/src/main/java/com/muwahid/app/PrivacyActivity.java
grep -Fq 'mw_sessions_list' app/src/main/java/com/muwahid/app/PrivacyActivity.java
grep -Fq 'create or replace function public.mw_privacy_get()' backend/022_privacy_controls.sql
grep -Fq "privacy_allows(p_person,auth.uid(),'messages')" backend/022_privacy_controls.sql
grep -Fq "privacy_allows(peer,auth.uid(),'calls')" backend/022_privacy_controls.sql

grep -Fq 'private void showWallpaperSettings()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void showNameColorSettings()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Углы блоков с сообщениями' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Смахивание влево в списке чатов' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Поднести и слушать' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Отправка по Enter' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'android:name=".LauncherNight"' app/src/main/AndroidManifest.xml
grep -Fq 'private void showAttachmentSheet()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void sendCurrentLocation()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'ACCESS_FINE_LOCATION' app/src/main/AndroidManifest.xml
grep -Fq 'android.permission.REQUEST_INSTALL_PACKAGES' app/src/main/AndroidManifest.xml
grep -Fq 'canRequestPackageInstalls' app/src/main/java/com/muwahid/app/UpdateActivity.java
grep -Fq 'ACTION_MANAGE_UNKNOWN_APP_SOURCES' app/src/main/java/com/muwahid/app/UpdateActivity.java
grep -Fq 'Скачать и установить' app/src/main/java/com/muwahid/app/UpdateActivity.java
grep -Fq 'expectedSha256' app/src/main/java/com/muwahid/app/UpdateActivity.java
grep -Fq 'FileProvider.getUriForFile' app/src/main/java/com/muwahid/app/UpdateActivity.java
grep -Fq 'application/vnd.android.package-archive' app/src/main/java/com/muwahid/app/UpdateActivity.java
! grep -Fq 'Intent.CATEGORY_BROWSABLE' app/src/main/java/com/muwahid/app/UpdateActivity.java
! grep -Fq 'releasePage(' app/src/main/java/com/muwahid/app/UpdateActivity.java
grep -Fq 'startTimer()' app/src/main/java/com/muwahid/app/CallActivity.java


grep -Fq 'android:name=".MuwahidCameraActivity"' app/src/main/AndroidManifest.xml
grep -Fq 'android:name=".LocationShareActivity"' app/src/main/AndroidManifest.xml
grep -Fq 'android:name=".MuwahidDocumentActivity"' app/src/main/AndroidManifest.xml
grep -Fq '"Все","Личные","Группы","Каналы"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq '"Чаты","Звонки","Контакты","Настройки"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"image","Галерея"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"camera","Камера"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"video","Видео"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"document","Документ"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"location","Местоположение"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"contacts","Контакт"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"audio","Аудио"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"poll","Опрос"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"more","Ещё"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'cycleInlineVoiceSpeed' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq "id='add'" app/src/main/java/com/muwahid/app/CallActivity.java
grep -Fq 'MW_SMOKE_OK: 0.13.22' app/src/androidTest/java/com/muwahid/app/SmokeInstrumentation.java

# Reference UI implementation checks
test -f app/src/main/java/com/muwahid/app/UiIconDrawable.java
test -f app/src/main/java/com/muwahid/app/MiniMapView.java
grep -Fq 'refIconButton("phone"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'composer.setTextSize(16)' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Muwahid_0.13.22_PROJECT.zip' .github/workflows/build-apk.yml
# Compile-regression guard: long-press "Скрыть чат" must call the real helper.
! grep -Fq 'setHiddenChat(' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'else hideChat(id);drawChatList();' app/src/main/java/com/muwahid/app/MainActivity.java

# 0.13.13 visible chat redesign guards
grep -Fq 'new LinearLayout.LayoutParams(dp(270),-2)' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'gp.height=dp(90)' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'int step=dp(74)' app/src/main/java/com/muwahid/app/MainActivity.java
# 0.13.11 UI smoke-test contract: real composer uses the reference hint with ellipsis.
grep -Fq 'composer.setHint("Сообщение...")' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq '"Сообщение...".contentEquals(hint)' app/src/androidTest/java/com/muwahid/app/SmokeInstrumentation.java

# GitHub emulator-runner executes script lines independently via /usr/bin/sh -c.
# Keep the crash-log check on one physical line to avoid an unterminated if/fi block.
grep -Fq "! grep -q 'FATAL EXCEPTION' crash-log.txt || { cat crash-log.txt; exit 1; }" .github/workflows/build-apk.yml
! grep -Fq "if grep -q 'FATAL EXCEPTION' crash-log.txt; then" .github/workflows/build-apk.yml

# 0.13.15 regression guards: modern outline icons must be visible but not oversized.
grep -Fq 'b.setScaleType(ImageView.ScaleType.FIT_CENTER)' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'v.setScaleType(ImageView.ScaleType.FIT_CENTER)' app/src/main/java/com/muwahid/app/MainActivity.java
! grep -Fq 'ScaleType.CENTER_INSIDE' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'p.setStrokeWidth(1.65f)' app/src/main/java/com/muwahid/app/UiIconDrawable.java
grep -Fq 'new LinearLayout.LayoutParams(dp(42),dp(42))' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'new LinearLayout.LayoutParams(dp(40),dp(44))' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'compose.addView(fieldBox,new LinearLayout.LayoutParams(0,dp(50),1));' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'root.addView(compose,new LinearLayout.LayoutParams(-1,dp(64)));' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Main camera control is not balanced' app/src/androidTest/java/com/muwahid/app/SmokeInstrumentation.java
grep -Fq 'Audio-call control is not balanced' app/src/androidTest/java/com/muwahid/app/SmokeInstrumentation.java
grep -Fq 'Composer height is not balanced' app/src/androidTest/java/com/muwahid/app/SmokeInstrumentation.java

# 0.13.16 stage-1 regression guards: internal updater, ringtone, voice preview,
# real presence heartbeat, and open-listener voice rooms.
test -f app/src/main/java/com/muwahid/app/CallRingtone.java
grep -Fq 'USAGE_NOTIFICATION_RINGTONE' app/src/main/java/com/muwahid/app/CallRingtone.java
grep -Fq 'CallRingtone.start(this,id)' app/src/main/java/com/muwahid/app/NotificationService.java
grep -Fq 'muwahid_calls_v2' app/src/main/java/com/muwahid/app/NotificationService.java
grep -Fq 'c.setSound(null,null)' app/src/main/java/com/muwahid/app/NotificationService.java
grep -Fq 'Выбрать песню или музыку' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'toggleVoicePause' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'showVoicePreview' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'presenceHeartbeat' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'mw_presence_set' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'был сегодня в ' app/src/main/java/com/muwahid/app/MainActivity.java
test -f backend/023_presence_and_open_voice_rooms.sql
grep -Fq 'add column if not exists last_seen' backend/023_presence_and_open_voice_rooms.sql
grep -Fq "'status','listener'" backend/023_presence_and_open_voice_rooms.sql
grep -Fq 'seat is null or seat between 1 and 8' backend/023_presence_and_open_voice_rooms.sql
grep -Fq '🎧 Слушатели' app/src/main/assets/voice_room.html
grep -Fq '⬆ Поднять в спикеры' app/src/main/assets/voice_room.html
# 0.13.22 regression guards: real audio-room mixer, local music, soundboard and recording.
grep -Fq 'REQ_ROOM_AUDIO=7404' app/src/main/java/com/muwahid/app/VoiceRoomActivity.java
grep -Fq 'recordingChunk' app/src/main/java/com/muwahid/app/VoiceRoomActivity.java
grep -Fq '"/music-file"' app/src/main/java/com/muwahid/app/VoiceRoomActivity.java
grep -Fq 'grid-template-columns:repeat(4,1fr)' app/src/main/assets/voice_room.html
grep -Fq 'function openMixer()' app/src/main/assets/voice_room.html
grep -Fq 'createMediaStreamDestination()' app/src/main/assets/voice_room.html
grep -Fq 'function playSfx(kind)' app/src/main/assets/voice_room.html
grep -Fq 'new MediaRecorder(recordDest.stream,opts)' app/src/main/assets/voice_room.html


# 0.13.18 stage-2 regression guards: profile statuses and community controls.
grep -Fq 'private void showProfileStatusPicker()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void addProfileHeader()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'REQ_PROFILE_BACKGROUND=6114' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void showCommunitySettings(String kind,String id,String name)' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Медленный режим' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Скрыть участников' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Пригласительная ссылка' app/src/main/java/com/muwahid/app/MainActivity.java
test -f backend/024_profile_status.sql
grep -Fq 'create or replace function public.mw_update_profile_status' backend/024_profile_status.sql

# 0.13.19 regression guards: call resume and visible voice rooms.
grep -Fq 'private void addActiveCallBanner()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void returnToActiveCall()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'mw_active_call' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Нажмите, чтобы вернуться в звонок' app/src/main/java/com/muwahid/app/CallActivity.java
grep -Fq '8 мест с микрофоном · слушатели входят сразу' app/src/main/java/com/muwahid/app/MainActivity.java
test -f backend/025_active_call_and_open_voice_room_fix.sql
grep -Fq 'create or replace function public.mw_active_call()' backend/025_active_call_and_open_voice_room_fix.sql

# 0.13.20 regression guards: Supabase sticker bridge and Android share import.
grep -Fq 'mw_sticker_catalog' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'interface JsonDone { void accept(JSONObject result) throws Exception; }' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void loadStickerCloud(boolean force,JsonDone done,Runnable failed)' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'mw_sticker_create_pack' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'mw_sticker_register_asset' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'mw_sticker_set_favorite' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'uploadSticker(' app/src/main/java/com/muwahid/app/Api.java
grep -Fq 'downloadSticker(' app/src/main/java/com/muwahid/app/Api.java
grep -Fq 'android.intent.action.SEND' app/src/main/AndroidManifest.xml
grep -Fq 'REQ_STICKER_IMPORT=6115' app/src/main/java/com/muwahid/app/MainActivity.java
test -f backend/026_supabase_sticker_bridge.sql

grep -Fq '＋  Создать набор' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq '⇧  Добавить / импортировать' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq '⚙  Управление наборами' app/src/main/java/com/muwahid/app/MainActivity.java
echo 'MW_SOURCE_OK 0.13.22 STICKER_PICKER_CREATE_IMPORT_CONTROLS' 
