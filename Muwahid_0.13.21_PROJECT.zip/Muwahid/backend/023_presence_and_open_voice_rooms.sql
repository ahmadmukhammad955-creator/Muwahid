begin;

-- Muwahid 0.13.16: real presence/last-seen + open voice rooms.
-- Users enter a voice room immediately as listeners. A moderator promotes a
-- listener to one of eight microphone seats after a raised-hand request.

alter table public.mw_profiles
  add column if not exists last_seen timestamptz not null default now(),
  add column if not exists is_online boolean not null default false,
  add column if not exists bio text not null default '',
  add column if not exists status_text text not null default '';

create or replace function public.mw_presence_set(p_online boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  update public.mw_profiles
     set is_online=coalesce(p_online,false), last_seen=now()
   where id=auth.uid();
  return jsonb_build_object('online',coalesce(p_online,false),'last_seen',now());
end $$;

create or replace function public.mw_chat_list() returns jsonb
language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 perform mw_private.require_mfa();
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 select coalesce(jsonb_agg(to_jsonb(x) order by x.updated_at desc),'[]'::jsonb) into result from (
  select c.id,p.display_name,p.username,p.id as person_id,
   case when m.body like 'mw1:%' then '🔒 Зашифрованное сообщение' else m.body end as last_message,
   coalesce(m.created_at,c.created_at) as updated_at,
   (p.is_online and p.last_seen > now()-interval '35 seconds') as online,
   p.last_seen,
   p.status_text
  from public.mw_chats c
  join public.mw_profiles p on p.id=case when c.member_a=auth.uid() then c.member_b else c.member_a end
  left join lateral(select body,created_at from public.mw_messages where chat_id=c.id order by id desc limit 1) m on true
  where auth.uid() in(c.member_a,c.member_b)
 ) x;
 return result;
end $$;

-- More than eight people may listen. Only microphone seats are numbered 1..8.
alter table public.mw_voice_room_members alter column seat drop not null;
alter table public.mw_voice_room_members drop constraint if exists mw_voice_room_members_seat_check;
alter table public.mw_voice_room_members add constraint mw_voice_room_members_seat_check
  check(seat is null or seat between 1 and 8);

create or replace function public.mw_room_join(p_room uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare room_title text;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  perform mw_private.room_cleanup(p_room);
  select title into room_title from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта или не существует'; end if;
  if exists(select 1 from public.mw_voice_room_bans where room_id=p_room and user_id=auth.uid()) then raise exception 'MW:Вы заблокированы в этой комнате'; end if;

  update public.mw_voice_room_members set last_seen=now() where room_id=p_room and user_id=auth.uid();
  if found then
    delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
    return jsonb_build_object('room_id',p_room,'title',room_title,'status','joined');
  end if;

  delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
  insert into public.mw_voice_room_members(room_id,user_id,seat,mic_allowed,mic_enabled)
  values(p_room,auth.uid(),null,false,false)
  on conflict(room_id,user_id) do update set last_seen=now();
  return jsonb_build_object('room_id',p_room,'title',room_title,'status','listener');
end $$;

create or replace function public.mw_room_state(p_room uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb; my_rank integer; can_mod boolean; room_title text; room_creator uuid;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  select title,created_by into room_title,room_creator from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта'; end if;
  update public.mw_voice_room_members set last_seen=now()
    where room_id=p_room and user_id=auth.uid() and last_seen < now()-interval '10 seconds';
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) then
    raise exception 'MW:Вы больше не участник комнаты';
  end if;
  perform mw_private.room_cleanup(p_room);
  my_rank:=mw_private.room_rank(auth.uid(),p_room);can_mod:=my_rank>=20;
  select jsonb_build_object(
    'id',p_room,'title',room_title,'self_id',auth.uid(),'created_by',room_creator,
    'waiting',false,'waiting_count',0,
    'role',case when my_rank=40 then 'owner' when my_rank=30 then 'host' when my_rank=20 then 'moderator' else 'user' end,
    'can_moderate',can_mod,'can_assign_moderator',my_rank>=30,
    'participant_count',(select count(*) from public.mw_voice_room_members where room_id=p_room),
    'members',coalesce((select jsonb_agg(jsonb_build_object(
      'id',p.id,'display_name',p.display_name,'username',p.username,'seat',m.seat,
      'mic_allowed',m.mic_allowed,'mic_enabled',m.mic_enabled,
      'hand_raised',exists(select 1 from public.mw_voice_room_hands h where h.room_id=m.room_id and h.user_id=m.user_id),
      'role',case when mw_private.room_rank(p.id,p_room)=40 then 'owner' when mw_private.room_rank(p.id,p_room)=30 then 'host' when mw_private.room_rank(p.id,p_room)=20 then 'moderator' else 'user' end
    ) order by m.seat nulls last,m.joined_at)
    from public.mw_voice_room_members m join public.mw_profiles p on p.id=m.user_id where m.room_id=p_room),'[]'::jsonb),
    'waiting_users','[]'::jsonb
  ) into result;
  return result;
end $$;

-- "Allow microphone" promotes a listener to a free stage seat. Muting a
-- regular user returns them to the audience. Hosts/owners keep their seat.
create or replace function public.mw_room_mic_moderate(p_room uuid,p_user uuid,p_allowed boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare caller_rank integer; target_rank integer; free_seat integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  caller_rank:=mw_private.room_rank(auth.uid(),p_room);target_rank:=mw_private.room_rank(p_user,p_room);
  if caller_rank<20 then raise exception 'MW:Нет прав модератора'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_user) then raise exception 'MW:Участник уже вышел'; end if;
  if p_user='025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid and auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then raise exception 'MW:Микрофоном владельца управляет только владелец'; end if;
  if auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid and caller_rank<=target_rank then raise exception 'MW:Нельзя управлять участником с равной или более высокой ролью'; end if;
  if p_allowed then
    select g into free_seat from generate_series(1,8) g where not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=g) order by g limit 1;
    if free_seat is null and (select seat from public.mw_voice_room_members where room_id=p_room and user_id=p_user) is null then raise exception 'MW:Все 8 мест для выступающих заняты'; end if;
    update public.mw_voice_room_members set mic_allowed=true,seat=coalesce(seat,free_seat),last_seen=now() where room_id=p_room and user_id=p_user;
    delete from public.mw_voice_room_hands where room_id=p_room and user_id=p_user;
  else
    update public.mw_voice_room_members set mic_allowed=false,mic_enabled=false,seat=case when target_rank>=30 then seat else null end,last_seen=now() where room_id=p_room and user_id=p_user;
  end if;
  return jsonb_build_object('user_id',p_user,'mic_allowed',p_allowed);
end $$;

revoke all on function public.mw_presence_set(boolean),public.mw_room_join(uuid),public.mw_room_state(uuid),public.mw_room_mic_moderate(uuid,uuid,boolean) from public,anon,authenticated;
grant execute on function public.mw_presence_set(boolean),public.mw_room_join(uuid),public.mw_room_state(uuid),public.mw_room_mic_moderate(uuid,uuid,boolean),public.mw_chat_list() to authenticated;

commit;
