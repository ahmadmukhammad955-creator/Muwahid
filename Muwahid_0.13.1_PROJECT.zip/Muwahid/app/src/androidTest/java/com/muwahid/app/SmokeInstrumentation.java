package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.graphics.Bitmap;
import java.io.*;

public class SmokeInstrumentation extends Instrumentation {
    private Activity activity;

    @Override public void onCreate(Bundle args) {
        super.onCreate(args);
        start();
    }

    private View findText(View view, String text) {
        if (view instanceof TextView && text.equals(((TextView) view).getText().toString())) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                View found = findText(group.getChildAt(i), text);
                if (found != null) return found;
            }
        }
        return null;
    }

    private View findTag(View v,String tag){
        if(tag.equals(v.getTag()))return v;
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++){View found=findTag(g.getChildAt(i),tag);if(found!=null)return found;}}
        return null;
    }
    private Dialog phonePicker(){
        try {java.lang.reflect.Field f=MainActivity.class.getDeclaredField("phoneEntry");f.setAccessible(true);Object entry=f.get(activity);
            java.lang.reflect.Field d=PhoneEntryView.class.getDeclaredField("picker");d.setAccessible(true);return (Dialog)d.get(entry);
        }catch(Exception e){throw new RuntimeException(e);}
    }
    private void checkPhoneEntry() throws Exception {
        if(PhoneCountries.load(getTargetContext()).length()<240)throw new AssertionError("Incomplete offline countries");
        String[] raw={"901234567","+998 90 123 45 67","00998901234567"};
        for(String value:raw)if(!"+998901234567".equals(PhoneEntryView.normalize(value,"UZ","+998")))throw new AssertionError("Phone normalization: "+value);
        if(PhoneEntryView.normalize("+4915123456789","UZ","+998")!=null)throw new AssertionError("Mismatched country accepted");
        runOnMainSync(()->invoke("showAuth",new Class<?>[]{boolean.class},true));waitForIdleSync();
        runOnMainSync(()->{
            View decor=activity.getWindow().getDecorView();
            ((EditText)findTag(decor,"phone_number")).setText("901234567");
        });
        capture("phone_entry.png");
        runOnMainSync(()->findTag(activity.getWindow().getDecorView(),"phone_country").performClick());waitForIdleSync();
        capture("phone_countries.png");
        runOnMainSync(()->{
            Dialog d=phonePicker();EditText search=(EditText)findTag(d.getWindow().getDecorView(),"country_search");search.setText("Узбекистан");
            ListView list=(ListView)findTag(d.getWindow().getDecorView(),"country_list");
            if(list.getAdapter().getCount()!=1)throw new AssertionError("Country search failed");
            list.performItemClick(null,0,0);
            if(!"901234567".contentEquals(((EditText)findTag(activity.getWindow().getDecorView(),"phone_number")).getText()))throw new AssertionError("Phone lost on selection");
            if(findText(activity.getWindow().getDecorView(),"+998")==null)throw new AssertionError("Country code not selected");
        });
        capture("phone_selected.png");
        runOnMainSync(()->findTag(activity.getWindow().getDecorView(),"phone_country").performClick());waitForIdleSync();
        runOnMainSync(()->{
            Dialog d=phonePicker();EditText search=(EditText)findTag(d.getWindow().getDecorView(),"country_search");ListView list=(ListView)findTag(d.getWindow().getDecorView(),"country_list");
            search.setText("+49");if(list.getAdapter().getCount()!=1)throw new AssertionError("Dialling-code search failed");
            search.setText("zzzzzz");if(list.getAdapter().getCount()!=0)throw new AssertionError("Empty search failed");
            d.dismiss();
        });
    }

    private EditText findComposer(View view) {
        if (view instanceof EditText && "Сообщение".contentEquals(((EditText) view).getHint())) return (EditText) view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                EditText found = findComposer(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    private void invoke(String method, Class<?>[] types, Object... args) {
        try {
            java.lang.reflect.Method m = MainActivity.class.getDeclaredMethod(method, types);
            m.setAccessible(true);
            m.invoke(activity, args);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Activity launch() {
        Intent intent = new Intent(getTargetContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return startActivitySync(intent);
    }

    private void capture(String name) throws Exception {
        waitForIdleSync();
        Bitmap bitmap = getUiAutomation().takeScreenshot();
        if (bitmap == null) return;
        File file = new File(getTargetContext().getExternalFilesDir(null), name);
        try (FileOutputStream out = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
        } finally {
            bitmap.recycle();
        }
    }

    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            getTargetContext().getSharedPreferences("muwahid", 0).edit().clear().commit();
            try { new SecureStore(getTargetContext()).clear(); } catch (Throwable ignored) {}

            activity = launch();
            waitForIdleSync();

            if (!"0.13.1".equals(BuildConfig.VERSION_NAME)) {
                throw new AssertionError("Wrong version " + BuildConfig.VERSION_NAME);
            }
            capture("welcome.png");
            checkPhoneEntry();

            runOnMainSync(() -> invoke("showChats", new Class<?>[]{}));
            waitForIdleSync();
            runOnMainSync(() -> {
                View decor = activity.getWindow().getDecorView();
                if (findText(decor, "Muwahid") == null) throw new AssertionError("Missing Muwahid title");
                if (findText(decor, "Чаты") == null) throw new AssertionError("Missing chats tab");
                if (findText(decor, "Группы") == null) throw new AssertionError("Missing groups tab");
                if (findText(decor, "Каналы") == null) throw new AssertionError("Missing channels tab");
                if (findText(decor, "Профиль") == null) throw new AssertionError("Missing profile navigation");
                if (findText(decor, "Контакты") == null) throw new AssertionError("Missing contacts navigation");
                if (findText(decor, "Настройки") == null) throw new AssertionError("Missing settings navigation");
            });
            capture("main_chat_screen.png");

            runOnMainSync(() -> invoke("showChatSettings", new Class<?>[]{}));
            waitForIdleSync();
            runOnMainSync(() -> {
                View decor = activity.getWindow().getDecorView();
                if (findText(decor, "Размер текста сообщений") == null) throw new AssertionError("Missing message text size setting");
                if (findText(decor, "▧  Изменить обои") == null) throw new AssertionError("Missing wallpaper setting");
                if (findText(decor, "Цветовая тема") == null) throw new AssertionError("Missing chat theme setting");
                if (findText(decor, "Иконка приложения") == null) throw new AssertionError("Missing app icon setting");
            });
            capture("chat_settings_0130.png");

            runOnMainSync(() -> invoke("openConversation", new Class<?>[]{String.class, String.class}, "smoke-chat", "Алибек"));
            waitForIdleSync();
            runOnMainSync(() -> {
                View decor = activity.getWindow().getDecorView();
                if (findText(decor, "Алибек") == null) throw new AssertionError("Missing chat title");
                if (findComposer(decor) == null) throw new AssertionError("Missing message composer");
            });
            capture("chat_screen.png");

            runOnMainSync(() -> activity.finish());
            waitForIdleSync();

            activity = startActivitySync(new Intent(getTargetContext(), PrivacyActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            waitForIdleSync();
            runOnMainSync(() -> {
                View decor=activity.getWindow().getDecorView();
                for(String label:new String[]{"Конфиденциальность","Двухэтапная проверка","Код-пароль","Чёрный список","Устройства","Номер телефона","Поиск по номеру","Звонки","Сообщения","Доверенные контакты"})
                    if(findText(decor,label)==null)throw new AssertionError("Missing privacy row: "+label);
            });
            capture("privacy_screen.png");
            runOnMainSync(()->findText(activity.getWindow().getDecorView(),"Остальные настройки").performClick());
            waitForIdleSync();
            runOnMainSync(()->{if(findText(activity.getWindow().getDecorView(),"Ещё не подключено")==null)throw new AssertionError("Unsupported features shown as active");});
            capture("privacy_unavailable.png");
            runOnMainSync(()->activity.finish());
            waitForIdleSync();
            getTargetContext().getSharedPreferences("muwahid",0).edit().putBoolean("app_lock",true).commit();
            for(Class<?> entry:new Class<?>[]{MainActivity.class,CallActivity.class,VoiceRoomActivity.class,PrivacyActivity.class}){
                ActivityMonitor monitor=addMonitor(UnlockActivity.class.getName(),null,false);
                getTargetContext().startActivity(new Intent(getTargetContext(),entry).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                Activity locked=waitForMonitorWithTimeout(monitor,5000);
                removeMonitor(monitor);
                if(locked==null)throw new AssertionError("Lock bypassed at "+entry.getSimpleName());
                runOnMainSync(()->locked.finish());waitForIdleSync();
            }
            getTargetContext().getSharedPreferences("muwahid",0).edit().putBoolean("app_lock",false).commit();
            result.putString("stream", "MW_SMOKE_OK: 0.13.1 chat settings video match, phone entry, chat UI, profile navigation");
            finish(Activity.RESULT_OK, result);
        } catch (Throwable e) {
            result.putString("stream", "MW_SMOKE_FAILED: " + e.getClass().getName() + ": " + String.valueOf(e.getMessage()));
            finish(Activity.RESULT_CANCELED, result);
        }
    }
}
