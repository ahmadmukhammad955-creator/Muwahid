begin;
insert into auth.users(id,raw_user_meta_data) values
('11111111-1111-4111-8111-111111111111','{"display_name":"Test A"}'),
('22222222-2222-4222-8222-222222222222','{"display_name":"Test B"}'),
('33333333-3333-4333-8333-333333333333','{"display_name":"Test C"}');
set local role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.mw_update_profile('Test A','muwahid_test_a');
select set_config('muwahid.test_chat',public.mw_start_chat('22222222-2222-4222-8222-222222222222')::text,true);
select public.mw_send(current_setting('muwahid.test_chat')::uuid,'test message','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');
select public.mw_send(current_setting('muwahid.test_chat')::uuid,'test message','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
do $$ begin
 if jsonb_array_length(public.mw_messages_get(current_setting('muwahid.test_chat')::uuid))<>1 then raise exception 'TEST FAILED: receive or duplicate'; end if;
 if jsonb_array_length(public.mw_chat_list())<>1 then raise exception 'TEST FAILED: chat list'; end if;
end $$;
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
do $$ begin
 begin
  perform public.mw_messages_get(current_setting('muwahid.test_chat')::uuid);
  raise exception 'TEST FAILED: outsider read allowed';
 exception when raise_exception then
  if SQLERRM not like 'MW:Нет доступа%' then raise; end if;
 end;
 begin
  perform public.mw_send(current_setting('muwahid.test_chat')::uuid,'intruder','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb');
  raise exception 'TEST FAILED: outsider write allowed';
 exception when raise_exception then
  if SQLERRM not like 'MW:Нет доступа%' then raise; end if;
 end;
 begin
  perform * from public.mw_messages;
  raise exception 'TEST FAILED: direct table access';
 exception when insufficient_privilege then null;
 end;
end $$;
reset role;
set local role anon;
do $$ begin
 begin
  perform public.mw_chat_list();
  raise exception 'TEST FAILED: anonymous RPC';
 exception when insufficient_privilege then null;
 end;
end $$;
reset role;
select 'PASS: send, receive, idempotent retry, outsider denial, table denial, anonymous denial' as verification;
rollback;
