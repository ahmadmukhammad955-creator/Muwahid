package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.graphics.Bitmap;
import java.io.*;
import org.json.JSONObject;
import java.lang.reflect.Field;

public class SmokeInstrumentation extends Instrumentation {
    private Activity activity;
    @Override public void onCreate(Bundle args){super.onCreate(args);start();}
    private View find(View view,String text){
        if(view instanceof TextView && ((TextView)view).getText().toString().equals(text))return view;
        if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++){View result=find(group.getChildAt(i),text);if(result!=null)return result;}}
        return null;
    }
    private void tap(String text){runOnMainSync(()->{View v=find(activity.getWindow().getDecorView(),text);if(v==null)throw new AssertionError("Missing "+text);v.performClick();});waitForIdleSync();}
    private void capture(String name)throws Exception{waitForIdleSync();Bitmap b=getUiAutomation().takeScreenshot();if(b==null)throw new Exception("No screenshot");File f=new File(getTargetContext().getExternalFilesDir(null),name);try(FileOutputStream out=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.PNG,100,out);}finally{b.recycle();}}
    private Activity launch(){Intent i=new Intent(getTargetContext(),MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);return startActivitySync(i);}
    @Override public void onStart(){Bundle result=new Bundle();try{
        getTargetContext().getSharedPreferences("muwahid",0).edit().clear().commit();
        SecureStore sessionStore=new SecureStore(getTargetContext());
        sessionStore.clear();
        sessionStore.save(new JSONObject()
                .put("access_token","test-access")
                .put("refresh_token","test-refresh")
                .put("expires_at",System.currentTimeMillis()/1000+3600)
                .put("user",new JSONObject().put("id","00000000-0000-0000-0000-000000000001")).toString());
        Api restored=new Api(new SecureStore(getTargetContext()));
        if(!restored.signedIn()||restored.uid().isEmpty())throw new AssertionError("Encrypted session not restored");
        sessionStore.clear();
        activity=launch();capture("welcome.png");
        if(!"0.9.2".equals(BuildConfig.VERSION_NAME))throw new AssertionError("Wrong version "+BuildConfig.VERSION_NAME);
        runOnMainSync(()->{try{java.lang.reflect.Method m=MainActivity.class.getDeclaredMethod("showChats");m.setAccessible(true);m.invoke(activity);}catch(Exception e){throw new RuntimeException(e);}});waitForIdleSync();
        runOnMainSync(()->{View decor=activity.getWindow().getDecorView();if(find(decor,"Muwahid")==null||find(decor,"Чаты")==null||find(decor,"Группы")==null||find(decor,"Каналы")==null||find(decor,"Звонки")==null||find(decor,"Контакты")==null||find(decor,"Настройки")==null)throw new AssertionError("Main chat screen incomplete");});
        capture("main_chat_screen.png");
        runOnMainSync(()->{try{java.lang.reflect.Method m=MainActivity.class.getDeclaredMethod("showWelcome");m.setAccessible(true);m.invoke(activity);}catch(Exception e){throw new RuntimeException(e);}});waitForIdleSync();
        tap("Начать");
        runOnMainSync(()->{
            View decor=activity.getWindow().getDecorView();
            if(find(decor,"Получить SMS-код")==null)throw new AssertionError("Missing SMS login");
            if(find(decor,"Продолжить с Google")==null)throw new AssertionError("Missing Google login");
            Intent deep=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("muwahid://auth-callback#test=1"));
            deep.setPackage(getTargetContext().getPackageName());
            if(deep.resolveActivity(getTargetContext().getPackageManager())==null)throw new AssertionError("OAuth deep link not registered");
            activity.onBackPressed();
        });waitForIdleSync();
        tap("Открыть личные заметки");
        runOnMainSync(()->{ViewGroup root=(ViewGroup)activity.findViewById(android.R.id.content);setComposer(root,"Проверка сохранения Muwahid");});tap("↑");capture("notes.png");
        runOnMainSync(()->activity.finish());waitForIdleSync();activity=launch();tap("Открыть личные заметки");
        runOnMainSync(()->{String notes=getTargetContext().getSharedPreferences("muwahid",0).getString("notes","");if(!notes.contains("Проверка сохранения Muwahid"))throw new AssertionError("Note not persisted");activity.onBackPressed();});waitForIdleSync();
        tap("Настройки");capture("settings.png");
        runOnMainSync(()->{View decor=activity.getWindow().getDecorView();if(find(decor,"Аккаунт")==null||find(decor,"Настройки чатов")==null||find(decor,"Конфиденциальность")==null||find(decor,"Данные и память")==null||find(decor,"Папки с чатами")==null||find(decor,"Premium Muwahid")==null)throw new AssertionError("Settings menu incomplete");});
        runOnMainSync(()->{
            android.content.SharedPreferences prefs=getTargetContext().getSharedPreferences("muwahid",0);
            prefs.edit().putBoolean("dark",false).putInt("message_text_size",18).putBoolean("compact_bubbles",true).commit();
            if(prefs.getBoolean("dark",true))throw new AssertionError("Theme preference not persisted");
            if(prefs.getInt("message_text_size",0)!=18)throw new AssertionError("Text size preference not persisted");
            if(!prefs.getBoolean("compact_bubbles",false))throw new AssertionError("Compact preference not persisted");
        });
        runOnMainSync(()->{try{Field f=MainActivity.class.getDeclaredField("screen");f.setAccessible(true);f.set(activity,"chats");activity.onBackPressed();}catch(Exception e){throw new RuntimeException(e);}});waitForIdleSync();
        if(!activity.isFinishing())throw new AssertionError("Back from chats must exit without logout");
        result.putString("stream","MW_SMOKE_OK: 0.9.2 main chat screen, auth UI, OAuth deep link, encrypted session restore, note persistence, settings hub, settings persistence, Back exit");finish(Activity.RESULT_OK,result);
    }catch(Throwable e){result.putString("stream","MW_SMOKE_FAILED: "+e.toString());finish(Activity.RESULT_CANCELED,result);}}
    private void setComposer(View view,String value){if(view instanceof EditText && "Сообщение".contentEquals(((EditText)view).getHint())){((EditText)view).setText(value);return;}if(view instanceof ViewGroup){ViewGroup g=(ViewGroup)view;for(int i=0;i<g.getChildCount();i++)setComposer(g.getChildAt(i),value);}}
}
