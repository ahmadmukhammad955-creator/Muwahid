# Muwahid product roadmap captured from the owner

## Calls and video
- Modern incoming/outgoing call screens based on the approved dark teal reference.
- Real incoming ringtone, custom music selection, system/default and silent options.
- Custom call background/photo per user/contact.
- Video-call face effects/masks (cat, dog, rabbit, glasses, hearts, etc.) as a later media-processing module.

## Voice messages
- Pause/resume, cancel, preview before sending, re-record, send.

## Profile and presence
- Profile photo and profile background.
- About/bio.
- Quick statuses such as Working, Sleeping, Travelling, Business trip, Do not disturb, plus custom status and expiry.
- Real online/last-seen state with privacy controls.

## Voice rooms
- Open rooms: anyone may enter immediately as a listener and hear the room.
- Raise hand -> host/moderator promotes to speaker; demote back to listener.
- Any regular Muwahid user can create and close their own room.
- Leave room is separate from End room for everyone.
- Roles: room owner, moderator, speaker, listener.
- Moderation: mute/demote/kick/ban.

## Stickers, emoji, reactions
- Emoji, reactions, favourites, recent stickers.
- Create personal stickers/sticker packs in Muwahid.
- Import supported image/animation files via Android share/open-document flow; do not bypass another app's private storage.
- Quick reactions inside voice rooms.

## Moderation
- Owner/moderator report queue for reported messages/users/groups/rooms.
- Warning, temporary restrictions, room/group ban, app suspension, permanent ban.
- Audit log with actor, reason and duration.
- Moderation based on reports/specific reported material rather than unrestricted reading of private chats.

## Groups and communities
- Public/private groups, join requests, invite links, visible/hidden history, welcome message, themes.
- Granular permissions for text, photo, video, stickers, music, files, voice/video messages, link previews, polls, reactions, adding members, pinning and editing group profile.
- Slow mode from seconds to longer intervals.
- Member visibility controls, admins, community links, leave/delete, member join/leave events.
- Group audio/video chats and notification mute durations.

## Channels
- Public/private channels, owner/admin controls, text/photo/video/travel posts, polls and articles, optional linked discussion group.


## Stage 2 — 0.13.18
- Profile status presets/custom status with expiration.
- User-selected profile background.
- Group/channel public/private creation controls.
- Group/channel permissions, history visibility, hidden members, slow mode, welcome text, invite-link regeneration.
- Server profile-status migration: `backend/024_profile_status.sql`.
- Community multi-user backend synchronization remains planned for the next stage.
