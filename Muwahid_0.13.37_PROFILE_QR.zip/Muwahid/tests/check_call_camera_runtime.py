from pathlib import Path
import json, subprocess, tempfile
src=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/muwahid/app/CallActivity.java').read_text()
js=''.join(json.loads(s.strip()[:-1]) for s in src[src.index('private static final String JS=""+'):].splitlines()[1:] if s.strip()!='}')
harness=r'''
const assert=require('node:assert/strict');
(async()=>{
const names={},requests=[],tracks=[],senders=[];let failRear=false,failReplace=false,delay=null,closed=0;
const element=id=>names[id]||(names[id]={style:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},addEventListener(){},querySelector(){return {}},play:async()=>{}});
const document={body:{classList:{add(){}}},getElementById:element};
const window={MW:{kind:'video',incoming:false,chatId:'c',peer:'Peer',initial:'P'}};
const setTimeout=()=>1,clearTimeout=()=>{};
function track(kind,side){const t={kind,enabled:true,readyState:'live',getSettings:()=>({facingMode:side}),stop(){this.readyState='ended'}};tracks.push(t);return t;}
class MediaStream{constructor(ts){this.ts=ts}getTracks(){return this.ts}getAudioTracks(){return this.ts.filter(t=>t.kind==='audio')}getVideoTracks(){return this.ts.filter(t=>t.kind==='video')}addTrack(t){this.ts.push(t)}removeTrack(t){this.ts=this.ts.filter(v=>v!==t)}}
const navigator={mediaDevices:{getUserMedia:async opts=>{requests.push(opts);if(delay)await delay;const side=opts.video.facingMode.exact||opts.video.facingMode.ideal;if(failRear&&side==='environment')throw Error('no rear');return new MediaStream([...(opts.audio?[track('audio')]:[]),track('video',side)])}}};
class RTCPeerConnection{addTrack(t){senders.push({track:t,parameters:{encodings:[{}]},getParameters(){return this.parameters},async setParameters(p){this.parameters=p},async replaceTrack(t){if(failReplace){failReplace=false;throw Error('replace failed')}this.track=t}})}getSenders(){return senders}async createOffer(){return {sdp:'sdp'}}async setLocalDescription(){}close(){closed++}}
const MuwahidNative={ringback(){},speaker(){},action(){},close(){},rpc(id,fn){queueMicrotask(()=>window.mwResult(id,JSON.stringify(fn==='mw_call_start'?{id:'c'}:{status:'ringing'}),null))}};
eval(SOURCE);
const spin=async()=>{for(let i=0;i<100;i++)await Promise.resolve()};await spin();
const audio=senders.find(s=>s.track.kind==='audio').track,video=senders.find(s=>s.track.kind==='video');
assert.equal(requests[0].video.width.ideal,1280);assert.equal(requests[0].video.height.ideal,720);
const first=video.track;await names.flipCamera.onclick();assert.equal(first.readyState,'ended');assert.equal(video.track.getSettings().facingMode,'environment');assert.equal(audio.readyState,'live');assert.equal(requests[1].audio,false);assert.equal(video.parameters.encodings[0].maxBitrate,2500000);
names.cam2.onclick();assert.equal(video.track.enabled,false);await names.flipCamera.onclick();assert.equal(video.track.getSettings().facingMode,'user');assert.equal(video.track.enabled,false);
failRear=true;await names.flipCamera.onclick();assert.equal(video.track.getSettings().facingMode,'user');assert.equal(video.track.readyState,'live');assert.equal(audio.readyState,'live');assert.match(names.callNotice.textContent,/восстановлена/);failRear=false;
failReplace=true;await names.flipCamera.onclick();assert.equal(video.track.getSettings().facingMode,'user');assert.equal(video.track.readyState,'live');
let release;delay=new Promise(r=>release=r);const before=requests.length;const switching=names.flipCamera.onclick();await names.flipCamera.onclick();assert.equal(requests.length,before+1);await window.hangup();release();await switching;assert.equal(audio.readyState,'ended');assert(tracks.every(t=>t.readyState==='ended'));assert.equal(closed,1);
console.log('CAMERA_OK: HD request, both directions, audio continuity, mute, recovery, duplicate taps, hangup race');
})().catch(e=>{console.error(e);process.exit(1)});
'''
with tempfile.NamedTemporaryFile(mode='w',suffix='.js') as f:
 f.write('const SOURCE='+json.dumps(js)+';\n'+harness);f.flush()
 subprocess.run(['node',f.name],check=True,timeout=15)
