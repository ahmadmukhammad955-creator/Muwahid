-- Muwahid 0.13.34: LIVE lobby lists only new or actually active sessions.
-- Existing LIVE-room records and chat history are retained (non-destructive).
-- 120s grace period allows a creator to join a newly created room.
-- 90s heartbeat freshness prevents ghost rooms from appearing indefinitely.
create or replace function public.mw_room_list()
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',r.id,'title',r.title,'created_at',r.created_at,
    'room_mode',r.room_mode,'capacity',r.capacity,'access_mode',r.access_mode,
    'participants',(select count(*) from public.mw_voice_room_members m
                    where m.room_id=r.id and m.last_seen >= now()-interval '90 seconds'),
    'speaking',(select count(*) from public.mw_voice_room_members m
                where m.room_id=r.id and m.last_seen >= now()-interval '90 seconds'
                  and m.mic_allowed and m.mic_enabled)
  ) order by r.created_at desc),'[]'::jsonb)
  into result
  from public.mw_voice_rooms r
  where r.active=true
    and (
      r.created_at > now()-interval '120 seconds'
      or exists(select 1 from public.mw_voice_room_members m
                where m.room_id=r.id and m.last_seen >= now()-interval '90 seconds')
    )
    and (r.access_mode='open' or r.created_by=auth.uid()
      or exists(select 1 from public.mw_voice_room_members m
                where m.room_id=r.id and m.user_id=auth.uid())
      or exists(select 1 from public.mw_voice_room_waiting w
                where w.room_id=r.id and w.user_id=auth.uid()));
  return result;
end $$;
revoke all on function public.mw_room_list() from public, anon;
grant execute on function public.mw_room_list() to authenticated;
