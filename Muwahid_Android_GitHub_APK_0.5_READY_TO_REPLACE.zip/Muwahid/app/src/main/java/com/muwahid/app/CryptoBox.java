package com.muwahid.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Per-account E2EE identity for Muwahid direct chats.
 *
 * The EC private key is generated in software so it can be used by the standard
 * ECDH provider on Android 6+, then encrypted at rest with an AES key held by
 * Android Keystore. The private key never leaves this app in plaintext storage.
 *
 * v1 message format: mw1:<base64 12-byte IV>:<base64 AES-GCM ciphertext+tag>
 */
final class CryptoBox {
    private static final String WRAP_ALIAS = "muwahid.e2ee.wrap.v1";
    private static final String FORMAT = "mw1:";
    private final SharedPreferences prefs;
    private final SecureRandom random = new SecureRandom();

    CryptoBox(Context context) {
        prefs = context.getSharedPreferences("muwahid_e2ee", Context.MODE_PRIVATE);
    }

    synchronized String publicKey(String userId) throws Exception {
        ensureIdentity(userId);
        return prefs.getString(key(userId, "pub"), "");
    }

    synchronized String encryptText(String userId, String chatId, String peerPublicKey, String plaintext) throws Exception {
        if (plaintext == null || plaintext.isEmpty()) throw new Exception("Пустое сообщение");
        SecretKey key = chatKey(userId, chatId, peerPublicKey);
        byte[] iv = new byte[12];
        random.nextBytes(iv);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
        cipher.updateAAD(aad(chatId));
        byte[] encrypted = cipher.doFinal(plaintext.getBytes("UTF-8"));
        return FORMAT + Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP);
    }

    synchronized String decryptText(String userId, String chatId, String peerPublicKey, String payload) throws Exception {
        if (payload == null) return "";
        if (!payload.startsWith(FORMAT)) return payload; // Legacy plaintext remains readable.
        String[] parts = payload.split(":", 3);
        if (parts.length != 3) throw new Exception("Повреждённое зашифрованное сообщение");
        byte[] iv = Base64.decode(parts[1], Base64.NO_WRAP);
        byte[] encrypted = Base64.decode(parts[2], Base64.NO_WRAP);
        if (iv.length != 12 || encrypted.length < 16) throw new Exception("Повреждённое зашифрованное сообщение");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, chatKey(userId, chatId, peerPublicKey), new GCMParameterSpec(128, iv));
        cipher.updateAAD(aad(chatId));
        return new String(cipher.doFinal(encrypted), "UTF-8");
    }

    private byte[] aad(String chatId) throws Exception {
        return ("Muwahid:E2EE:v1:" + chatId).getBytes("UTF-8");
    }

    private SecretKey chatKey(String userId, String chatId, String peerPublicKey) throws Exception {
        if (peerPublicKey == null || peerPublicKey.isEmpty()) throw new Exception("Ключ собеседника ещё недоступен");
        ensureIdentity(userId);
        PrivateKey mine = privateKey(userId);
        byte[] peerBytes = Base64.decode(peerPublicKey, Base64.NO_WRAP);
        PublicKey peer = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(peerBytes));
        KeyAgreement agreement = KeyAgreement.getInstance("ECDH");
        agreement.init(mine);
        agreement.doPhase(peer, true);
        byte[] secret = agreement.generateSecret();

        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] salt = sha.digest(("Muwahid:E2EE:salt:" + chatId).getBytes("UTF-8"));
        byte[] derived = hkdf(secret, salt, "Muwahid:E2EE:chat-key:v1".getBytes("UTF-8"), 32);
        return new SecretKeySpec(derived, "AES");
    }

    private byte[] hkdf(byte[] ikm, byte[] salt, byte[] info, int length) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(salt, "HmacSHA256"));
        byte[] prk = mac.doFinal(ikm);
        byte[] out = new byte[length];
        byte[] previous = new byte[0];
        int written = 0;
        int counter = 1;
        while (written < length) {
            mac.init(new SecretKeySpec(prk, "HmacSHA256"));
            mac.update(previous);
            mac.update(info);
            mac.update((byte) counter);
            previous = mac.doFinal();
            int copy = Math.min(previous.length, length - written);
            System.arraycopy(previous, 0, out, written, copy);
            written += copy;
            counter++;
        }
        return out;
    }

    private void ensureIdentity(String userId) throws Exception {
        if (userId == null || userId.isEmpty()) throw new Exception("Войдите в аккаунт");
        String pubKey = key(userId, "pub"), privateData = key(userId, "priv"), privateIv = key(userId, "iv");
        if (prefs.contains(pubKey) && prefs.contains(privateData) && prefs.contains(privateIv)) {
            try {
                privateKey(userId);
                return;
            } catch (Exception unusableBackupOrInvalidatedKey) {
                // Android Keystore keys are intentionally not portable. If encrypted
                // preferences were restored onto another device, create a new identity.
                prefs.edit().remove(pubKey).remove(privateData).remove(privateIv).commit();
            }
        }

        KeyPairGenerator generator = KeyPairGenerator.getInstance("EC");
        generator.initialize(new ECGenParameterSpec("secp256r1"), random);
        KeyPair pair = generator.generateKeyPair();

        Cipher wrap = Cipher.getInstance("AES/GCM/NoPadding");
        wrap.init(Cipher.ENCRYPT_MODE, wrappingKey());
        byte[] encryptedPrivate = wrap.doFinal(pair.getPrivate().getEncoded());
        boolean saved = prefs.edit()
                .putString(pubKey, Base64.encodeToString(pair.getPublic().getEncoded(), Base64.NO_WRAP))
                .putString(privateIv, Base64.encodeToString(wrap.getIV(), Base64.NO_WRAP))
                .putString(privateData, Base64.encodeToString(encryptedPrivate, Base64.NO_WRAP))
                .commit();
        if (!saved) throw new Exception("Не удалось сохранить ключ шифрования на телефоне");
    }

    private PrivateKey privateKey(String userId) throws Exception {
        Cipher unwrap = Cipher.getInstance("AES/GCM/NoPadding");
        byte[] iv = Base64.decode(prefs.getString(key(userId, "iv"), ""), Base64.NO_WRAP);
        byte[] data = Base64.decode(prefs.getString(key(userId, "priv"), ""), Base64.NO_WRAP);
        unwrap.init(Cipher.DECRYPT_MODE, wrappingKey(), new GCMParameterSpec(128, iv));
        byte[] encoded = unwrap.doFinal(data);
        return KeyFactory.getInstance("EC").generatePrivate(new PKCS8EncodedKeySpec(encoded));
    }

    private SecretKey wrappingKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (!store.containsAlias(WRAP_ALIAS)) {
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(WRAP_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .build());
            generator.generateKey();
        }
        return (SecretKey) store.getKey(WRAP_ALIAS, null);
    }

    private String key(String userId, String suffix) {
        return "identity:" + userId + ":" + suffix;
    }
}
