# Muwahid 0.13.23 build 58 — reference UI correction

- One-time migration switches existing installations to the approved light reference theme so old saved dark-mode preferences do not hide the redesign.
- Recent calls no longer render the legacy red telephone emoji; rows use the native vector phone icon and modern avatar layout.
- Generic settings/menu rows map legacy decorative glyphs to native vector icons.
- Existing voice rooms, shared PDF/book reading, chats, calls, E2EE, stickers, groups/channels and backend contracts are unchanged.
- versionName remains 0.13.23; only versionCode is increased to 58 so installed build 57 can detect the update.
