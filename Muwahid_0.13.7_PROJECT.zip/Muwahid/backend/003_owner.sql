-- TEMPLATE: replace owner UUID/email after checking the real confirmed account.
-- Owner access, scoped to the verified Muwahid account. Applied to the deployment after owner authorization.
begin;
create schema if not exists mw_private;
revoke all on schema mw_private from public,anon,authenticated;
create table mw_private.owner_account (
 singleton boolean primary key default true check(singleton),
 user_id uuid not null unique references auth.users(id) on delete restrict
);
alter table mw_private.owner_account enable row level security;
revoke all on mw_private.owner_account from public,anon,authenticated;
do $$ begin
 if not exists(select 1 from auth.users where id='00000000-0000-0000-0000-000000000000' and lower(email)='OWNER_EMAIL_TO_SET' and email_confirmed_at is not null) then
  raise exception 'Owner identity verification failed';
 end if;
end $$;
insert into mw_private.owner_account(singleton,user_id) values(true,'00000000-0000-0000-0000-000000000000');
create function public.mw_owner_status() returns jsonb language plpgsql security definer set search_path='' as $$
declare is_owner boolean; second_factor boolean;
begin
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 select exists(select 1 from mw_private.owner_account where user_id=auth.uid()) into is_owner;
 second_factor:=coalesce(auth.jwt()->>'aal','')='aal2';
 return jsonb_build_object('is_owner',is_owner,'mfa_verified',second_factor,'owner_access',is_owner and second_factor);
end $$;
create function public.mw_owner_overview() returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not exists(select 1 from mw_private.owner_account where user_id=auth.uid()) then
  raise exception 'MW:Доступ только для владельца';
 end if;
 if coalesce(auth.jwt()->>'aal','')<>'aal2' then raise exception 'MW:Подтвердите вход кодом второго фактора'; end if;
 return jsonb_build_object('users',(select count(*) from public.mw_profiles),'chats',(select count(*) from public.mw_chats),'messages',(select count(*) from public.mw_messages));
end $$;
revoke all on function public.mw_owner_status(),public.mw_owner_overview() from public,anon,authenticated;
grant execute on function public.mw_owner_status(),public.mw_owner_overview() to authenticated;
commit;
