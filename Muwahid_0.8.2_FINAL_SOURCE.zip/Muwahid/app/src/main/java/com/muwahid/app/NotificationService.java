package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.os.*;
import org.json.*;
import java.util.concurrent.*;

public final class NotificationService extends Service {
    private static final String CH_SERVICE="muwahid_service";
    private static final String CH_MSG="muwahid_messages";
    private static final String CH_CALL="muwahid_calls";
    private ScheduledExecutorService executor;
    private Api api;
    private android.content.SharedPreferences prefs;

    public static void ensureStarted(Context c){
        Intent i=new Intent(c,NotificationService.class);
        if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i); else c.startService(i);
    }
    public static void stop(Context c){c.stopService(new Intent(c,NotificationService.class));}

    @Override public void onCreate(){
        super.onCreate();api=new Api(new SecureStore(this));prefs=getSharedPreferences("muwahid_notify",MODE_PRIVATE);channels();
        Notification service=builder(CH_SERVICE).setSmallIcon(R.drawable.ic_launcher).setContentTitle("Muwahid").setContentText("Ожидание сообщений и звонков").setOngoing(true).build();
        startForeground(1001,service);
        executor=Executors.newSingleThreadScheduledExecutor();executor.scheduleWithFixedDelay(this::poll,1,5,TimeUnit.SECONDS);
    }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){if(executor!=null)executor.shutdownNow();super.onDestroy();}

    private Notification.Builder builder(String channel){return Build.VERSION.SDK_INT>=26?new Notification.Builder(this,channel):new Notification.Builder(this);}
    private void channels(){if(Build.VERSION.SDK_INT<26)return;NotificationManager n=getSystemService(NotificationManager.class);
        NotificationChannel s=new NotificationChannel(CH_SERVICE,"Фоновая связь",NotificationManager.IMPORTANCE_LOW);s.setDescription("Поддерживает уведомления Muwahid");n.createNotificationChannel(s);
        NotificationChannel m=new NotificationChannel(CH_MSG,"Сообщения",NotificationManager.IMPORTANCE_HIGH);m.setDescription("Новые сообщения");n.createNotificationChannel(m);
        NotificationChannel c=new NotificationChannel(CH_CALL,"Звонки",NotificationManager.IMPORTANCE_HIGH);c.setDescription("Входящие аудио- и видеозвонки");c.enableVibration(true);n.createNotificationChannel(c);
    }
    private void poll(){
        try{
            if(!api.signedIn()){stopSelf();return;}
            long after=prefs.getLong("cursor",0);
            JSONObject data=(JSONObject)api.rpc("mw_events_poll",new JSONObject().put("p_after",after));
            long cursor=data.optLong("cursor",after);
            JSONArray messages=data.optJSONArray("messages");
            if(after==0){prefs.edit().putLong("cursor",cursor).apply();}
            else if(messages!=null){for(int i=0;i<messages.length();i++){JSONObject m=messages.optJSONObject(i);if(m!=null)notifyMessage(m);}prefs.edit().putLong("cursor",Math.max(after,cursor)).apply();}
            JSONArray calls=data.optJSONArray("calls");if(calls!=null)for(int i=0;i<calls.length();i++){JSONObject c=calls.optJSONObject(i);if(c!=null)notifyCall(c);}
        }catch(Exception ignored){}
    }
    private void notifyMessage(JSONObject m){
        long id=m.optLong("id");if(id<=prefs.getLong("last_message_notification",0))return;
        Intent open=new Intent(this,MainActivity.class).putExtra("open_chat_id",m.optString("chat_id")).putExtra("open_chat_name",m.optString("sender_name")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,(int)(id&0x7fffffff),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=builder(CH_MSG).setSmallIcon(R.drawable.ic_launcher).setContentTitle(m.optString("sender_name","Новое сообщение")).setContentText("Новое защищённое сообщение").setAutoCancel(true).setContentIntent(pi).setCategory(Notification.CATEGORY_MESSAGE).setPriority(Notification.PRIORITY_HIGH).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify((int)(200000+(id%100000)),n);prefs.edit().putLong("last_message_notification",id).apply();
    }
    private void notifyCall(JSONObject c){
        String id=c.optString("id");if(id.isEmpty()||id.equals(prefs.getString("last_call_notification","")))return;
        Intent open=new Intent(this,CallActivity.class).putExtra("call_id",id).putExtra("incoming",true).putExtra("kind",c.optString("kind","audio")).putExtra("peer_name",c.optString("caller_name","Входящий звонок")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,id.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String kind="video".equals(c.optString("kind"))?"Видеозвонок":"Аудиозвонок";
        Notification.Builder b=builder(CH_CALL).setSmallIcon(R.drawable.ic_launcher).setContentTitle(c.optString("caller_name","Muwahid")).setContentText("Входящий "+kind.toLowerCase()).setCategory(Notification.CATEGORY_CALL).setPriority(Notification.PRIORITY_MAX).setAutoCancel(true).setContentIntent(pi).setFullScreenIntent(pi,true);if(Build.VERSION.SDK_INT>=26)b.setTimeoutAfter(90000);Notification n=b.build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(300000+Math.abs(id.hashCode()%50000),n);prefs.edit().putString("last_call_notification",id).apply();
    }
}
