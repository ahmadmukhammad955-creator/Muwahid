-- Muwahid 0.13.31: restore the latest creator-selected LIVE background.
-- No new tables; the current messages table and its media storage remain authoritative.
-- This function is read-only and fails closed for ended rooms and nonparticipants.
create or replace function public.mw_room_background_get(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare result jsonb;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null or not exists(
    select 1 from public.mw_voice_rooms r
    where r.id=p_room and r.active=true and (
      exists(select 1 from public.mw_voice_room_members mb where mb.room_id=r.id and mb.user_id=auth.uid())
      or exists(select 1 from public.mw_voice_room_waiting w where w.room_id=r.id and w.user_id=auth.uid())
    )
  ) then
    raise exception 'MW:Эфир закрыт или доступ запрещён';
  end if;
  select jsonb_build_object('id',m.id,'kind',m.kind,'path',m.media->>'path') into result
  from public.mw_voice_room_messages m
  join public.mw_voice_rooms r on r.id=m.room_id and r.created_by=m.sender_id
  where m.room_id=p_room and m.kind in ('image','video')
    and m.media @> '{"live_background":true}'::jsonb
    and m.media->>'path' like (p_room::text || '/background/%')
  order by m.id desc limit 1;
  return result;
end $$;
revoke all on function public.mw_room_background_get(uuid) from public,anon,authenticated;
grant execute on function public.mw_room_background_get(uuid) to authenticated;
