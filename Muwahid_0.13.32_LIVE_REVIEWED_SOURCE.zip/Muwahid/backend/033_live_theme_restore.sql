-- Muwahid 0.13.32: retrieve the most recent creator-selected room decoration.
-- This is needed only when the original decoration event has scrolled out of recent chat messages.
-- No room rows are deleted or modified. The function rejects ended rooms and outsiders.
create or replace function public.mw_room_theme_get(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null or not exists (
    select 1 from public.mw_voice_rooms r
    join public.mw_voice_room_members member on member.room_id=r.id and member.user_id=auth.uid()
    where r.id=p_room and r.active=true
  ) then raise exception 'MW:Эфир закрыт или доступ запрещён'; end if;
  select jsonb_build_object(
    'id',m.id,'live_theme',true,
    'theme',m.media->>'theme','layout',m.media->>'layout',
    'decor',m.media->>'decor','waves',m.media->>'waves'
  ) into result
  from public.mw_voice_room_messages m
  join public.mw_voice_rooms r on r.id=m.room_id and r.created_by=m.sender_id
  where m.room_id=p_room and m.media @> '{"live_theme":true}'::jsonb
  order by m.id desc limit 1;
  return result;
end $$;
revoke all on function public.mw_room_theme_get(uuid) from public,anon,authenticated;
grant execute on function public.mw_room_theme_get(uuid) to authenticated;
