-- Muwahid 0.12.5 phone authentication support
-- The live project already has mw_phone_countries populated from international calling metadata.
create table if not exists public.mw_phone_countries (
  sort_order integer primary key,
  iso2 text not null unique check (iso2 ~ '^[A-Z]{2}$'),
  name_en text not null,
  calling_code text not null check (calling_code ~ '^[+][1-9][0-9]{0,3}$'),
  flag text not null
);
alter table public.mw_phone_countries enable row level security;
drop policy if exists mw_phone_countries_read on public.mw_phone_countries;
create policy mw_phone_countries_read on public.mw_phone_countries for select to anon, authenticated using (true);
revoke all on table public.mw_phone_countries from public, anon, authenticated;
grant select on table public.mw_phone_countries to anon, authenticated;

create or replace function public.mw_phone_country_list()
returns table(sort_order integer, iso2 text, name_en text, calling_code text, flag text)
language sql stable security invoker set search_path=''
as $$
  select c.sort_order,c.iso2,c.name_en,c.calling_code,c.flag
  from public.mw_phone_countries c order by c.sort_order
$$;
revoke all on function public.mw_phone_country_list() from public, anon, authenticated;
grant execute on function public.mw_phone_country_list() to anon, authenticated;
