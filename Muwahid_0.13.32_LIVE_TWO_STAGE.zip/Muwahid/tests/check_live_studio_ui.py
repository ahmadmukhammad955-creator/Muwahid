"""Regression guard for LIVE Studio 2026 UI and existing click handlers.

Source checks only; actual server/WebRTC/device verification must remain separate.
"""
from pathlib import Path
import re
import subprocess
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/voice_room.html').read_text(encoding='utf-8')
java=(root/'app/src/main/java/com/muwahid/app/MainActivity.java').read_text(encoding='utf-8')
for id_, handler in {
    'mic':'micAction()',
    'cameraBtn':'cameraAction()',
    'participantsAction':'openParticipants()',
    'chatAction':'toolComments()',
    'moreAction':'openTools()',
    'exitRoomBtn':'requestExitRoom()',
}.items():
    assert re.search(r'<button[^>]*id="'+id_+r'"[^>]*onclick="'+re.escape(handler)+r'"', html), (id_,handler)
assert 'gridTemplateColumns=\'repeat(2,minmax(0,1fr))\'' in html
assert 'for(let position=1;position<=seatCount;position++)' in html
assert 'final int min=4,max=8;' in java
assert 'if(mode[0]==null||cap<4||cap>8)' in java
assert 'Math.min(12,capacity)' in html  # Legacy rooms continue showing every active seat.
assert 'function toggleStudioSpeaker()' in html and 'function studioInvite()' in html
scripts=re.findall(r'<script>(.*?)</script>',html,re.S)
assert len(scripts)==2 and len(scripts[-1])>10000
proc=subprocess.run(['node','--check','-'],input=scripts[-1],text=True,capture_output=True)
assert proc.returncode==0,proc.stderr
print('MW_LIVE_STUDIO_8_UI_SOURCE_OK')
