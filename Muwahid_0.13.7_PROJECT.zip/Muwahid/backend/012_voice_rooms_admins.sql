begin;

-- Muwahid 0.10.0: delegated administrators + moderated voice rooms.
-- The project owner remains exactly one immutable account. Admin is only a helper role.

create table if not exists mw_private.admins (
  user_id uuid primary key references public.mw_profiles(id) on delete cascade,
  granted_by uuid not null,
  granted_at timestamptz not null default now(),
  check (user_id <> '025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid),
  check (granted_by = '025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid)
);
alter table mw_private.admins enable row level security;
alter table mw_private.admins force row level security;
revoke all on table mw_private.admins from public, anon, authenticated;

create or replace function public.mw_owner_admin_set(p_user uuid, p_enabled boolean)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  perform mw_private.require_owner();
  if p_user is null or not exists(select 1 from public.mw_profiles p where p.id=p_user) then
    raise exception 'MW:Пользователь не найден';
  end if;
  if p_user='025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then
    raise exception 'MW:Владелец не является администратором. Это отдельная неизменяемая роль.';
  end if;
  if p_enabled then
    insert into mw_private.admins(user_id,granted_by)
    values(p_user,'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid)
    on conflict(user_id) do update set granted_by=excluded.granted_by,granted_at=now();
  else
    delete from mw_private.admins where user_id=p_user;
  end if;
  return jsonb_build_object('user_id',p_user,'is_admin',p_enabled);
end
$$;

create or replace function public.mw_admin_list()
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  perform mw_private.require_owner();
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',p.id,'display_name',p.display_name,'username',p.username,'granted_at',a.granted_at
  ) order by a.granted_at),'[]'::jsonb)
  into result
  from mw_private.admins a join public.mw_profiles p on p.id=a.user_id;
  return result;
end
$$;

create table if not exists public.mw_voice_rooms (
  id uuid primary key default gen_random_uuid(),
  title text not null check(char_length(btrim(title)) between 1 and 80),
  created_by uuid not null references public.mw_profiles(id) on delete cascade,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.mw_voice_room_members (
  room_id uuid not null references public.mw_voice_rooms(id) on delete cascade,
  user_id uuid not null references public.mw_profiles(id) on delete cascade,
  seat smallint not null check(seat between 1 and 8),
  joined_at timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  primary key(room_id,user_id),
  unique(room_id,seat)
);

create table if not exists public.mw_voice_room_hands (
  room_id uuid not null references public.mw_voice_rooms(id) on delete cascade,
  user_id uuid not null references public.mw_profiles(id) on delete cascade,
  raised_at timestamptz not null default now(),
  primary key(room_id,user_id)
);

create table if not exists public.mw_voice_room_floor (
  room_id uuid primary key references public.mw_voice_rooms(id) on delete cascade,
  user_id uuid references public.mw_profiles(id) on delete set null,
  granted_by uuid references public.mw_profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);

create table if not exists public.mw_voice_room_bans (
  room_id uuid not null references public.mw_voice_rooms(id) on delete cascade,
  user_id uuid not null references public.mw_profiles(id) on delete cascade,
  banned_by uuid not null references public.mw_profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(room_id,user_id)
);

create table if not exists public.mw_voice_room_signals (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.mw_voice_rooms(id) on delete cascade,
  from_user uuid not null references public.mw_profiles(id) on delete cascade,
  to_user uuid not null references public.mw_profiles(id) on delete cascade,
  kind text not null check(kind in ('offer','answer','ice','bye')),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists mw_voice_room_signals_target_idx on public.mw_voice_room_signals(room_id,to_user,id);

alter table public.mw_voice_rooms enable row level security;
alter table public.mw_voice_room_members enable row level security;
alter table public.mw_voice_room_hands enable row level security;
alter table public.mw_voice_room_floor enable row level security;
alter table public.mw_voice_room_bans enable row level security;
alter table public.mw_voice_room_signals enable row level security;
revoke all on public.mw_voice_rooms,public.mw_voice_room_members,public.mw_voice_room_hands,public.mw_voice_room_floor,public.mw_voice_room_bans,public.mw_voice_room_signals from public,anon,authenticated;
revoke all on sequence public.mw_voice_room_signals_id_seq from public,anon,authenticated;

create or replace function mw_private.role_rank(p_user uuid, p_room uuid default null)
returns integer
language sql
stable
security definer
set search_path=''
as $$
  select case
    when p_user = '025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then 30
    when exists(select 1 from mw_private.admins a where a.user_id=p_user) then 20
    when p_room is not null and exists(select 1 from public.mw_voice_rooms r where r.id=p_room and r.created_by=p_user) then 10
    else 0
  end
$$;
revoke all on function mw_private.role_rank(uuid,uuid) from public, anon, authenticated;

create or replace function public.mw_role_status()
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare r integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  r := mw_private.role_rank(auth.uid(),null);
  return jsonb_build_object(
    'is_owner', r=30,
    'is_admin', r=20,
    'role', case when r=30 then 'owner' when r=20 then 'admin' else 'user' end
  );
end
$$;

create or replace function mw_private.room_cleanup(p_room uuid)
returns void
language plpgsql
security definer
set search_path=''
as $$
begin
  delete from public.mw_voice_room_members m
  where m.room_id=p_room and m.last_seen < now()-interval '90 seconds';
  delete from public.mw_voice_room_hands h
  where h.room_id=p_room and not exists(
    select 1 from public.mw_voice_room_members m where m.room_id=h.room_id and m.user_id=h.user_id
  );
  update public.mw_voice_room_floor f set user_id=null,granted_by=null,updated_at=now()
  where f.room_id=p_room and f.user_id is not null and not exists(
    select 1 from public.mw_voice_room_members m where m.room_id=f.room_id and m.user_id=f.user_id
  );
  delete from public.mw_voice_room_signals s where s.created_at < now()-interval '10 minutes';
end
$$;
revoke all on function mw_private.room_cleanup(uuid) from public,anon,authenticated;

create or replace function mw_private.room_can_moderate(p_room uuid,p_user uuid)
returns boolean
language sql
stable
security definer
set search_path=''
as $$ select mw_private.role_rank(p_user,p_room) >= 10 $$;
revoke all on function mw_private.room_can_moderate(uuid,uuid) from public,anon,authenticated;

create or replace function public.mw_room_create(p_title text)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare rid uuid;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if char_length(btrim(p_title)) not between 1 and 80 then raise exception 'MW:Название комнаты должно содержать 1–80 символов'; end if;
  insert into public.mw_voice_rooms(title,created_by) values(btrim(p_title),auth.uid()) returning id into rid;
  insert into public.mw_voice_room_members(room_id,user_id,seat) values(rid,auth.uid(),1);
  insert into public.mw_voice_room_floor(room_id) values(rid) on conflict do nothing;
  return jsonb_build_object('id',rid,'title',btrim(p_title));
end
$$;

create or replace function public.mw_room_list()
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  delete from public.mw_voice_room_members m where m.last_seen < now()-interval '90 seconds';
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',r.id,'title',r.title,'created_at',r.created_at,
    'participants',(select count(*) from public.mw_voice_room_members m where m.room_id=r.id),
    'speaker',(select p.display_name from public.mw_voice_room_floor f join public.mw_profiles p on p.id=f.user_id where f.room_id=r.id)
  ) order by r.created_at desc),'[]'::jsonb)
  into result from public.mw_voice_rooms r where r.active=true;
  return result;
end
$$;

create or replace function public.mw_room_join(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare s integer; room_title text;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  perform mw_private.room_cleanup(p_room);
  select title into room_title from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта или не существует'; end if;
  if exists(select 1 from public.mw_voice_room_bans where room_id=p_room and user_id=auth.uid()) then raise exception 'MW:Вы заблокированы в этой комнате'; end if;
  update public.mw_voice_room_members set last_seen=now() where room_id=p_room and user_id=auth.uid();
  if found then return jsonb_build_object('room_id',p_room,'title',room_title); end if;
  select g into s from generate_series(1,8) g
  where not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=g)
  order by g limit 1;
  if s is null then raise exception 'MW:В комнате уже заняты все 8 мест'; end if;
  insert into public.mw_voice_room_members(room_id,user_id,seat) values(p_room,auth.uid(),s);
  return jsonb_build_object('room_id',p_room,'title',room_title,'seat',s);
end
$$;

create or replace function public.mw_room_leave(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  if auth.uid() is null then return jsonb_build_object('left',true); end if;
  delete from public.mw_voice_room_hands where room_id=p_room and user_id=auth.uid();
  delete from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid();
  update public.mw_voice_room_floor set user_id=null,granted_by=null,updated_at=now()
    where room_id=p_room and user_id=auth.uid();
  delete from public.mw_voice_room_signals where room_id=p_room and (from_user=auth.uid() or to_user=auth.uid());
  return jsonb_build_object('left',true);
end
$$;

create or replace function public.mw_room_state(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb; my_rank integer; floor_user uuid; can_mod boolean; room_title text; room_creator uuid;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  perform mw_private.room_cleanup(p_room);
  update public.mw_voice_room_members set last_seen=now() where room_id=p_room and user_id=auth.uid();
  if not found then raise exception 'MW:Вы больше не участник комнаты'; end if;
  select title,created_by into room_title,room_creator from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта'; end if;
  select f.user_id into floor_user from public.mw_voice_room_floor f where f.room_id=p_room;
  my_rank:=mw_private.role_rank(auth.uid(),p_room); can_mod:=my_rank>=10;
  select jsonb_build_object(
    'id',p_room,'title',room_title,'self_id',auth.uid(),'created_by',room_creator,
    'role',case when my_rank=30 then 'owner' when my_rank=20 then 'admin' when my_rank=10 then 'host' else 'user' end,
    'can_moderate',can_mod,'floor_user',floor_user,
    'members',coalesce((select jsonb_agg(jsonb_build_object(
      'id',p.id,'display_name',p.display_name,'username',p.username,'seat',m.seat,
      'hand_raised',exists(select 1 from public.mw_voice_room_hands h where h.room_id=m.room_id and h.user_id=m.user_id),
      'role',case when mw_private.role_rank(p.id,p_room)=30 then 'owner' when mw_private.role_rank(p.id,p_room)=20 then 'admin' when mw_private.role_rank(p.id,p_room)=10 then 'host' else 'user' end
    ) order by m.seat)
    from public.mw_voice_room_members m join public.mw_profiles p on p.id=m.user_id where m.room_id=p_room),'[]'::jsonb)
  ) into result;
  return result;
end
$$;

create or replace function public.mw_room_raise_hand(p_room uuid,p_raised boolean)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  if auth.uid() is null or not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) then
    raise exception 'MW:Сначала войдите в комнату';
  end if;
  if p_raised then
    insert into public.mw_voice_room_hands(room_id,user_id) values(p_room,auth.uid())
      on conflict(room_id,user_id) do update set raised_at=now();
  else
    delete from public.mw_voice_room_hands where room_id=p_room and user_id=auth.uid();
  end if;
  return jsonb_build_object('raised',p_raised);
end
$$;

create or replace function public.mw_room_grant_floor(p_room uuid,p_user uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare caller_rank integer; target_rank integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  caller_rank:=mw_private.role_rank(auth.uid(),p_room);
  if caller_rank<10 then raise exception 'MW:Только ведущий, администратор или владелец может включить микрофон'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_user) then raise exception 'MW:Участник уже вышел'; end if;
  target_rank:=mw_private.role_rank(p_user,p_room);
  -- A helper admin/host cannot forcibly take the floor away from the immutable owner.
  if exists(select 1 from public.mw_voice_room_floor f where f.room_id=p_room and f.user_id='025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid)
     and auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid
     and p_user<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then
    raise exception 'MW:Микрофон владельца может изменить только владелец';
  end if;
  insert into public.mw_voice_room_floor(room_id,user_id,granted_by,updated_at)
  values(p_room,p_user,auth.uid(),now())
  on conflict(room_id) do update set user_id=excluded.user_id,granted_by=excluded.granted_by,updated_at=now();
  delete from public.mw_voice_room_hands where room_id=p_room and user_id=p_user;
  delete from public.mw_voice_room_signals where room_id=p_room;
  return jsonb_build_object('floor_user',p_user);
end
$$;

create or replace function public.mw_room_release_floor(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare current_user uuid; caller_rank integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  select user_id into current_user from public.mw_voice_room_floor where room_id=p_room;
  caller_rank:=mw_private.role_rank(auth.uid(),p_room);
  if current_user is null then return jsonb_build_object('floor_user',null); end if;
  if current_user<>auth.uid() and caller_rank<10 then raise exception 'MW:Нет права выключить чужой микрофон'; end if;
  if current_user='025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid and auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then
    raise exception 'MW:Микрофон владельца может выключить только владелец';
  end if;
  update public.mw_voice_room_floor set user_id=null,granted_by=null,updated_at=now() where room_id=p_room;
  delete from public.mw_voice_room_signals where room_id=p_room;
  return jsonb_build_object('floor_user',null);
end
$$;

create or replace function public.mw_room_kick(p_room uuid,p_user uuid,p_ban boolean default false)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare caller_rank integer; target_rank integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  caller_rank:=mw_private.role_rank(auth.uid(),p_room); target_rank:=mw_private.role_rank(p_user,p_room);
  if caller_rank<10 then raise exception 'MW:Нет прав модератора'; end if;
  if p_user='025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then raise exception 'MW:Владелец не может быть удалён или заблокирован'; end if;
  if auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid and caller_rank<=target_rank then
    raise exception 'MW:Нельзя ограничить участника с равной или более высокой ролью';
  end if;
  if p_ban then
    insert into public.mw_voice_room_bans(room_id,user_id,banned_by) values(p_room,p_user,auth.uid())
    on conflict(room_id,user_id) do update set banned_by=excluded.banned_by,created_at=now();
  end if;
  delete from public.mw_voice_room_hands where room_id=p_room and user_id=p_user;
  delete from public.mw_voice_room_members where room_id=p_room and user_id=p_user;
  update public.mw_voice_room_floor set user_id=null,granted_by=null,updated_at=now() where room_id=p_room and user_id=p_user;
  delete from public.mw_voice_room_signals where room_id=p_room and (from_user=p_user or to_user=p_user);
  return jsonb_build_object('removed',p_user,'banned',p_ban);
end
$$;

create or replace function public.mw_room_end(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  if auth.uid() is null or not mw_private.room_can_moderate(p_room,auth.uid()) then raise exception 'MW:Нет права закрыть комнату'; end if;
  update public.mw_voice_rooms set active=false where id=p_room;
  delete from public.mw_voice_room_members where room_id=p_room;
  delete from public.mw_voice_room_hands where room_id=p_room;
  delete from public.mw_voice_room_signals where room_id=p_room;
  return jsonb_build_object('closed',true);
end
$$;

create or replace function public.mw_room_signal_send(p_room uuid,p_to uuid,p_kind text,p_payload jsonb)
returns bigint
language plpgsql
security definer
set search_path=''
as $$
declare floor_user uuid; new_id bigint;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if p_kind not in ('offer','answer','ice','bye') then raise exception 'MW:Некорректный сигнал'; end if;
  if auth.uid()=p_to then raise exception 'MW:Некорректный получатель'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid())
     or not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_to) then
    raise exception 'MW:Участник уже вышел из комнаты';
  end if;
  select user_id into floor_user from public.mw_voice_room_floor where room_id=p_room;
  if floor_user is null then raise exception 'MW:Сейчас никто не говорит'; end if;
  if p_kind='offer' and auth.uid()<>floor_user then raise exception 'MW:Offer может отправлять только говорящий'; end if;
  if p_kind='answer' and p_to<>floor_user then raise exception 'MW:Answer должен быть отправлен говорящему'; end if;
  if p_kind in ('ice','bye') and auth.uid()<>floor_user and p_to<>floor_user then raise exception 'MW:Сигнал не относится к текущему говорящему'; end if;
  insert into public.mw_voice_room_signals(room_id,from_user,to_user,kind,payload)
  values(p_room,auth.uid(),p_to,p_kind,coalesce(p_payload,'{}'::jsonb)) returning id into new_id;
  return new_id;
end
$$;

create or replace function public.mw_room_signal_poll(p_room uuid,p_after bigint default 0)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  if auth.uid() is null or not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) then
    raise exception 'MW:Вы больше не участник комнаты';
  end if;
  update public.mw_voice_room_members set last_seen=now() where room_id=p_room and user_id=auth.uid();
  select coalesce(jsonb_agg(to_jsonb(x) order by x.id),'[]'::jsonb) into result from (
    select s.id,s.from_user,s.kind,s.payload,s.created_at
    from public.mw_voice_room_signals s
    where s.room_id=p_room and s.to_user=auth.uid() and s.id>coalesce(p_after,0)
    order by s.id asc limit 100
  ) x;
  return result;
end
$$;

revoke all on function public.mw_role_status(),public.mw_owner_admin_set(uuid,boolean),public.mw_admin_list(),
  public.mw_room_create(text),public.mw_room_list(),public.mw_room_join(uuid),public.mw_room_leave(uuid),
  public.mw_room_state(uuid),public.mw_room_raise_hand(uuid,boolean),public.mw_room_grant_floor(uuid,uuid),
  public.mw_room_release_floor(uuid),public.mw_room_kick(uuid,uuid,boolean),public.mw_room_end(uuid),
  public.mw_room_signal_send(uuid,uuid,text,jsonb),public.mw_room_signal_poll(uuid,bigint)
from public,anon,authenticated;

grant execute on function public.mw_role_status(),public.mw_owner_admin_set(uuid,boolean),public.mw_admin_list(),
  public.mw_room_create(text),public.mw_room_list(),public.mw_room_join(uuid),public.mw_room_leave(uuid),
  public.mw_room_state(uuid),public.mw_room_raise_hand(uuid,boolean),public.mw_room_grant_floor(uuid,uuid),
  public.mw_room_release_floor(uuid),public.mw_room_kick(uuid,uuid,boolean),public.mw_room_end(uuid),
  public.mw_room_signal_send(uuid,uuid,text,jsonb),public.mw_room_signal_poll(uuid,bigint)
to authenticated;

commit;
