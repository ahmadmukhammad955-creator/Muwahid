# Muwahid 0.12.4 security hardening

- Production updates are built from the Android `release` variant, never from `debug`.
- R8/code shrinking and resource shrinking are enabled for release builds.
- WebView debugging is disabled and call/voice-room WebViews reject external top-level navigation.
- Camera/microphone WebView permission grants are restricted to the trusted local origin `https://muwahid.local`.
- External HTTP(S) subresources are blocked from bridge-enabled WebViews.
- JavaScript bridge method names are preserved explicitly for R8.
- Supabase complaint-table privileges are reduced to `SELECT` and `INSERT` for authenticated users.

Do not put service-role keys, database passwords, GitHub tokens, signing-key passwords, or private keys in the APK or repository.

## 2026-10-05 live audit patch
- Restored MFA guards after later SQL migrations overwrote protected RPC definitions.
- Legacy `mw_find_person` no longer returns the whole profile row / peer phone number.
- Added size/count bounds for ICE candidates and voice-room signaling/media metadata.
- Future functions created by the `postgres` migration role default to no `anon`/`authenticated` EXECUTE until explicitly granted.
- Current architecture intentionally keeps direct table grants closed and exposes validated RPCs; Supabase Advisor may still flag these RPCs as SECURITY DEFINER by design.
