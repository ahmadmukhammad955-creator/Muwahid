package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.provider.ContactsContract;
import android.location.*;
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.hardware.*;
import android.content.res.Configuration;
import android.content.pm.PackageManager;
import androidx.core.content.FileProvider;
import java.io.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity implements SensorEventListener {
    private static final String OWNER_UUID="025a8bd0-c7ff-4e39-802a-f1c39ab76a9c";
    private int bg, panel, text, muted, line;
    private int accent=Color.rgb(16,214,171), cyan=Color.rgb(22,191,231);
    private LinearLayout root, content, list, messages;
    private ScrollView messageScroll;
    private TextView connection, chatPresenceStatus, activeCallBanner;
    private EditText composer;
    private Button sendButton, attachButton, emojiButton, videoMessageButton, voiceCancelButton, voicePauseButton;
    private Uri pendingCameraPhotoUri;
    private static final int REQ_IMAGE=6101, REQ_VIDEO=6102, REQ_AUDIO=6103, REQ_VIDEO_MESSAGE=6104, REQ_CHAT_WALLPAPER=6105, REQ_DOCUMENT=6106, REQ_CAMERA_PHOTO=6107, REQ_CAMERA_VIDEO=6108, REQ_CONTACT=6109, REQ_MW_CAMERA=6110, REQ_MW_LOCATION=6111, REQ_MW_DOCUMENT=6112, REQ_CALL_RINGTONE=6113, REQ_PROFILE_BACKGROUND=6114, REQ_STICKER_IMPORT=6115;
    private static final int REQ_RECORD_AUDIO_PERMISSION=6201, REQ_VIDEO_MESSAGE_PERMISSION=6202, REQ_CAMERA_PHOTO_PERMISSION=6203, REQ_LOCATION_PERMISSION=6204, REQ_CAMERA_VIDEO_PERMISSION=6205;
    private MediaRecorder voiceRecorder;
    private MediaPlayer inlineVoicePlayer;
    private String inlineVoicePath="";
    private TextView inlineVoiceButton, inlineVoiceDuration;
    private long inlineVoiceKnownDuration;
    private float inlineVoiceSpeed=1f;
    private TextView inlineVoiceSpeedButton;
    private final Map<String,File> inlineVoiceCache=Collections.synchronizedMap(new HashMap<>());
    private final Set<String> inlineVoiceLoading=Collections.synchronizedSet(new HashSet<>());
    private final Runnable inlineVoiceTicker=new Runnable(){public void run(){
        if(inlineVoicePlayer==null)return;
        try{
            long pos=inlineVoicePlayer.getCurrentPosition(),dur=inlineVoicePlayer.getDuration();
            if(inlineVoiceDuration!=null)inlineVoiceDuration.setText(formatDuration(pos)+" / "+formatDuration(dur));
            if(inlineVoicePlayer.isPlaying())handler.postDelayed(this,200);
        }catch(Exception ignored){}
    }};
    private File voiceFile;
    private boolean voiceRecording, voicePaused;
    private long voiceStartedAt, voicePauseStartedAt, voicePausedTotal;
    private AudioManager audioManager;
    private boolean voiceAudioFocus, proximityStartedRecording;
    private SensorManager sensorManager;
    private Sensor proximitySensor;
    private final Runnable voiceTicker=new Runnable(){public void run(){
        if(!voiceRecording)return;
        long now=System.currentTimeMillis();
        long paused=voicePausedTotal+(voicePaused?Math.max(0,now-voicePauseStartedAt):0);
        long elapsed=Math.max(0,now-voiceStartedAt-paused);
        if(connection!=null)connection.setText(voicePaused?("⏸ Пауза · "+formatDuration(elapsed)+" · можно продолжить или завершить"):("🎙 Запись "+formatDuration(elapsed)+" · пауза, отмена или готово"));
        if(elapsed>=120000){stopVoiceRecording(true);return;}
        handler.postDelayed(this,500);
    }};
    private Api api;
    private CryptoBox crypto;
    private android.content.SharedPreferences prefs;
    private RemoteConfig remote;
    private long remoteAttemptAt;
    private JSONObject stickerCloudCatalog=new JSONObject();
    private long stickerCloudLoadedAt;
    private String pendingStickerPackId="";
    private final ArrayList<Uri> pendingSharedStickerUris=new ArrayList<>();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private String screen="welcome", chatId="", chatName="", filter="", chatPeerLastSeen="";
    private boolean chatPeerOnline;
    private String chatFolderFilter="all";
    private String mainTab="Все";
    private boolean phoneRegisterMode;
    private PhoneEntryView phoneEntry;
    private String pendingText="", pendingNonce="", peerE2eeKey="";
    private volatile String pendingPayload="", e2eePublishedFor="";
    private volatile boolean e2eePublishing;
    private boolean e2eeBackendReady;
    private JSONArray chats=new JSONArray();
    private final TreeMap<Long,JSONObject> history=new TreeMap<>();
    private JSONObject profile=new JSONObject();
    private int generation=0;
    private boolean foreground, loading, sending, notesMode, olderAvailable;
    private final Runnable poll=new Runnable(){public void run(){
        if(!foreground)return;
        if(!loading&&!sending&&api.signedIn()){
            if(screen.equals("chats"))loadChats(false);
            else if(screen.equals("chat")&&!notesMode)loadMessages(false);
        }
        handler.postDelayed(this,prefs.getBoolean("energy_saver",false)?12000:5000);
    }};
    private final Runnable presenceHeartbeat=new Runnable(){public void run(){
        if(!foreground||api==null||!api.signedIn())return;
        updatePresence(true);
        handler.postDelayed(this,20000);
    }};
    interface Task { Object run() throws Exception; }
    interface Done { void accept(Object result) throws Exception; }
    interface JsonDone { void accept(JSONObject result) throws Exception; }
    interface StringDone { void accept(String value); }
    @Override public void onCreate(Bundle b){
        super.onCreate(b); if(AppLock.guard(this))return; prefs=getSharedPreferences("muwahid",MODE_PRIVATE); api=new Api(new SecureStore(this)); crypto=new CryptoBox(this); remote=new RemoteConfig(prefs); audioManager=(AudioManager)getSystemService(AUDIO_SERVICE); sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE); proximitySensor=sensorManager==null?null:sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY); colors();
        UpdateManager.checkOnLaunch(this);
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        if(getIntent().getBooleanExtra("open_security_mfa",false)){showTwoFactor();return;}
        if(handleOAuthIntent(getIntent()))return;
        if(api.signedIn()){maybeStartNotifications();if(getIntent().getBooleanExtra("open_contacts",false))showContacts();else{String id=getIntent().getStringExtra("open_chat_id");String name=getIntent().getStringExtra("open_chat_name");if(id!=null&&!id.isEmpty())showChat(id,name==null?"Чат":name);else showChats();}handler.post(()->handleSharedStickerIntent(getIntent()));}else showWelcome();
        refreshRemoteConfig(true);
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(intent.getBooleanExtra("open_security_mfa",false)){showTwoFactor();return;}if(handleOAuthIntent(intent))return;if(api.signedIn()){if(handleSharedStickerIntent(intent))return;if(intent.getBooleanExtra("open_contacts",false)){showContacts();return;}String id=intent.getStringExtra("open_chat_id");if(id!=null&&!id.isEmpty())showChat(id,intent.getStringExtra("open_chat_name"));}}
    private boolean handleOAuthIntent(Intent intent){
        Uri data=intent==null?null:intent.getData();
        if(data==null||!"muwahid".equalsIgnoreCase(data.getScheme())||!"auth-callback".equalsIgnoreCase(data.getHost()))return false;
        begin("oauth");toolbar("Вход через Google",false,null,null);scrollContent();note(content,"Завершаем безопасный вход через Google…");
        final int stamp=generation;final String fragment=data.getFragment();
        worker.execute(()->{try{api.acceptOAuthCallback(fragment);handler.post(()->{if(stamp!=generation)return;maybeStartNotifications();showChats();});}catch(Exception ex){handler.post(()->{if(stamp!=generation)return;error(ex);showAuth(false);});}});
        return true;
    }
    private void maybeStartNotifications(){
        boolean messages=prefs.getBoolean("notify_messages",true),calls=prefs.getBoolean("notify_calls",true),updates=prefs.getBoolean("notify_updates",true);
        if(!messages&&!calls&&!updates){try{NotificationService.stop(this);}catch(Exception ignored){}return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=getPackageManager().PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},7001);
        try{NotificationService.ensureStarted(this);}catch(Exception ignored){}
    }
    @Override protected void onResume(){
        super.onResume();if(isFinishing()||AppLock.guard(this))return;foreground=true;handler.removeCallbacks(poll);
        // If Android restored an already authenticated task on the public welcome screen,
        // return the user to the messenger instead of showing registration again.
        handler.removeCallbacks(presenceHeartbeat);
        if(api!=null && api.signedIn()){updatePresence(true);handler.postDelayed(presenceHeartbeat,20000);}
        if(api!=null && api.signedIn() && "welcome".equals(screen)){showChats();refreshRemoteConfig(false);return;}
        refreshRemoteConfig(false);
        updateProximityListener();
        if("chats".equals(screen))syncActiveCallBanner();
        handler.postDelayed(poll,prefs.getBoolean("energy_saver",false)?12000:5000);
    }
    @Override protected void onPause(){saveDraft();foreground=false;handler.removeCallbacks(poll);handler.removeCallbacks(presenceHeartbeat);unregisterProximity();if(api!=null&&api.signedIn())updatePresence(false);if(voiceRecording)cancelVoiceRecording(false);super.onPause();}
    @Override protected void onDestroy(){unregisterProximity();stopInlineVoice();abandonVoiceAudioFocus();handler.removeCallbacksAndMessages(null);worker.shutdownNow();if(phoneEntry!=null)phoneEntry.dispose();super.onDestroy();}
    private void colors(){
        boolean dark;
        String mode=prefs.getString("theme_mode",prefs.getBoolean("dark",true)?"dark":"light");
        if("system".equals(mode))dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;else dark=!"light".equals(mode);
        prefs.edit().putBoolean("dark",dark).apply();
        String theme=prefs.getString("chat_theme","mint");
        if("blue".equals(theme)){accent=Color.parseColor("#3D9BFF");cyan=Color.parseColor("#66C8FF");}
        else if("orange".equals(theme)){accent=Color.parseColor("#F09B35");cyan=Color.parseColor("#FFD05A");}
        else if("pink".equals(theme)){accent=Color.parseColor("#E66BC4");cyan=Color.parseColor("#8C73FF");}
        else if("ocean".equals(theme)){accent=Color.parseColor("#18B9C8");cyan=Color.parseColor("#3A8DFF");}
        else {accent=Color.rgb(16,214,171);cyan=Color.rgb(22,191,231);}
        bg=Color.parseColor(dark?"#17212B":"#F3F6FA");panel=Color.parseColor(dark?"#1E2A36":"#FFFFFF");text=Color.parseColor(dark?"#F4F8FD":"#132033");muted=Color.parseColor(dark?"#7F8D99":"#60728A");line=Color.parseColor(dark?"#183149":"#DDE5EE");
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    private void bold(TextView t){t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable gradient(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{accent,cyan});d.setCornerRadius(dp(18));return d;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(16);b.setTextColor(Color.rgb(3,27,39));b.setBackground(gradient());b.setMinHeight(dp(50));return b;}
    private void gap(LinearLayout l,int h){l.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(h)));}
    private void note(LinearLayout l,String s){TextView t=label(s,13,muted);t.setLineSpacing(dp(3),1);l.addView(t);}
    private void notice(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("Понятно",null).show();}
    private void error(Exception e){if(e instanceof Api.MfaRequiredException){showTwoFactor();return;}String s=e.getMessage();if(e instanceof java.io.IOException)s="Нет связи с сервером. Проверьте интернет и попробуйте снова.";notice(s==null?"Не удалось выполнить действие":s);}
    private void refreshRemoteConfig(boolean force){
        if(remote==null||api==null||!api.configured())return;
        long now=System.currentTimeMillis();
        if(!force && now-remoteAttemptAt<60000)return;
        remoteAttemptAt=now;
        final String activeScreen=screen;
        worker.execute(()->{try{
            Object value=api.publicRpc("mw_app_config",new JSONObject());
            if(!(value instanceof JSONObject))return;
            boolean changed=remote.replace((JSONObject)value);
            if(!changed)return;
            handler.post(()->{
                if(isFinishing()||isDestroyed())return;
                if("welcome".equals(activeScreen)&&"welcome".equals(screen))showWelcome();
                // Keep the current phone entry and country picker intact during config refresh.
                else if("settings".equals(activeScreen)&&"settings".equals(screen))showSettings();
                else if("chats".equals(activeScreen)&&"chats".equals(screen))showHub(mainTab);
            });
        }catch(Exception ignored){}});
    }
    private boolean feature(String key,boolean fallback){return remote==null?fallback:remote.bool("features."+key,fallback);}
    private String rc(String key,String fallback){return remote==null?fallback:remote.text(key,fallback);}
    private void async(Task task,Done done){final int stamp=generation;loading=true;
        worker.execute(()->{Object value=null;Exception error=null;try{value=task.run();}catch(Exception e){error=e;}final Object v=value;final Exception err=error;
            handler.post(()->{loading=false;if(isFinishing()||isDestroyed()||stamp!=generation)return;try{if(err!=null)throw err;done.accept(v);}catch(Exception e){error(e);}});
        });
    }
    private void begin(String name){unregisterProximity();if(phoneEntry!=null){phoneEntry.dispose();phoneEntry=null;}stopInlineVoice();if(!AppLock.enabled(this))getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);saveDraft();screen=name;generation++;colors();getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);root=vertical();root.setBackgroundColor(bg);setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        root.requestApplyInsets();composer=null;sendButton=null;attachButton=null;emojiButton=null;videoMessageButton=null;voiceCancelButton=null;voicePauseButton=null;activeCallBanner=null;
    }
    private void toolbar(String title,boolean back,String action,Runnable onAction){
        LinearLayout bar=horizontal();bar.setPadding(dp(16),dp(8),dp(16),dp(8));
        if(back){TextView b=label("‹",36,text);b.setGravity(Gravity.CENTER);b.setContentDescription("Назад");bar.addView(b,new LinearLayout.LayoutParams(dp(38),dp(42)));b.setOnClickListener(v->onBackPressed());}
        else{Logo logo=new Logo(this,false);bar.addView(logo,new LinearLayout.LayoutParams(dp(34),dp(40)));}
        TextView t=label(title,21,text);bold(t);t.setPadding(dp(10),0,0,0);bar.addView(t,new LinearLayout.LayoutParams(0,dp(44),1));t.setGravity(Gravity.CENTER_VERTICAL);
        if(action!=null){TextView a=label(action,25,accent);a.setGravity(Gravity.CENTER);bar.addView(a,new LinearLayout.LayoutParams(dp(44),dp(44)));a.setOnClickListener(v->onAction.run());}
        root.addView(bar);View rule=new View(this);rule.setBackgroundColor(line);root.addView(rule,new LinearLayout.LayoutParams(-1,dp(1)));
    }
    private void scrollContent(){ScrollView s=new ScrollView(this);s.setFillViewport(true);content=vertical();content.setPadding(dp(22),dp(20),dp(22),dp(24));s.addView(content);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));}

    private void bottom(String selected){
        final int navy=Color.parseColor("#061522"), cyanRef=Color.parseColor("#18C7D7"), inactive=Color.parseColor("#7C8DA2");
        View topRule=new View(this);topRule.setBackgroundColor(Color.parseColor("#11293C"));root.addView(topRule,new LinearLayout.LayoutParams(-1,dp(1)));
        LinearLayout nav=horizontal();nav.setPadding(dp(5),dp(4),dp(5),dp(6));nav.setBackgroundColor(navy);
        String[] names={"Чаты","Звонки","Контакты","Настройки"};String[] icons={"chat","phone","contacts","settings"};
        for(int i=0;i<4;i++){
            final int index=i;boolean active=selected.equals(names[i]);LinearLayout item=vertical();item.setGravity(Gravity.CENTER);item.setPadding(0,dp(2),0,0);
            ImageView icon=refIcon(icons[i],active?cyanRef:inactive);icon.setPadding(dp(5),dp(5),dp(5),dp(5));item.addView(icon,new LinearLayout.LayoutParams(dp(32),dp(32)));
            TextView caption=label(names[i],11,active?cyanRef:inactive);caption.setGravity(Gravity.CENTER);caption.setPadding(0,0,0,0);if(active)bold(caption);item.addView(caption,new LinearLayout.LayoutParams(-1,dp(20)));
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(58),1));
            item.setOnClickListener(v->{if(index==0)showChats();else if(index==1)showRecentCalls();else if(index==2)showContacts();else showSettings();});
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(64)));
    }

    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setTextSize(16);e.setTextColor(text);e.setHintTextColor(muted);e.setHint(hint);e.setSingleLine(true);e.setPadding(dp(16),dp(14),dp(16),dp(14));e.setBackground(shape(panel,14));if(password)e.setInputType(129);else e.setInputType(1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.bottomMargin=dp(12);content.addView(e,p);return e;}
    private LinearLayout settingsCard(){LinearLayout card=vertical();card.setBackground(shape(panel,22));card.setPadding(dp(8),dp(7),dp(8),dp(7));content.addView(card,new LinearLayout.LayoutParams(-1,-2));return card;}
    private void settingRow(LinearLayout card,String icon,int iconColor,String title,String subtitle,Runnable action){
        LinearLayout row=horizontal();row.setPadding(dp(10),dp(9),dp(8),dp(9));row.setBackground(shape(Color.TRANSPARENT,16));
        TextView badge=label(icon,22,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setBackground(shape(iconColor,13));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(36),dp(36));bp.rightMargin=dp(14);row.addView(badge,bp);
        LinearLayout words=vertical();TextView t=label(title,17,text);bold(t);words.addView(t);if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=label(subtitle,13,muted);sub.setMaxLines(2);sub.setEllipsize(TextUtils.TruncateAt.END);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(3);words.addView(sub,sp);}row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=label("›",29,muted);arrow.setGravity(Gravity.CENTER);row.addView(arrow,new LinearLayout.LayoutParams(dp(28),dp(42)));card.addView(row,new LinearLayout.LayoutParams(-1,-2));row.setOnClickListener(v->action.run());
    }
    private void sectionTitle(String value){TextView t=label(value,13,muted);bold(t);t.setPadding(dp(5),0,0,dp(9));content.addView(t);}
    private Switch settingSwitch(String title,String subtitle,boolean checked){
        LinearLayout wrap=vertical();wrap.setPadding(dp(4),dp(4),dp(4),dp(4));Switch sw=new Switch(this);sw.setText(title);sw.setTextColor(text);sw.setTextSize(16);sw.setChecked(checked);wrap.addView(sw,new LinearLayout.LayoutParams(-1,dp(52)));if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=label(subtitle,13,muted);sub.setPadding(dp(4),0,dp(4),dp(10));wrap.addView(sub);}content.addView(wrap);return sw;
    }
    private long folderSize(File f){if(f==null||!f.exists())return 0;if(f.isFile())return f.length();long n=0;File[] files=f.listFiles();if(files!=null)for(File x:files)n+=folderSize(x);return n;}
    private String humanBytes(long n){if(n<1024)return n+" Б";if(n<1024*1024)return String.format(Locale.ROOT,"%.1f КБ",n/1024.0);return String.format(Locale.ROOT,"%.1f МБ",n/(1024.0*1024.0));}
    private boolean deleteTree(File f){if(f==null||!f.exists())return true;boolean ok=true;if(f.isDirectory()){File[] files=f.listFiles();if(files!=null)for(File x:files)ok&=deleteTree(x);}return f.delete()&&ok;}
    private Set<String> importantChats(){Set<String> out=new HashSet<>();String raw=prefs.getString("important_chats","");if(raw!=null&&!raw.trim().isEmpty())for(String id:raw.split(","))if(!id.trim().isEmpty())out.add(id.trim());return out;}
    private boolean isImportantChat(String id){return importantChats().contains(id);}
    private void setImportantChat(String id,boolean on){Set<String> set=importantChats();if(on)set.add(id);else set.remove(id);StringBuilder b=new StringBuilder();for(String v:set){if(b.length()>0)b.append(',');b.append(v);}prefs.edit().putString("important_chats",b.toString()).apply();}
    private void showSettings(){
        begin("settings");toolbar("Настройки",false,null,null);scrollContent();
        String name=prefs.getString("name","Пользователь Muwahid"),user=prefs.getString("username","");
        sectionTitle("ОСНОВНЫЕ");
        LinearLayout main=settingsCard();
        settingRow(main,"●",Color.rgb(32,151,225),"Аккаунт",user.isEmpty()?name:name+" · @"+user,this::showAccountSettings);
        settingRow(main,"✦",Color.rgb(235,155,24),"Настройки чатов","Тема, размер текста, вид сообщений",this::showChatSettings);
        settingRow(main,"◆",Color.rgb(42,190,91),"Конфиденциальность","Видимость, сообщения, звонки и защита",this::showSecurity);
        settingRow(main,"♪",Color.rgb(235,70,95),"Уведомления","Сообщения, звонки, обновления и системные настройки",this::showNotificationSettings);
        settingRow(main,"▣",Color.rgb(71,111,225),"Данные и память","Кэш расшифрованных медиафайлов",this::showDataSettings);
        settingRow(main,"□",Color.rgb(31,161,214),"Папки с чатами","Все чаты и папка «Важные»",this::showFolderSettings);
        settingRow(main,"▤",Color.rgb(38,171,190),"Устройства","Текущий телефон и другие сеансы",this::showDevices);
        settingRow(main,"▱",Color.rgb(239,119,31),"Энергосбережение",prefs.getBoolean("energy_saver",false)?"Включено":"Выключено",this::showEnergySettings);
        settingRow(main,"◎",Color.rgb(165,73,217),"Язык","Русский",this::showLanguageSettings);
        gap(content,22);sectionTitle("MUWAHID");
        LinearLayout services=settingsCard();
        if(feature("premium",false))settingRow(services,"★",Color.rgb(126,87,235),"Premium Muwahid","Дополнительные возможности",this::showPremium);
        if(feature("owner_chat",true))settingRow(services,"★",Color.rgb(237,155,20),"Чат с владельцем","Прямая переписка с владельцем Muwahid",this::openOwnerChat);
        if(feature("business",false))settingRow(services,"▦",Color.rgb(227,70,86),"Business Muwahid","Инструменты для бизнес-профиля",this::showBusiness);
        if(feature("gifts",false))settingRow(services,"■",Color.rgb(236,119,40),"Отправить подарок","Подарки Muwahid",this::showGift);
        bottom("Настройки");
    }
    private TextView cardCaption(LinearLayout card,String value){TextView t=label(value,13,Color.rgb(112,184,235));bold(t);t.setPadding(dp(10),dp(9),dp(10),dp(7));card.addView(t);return t;}
    private LinearLayout simpleSettingRow(LinearLayout card,String title,String subtitle,View right){LinearLayout row=horizontal();row.setPadding(dp(10),dp(9),dp(8),dp(9));LinearLayout words=vertical();TextView t=label(title,16,text);words.addView(t);if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=label(subtitle,12,muted);sub.setPadding(0,dp(2),0,0);words.addView(sub);}row.addView(words,new LinearLayout.LayoutParams(0,-2,1));if(right!=null)row.addView(right);card.addView(row,new LinearLayout.LayoutParams(-1,-2));return row;}
    private Switch cardSwitch(LinearLayout card,String title,String subtitle,boolean checked,String key){Switch sw=new Switch(this);sw.setChecked(checked);sw.setShowText(false);LinearLayout row=simpleSettingRow(card,title,subtitle,sw);row.setOnClickListener(v->sw.toggle());sw.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean(key,on).apply());return sw;}
    private TextView valueText(String value){TextView v=label(value,14,Color.rgb(104,183,236));v.setGravity(Gravity.CENTER_VERTICAL|Gravity.END);v.setPadding(dp(10),0,dp(4),0);return v;}
    private SeekBar settingSeek(LinearLayout card,String title,int min,int max,int value,String key,Runnable changed){LinearLayout top=horizontal();TextView t=label(title,13,Color.rgb(112,184,235));bold(t);top.addView(t,new LinearLayout.LayoutParams(0,-2,1));TextView number=label(String.valueOf(value),13,Color.rgb(112,184,235));top.addView(number);top.setPadding(dp(10),dp(8),dp(10),0);card.addView(top);SeekBar seek=new SeekBar(this);if(Build.VERSION.SDK_INT>=26)seek.setMin(min);seek.setMax(max);seek.setProgress(value);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean from){int v=Math.max(min,p);number.setText(String.valueOf(v));if(from)prefs.edit().putInt(key,v).apply();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){if(changed!=null)changed.run();}});card.addView(seek,new LinearLayout.LayoutParams(-1,dp(44)));return seek;}
    private void showChatSettings(){
        begin("chat_settings");toolbar("Настройки чатов",true,"⋮",()->notice("Настройки оформления сохраняются только на этом устройстве."));scrollContent();
        LinearLayout sizeCard=settingsCard();settingSeek(sizeCard,"Размер текста сообщений",14,24,prefs.getInt("message_text_size",18),"message_text_size",null);
        LinearLayout preview=horizontal();preview.setPadding(dp(8),dp(8),dp(8),dp(12));LinearLayout left=vertical();TextView one=label("Доброе утро! 👋",prefs.getInt("message_text_size",18),Color.WHITE);left.setPadding(dp(10),dp(7),dp(10),dp(7));left.setBackground(incomingBubbleDrawable());left.addView(one);preview.addView(left,new LinearLayout.LayoutParams(0,-2,1));TextView mine=label("В Токио утро 😎",prefs.getInt("message_text_size",18),Color.WHITE);mine.setPadding(dp(12),dp(9),dp(12),dp(9));mine.setBackground(outgoingBubbleDrawable());LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-2,-2);mp.leftMargin=dp(8);preview.addView(mine,mp);sizeCard.addView(preview);
        LinearLayout appearance=settingsCard();LinearLayout wall=simpleSettingRow(appearance,"▧  Изменить обои","Фон всех личных чатов",valueText("›"));wall.setOnClickListener(v->showWallpaperSettings());LinearLayout name=simpleSettingRow(appearance,"❖  Изменить цвет имени","Цвет имени и ответов",valueText("›"));name.setOnClickListener(v->showNameColorSettings());
        gap(content,12);LinearLayout themes=settingsCard();cardCaption(themes,"Цветовая тема");addThemeChooser(themes);LinearLayout day=simpleSettingRow(themes,"☀  Переключить на дневную тему","",null);day.setOnClickListener(v->{prefs.edit().putString("theme_mode","light").apply();showChatSettings();});LinearLayout themeSettings=simpleSettingRow(themes,"⚒  Настройки темы","Системная, светлая или тёмная",valueText("›"));themeSettings.setOnClickListener(v->showThemeModeDialog());
        gap(content,12);LinearLayout corners=settingsCard();settingSeek(corners,"Углы блоков с сообщениями",6,28,prefs.getInt("message_corner_radius",17),"message_corner_radius",null);
        gap(content,12);LinearLayout listStyle=settingsCard();cardCaption(listStyle,"Список чатов");LinearLayout choices=horizontal();choices.setPadding(dp(8),dp(5),dp(8),dp(10));int lines=prefs.getInt("chat_list_lines",2);String[] ls={"Двухстрочный","Трёхстрочный"};for(int i=0;i<2;i++){final int v=i+2;TextView x=label((lines==v?"◉  ":"○  ")+ls[i],14,lines==v?accent:text);x.setGravity(Gravity.CENTER);x.setBackground(shape(bg,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(52),1);if(i==0)lp.rightMargin=dp(6);choices.addView(x,lp);x.setOnClickListener(z->{prefs.edit().putInt("chat_list_lines",v).apply();showChatSettings();});}listStyle.addView(choices);
        gap(content,12);LinearLayout icons=settingsCard();cardCaption(icons,"Иконка приложения");addAppIconChooser(icons);
        gap(content,12);LinearLayout swipe=settingsCard();cardCaption(swipe,"Смахивание влево в списке чатов");String swipeValue=prefs.getString("chat_swipe_action","folder");String swipeText="folder".equals(swipeValue)?"Сменить папку":"pin".equals(swipeValue)?"Закрепить":"Удалить";LinearLayout swipeRow=simpleSettingRow(swipe,"Действие при смахивании",swipeText,valueText("›"));swipeRow.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Смахивание влево").setItems(new String[]{"Удалить","Сменить папку","Закрепить"},(d,w)->{String k=w==0?"delete":w==1?"folder":"pin";prefs.edit().putString("chat_swipe_action",k).apply();showChatSettings();}).show());
        gap(content,12);LinearLayout general=settingsCard();Switch night=cardSwitch(general,"Смена темы ночью","Как в системе: "+("system".equals(prefs.getString("theme_mode","dark"))?"Да":"Нет"),"system".equals(prefs.getString("theme_mode","dark")),"unused_auto_night");night.setOnCheckedChangeListener((b,on)->{prefs.edit().putString("theme_mode",on?"system":"dark").apply();showChatSettings();});Switch browser=cardSwitch(general,"Встроенный браузер","Открывать ссылки внутри Muwahid",prefs.getBoolean("in_app_browser",false),"in_app_browser");LinearLayout anim=simpleSettingRow(general,"Анимации","Настройки для экономии заряда",valueText("›"));anim.setOnClickListener(v->showAnimationSettings());LinearLayout sticker=simpleSettingRow(general,"Стикеры и эмодзи","Настройки стикеров, эмодзи и реакций",valueText("›"));sticker.setOnClickListener(v->showStickerSettings());
        gap(content,12);LinearLayout media=settingsCard();cardCaption(media,"Медиафайлы и звук");cardSwitch(media,"Листать медиафайлы по нажатию","Нажатие у края экрана переключает медиа",prefs.getBoolean("tap_media_nav",true),"tap_media_nav");cardSwitch(media,"Поднести и слушать","Переключать голосовые на верхний динамик",prefs.getBoolean("raise_listen",true),"raise_listen");cardSwitch(media,"Поднести и говорить","Начинать голосовую запись у уха",prefs.getBoolean("raise_speak",false),"raise_speak");cardSwitch(media,"Пауза музыки при записи","Приостанавливать музыку при записи",prefs.getBoolean("pause_music_recording",false),"pause_music_recording");cardSwitch(media,"Пауза музыки при запуске медиа","Приостанавливать музыку при воспроизведении",prefs.getBoolean("pause_music_media",false),"pause_music_media");LinearLayout mic=simpleSettingRow(media,"Микрофон","Источник для голосовых сообщений",valueText(prefs.getString("microphone_source","built_in").equals("built_in")?"Встроенный":"Системный"));mic.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Микрофон").setItems(new String[]{"Встроенный","Системный"},(d,w)->{prefs.edit().putString("microphone_source",w==0?"built_in":"system").apply();showChatSettings();}).show());
        gap(content,12);LinearLayout other=settingsCard();cardCaption(other,"Прочие настройки");cardSwitch(other,"Direct Share","Показывать недавние чаты в меню Поделиться",prefs.getBoolean("direct_share",false),"direct_share");cardSwitch(other,"Показывать материалы 18+","Не скрывать материалы с возрастным ограничением",prefs.getBoolean("adult_content",false),"adult_content");cardSwitch(other,"Отправка по Enter","Enter отправляет сообщение",prefs.getBoolean("send_by_enter",false),"send_by_enter");LinearLayout distance=simpleSettingRow(other,"Мера расстояния","",valueText(prefs.getString("distance_units","auto").equals("auto")?"Автоматически":"Километры"));distance.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Мера расстояния").setItems(new String[]{"Автоматически","Километры"},(d,w)->{prefs.edit().putString("distance_units",w==0?"auto":"km").apply();showChatSettings();}).show());
    }
    private void addThemeChooser(LinearLayout card){HorizontalScrollView sv=new HorizontalScrollView(this);sv.setHorizontalScrollBarEnabled(false);LinearLayout row=horizontal();String[] keys={"mint","blue","orange","pink","ocean"};String[] names={"Мята","Синяя","Закат","Неон","Океан"};int[] colors={Color.parseColor("#10D6AB"),Color.parseColor("#3D9BFF"),Color.parseColor("#F09B35"),Color.parseColor("#E66BC4"),Color.parseColor("#18B9C8")};String current=prefs.getString("chat_theme","mint");for(int i=0;i<keys.length;i++){final String key=keys[i];LinearLayout item=vertical();item.setGravity(Gravity.CENTER);TextView dot=label("●",35,colors[i]);dot.setGravity(Gravity.CENTER);dot.setBackground(shape(current.equals(key)?Color.parseColor("#24455A"):bg,14));item.addView(dot,new LinearLayout.LayoutParams(dp(66),dp(52)));TextView n=label(names[i],11,current.equals(key)?accent:muted);n.setGravity(Gravity.CENTER);item.addView(n);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(76),dp(78));ip.rightMargin=dp(5);row.addView(item,ip);item.setOnClickListener(v->{prefs.edit().putString("chat_theme",key).apply();showChatSettings();});}sv.addView(row);card.addView(sv,new LinearLayout.LayoutParams(-1,dp(88)));}
    private void showThemeModeDialog(){String current=prefs.getString("theme_mode","dark");String[] labels={"Как в системе","Всегда светлая","Всегда тёмная"};int checked="system".equals(current)?0:"light".equals(current)?1:2;new AlertDialog.Builder(this).setTitle("Тема").setSingleChoiceItems(labels,checked,(d,w)->{prefs.edit().putString("theme_mode",w==0?"system":w==1?"light":"dark").apply();d.dismiss();showChatSettings();}).show();}
    private void showAnimationSettings(){boolean enabled=prefs.getBoolean("chat_animations",true);new AlertDialog.Builder(this).setTitle("Анимации").setSingleChoiceItems(new String[]{"Все анимации","Экономия заряда"},enabled?0:1,(d,w)->{prefs.edit().putBoolean("chat_animations",w==0).apply();d.dismiss();}).show();}
    private void showStickerSettings(){
        begin("stickers");toolbar("Стикеры и эмодзи",true,null,null);scrollContent();
        note(content,"Стикеры Muwahid теперь связаны с Supabase. Новые наборы и загруженные стикеры появляются без отдельной сборки APK.");
        LinearLayout cloudActions=settingsCard();
        LinearLayout create=simpleSettingRow(cloudActions,"＋  Создать набор","Личный или общий набор стикеров",valueText("›"));create.setOnClickListener(v->createStickerPackDialog(null));
        LinearLayout add=simpleSettingRow(cloudActions,"⇧  Добавить стикер","PNG, JPG, WebP, GIF, WebM или TGS",valueText("›"));add.setOnClickListener(v->chooseStickerImportTarget());
        LinearLayout refresh=simpleSettingRow(cloudActions,"↻  Обновить каталог","Загрузить изменения из Supabase",valueText("›"));refresh.setOnClickListener(v->loadStickerCloud(true,c->{showStickerSettings();},()->notice("Не удалось обновить каталог стикеров.")));
        gap(content,12);LinearLayout cloudArea=vertical();content.addView(cloudArea,new LinearLayout.LayoutParams(-1,-2));
        renderCloudStickerSettings(cloudArea,stickerCloudCatalog);
        loadStickerCloud(false,c->{cloudArea.removeAllViews();renderCloudStickerSettings(cloudArea,c);},()->{if(cloudArea.getChildCount()==0)note(cloudArea,"Каталог Supabase временно недоступен. Встроенные наборы остаются доступны.");});
        gap(content,12);LinearLayout builtIn=settingsCard();cardCaption(builtIn,"Встроенные наборы");
        for(int pack=0;pack<StickerCatalog.PACKS.length;pack++){
            final int index=pack;Switch enabled=cardSwitch(builtIn,StickerCatalog.PACKS[pack],"6 анимированных стикеров · Muwahid",prefs.getBoolean("sticker_pack_"+pack,true),"sticker_pack_"+pack);
            LinearLayout previews=horizontal();for(int j=0;j<3;j++){AnimatedStickerView iv=stickerImage(pack*6+j);previews.addView(iv,new LinearLayout.LayoutParams(0,dp(86),1));iv.setOnClickListener(v->showStickerPack(index));}builtIn.addView(previews);
        }
        gap(content,16);LinearLayout options=settingsCard();cardCaption(options,"Эмодзи");
        cardSwitch(options,"Большие эмодзи","Увеличивать сообщения из эмодзи",prefs.getBoolean("large_emoji",true),"large_emoji");
        cardSwitch(options,"Реакции на сообщения","Каталог реакций загружается из Supabase",prefs.getBoolean("message_reactions",true),"message_reactions");
        cardSwitch(options,"Предлагать эмодзи","",prefs.getBoolean("emoji_suggestions",true),"emoji_suggestions");
    }
    private void renderCloudStickerSettings(LinearLayout area,JSONObject catalog){
        if(catalog==null||catalog.length()==0){note(area,"Загрузка наборов Supabase…");return;}
        JSONArray packs=catalog.optJSONArray("packs");if(packs==null||packs.length()==0){note(area,"В Supabase пока нет наборов. Нажмите «Создать набор».");return;}
        for(int i=0;i<packs.length();i++){JSONObject pack=packs.optJSONObject(i);if(pack==null)continue;LinearLayout card=vertical();card.setBackground(shape(panel,20));card.setPadding(dp(8),dp(7),dp(8),dp(8));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(10);area.addView(card,cp);String title=pack.optString("title","Набор");JSONArray items=pack.optJSONArray("items");int count=items==null?0:items.length();cardCaption(card,title);TextView sub=label(count+" стикеров"+(api.uid().equals(pack.optString("owner_id"))?" · мой набор":" · общий набор"),12,muted);sub.setPadding(dp(10),0,dp(10),dp(6));card.addView(sub);if(count>0){JSONArray preview=new JSONArray();for(int j=0;j<Math.min(3,count);j++)preview.put(items.optJSONObject(j));addCloudStickerGrid(card,preview,null,false);}LinearLayout open=simpleSettingRow(card,"Открыть набор",count+" стикеров",valueText("›"));open.setOnClickListener(v->showCloudStickerPack(pack));}
    }
    private void showCloudStickerPack(JSONObject pack){
        LinearLayout body=vertical();body.setPadding(dp(8),dp(8),dp(8),dp(8));ScrollView scroll=new ScrollView(this);scroll.addView(body);JSONArray items=pack.optJSONArray("items");if(items==null||items.length()==0)note(body,"Набор пока пуст.");else addCloudStickerGrid(body,items,null,false);AlertDialog d=new AlertDialog.Builder(this).setTitle(pack.optString("title","Набор")).setView(scroll).setNegativeButton("Закрыть",null).create();if(api.uid().equals(pack.optString("owner_id")))d.setButton(AlertDialog.BUTTON_POSITIVE,"Добавить",(x,w)->{});d.setOnShowListener(x->{if(api.uid().equals(pack.optString("owner_id"))){Button b=d.getButton(AlertDialog.BUTTON_POSITIVE);if(b!=null)b.setOnClickListener(v->{d.dismiss();pendingStickerPackId=pack.optString("id");launchStickerImportPicker();});}});d.show();
    }
    private void loadStickerCloud(boolean force,JsonDone done,Runnable failed){
        if(api==null||!api.signedIn()){if(failed!=null)failed.run();return;}long now=System.currentTimeMillis();if(!force&&stickerCloudCatalog!=null&&stickerCloudCatalog.length()>0&&now-stickerCloudLoadedAt<30000){try{done.accept(stickerCloudCatalog);}catch(Exception e){if(failed!=null)failed.run();}return;}
        worker.execute(()->{try{Object raw=api.rpc("mw_sticker_catalog",new JSONObject());JSONObject cat=raw instanceof JSONObject?(JSONObject)raw:new JSONObject();handler.post(()->{stickerCloudCatalog=cat;stickerCloudLoadedAt=System.currentTimeMillis();try{done.accept(cat);}catch(Exception e){if(failed!=null)failed.run();}});}catch(Exception e){handler.post(()->{if(failed!=null)failed.run();});}});
    }
    private void createStickerPackDialog(StringDone created){
        LinearLayout box=vertical();box.setPadding(dp(18),0,dp(18),0);EditText title=new EditText(this);title.setHint("Название набора");title.setSingleLine(true);EditText desc=new EditText(this);desc.setHint("Описание (необязательно)");desc.setSingleLine(true);CheckBox pub=new CheckBox(this);pub.setText("Общий набор — виден другим пользователям");box.addView(title);box.addView(desc);box.addView(pub);AlertDialog d=new AlertDialog.Builder(this).setTitle("Создать набор стикеров").setView(box).setNegativeButton("Отмена",null).setPositiveButton("Создать",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String t=title.getText().toString().trim();if(t.isEmpty()){title.setError("Введите название");return;}d.dismiss();worker.execute(()->{try{String id=String.valueOf(api.rpc("mw_sticker_create_pack",new JSONObject().put("p_title",t).put("p_description",desc.getText().toString().trim()).put("p_is_public",pub.isChecked())));handler.post(()->{stickerCloudLoadedAt=0;Toast.makeText(this,"Набор создан",Toast.LENGTH_SHORT).show();if(created!=null)created.accept(id);else showStickerSettings();});}catch(Exception e){handler.post(()->error(e));}});}));d.show();
    }
    private void chooseStickerImportTarget(){
        loadStickerCloud(true,c->{JSONArray packs=c.optJSONArray("packs");ArrayList<JSONObject> mine=new ArrayList<>();if(packs!=null)for(int i=0;i<packs.length();i++){JSONObject p=packs.optJSONObject(i);if(p!=null&&api.uid().equals(p.optString("owner_id")))mine.add(p);}String[] labels=new String[mine.size()+1];for(int i=0;i<mine.size();i++)labels[i]=mine.get(i).optString("title","Набор");labels[mine.size()]="＋ Создать новый набор";new AlertDialog.Builder(this).setTitle("Куда добавить стикер?").setItems(labels,(d,w)->{if(w==mine.size())createStickerPackDialog(id->{pendingStickerPackId=id;launchStickerImportPicker();});else{pendingStickerPackId=mine.get(w).optString("id");launchStickerImportPicker();}}).show();},()->notice("Не удалось загрузить список наборов."));
    }
    private void launchStickerImportPicker(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/png","image/jpeg","image/webp","image/gif","video/webm","application/octet-stream","application/gzip","application/json"});i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_STICKER_IMPORT);
    }
    private AnimatedStickerView stickerImage(int id){AnimatedStickerView iv=new AnimatedStickerView(this,id);iv.setPadding(dp(5),dp(5),dp(5),dp(5));return iv;}
    private void showStickerPack(int pack){
        ScrollView scroll=new ScrollView(this);GridLayout grid=new GridLayout(this);grid.setColumnCount(3);grid.setPadding(dp(8),dp(8),dp(8),dp(8));scroll.addView(grid);
        for(int j=0;j<6;j++){final int id=pack*6+j;AnimatedStickerView iv=stickerImage(id);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(108);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(iv,lp);iv.setOnClickListener(v->previewSticker(id,false,null));}
        new AlertDialog.Builder(this).setTitle(StickerCatalog.PACKS[pack]+" · 6 стикеров").setView(scroll).setPositiveButton("Готово",null).show();
    }
    private void previewSticker(int id,boolean send,Dialog picker){
        AnimatedStickerView image=stickerImage(id);FrameLayout box=new FrameLayout(this);box.addView(image,new FrameLayout.LayoutParams(-1,dp(240)));
        AlertDialog.Builder d=new AlertDialog.Builder(this).setTitle(StickerCatalog.name(id)).setView(box).setNegativeButton("Закрыть",null);
        if(send)d.setPositiveButton("Отправить",(dialog,w)->{if(picker!=null)picker.dismiss();sendSticker(id);});d.show();
    }
    private AlertDialog stickerPicker;
    private void showStickerPicker(){
        LinearLayout body=vertical();body.setPadding(dp(8),dp(8),dp(8),dp(8));ScrollView scroll=new ScrollView(this);scroll.addView(body);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Стикеры").setView(scroll).setNegativeButton("Закрыть",null).setNeutralButton("Эмодзи",(d,w)->showPlainEmojiPicker()).create();
        String recent=prefs.getString("recent_stickers","");if(!recent.isEmpty()){ArrayList<Integer> ids=new ArrayList<>();for(String part:recent.split(",")){try{int id=Integer.parseInt(part);if(id>=0&&id<12&&prefs.getBoolean("sticker_pack_"+(id/6),true))ids.add(id);}catch(Exception ignored){}}if(!ids.isEmpty()){cardCaption(body,"Недавние встроенные");addStickerGrid(body,ids,dialog);}}
        for(int pack=0;pack<2;pack++){if(!prefs.getBoolean("sticker_pack_"+pack,true))continue;cardCaption(body,StickerCatalog.PACKS[pack]);ArrayList<Integer> ids=new ArrayList<>();for(int j=0;j<6;j++)ids.add(pack*6+j);addStickerGrid(body,ids,dialog);}
        LinearLayout cloud=vertical();body.addView(cloud,new LinearLayout.LayoutParams(-1,-2));note(cloud,"Загрузка стикеров Supabase…");stickerPicker=dialog;dialog.show();
        loadStickerCloud(false,c->{cloud.removeAllViews();renderCloudStickerPicker(cloud,c,dialog);},()->{cloud.removeAllViews();note(cloud,"Supabase временно недоступен. Встроенные стикеры работают.");});
    }
    private void renderCloudStickerPicker(LinearLayout body,JSONObject catalog,Dialog dialog){
        JSONArray emoji=catalog.optJSONArray("custom_emoji_items");if(emoji!=null&&emoji.length()>0){cardCaption(body,"Мои эмодзи");addCloudStickerGrid(body,emoji,dialog,true);}JSONArray fav=catalog.optJSONArray("favorite_items");if(fav!=null&&fav.length()>0){cardCaption(body,"Избранное");addCloudStickerGrid(body,fav,dialog,true);}JSONArray recent=catalog.optJSONArray("recent_items");if(recent!=null&&recent.length()>0){cardCaption(body,"Недавние");JSONArray cut=new JSONArray();for(int i=0;i<Math.min(12,recent.length());i++)cut.put(recent.optJSONObject(i));addCloudStickerGrid(body,cut,dialog,true);}JSONArray packs=catalog.optJSONArray("packs");if(packs!=null)for(int i=0;i<packs.length();i++){JSONObject pack=packs.optJSONObject(i);if(pack==null)continue;JSONArray items=pack.optJSONArray("items");if(items==null||items.length()==0)continue;cardCaption(body,pack.optString("title","Набор"));addCloudStickerGrid(body,items,dialog,true);}if((packs==null||packs.length()==0)&&(fav==null||fav.length()==0))note(body,"Облачных наборов пока нет. Создайте набор в Настройки → Чаты → Стикеры и эмодзи.");
    }
    private void addStickerGrid(LinearLayout body,List<Integer> ids,Dialog dialog){GridLayout grid=new GridLayout(this);grid.setColumnCount(3);for(int id:ids){AnimatedStickerView iv=stickerImage(id);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(100);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(iv,lp);iv.setOnClickListener(v->{dialog.dismiss();sendSticker(id);});iv.setOnLongClickListener(v->{previewSticker(id,true,dialog);return true;});}body.addView(grid,new LinearLayout.LayoutParams(-1,-2));}
    private void addCloudStickerGrid(LinearLayout body,JSONArray items,Dialog dialog,boolean send){GridLayout grid=new GridLayout(this);grid.setColumnCount(3);for(int i=0;i<items.length();i++){JSONObject asset=items.optJSONObject(i);if(asset==null)continue;View tile=cloudStickerTile(asset,dialog,send);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(send?104:96);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);lp.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(tile,lp);}body.addView(grid,new LinearLayout.LayoutParams(-1,-2));}
    private View cloudStickerTile(JSONObject asset,Dialog dialog,boolean send){FrameLayout frame=new FrameLayout(this);frame.setBackground(shape(Color.parseColor("#10283B"),14));ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setPadding(dp(5),dp(5),dp(5),dp(5));frame.addView(image,new FrameLayout.LayoutParams(-1,-1));String mime=asset.optString("mime_type","");TextView state=label(mime.contains("webm")?"WEBM":mime.contains("tg")?"TGS":"…",12,muted);state.setGravity(Gravity.CENTER);frame.addView(state,new FrameLayout.LayoutParams(-1,-1));loadCloudStickerPreview(asset,image,state);if(send)frame.setOnClickListener(v->{if(dialog!=null)dialog.dismiss();sendCloudSticker(asset);});else frame.setOnClickListener(v->previewCloudSticker(asset));frame.setOnLongClickListener(v->{showCloudStickerMenu(asset);return true;});return frame;}
    private void loadCloudStickerPreview(JSONObject asset,ImageView image,TextView state){String path=asset.optString("storage_path","");String mime=asset.optString("mime_type","");if(path.isEmpty())return;worker.execute(()->{try{byte[] raw=api.downloadSticker(path);Drawable drawable=decodeStickerDrawable(raw,mime);handler.post(()->{if(drawable!=null){image.setImageDrawable(drawable);state.setVisibility(View.GONE);if(Build.VERSION.SDK_INT>=28&&drawable instanceof android.graphics.drawable.AnimatedImageDrawable)((android.graphics.drawable.AnimatedImageDrawable)drawable).start();}else state.setText(mime.contains("webm")?"WEBM\nнажмите":mime.contains("tg")?"TGS\nнажмите":"Стикер");});}catch(Exception e){handler.post(()->state.setText("Не загружен"));}});}
    private Drawable decodeStickerDrawable(byte[] raw,String mime){try{if(Build.VERSION.SDK_INT>=28&&!mime.contains("webm")&&!mime.contains("tg")){android.graphics.ImageDecoder.Source src=android.graphics.ImageDecoder.createSource(java.nio.ByteBuffer.wrap(raw));return android.graphics.ImageDecoder.decodeDrawable(src);}Bitmap b=BitmapFactory.decodeByteArray(raw,0,raw.length);return b==null?null:new BitmapDrawable(getResources(),b);}catch(Exception e){return null;}}
    private void previewCloudSticker(JSONObject asset){LinearLayout box=vertical();box.setPadding(dp(8),dp(8),dp(8),dp(8));FrameLayout frame=(FrameLayout)cloudStickerTile(asset,null,false);box.addView(frame,new LinearLayout.LayoutParams(-1,dp(260)));new AlertDialog.Builder(this).setTitle(asset.optString("original_name","Стикер")).setView(box).setNegativeButton("Закрыть",null).setPositiveButton("В избранное",(d,w)->setCloudStickerFavorite(asset,true)).show();}
    private void showCloudStickerMenu(JSONObject asset){new AlertDialog.Builder(this).setTitle(asset.optString("original_name","Стикер")).setItems(new String[]{"Добавить в избранное","Убрать из избранного","Создать своё эмодзи"},(d,w)->{if(w==0)setCloudStickerFavorite(asset,true);else if(w==1)setCloudStickerFavorite(asset,false);else createCustomEmojiDialog(asset);}).show();}
    private void createCustomEmojiDialog(JSONObject asset){String id=asset.optString("id","");if(id.isEmpty())return;EditText input=new EditText(this);input.setHint("Например: muwa");input.setSingleLine(true);new AlertDialog.Builder(this).setTitle("Новое эмодзи").setMessage("Введите короткое имя. Оно будет храниться вместе со стикером в Supabase.").setView(input).setNegativeButton("Отмена",null).setPositiveButton("Создать",(d,w)->{String code=input.getText().toString().trim().replace(":","");if(code.isEmpty()){Toast.makeText(this,"Введите имя эмодзи",Toast.LENGTH_SHORT).show();return;}worker.execute(()->{try{api.rpc("mw_custom_emoji_create",new JSONObject().put("p_sticker",id).put("p_shortcode",code).put("p_is_public",false));handler.post(()->{stickerCloudLoadedAt=0;Toast.makeText(this,"Эмодзи создано",Toast.LENGTH_SHORT).show();});}catch(Exception e){handler.post(()->error(e));}});}).show();}
    private void setCloudStickerFavoriteById(String id,boolean favorite){if(id==null||id.isEmpty())return;JSONObject asset=new JSONObject();try{asset.put("id",id);}catch(Exception ignored){}setCloudStickerFavorite(asset,favorite);}
    private void setCloudStickerFavorite(JSONObject asset,boolean favorite){String id=asset.optString("id","");if(id.isEmpty())return;worker.execute(()->{try{api.rpc("mw_sticker_set_favorite",new JSONObject().put("p_sticker",id).put("p_favorite",favorite));handler.post(()->{stickerCloudLoadedAt=0;Toast.makeText(this,favorite?"Стикер добавлен в избранное":"Стикер убран из избранного",Toast.LENGTH_SHORT).show();});}catch(Exception e){handler.post(()->error(e));}});}
    private void sendCloudSticker(JSONObject asset){
        if(sending||voiceRecording||notesMode||!"chat".equals(screen))return;if(!api.signedIn()||!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для отправки стикера нужен защищённый чат с собеседником.");return;}final String id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;setComposeEnabled(false);sendButton.setEnabled(false);connection.setText("Отправляем стикер…");worker.execute(()->{try{byte[] raw=api.downloadSticker(asset.getString("storage_path"));byte[] encrypted=crypto.encryptBytes(uid,id,peer,raw);String path=id+"/"+UUID.randomUUID()+".bin";api.uploadMedia(path,encrypted);String assetId=asset.optString("id","");String mime=asset.optString("mime_type","image/webp");String name=asset.optString("original_name","sticker");JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type","image").put("sticker",true).put("sticker_asset_id",assetId).put("sticker_storage_path",asset.optString("storage_path","")).put("sticker_source_kind",asset.optString("source_kind","supabase")).put("name",name).put("mime",mime).put("path",path).put("size",raw.length);String payload=crypto.encryptText(uid,id,peer,meta.toString());JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",UUID.randomUUID().toString()));if(!assetId.isEmpty())try{api.rpc("mw_sticker_mark_recent",new JSONObject().put("p_sticker",assetId));}catch(Exception ignored){}handler.post(()->{stickerCloudLoadedAt=0;sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);connection.setText(chatSecurityStatus());history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});}catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);connection.setText(chatSecurityStatus());updateComposeAction();error(e);});}});
    }
    private void sendSticker(int stickerId){
        if(sending||voiceRecording||notesMode||!"chat".equals(screen))return;if(!api.signedIn()||!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для отправки стикера нужен защищённый чат с собеседником.");return;}final String id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;setComposeEnabled(false);sendButton.setEnabled(false);connection.setText("Отправляем стикер…");worker.execute(()->{try{byte[] raw=StickerCatalog.png(stickerId);byte[] encrypted=crypto.encryptBytes(uid,id,peer,raw);String path=id+"/"+UUID.randomUUID()+".bin";api.uploadMedia(path,encrypted);JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type","image").put("sticker",true).put("sticker_id",stickerId).put("sticker_animation","muwahid-vector-v1").put("name",StickerCatalog.name(stickerId)+".png").put("mime","image/png").put("path",path).put("size",raw.length);String payload=crypto.encryptText(uid,id,peer,meta.toString());JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",UUID.randomUUID().toString()));LinkedHashSet<String> recent=new LinkedHashSet<>();recent.add(String.valueOf(stickerId));for(String value:prefs.getString("recent_stickers","").split(","))if(!value.isEmpty()&&recent.size()<12)recent.add(value);prefs.edit().putString("recent_stickers",TextUtils.join(",",recent)).apply();handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);connection.setText(chatSecurityStatus());history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});}catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);connection.setText(chatSecurityStatus());updateComposeAction();error(e);});}});
    }
    private boolean handleSharedStickerIntent(Intent intent){
        if(intent==null||api==null||!api.signedIn())return false;String action=intent.getAction();if(!Intent.ACTION_SEND.equals(action)&&!Intent.ACTION_SEND_MULTIPLE.equals(action))return false;pendingSharedStickerUris.clear();try{if(Intent.ACTION_SEND_MULTIPLE.equals(action)){ArrayList<Uri> many=intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);if(many!=null)pendingSharedStickerUris.addAll(many);}else{Uri one=intent.getParcelableExtra(Intent.EXTRA_STREAM);if(one!=null)pendingSharedStickerUris.add(one);}ClipData clip=intent.getClipData();if(clip!=null)for(int i=0;i<clip.getItemCount();i++){Uri u=clip.getItemAt(i).getUri();if(u!=null&&!pendingSharedStickerUris.contains(u))pendingSharedStickerUris.add(u);}}catch(Exception ignored){}if(pendingSharedStickerUris.isEmpty())return false;showChats();new AlertDialog.Builder(this).setTitle("Добавить в Muwahid").setMessage("Сохранить "+pendingSharedStickerUris.size()+" стикер(а) в набор «Импортированные»?").setNegativeButton("Отмена",(d,w)->pendingSharedStickerUris.clear()).setPositiveButton("Добавить",(d,w)->importSharedStickers()).show();return true;
    }
    private void importSharedStickers(){ArrayList<Uri> uris=new ArrayList<>(pendingSharedStickerUris);pendingSharedStickerUris.clear();if(uris.isEmpty())return;worker.execute(()->{try{JSONObject cat=(JSONObject)api.rpc("mw_sticker_catalog",new JSONObject());String pack=findOwnedPackByTitle(cat,"Импортированные");if(pack.isEmpty())pack=String.valueOf(api.rpc("mw_sticker_create_pack",new JSONObject().put("p_title","Импортированные").put("p_description","Стикеры, добавленные через меню Поделиться").put("p_is_public",false)));final String target=pack;int ok=0;for(Uri uri:uris){try{importStickerUriBlocking(uri,target,"shared_app");ok++;}catch(Exception ignored){}}final int count=ok;handler.post(()->{stickerCloudLoadedAt=0;Toast.makeText(this,"Добавлено стикеров: "+count,Toast.LENGTH_LONG).show();showStickerSettings();});}catch(Exception e){handler.post(()->error(e));}});}
    private String findOwnedPackByTitle(JSONObject cat,String title){JSONArray packs=cat==null?null:cat.optJSONArray("packs");if(packs!=null)for(int i=0;i<packs.length();i++){JSONObject p=packs.optJSONObject(i);if(p!=null&&api.uid().equals(p.optString("owner_id"))&&title.equalsIgnoreCase(p.optString("title")))return p.optString("id","");}return "";}
    private void importStickerUris(List<Uri> uris,String packId,String sourceKind){if(uris==null||uris.isEmpty()||packId==null||packId.isEmpty())return;worker.execute(()->{try{int ok=0;for(Uri uri:uris){importStickerUriBlocking(uri,packId,sourceKind);ok++;}final int count=ok;handler.post(()->{stickerCloudLoadedAt=0;Toast.makeText(this,"Добавлено стикеров: "+count,Toast.LENGTH_LONG).show();showStickerSettings();});}catch(Exception e){handler.post(()->error(e));}});}
    private String importStickerUriBlocking(Uri uri,String packId,String sourceKind) throws Exception{String mime=getContentResolver().getType(uri);String name=fileName(uri);if(mime==null||mime.isEmpty())mime=guessStickerMime(name);String lower=(mime+" "+name).toLowerCase(Locale.ROOT);if(!(lower.contains("png")||lower.contains("jpeg")||lower.contains("jpg")||lower.contains("webp")||lower.contains("gif")||lower.contains("webm")||lower.contains("tgs")||lower.endsWith(".json")||lower.contains("gzip")||lower.contains("octet-stream")))throw new Exception("Поддерживаются PNG, JPG, WebP, GIF, WebM и TGS");byte[] raw=readUri(uri,10*1024*1024);String ext=stickerExtension(name,mime);String storage=api.uid()+"/"+UUID.randomUUID()+"."+ext;api.uploadSticker(storage,raw);BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(raw,0,raw.length,bounds);boolean animated=lower.contains("gif")||lower.contains("webm")||lower.contains("tgs")||lower.contains("webp");String asset=String.valueOf(api.rpc("mw_sticker_register_asset",new JSONObject().put("p_storage_path",storage).put("p_original_name",name).put("p_mime_type",mime).put("p_file_size_bytes",raw.length).put("p_width",bounds.outWidth>0?bounds.outWidth:JSONObject.NULL).put("p_height",bounds.outHeight>0?bounds.outHeight:JSONObject.NULL).put("p_animated",animated).put("p_source_kind",sourceKind).put("p_source_ref","").put("p_sha256",sha256(raw))));api.rpc("mw_sticker_add_to_pack",new JSONObject().put("p_pack",packId).put("p_sticker",asset).put("p_sort_order",0));return asset;}
    private String guessStickerMime(String name){String n=name==null?"":name.toLowerCase(Locale.ROOT);if(n.endsWith(".png"))return "image/png";if(n.endsWith(".jpg")||n.endsWith(".jpeg"))return "image/jpeg";if(n.endsWith(".gif"))return "image/gif";if(n.endsWith(".webp"))return "image/webp";if(n.endsWith(".webm"))return "video/webm";if(n.endsWith(".tgs"))return "application/x-tgsticker";return "application/octet-stream";}
    private String stickerExtension(String name,String mime){String n=name==null?"":name.toLowerCase(Locale.ROOT);for(String ext:new String[]{"png","jpg","jpeg","webp","gif","webm","tgs"})if(n.endsWith("."+ext))return ext;if(mime.contains("png"))return "png";if(mime.contains("jpeg"))return "jpg";if(mime.contains("gif"))return "gif";if(mime.contains("webp"))return "webp";if(mime.contains("webm"))return "webm";if(mime.contains("tg"))return "tgs";return "bin";}
    private String sha256(byte[] data) throws Exception{java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");byte[] hash=md.digest(data);StringBuilder b=new StringBuilder();for(byte x:hash)b.append(String.format(Locale.ROOT,"%02x",x&255));return b.toString();}
    private void showWallpaperSettings(){begin("chat_wallpaper");toolbar("Обои для чатов",true,null,null);scrollContent();LinearLayout actions=settingsCard();LinearLayout gallery=simpleSettingRow(actions,"▧  Выбрать из галереи","Любое изображение с телефона",valueText("›"));gallery.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_CHAT_WALLPAPER);});LinearLayout color=simpleSettingRow(actions,"◉  Задать цвет","Однотонный фон",valueText("›"));color.setOnClickListener(v->showWallpaperColorDialog());gap(content,12);LinearLayout presets=settingsCard();cardCaption(presets,"Готовые фоны");GridLayout grid=new GridLayout(this);grid.setColumnCount(3);int[] cs={0xFF142433,0xFF7CC8A8,0xFFF2F3F5,0xFFE4F1B6,0xFFE3A4D8,0xFFF6D481,0xFFA8C9EE,0xFFE3A672,0xFF87C3A0,0xFFF0A28C,0xFFA2C6E8,0xFFB9B0E8};for(int i=0;i<cs.length;i++){final int index=i;TextView sw=label(i==prefs.getInt("wallpaper_preset",0)?"✓":"",22,Color.WHITE);sw.setGravity(Gravity.CENTER);sw.setBackground(shape(cs[i],8));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(90);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(dp(4),dp(4),dp(4),dp(4));grid.addView(sw,gp);sw.setOnClickListener(v->{prefs.edit().remove("chat_wallpaper_uri").putInt("wallpaper_preset",index).putInt("chat_wallpaper_color",cs[index]).apply();showWallpaperSettings();});}presets.addView(grid,new LinearLayout.LayoutParams(-1,-2));}
    private void showWallpaperColorDialog(){int[] colors={0xFF061321,0xFF10253D,0xFF23495A,0xFF1F5E52,0xFF4F3A64,0xFF6A4934,0xFF8A395D,0xFF5A6C7E,0xFFE9EDF2};String[] labels={"Тёмно-синий","Ночной","Сине-зелёный","Изумрудный","Фиолетовый","Кофейный","Розовый","Серый","Светлый"};new AlertDialog.Builder(this).setTitle("Цвет обоев").setItems(labels,(d,w)->{prefs.edit().remove("chat_wallpaper_uri").putInt("chat_wallpaper_color",colors[w]).putInt("wallpaper_preset",-1).apply();showWallpaperSettings();}).show();}
    private void showNameColorSettings(){begin("chat_name_color");toolbar("Цвет имени",true,null,null);scrollContent();LinearLayout preview=settingsCard();TextView avatar=label("M",28,Color.WHITE);avatar.setGravity(Gravity.CENTER);avatar.setBackground(shape(Color.parseColor("#F0A34A"),40));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(78),dp(78));ap.gravity=Gravity.CENTER_HORIZONTAL;preview.addView(avatar,ap);TextView n=label(prefs.getString("name","Muwahid"),18,prefs.getInt("chat_name_color",Color.parseColor("#E8A646")));bold(n);n.setGravity(Gravity.CENTER);preview.addView(n);gap(content,12);LinearLayout palette=settingsCard();cardCaption(palette,"Цвет имени");GridLayout grid=new GridLayout(this);grid.setColumnCount(8);int[] colors={0xFF399DE5,0xFF2BBE48,0xFFDE7D25,0xFFE2534C,0xFF9B5BD4,0xFF42B6C5,0xFFD94C86,0xFF8493A1,0xFF62C7EA,0xFF9CCF4E,0xFFF1AE3E,0xFFFF7E66,0xFFD870D8,0xFF68D1C6,0xFFF07586,0xFFB7C0CA};int selected=prefs.getInt("chat_name_color",colors[2]);for(int c:colors){final int value=c;TextView dot=label(c==selected?"✓":"",16,Color.WHITE);dot.setGravity(Gravity.CENTER);GradientDrawable g=shape(c,24);dot.setBackground(g);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(44);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(dp(3),dp(5),dp(3),dp(5));grid.addView(dot,gp);dot.setOnClickListener(v->{prefs.edit().putInt("chat_name_color",value).apply();showNameColorSettings();});}palette.addView(grid);gap(content,16);Button apply=button("Применить стиль");content.addView(apply,new LinearLayout.LayoutParams(-1,dp(54)));apply.setOnClickListener(v->showChatSettings());}
    private void addAppIconChooser(LinearLayout card){HorizontalScrollView sv=new HorizontalScrollView(this);sv.setHorizontalScrollBarEnabled(false);LinearLayout row=horizontal();String[] keys={"default","classic","ocean","turbo","night"};String[] names={"Основная","Классика","Океан","Турбо","Ночь"};int[] colors={0xFF13CDB3,0xFF2698E4,0xFF18AEB8,0xFF6C8CFF,0xFF233342};String selected=prefs.getString("app_icon","default");for(int i=0;i<keys.length;i++){final String key=keys[i];LinearLayout item=vertical();item.setGravity(Gravity.CENTER);TextView icon=label("M",20,Color.WHITE);bold(icon);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(colors[i],14));item.addView(icon,new LinearLayout.LayoutParams(dp(52),dp(52)));TextView name=label(names[i],11,key.equals(selected)?accent:muted);name.setGravity(Gravity.CENTER);name.setPadding(0,dp(4),0,0);item.addView(name);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(78),dp(78));row.addView(item,ip);item.setOnClickListener(v->setLauncherIcon(key));}sv.addView(row);card.addView(sv,new LinearLayout.LayoutParams(-1,dp(88)));}
    private void setLauncherIcon(String key){String[] names={"LauncherDefault","LauncherClassic","LauncherOcean","LauncherTurbo","LauncherNight"};String[] keys={"default","classic","ocean","turbo","night"};PackageManager pm=getPackageManager();for(int i=0;i<names.length;i++){boolean enable=keys[i].equals(key);ComponentName c=new ComponentName(this,getPackageName()+"."+names[i]);pm.setComponentEnabledSetting(c,enable?PackageManager.COMPONENT_ENABLED_STATE_ENABLED:PackageManager.COMPONENT_ENABLED_STATE_DISABLED,PackageManager.DONT_KILL_APP);}prefs.edit().putString("app_icon",key).apply();Toast.makeText(this,"Иконка Muwahid обновлена",Toast.LENGTH_SHORT).show();showChatSettings();}
    private void showNotificationSettings(){
        begin("notifications");toolbar("Уведомления",true,null,null);scrollContent();
        Switch messages=settingSwitch("Уведомления о сообщениях","Показывать уведомления о новых сообщениях.",prefs.getBoolean("notify_messages",true));
        Switch calls=settingSwitch("Уведомления о звонках","Показывать входящие аудио- и видеозвонки.",prefs.getBoolean("notify_calls",true));
        Switch updates=settingSwitch("Уведомления об обновлениях","Сообщать, когда доступна новая версия Muwahid.",prefs.getBoolean("notify_updates",true));
        messages.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("notify_messages",on).apply();maybeStartNotifications();});
        calls.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("notify_calls",on).apply();maybeStartNotifications();});
        updates.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean("notify_updates",on).apply());
        gap(content,14);LinearLayout ringCard=settingsCard();String ringMode=prefs.getString("call_ringtone_mode","default");String ringLabel="silent".equals(ringMode)?"Без звука":"custom".equals(ringMode)?prefs.getString("call_ringtone_name","Своя мелодия"):"Системная мелодия";LinearLayout ringRow=simpleSettingRow(ringCard,"Мелодия звонка","Можно выбрать любую музыку с телефона",valueText(ringLabel));ringRow.setOnClickListener(v->chooseCallRingtone());
        gap(content,14);Button checkUpdate=button("Проверить обновления");content.addView(checkUpdate,new LinearLayout.LayoutParams(-1,dp(54)));checkUpdate.setOnClickListener(v->{UpdateManager.checkAndNotify(this,true);Toast.makeText(this,"Проверяем обновления…",Toast.LENGTH_SHORT).show();});
        gap(content,18);Button system=button("Системные настройки уведомлений");content.addView(system,new LinearLayout.LayoutParams(-1,dp(54)));system.setOnClickListener(v->{
            try{Intent i=new Intent("android.settings.APP_NOTIFICATION_SETTINGS");i.putExtra("android.provider.extra.APP_PACKAGE",getPackageName());startActivity(i);}catch(Exception e){notice("Не удалось открыть системные настройки уведомлений.");}
        });
    }
    private void chooseCallRingtone(){
        new AlertDialog.Builder(this).setTitle("Мелодия входящего звонка").setItems(new String[]{"Системная мелодия Android","Выбрать песню или музыку","Без звука"},(d,w)->{
            if(w==0){prefs.edit().putString("call_ringtone_mode","default").remove("call_ringtone_uri").remove("call_ringtone_name").apply();showNotificationSettings();}
            else if(w==1){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_CALL_RINGTONE);}catch(Exception e){notice("Не удалось открыть выбор музыки.");}}
            else{prefs.edit().putString("call_ringtone_mode","silent").remove("call_ringtone_uri").remove("call_ringtone_name").apply();showNotificationSettings();}
        }).show();
    }
    private void updatePresence(boolean online){
        if(api==null||!api.signedIn()||worker.isShutdown())return;worker.execute(()->{try{api.rpc("mw_presence_set",new JSONObject().put("p_online",online));}catch(Exception ignored){}});
    }
    private void refreshChatPresence(String id){
        if(id==null||id.isEmpty()||api==null||!api.signedIn()||worker.isShutdown())return;
        final int stamp=generation;worker.execute(()->{try{JSONArray all=(JSONArray)api.rpc("mw_chat_list",new JSONObject());JSONObject found=null;for(int i=0;i<all.length();i++){JSONObject c=all.optJSONObject(i);if(c!=null&&id.equals(c.optString("id"))){found=c;break;}}if(found==null)return;final boolean online=found.optBoolean("online",false);final String seen=found.optString("last_seen","");handler.post(()->{if(stamp!=generation||!"chat".equals(screen)||!id.equals(chatId))return;chatPeerOnline=online;chatPeerLastSeen=seen;if(chatPresenceStatus!=null){chatPresenceStatus.setText(presenceLabel(online,seen));chatPresenceStatus.setTextColor(online?Color.parseColor("#5DD8E6"):Color.parseColor("#91A8BC"));}});}catch(Exception ignored){}});
    }
    private String presenceLabel(boolean online,String lastSeen){
        if(online)return "в сети";
        if(lastSeen==null||lastSeen.isEmpty()||"null".equals(lastSeen))return "был недавно";
        try{String raw=lastSeen.length()>=19?lastSeen.substring(0,19):lastSeen;SimpleDateFormat parser=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);parser.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=parser.parse(raw);if(d==null)return "был недавно";long delta=Math.max(0,System.currentTimeMillis()-d.getTime());if(delta<120000)return "был только что";Calendar now=Calendar.getInstance(),then=Calendar.getInstance();then.setTime(d);String hm=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(d);if(now.get(Calendar.YEAR)==then.get(Calendar.YEAR)&&now.get(Calendar.DAY_OF_YEAR)==then.get(Calendar.DAY_OF_YEAR))return "был сегодня в "+hm;now.add(Calendar.DAY_OF_YEAR,-1);if(now.get(Calendar.YEAR)==then.get(Calendar.YEAR)&&now.get(Calendar.DAY_OF_YEAR)==then.get(Calendar.DAY_OF_YEAR))return "был вчера в "+hm;return "был "+new SimpleDateFormat("dd.MM в HH:mm",Locale.getDefault()).format(d);}catch(Exception e){return "был недавно";}
    }

    private void showDataSettings(){
        begin("data_settings");toolbar("Данные и память",true,null,null);scrollContent();
        File media=new File(getCacheDir(),"media");long bytes=folderSize(media);
        note(content,"Кэш медиа: "+humanBytes(bytes)+"\nСюда временно сохраняются расшифрованные файлы, которые вы открывали в чатах.");gap(content,18);
        Button clear=button("Очистить кэш медиа");content.addView(clear,new LinearLayout.LayoutParams(-1,dp(54)));clear.setEnabled(bytes>0);clear.setOnClickListener(v->{
            boolean ok=deleteTree(media);Toast.makeText(this,ok?"Кэш очищен":"Не удалось полностью очистить кэш",Toast.LENGTH_SHORT).show();showDataSettings();
        });
        gap(content,18);note(content,"Сообщения на сервере этим действием не удаляются. Черновики, заметки и данные входа также сохраняются.");
    }
    private void showFolderSettings(){
        begin("folders");toolbar("Папки с чатами",true,null,null);scrollContent();
        int count=importantChats().size();note(content,"Папка «Важные» содержит "+count+" чат(ов). Чтобы добавить или убрать чат, удерживайте его в списке чатов.");gap(content,18);
        Button open=button("Открыть папку «Важные»");content.addView(open,new LinearLayout.LayoutParams(-1,dp(54)));open.setOnClickListener(v->{chatFolderFilter="important";prefs.edit().putString("chat_folder","important").apply();showChats();});
        gap(content,12);Button all=button("Показать все чаты");content.addView(all,new LinearLayout.LayoutParams(-1,dp(54)));all.setOnClickListener(v->{chatFolderFilter="all";prefs.edit().putString("chat_folder","all").apply();showChats();});
        if(count>0){gap(content,12);Button clear=button("Очистить папку «Важные»");content.addView(clear,new LinearLayout.LayoutParams(-1,dp(54)));clear.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Убрать все чаты из папки «Важные»?").setNegativeButton("Отмена",null).setPositiveButton("Очистить",(d,w)->{prefs.edit().remove("important_chats").apply();showFolderSettings();}).show());}
    }
    private String compactTimestamp(String value){
        if(value==null||value.isEmpty()||"null".equals(value))return "";
        String s=value.replace('T',' ');
        return s.length()>16?s.substring(0,16):s;
    }
    private void showDevices(){startActivity(new Intent(this,PrivacyActivity.class).putExtra("devices",true));}
    private void showEnergySettings(){
        begin("energy");toolbar("Энергосбережение",true,null,null);scrollContent();
        Switch saver=settingSwitch("Экономить заряд","Уменьшает частоту фонового обновления чатов и уведомлений.",prefs.getBoolean("energy_saver",false));
        saver.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("energy_saver",on).apply();try{NotificationService.stop(this);}catch(Exception ignored){}maybeStartNotifications();});
        gap(content,18);note(content,"В режиме энергосбережения обновление списка чатов выполняется реже. Входящие события могут появляться с небольшой дополнительной задержкой.");
    }
    private void showLanguageSettings(){
        begin("language");toolbar("Язык",true,null,null);scrollContent();
        LinearLayout card=settingsCard();settingRow(card,"RU",Color.rgb(165,73,217),"Русский","Текущий язык интерфейса",()->Toast.makeText(this,"Русский уже выбран",Toast.LENGTH_SHORT).show());
        gap(content,18);note(content,"Другие языки появятся после полной локализации интерфейса. Приложение не будет притворяться переведённым частично.");
    }
    private void showPremium(){
        begin("premium");toolbar("Premium Muwahid",true,null,null);scrollContent();
        note(content,"Раздел Premium подготовлен в настройках. Покупка пока не включена: в версии 0.9.2 нет подключённой платёжной системы и серверной проверки подписки.");gap(content,18);
        note(content,"Когда Premium будет подключён, оплата и статус подписки будут проверяться через официальный механизм магазина приложений, а не локальным переключателем.");
    }
    private void showBusiness(){
        begin("business");toolbar("Business Muwahid",true,null,null);scrollContent();
        note(content,"Раздел Business Muwahid добавлен в меню. Публичные бизнес-профили, категории и права для сотрудников требуют отдельной серверной модели и пока не включены в 0.9.2.");
    }
    private void showGift(){
        begin("gift");toolbar("Отправить подарок",true,null,null);scrollContent();
        note(content,"Подарки появятся после подключения Premium и безопасной оплаты. Сейчас списание денег или фиктивная отправка подарка не выполняются.");
    }
    private void openOwnerChat(){
        if(!api.signedIn()){showAuth(false);return;}
        if(OWNER_UUID.equals(api.uid())){notice("Вы вошли в аккаунт владельца Muwahid.");return;}
        async(()->{Object id=api.rpc("mw_start_chat",new JSONObject().put("p_person",OWNER_UUID));return id;},r->showChat(String.valueOf(r),"Владелец Muwahid"));
    }
    private void showWelcome(){
        begin("welcome");
        FrameLayout scene=new FrameLayout(this);scene.setBackgroundColor(Color.parseColor("#06101B"));
        Logo hero=new Logo(this,true);scene.addView(hero,new FrameLayout.LayoutParams(-1,-1));root.addView(scene,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=vertical();actions.setPadding(dp(28),dp(6),dp(28),dp(24));actions.setBackgroundColor(bg);
        Button start=button(rc("welcome.start_button","Начать"));actions.addView(start,new LinearLayout.LayoutParams(-1,dp(56)));start.setEnabled(remote==null||remote.bool("auth.enabled",true));start.setOnClickListener(v->{if(api.configured())showAuth(true);else notice("Сервер сообщений ещё не подключён.");});
        TextView login=label(rc("welcome.login_text","Уже есть аккаунт?  Войти"),14,muted);login.setGravity(Gravity.CENTER);login.setPadding(0,dp(17),0,dp(10));actions.addView(login);login.setOnClickListener(v->{if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");});
        TextView saved=label(rc("welcome.notes_text","Открыть личные заметки"),13,accent);saved.setGravity(Gravity.CENTER);saved.setPadding(0,dp(7),0,dp(9));actions.addView(saved);saved.setOnClickListener(v->showNotes());
        TextView state=label(rc("welcome.status_text","Muwahid · настройки обновляются через Supabase"),11,muted);state.setGravity(Gravity.CENTER);actions.addView(state);root.addView(actions);
    }
    private void showAuth(boolean register){
        phoneRegisterMode=register;begin("auth");
        if(remote!=null&&!remote.bool("auth.enabled",true)){
            toolbar("Номер телефона",true,null,null);scrollContent();
            note(content,rc("maintenance.message","Регистрация временно недоступна."));return;
        }
        final JSONArray offline=PhoneCountries.load(this);
        final int stamp=generation;
        phoneEntry=new PhoneEntryView(this,offline,()->showWelcome(),
            (remote==null||remote.bool("auth.google_enabled",true))?()->openGoogleLogin():null,number->{
            if(remote!=null&&(!remote.bool("auth.enabled",true)||!remote.bool("auth.phone_enabled",true))){
                notice("Регистрация по телефону временно отключена на сервере.");return;
            }
            phoneEntry.setBusy(true);
            worker.execute(()->{try{
                api.sendPhoneOtp(number);
                handler.post(()->{if(stamp==generation)showPhoneCode(number,register);});
            }catch(Exception ex){handler.post(()->{if(stamp==generation){phoneEntry.setBusy(false);error(ex);}});}});
        });
        root.addView(phoneEntry,new LinearLayout.LayoutParams(-1,0,1));
        getWindow().setStatusBarColor(Color.rgb(29,41,53));getWindow().setNavigationBarColor(Color.rgb(29,41,53));
        phoneEntry.showKeyboard();
        worker.execute(()->{try{
            Object result=api.publicRpc("mw_phone_country_list",new JSONObject());
            if(result instanceof JSONArray){
                JSONArray combined=PhoneCountries.merge(offline,(JSONArray)result);
                handler.post(()->{if(stamp==generation&&phoneEntry!=null)phoneEntry.updateCountries(combined);});
            }
        }catch(Exception ignored){/* The complete bundled directory remains available offline. */}});
    }
    private void openGoogleLogin(){
        final int stamp=generation;
        worker.execute(()->{try{
            if(!api.googleProviderEnabled())throw new Exception("Google сейчас не активен на живом Auth-сервере Supabase. Проверьте Client ID, Client Secret и Save в провайдере Google.");
            final Uri url=Uri.parse(api.googleOAuthUrl());
            handler.post(()->{if(stamp!=generation)return;try{startActivity(new Intent(Intent.ACTION_VIEW,url));}catch(Exception e){error(e);}});
        }catch(Exception e){handler.post(()->{if(stamp==generation)error(e);});}});
    }

    private Button smallIconButton(String value,String description){
        Button b=new Button(this);b.setText(value);b.setContentDescription(description);b.setAllCaps(false);b.setTextSize(20);b.setTextColor(accent);b.setMinWidth(0);b.setMinHeight(0);b.setPadding(0,0,0,0);b.setBackground(shape(panel,16));return b;
    }

    private ImageButton refIconButton(String icon,int color,String description){
        ImageButton b=new ImageButton(this);b.setImageDrawable(new UiIconDrawable(icon,color));b.setContentDescription(description);b.setPadding(dp(7),dp(7),dp(7),dp(7));b.setBackgroundColor(Color.TRANSPARENT);b.setScaleType(ImageView.ScaleType.FIT_CENTER);b.setColorFilter(null);return b;
    }
    private ImageView refIcon(String icon,int color){
        ImageView v=new ImageView(this);v.setImageDrawable(new UiIconDrawable(icon,color));v.setPadding(dp(5),dp(5),dp(5),dp(5));v.setScaleType(ImageView.ScaleType.FIT_CENTER);return v;
    }
    private void refCompoundIcon(TextView v,String icon,int color,int size){UiIconDrawable d=new UiIconDrawable(icon,color);d.setBounds(0,0,dp(size),dp(size));v.setCompoundDrawables(d,null,null,null);v.setCompoundDrawablePadding(0);}

    private GradientDrawable refCircle(int color){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setShape(GradientDrawable.OVAL);return d;
    }
    private void setComposeButtonIcon(String icon){
        if(sendButton==null)return;UiIconDrawable d=new UiIconDrawable(icon,Color.WHITE);d.setBounds(0,0,dp(21),dp(21));sendButton.setText("");sendButton.setCompoundDrawables(d,null,null,null);sendButton.setGravity(Gravity.CENTER);sendButton.setCompoundDrawablePadding(0);
    }

    private void mainToolbar(){
        final int cyanRef=Color.parseColor("#19C9D8");
        LinearLayout bar=horizontal();bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(18),dp(6),dp(14),dp(5));bar.setBackgroundColor(Color.parseColor("#0A2032"));
        TextView title=label("Muwahid",27,Color.WHITE);bold(title);bar.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));title.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton camera=refIconButton("camera",Color.parseColor("#E8F4FA"),"Камера");camera.setPadding(dp(9),dp(9),dp(9),dp(9));GradientDrawable camBg=shape(Color.parseColor("#102C42"),20);camBg.setStroke(dp(1),Color.parseColor("#244A62"));camera.setBackground(camBg);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(42),dp(42));cp.rightMargin=dp(9);bar.addView(camera,cp);camera.setOnClickListener(v->notice("Камера открывается внутри чата для отправки фото и видео."));
        ImageButton add=refIconButton("plus",Color.parseColor("#06232A"),"Создать чат");add.setPadding(dp(9),dp(9),dp(9),dp(9));add.setBackground(refCircle(cyanRef));bar.addView(add,new LinearLayout.LayoutParams(dp(42),dp(42)));add.setOnClickListener(v->{if(isChatListTab(mainTab))newChat();else createCommunity("Группы".equals(mainTab)?"group":"channel");});
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(62)));
    }
    private boolean isChatListTab(String tab){return "Все".equals(tab)||"Личные".equals(tab)||"Чаты".equals(tab);}

    private void mainTabs(){
        final int cyanRef=Color.parseColor("#18C7D7");
        if(isChatListTab(mainTab)){
            LinearLayout searchWrap=horizontal();searchWrap.setPadding(dp(14),0,dp(14),dp(7));
            EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Поиск чатов...");search.setHintTextColor(Color.parseColor("#91A7BA"));search.setTextColor(Color.WHITE);search.setTextSize(16);search.setPadding(dp(16),0,dp(16),0);search.setBackground(shape(Color.parseColor("#132B43"),24));
            UiIconDrawable magnify=new UiIconDrawable("search",Color.parseColor("#A2B7CA"));magnify.setBounds(0,0,dp(24),dp(24));search.setCompoundDrawables(magnify,null,null,null);search.setCompoundDrawablePadding(dp(9));searchWrap.addView(search,new LinearLayout.LayoutParams(-1,dp(46)));root.addView(searchWrap,new LinearLayout.LayoutParams(-1,dp(54)));
            search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){filter=s==null?"":s.toString().trim().toLowerCase(Locale.ROOT);drawChatList();}public void afterTextChanged(Editable e){}});
        }
        LinearLayout shell=horizontal();shell.setPadding(0,0,0,0);shell.setBackgroundColor(Color.TRANSPARENT);
        String[] keys={"Все","Личные","Группы","Каналы"};
        for(String name:keys){
            if("Группы".equals(name)&&!feature("groups",true))continue;if("Каналы".equals(name)&&!feature("channels",true))continue;
            boolean active=name.equals(mainTab);TextView item=label(name,14,active?Color.parseColor("#05202A"):Color.parseColor("#C6D0DB"));item.setGravity(Gravity.CENTER);if(active)bold(item);
            GradientDrawable chip=shape(active?cyanRef:Color.parseColor("#0A2032"),21);if(!active)chip.setStroke(dp(1),Color.parseColor("#28506A"));item.setBackground(chip);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,dp(38),1);ip.setMargins(dp(4),0,dp(4),0);shell.addView(item,ip);item.setOnClickListener(v->showHub(name));
        }
        LinearLayout wrap=horizontal();wrap.setPadding(dp(11),0,dp(11),dp(8));wrap.addView(shell,new LinearLayout.LayoutParams(-1,dp(40)));root.addView(wrap,new LinearLayout.LayoutParams(-1,dp(48)));
    }

    private void showChatSearchDialog(){
        if(!"Чаты".equals(mainTab)){Toast.makeText(this,"Поиск по чатам доступен во вкладке «Чаты»",Toast.LENGTH_SHORT).show();return;}
        EditText q=new EditText(this);q.setSingleLine(true);q.setHint("Имя или @имя пользователя");q.setPadding(dp(22),dp(12),dp(22),dp(12));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Поиск по чатам").setView(q).setNegativeButton("Закрыть",null).setPositiveButton("Найти",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{filter=q.getText().toString().trim().toLowerCase(Locale.ROOT);d.dismiss();drawChatList();}));d.show();
    }
    private void menuRow(LinearLayout card,String icon,String title,Runnable action){
        LinearLayout row=horizontal();row.setPadding(dp(8),dp(7),dp(6),dp(7));TextView mark=label(icon,21,accent);mark.setGravity(Gravity.CENTER);row.addView(mark,new LinearLayout.LayoutParams(dp(42),dp(44)));TextView t=label(title,16,text);t.setGravity(Gravity.CENTER_VERTICAL);row.addView(t,new LinearLayout.LayoutParams(0,dp(44),1));TextView a=label("›",26,muted);a.setGravity(Gravity.CENTER);row.addView(a,new LinearLayout.LayoutParams(dp(28),dp(44)));card.addView(row);row.setOnClickListener(v->action.run());
    }
    private void showAppMenu(){
        begin("menu");
        LinearLayout head=horizontal();head.setPadding(dp(18),dp(12),dp(14),dp(10));Logo logo=new Logo(this,false);head.addView(logo,new LinearLayout.LayoutParams(dp(38),dp(44)));TextView app=label(rc("ui.app_name","Muwahid"),20,text);bold(app);app.setPadding(dp(10),0,0,0);head.addView(app,new LinearLayout.LayoutParams(0,dp(44),1));TextView gear=label("⚙",23,text);gear.setGravity(Gravity.CENTER);head.addView(gear,new LinearLayout.LayoutParams(dp(44),dp(44)));gear.setOnClickListener(v->showSettings());root.addView(head);
        ScrollView sv=new ScrollView(this);content=vertical();content.setPadding(dp(18),dp(6),dp(18),dp(24));sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout profileCard=horizontal();profileCard.setPadding(dp(10),dp(12),dp(8),dp(12));profileCard.setBackground(shape(panel,20));String name=prefs.getString("name","Пользователь Muwahid");avatar(profileCard,name,Color.rgb(12,142,158));LinearLayout words=vertical();TextView n=label(name,18,text);bold(n);words.addView(n);TextView u=label(prefs.getString("username","").isEmpty()?"Мой аккаунт":"@"+prefs.getString("username",""),13,muted);words.addView(u);profileCard.addView(words,new LinearLayout.LayoutParams(0,-2,1));TextView ch=label("›",28,muted);ch.setGravity(Gravity.CENTER);profileCard.addView(ch,new LinearLayout.LayoutParams(dp(30),dp(52)));content.addView(profileCard);profileCard.setOnClickListener(v->showAccountSettings());
        gap(content,14);LinearLayout card=vertical();card.setBackground(shape(panel,20));card.setPadding(dp(5),dp(5),dp(5),dp(5));content.addView(card);
        menuRow(card,"◯","Мой профиль",this::showAccountSettings);menuRow(card,"☆","Избранное",this::showNotes);if(feature("voice_rooms",true))menuRow(card,"◉","Голосовые комнаты",this::showVoiceRooms);if(feature("admins",true))menuRow(card,"♛","Администраторы",this::showAdminManagement);menuRow(card,"☎","Недавние звонки",this::showRecentCalls);menuRow(card,"♧","Пригласить",this::shareInvite);menuRow(card,"⚙","Настройки",this::showSettings);
        gap(content,14);LinearLayout create=vertical();create.setBackground(shape(panel,20));create.setPadding(dp(5),dp(5),dp(5),dp(5));content.addView(create);
        if(feature("channels",true)){menuRow(create,"◉","Каналы",()->showHub("Каналы"));menuRow(create,"＋","Создать канал",()->createCommunity("channel"));}if(feature("groups",true)){menuRow(create,"♙","Группы",()->showHub("Группы"));menuRow(create,"＋","Создать группу",()->createCommunity("group"));}
        gap(content,16);Switch dark=new Switch(this);dark.setText("Тёмная тема");dark.setTextColor(text);dark.setTextSize(16);dark.setChecked(prefs.getBoolean("dark",true));content.addView(dark,new LinearLayout.LayoutParams(-1,dp(52)));dark.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("dark",on).apply();b.post(this::showAppMenu);});gap(content,10);TextView version=label("Muwahid "+BuildConfig.VERSION_NAME+" · Android",11,muted);version.setGravity(Gravity.CENTER);content.addView(version);
    }
    private void showVoiceRooms(){
        if(!feature("voice_rooms",true)){notice("Голосовые комнаты временно отключены через Supabase.");return;}
        if(!api.signedIn()){if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");return;}
        begin("voice_rooms");toolbar("Голосовые комнаты",true,"+",this::createVoiceRoom);scrollContent();
        TextView intro=label("Живые комнаты · 8 мест с микрофоном",14,muted);intro.setPadding(dp(2),0,0,dp(14));content.addView(intro);
        note(content,"В комнату можно войти сразу слушателем. Чтобы говорить, нажмите «Поднять руку» — ведущий или модератор даст одно из 8 мест с микрофоном.");
        gap(content,14);TextView state=label("Загружаем комнаты…",14,muted);content.addView(state);
        async(()->api.rpc("mw_room_list",new JSONObject()),value->{
            if(!(value instanceof JSONArray))throw new Exception("Сервер вернул некорректный список комнат");
            JSONArray rooms=(JSONArray)value;content.removeAllViews();
            TextView intro2=label("Живые комнаты · до 8 участников",14,muted);intro2.setPadding(dp(2),0,0,dp(14));content.addView(intro2);
            note(content,"В комнату можно войти сразу слушателем. Чтобы говорить, нажмите «Поднять руку» — ведущий или модератор даст одно из 8 мест с микрофоном.");gap(content,14);
            if(rooms.length()==0){
                LinearLayout empty=settingsCard();TextView e=label("Пока нет активных комнат",18,text);bold(e);empty.addView(e);gap(empty,6);TextView d=label("Нажмите +, чтобы создать первую голосовую комнату.",14,muted);empty.addView(d);return;
            }
            for(int i=0;i<rooms.length();i++){
                JSONObject room=rooms.optJSONObject(i);if(room==null)continue;
                String id=room.optString("id"),title=room.optString("title","Голосовая комната");int count=room.optInt("participants",0),speaking=room.optInt("speaking",0);
                LinearLayout card=settingsCard();LinearLayout row=horizontal();row.setPadding(dp(8),dp(9),dp(8),dp(9));
                TextView icon=label("◉",25,accent);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(Color.parseColor("#10364A"),17));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(50),dp(50));ip.rightMargin=dp(13);row.addView(icon,ip);
                LinearLayout words=vertical();TextView t=label(title,17,text);bold(t);words.addView(t);String sub=count+" из 8"+(speaking==0?" · все микрофоны выключены":" · говорят: "+speaking);TextView st=label(sub,13,muted);st.setPadding(0,dp(4),0,0);words.addView(st);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
                TextView go=label("›",30,muted);go.setGravity(Gravity.CENTER);row.addView(go,new LinearLayout.LayoutParams(dp(32),dp(50)));card.addView(row);row.setOnClickListener(v->openVoiceRoom(id,title));
            }
        });
    }
    private void createVoiceRoom(){
        if(!api.signedIn()){showAuth(false);return;}
        EditText name=new EditText(this);name.setSingleLine(true);name.setHint("Название комнаты");name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(80)});name.setPadding(dp(22),dp(14),dp(22),dp(14));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Новая голосовая комната").setView(name).setNegativeButton("Отмена",null).setPositiveButton("Создать",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{String title=name.getText().toString().trim();if(title.isEmpty()){name.setError("Введите название");return;}d.dismiss();async(()->api.rpc("mw_room_create",new JSONObject().put("p_title",title)),value->{if(!(value instanceof JSONObject))throw new Exception("Не удалось создать комнату");JSONObject room=(JSONObject)value;openVoiceRoom(room.getString("id"),room.optString("title",title));});}));d.show();
    }
    private void openVoiceRoom(String id,String title){
        Intent i=new Intent(this,VoiceRoomActivity.class);i.putExtra("room_id",id);i.putExtra("room_title",title);startActivity(i);
    }
    private void showAdminManagement(){
        if(!feature("admins",true)){notice("Раздел администраторов временно отключён через Supabase.");return;}
        if(!api.signedIn()){showAuth(false);return;}
        async(()->api.rpc("mw_role_status",new JSONObject()),value->{
            if(!(value instanceof JSONObject)||!((JSONObject)value).optBoolean("is_owner",false)){notice("Управлять администраторами может только владелец Muwahid.");return;}
            showAdminManagementOwner();
        });
    }
    private void showAdminManagementOwner(){
        begin("admins");toolbar("Администраторы",true,"+",this::addAdministrator);scrollContent();
        note(content,"Администратор — помощник владельца. Он может модерировать комнаты, но не может стать владельцем, передать владение или снять владельца.");gap(content,14);
        TextView state=label("Загружаем список…",14,muted);content.addView(state);
        async(()->api.rpc("mw_admin_list",new JSONObject()),value->{
            if(!(value instanceof JSONArray))throw new Exception("Сервер вернул некорректный список администраторов");
            JSONArray admins=(JSONArray)value;content.removeAllViews();note(content,"Администратор — помощник владельца. Он может модерировать комнаты, но не может стать владельцем, передать владение или снять владельца.");gap(content,14);
            if(admins.length()==0){LinearLayout card=settingsCard();TextView e=label("Администраторы не назначены",17,text);bold(e);card.addView(e);gap(card,5);card.addView(label("Нажмите +, чтобы назначить помощника.",14,muted));return;}
            for(int i=0;i<admins.length();i++){
                JSONObject a=admins.optJSONObject(i);if(a==null)continue;String id=a.optString("id"),name=a.optString("display_name","Пользователь"),username=a.optString("username","");
                LinearLayout card=settingsCard();settingRow(card,"♛",Color.rgb(30,160,145),name,username.isEmpty()?"Администратор":"@"+username+" · администратор",()->confirmRemoveAdministrator(id,name));
            }
        });
    }
    private void addAdministrator(){
        EditText q=new EditText(this);q.setSingleLine(true);q.setHint("+номер телефона или @имя");q.setPadding(dp(22),dp(14),dp(22),dp(14));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Назначить администратора").setView(q).setNegativeButton("Отмена",null).setPositiveButton("Найти",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{String query=q.getText().toString().trim();if(query.isEmpty()){q.setError("Введите пользователя");return;}d.dismiss();async(()->{
            Object found=api.rpc("mw_find_person_any",new JSONObject().put("p_query",query));if(!(found instanceof JSONObject))throw new Exception("Пользователь не найден");JSONObject p=(JSONObject)found;return p;
        },value->{JSONObject p=(JSONObject)value;String id=p.getString("id"),name=p.optString("display_name","Пользователь");new AlertDialog.Builder(this).setTitle("Назначить администратора?").setMessage(name+" сможет модерировать пользователей и голосовые комнаты от вашего имени. Права владельца ему не передаются.").setNegativeButton("Отмена",null).setPositiveButton("Назначить",(dd,w)->async(()->api.rpc("mw_owner_admin_set",new JSONObject().put("p_user",id).put("p_enabled",true)),ok->{Toast.makeText(this,"Администратор назначен",Toast.LENGTH_SHORT).show();showAdminManagementOwner();})).show();});}));d.show();
    }
    private void confirmRemoveAdministrator(String id,String name){
        new AlertDialog.Builder(this).setTitle("Снять администратора?").setMessage(name+" потеряет административные права. Его обычный аккаунт останется активным.").setNegativeButton("Отмена",null).setPositiveButton("Снять",(d,w)->async(()->api.rpc("mw_owner_admin_set",new JSONObject().put("p_user",id).put("p_enabled",false)),value->{Toast.makeText(this,"Права администратора сняты",Toast.LENGTH_SHORT).show();showAdminManagementOwner();})).show();
    }

    private void shareInvite(){
        Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("text/plain");String user=prefs.getString("username","");intent.putExtra(Intent.EXTRA_TEXT,user.isEmpty()?"Присоединяйся ко мне в Muwahid":"Найди меня в Muwahid: @"+user);try{startActivity(Intent.createChooser(intent,"Пригласить в Muwahid"));}catch(Exception e){notice("Не удалось открыть меню отправки.");}
    }
    private void showRecentCalls(){
        begin("calls");toolbar("Недавние звонки",false,"+",this::showChats);scrollContent();
        note(content,"Чтобы позвонить, выберите контакт. Аудио- и видеозвонки работают из личного чата.");gap(content,14);
        LinearLayout card=settingsCard();int shown=0;for(int i=0;i<chats.length();i++){JSONObject c=chats.optJSONObject(i);if(c==null)continue;shown++;String name=c.optString("display_name","Контакт");String id=c.optString("id");settingRow(card,"☎",Color.rgb(13,151,132),name,"Аудио или видеозвонок",()->{chatId=id;chatName=name;chooseCall();});}
        if(shown==0){note(content,"Пока нет контактов для звонка. Откройте «Чаты» и начните переписку.");}
        bottom("Звонки");
    }
    private void showContacts(){
        begin("contacts");toolbar("Контакты",false,"+",this::newChat);scrollContent();
        LinearLayout card=settingsCard();int shown=0;for(int i=0;i<chats.length();i++){JSONObject c=chats.optJSONObject(i);if(c==null)continue;shown++;String name=c.optString("display_name","Контакт");String id=c.optString("id");String username=c.optString("username","");settingRow(card,"●",Color.rgb(26,139,159),name,username.isEmpty()?"Открыть чат":"@"+username,()->showChat(id,name));}
        if(shown==0)note(content,"Контакты появятся после начала личных чатов.");
        bottom("Контакты");
    }
    private JSONArray localCommunities(String kind){try{return new JSONArray(prefs.getString("local_"+kind,"[]"));}catch(Exception e){return new JSONArray();}}
    private void saveCommunities(String kind,JSONArray a){prefs.edit().putString("local_"+kind,a.toString()).apply();}
    private JSONObject communityDefaults(JSONObject c,String kind){
        if(c==null)c=new JSONObject();
        try{
            if(!c.has("visibility"))c.put("visibility","private");
            if(!c.has("history_visible"))c.put("history_visible",true);
            if(!c.has("members_hidden"))c.put("members_hidden",false);
            if(!c.has("welcome"))c.put("welcome","");
            if(!c.has("slow_mode"))c.put("slow_mode",0);
            if(!c.has("allow_text"))c.put("allow_text",true);
            if(!c.has("allow_media"))c.put("allow_media",true);
            if(!c.has("allow_stickers"))c.put("allow_stickers",true);
            if(!c.has("allow_voice"))c.put("allow_voice",true);
            if(!c.has("allow_video_messages"))c.put("allow_video_messages",true);
            if(!c.has("allow_links"))c.put("allow_links",true);
            if(!c.has("allow_polls"))c.put("allow_polls",true);
            if(!c.has("allow_reactions"))c.put("allow_reactions",true);
            if(!c.has("allow_invites"))c.put("allow_invites",true);
            if(!c.has("allow_pin"))c.put("allow_pin",false);
            if(!c.has("allow_profile_edit"))c.put("allow_profile_edit",false);
            if(!c.has("join_approval"))c.put("join_approval",false);
            if(!c.has("invite_token"))c.put("invite_token",UUID.randomUUID().toString().replace("-","").substring(0,16));
            if(!c.has("kind"))c.put("kind",kind);
        }catch(Exception ignored){}
        return c;
    }
    private JSONObject findCommunity(String kind,String id){JSONArray a=localCommunities(kind);for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&id.equals(c.optString("id")))return communityDefaults(c,kind);}return null;}
    private void saveCommunity(String kind,JSONObject value){try{JSONArray a=localCommunities(kind),out=new JSONArray();boolean found=false;for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&value.optString("id").equals(c.optString("id"))){out.put(value);found=true;}else if(c!=null)out.put(c);}if(!found)out.put(value);saveCommunities(kind,out);}catch(Exception e){error(e);}}
    private void createCommunity(String kind){
        LinearLayout form=vertical();form.setPadding(dp(18),dp(4),dp(18),0);
        EditText name=new EditText(this);name.setSingleLine(true);name.setHint("Название");form.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView typeLabel=label("Тип",13,muted);typeLabel.setPadding(0,dp(8),0,dp(4));form.addView(typeLabel);
        Spinner visibility=new Spinner(this);visibility.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Частная","Публичная"}));form.addView(visibility,new LinearLayout.LayoutParams(-1,dp(52)));
        Switch approval=new Switch(this);approval.setText("Вход по заявке");approval.setTextColor(text);approval.setPadding(0,dp(8),0,dp(8));form.addView(approval);
        String title="group".equals(kind)?"Создать группу":"Создать канал";
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(form).setNegativeButton("Отмена",null).setPositiveButton("Создать",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String value=name.getText().toString().trim();if(value.isEmpty()){name.setError("Введите название");return;}try{JSONObject c=communityDefaults(new JSONObject().put("id",UUID.randomUUID().toString()).put("name",value).put("created",System.currentTimeMillis()).put("visibility",visibility.getSelectedItemPosition()==1?"public":"private").put("join_approval",approval.isChecked()),kind);JSONArray a=localCommunities(kind);a.put(c);saveCommunities(kind,a);dialog.dismiss();showHub("group".equals(kind)?"Группы":"Каналы");}catch(Exception e){error(e);}}));
        dialog.show();
    }
    private void drawCommunityList(String kind){
        if(list==null)return;list.removeAllViews();JSONArray a=localCommunities(kind);String singular="group".equals(kind)?"группа":"канал";
        for(int i=0;i<a.length();i++){JSONObject c=communityDefaults(a.optJSONObject(i),kind);String name=c.optString("name",singular),id=c.optString("id");LinearLayout row=horizontal();row.setPadding(dp(18),dp(12),dp(18),dp(12));avatar(row,name,"group".equals(kind)?Color.rgb(18,143,150):Color.rgb(27,119,185));LinearLayout words=vertical();TextView t=label(name,17,text);bold(t);words.addView(t);gap(words,4);String vis="public".equals(c.optString("visibility"))?"Публичная":"Частная";TextView sub=label(vis+" "+singular+" · "+(c.optBoolean("join_approval")?"вход по заявке":"вход по ссылке"),13,muted);words.addView(sub);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=label("›",27,muted);arrow.setGravity(Gravity.CENTER);row.addView(arrow,new LinearLayout.LayoutParams(dp(34),dp(52)));list.addView(row);row.setOnClickListener(v->showLocalCommunity(kind,id,name));}
        if(a.length()==0){LinearLayout empty=vertical();empty.setPadding(dp(28),dp(58),dp(28),dp(28));TextView icon=label("group".equals(kind)?"♙":"◉",52,accent);icon.setGravity(Gravity.CENTER);empty.addView(icon);gap(empty,16);TextView title=label("group".equals(kind)?"Создайте первую группу":"Создайте первый канал",20,text);bold(title);title.setGravity(Gravity.CENTER);empty.addView(title);gap(empty,10);TextView desc=label("Нажмите + сверху. Можно выбрать публичный или частный режим и затем настроить права участников.",14,muted);desc.setGravity(Gravity.CENTER);desc.setLineSpacing(dp(3),1);empty.addView(desc);list.addView(empty);}
    }
    private void showLocalCommunity(String kind,String id,String name){
        JSONObject cfg=findCommunity(kind,id);if(cfg==null){showHub("group".equals(kind)?"Группы":"Каналы");return;}
        begin("community");toolbar(name,true,"⋮",()->showCommunitySettings(kind,id,name));String vis="public".equals(cfg.optString("visibility"))?"Публичная":"Частная";connection=label(vis+" "+("group".equals(kind)?"группа":"канал")+" · управление ⋮",12,muted);connection.setPadding(dp(20),dp(8),dp(16),dp(8));root.addView(connection);
        String welcome=cfg.optString("welcome","");if(!welcome.isEmpty()){TextView w=label("👋 "+welcome,13,Color.parseColor("#C8E8F0"));w.setPadding(dp(16),dp(10),dp(16),dp(10));w.setBackground(shape(Color.parseColor("#12344A"),16));LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,-2);wp.setMargins(dp(12),0,dp(12),dp(6));root.addView(w,wp);}
        messageScroll=new ScrollView(this);messages=vertical();messages.setPadding(dp(12),dp(12),dp(12),dp(14));messageScroll.addView(messages);root.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));
        final String key="community_messages:"+id;Runnable redraw=()->{messages.removeAllViews();try{JSONArray a=new JSONArray(prefs.getString(key,"[]"));if(a.length()==0)note(messages,"Пока сообщений нет.");for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i);if(m!=null)bubble(m.optString("body"),true,m.optString("time"));}}catch(Exception e){note(messages,"Не удалось открыть локальные сообщения.");}bottomScroll();};redraw.run();
        LinearLayout compose=horizontal();compose.setPadding(dp(10),dp(8),dp(10),dp(10));compose.setBackgroundColor(panel);EditText local=new EditText(this);local.setHint("channel".equals(kind)?"Публикация":"Сообщение");local.setHintTextColor(muted);local.setTextColor(text);local.setTextSize(16);local.setMaxLines(4);local.setPadding(dp(14),dp(10),dp(14),dp(10));local.setBackground(shape(bg,20));compose.addView(local,new LinearLayout.LayoutParams(0,-2,1));Button send=button("↑");LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(50),dp(48));sp.leftMargin=dp(7);compose.addView(send,sp);root.addView(compose);
        boolean canText=cfg.optBoolean("allow_text",true);local.setEnabled(canText);send.setEnabled(canText);if(!canText)local.setHint("Отправка текста отключена");
        send.setOnClickListener(v->{String body=local.getText().toString().trim();if(body.isEmpty())return;JSONObject current=findCommunity(kind,id);int slow=current==null?0:current.optInt("slow_mode",0);long last=prefs.getLong("community_last_send:"+id,0),now=System.currentTimeMillis();if(slow>0&&now-last<slow*1000L){long wait=(slow*1000L-(now-last)+999)/1000;Toast.makeText(this,"Медленный режим · подождите "+wait+" сек.",Toast.LENGTH_SHORT).show();return;}try{JSONArray a=new JSONArray(prefs.getString(key,"[]"));a.put(new JSONObject().put("body",body).put("time",new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date())));prefs.edit().putString(key,a.toString()).putLong("community_last_send:"+id,now).apply();local.setText("");redraw.run();}catch(Exception e){error(e);}});
    }
    private void showCommunitySettings(String kind,String id,String name){
        JSONObject c=findCommunity(kind,id);if(c==null)return;begin("community_settings");toolbar("Управление",true,null,null);scrollContent();
        LinearLayout basic=settingsCard();profileCaption(basic,name);String vis="public".equals(c.optString("visibility"))?"Публичная":"Частная";LinearLayout type=simpleSettingRow(basic,"Тип "+("group".equals(kind)?"группы":"канала"),vis,valueText("›"));type.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Тип").setItems(new String[]{"Частная","Публичная"},(d,w)->{try{c.put("visibility",w==1?"public":"private");saveCommunity(kind,c);showCommunitySettings(kind,id,name);}catch(Exception e){error(e);}}).show());
        LinearLayout welcome=simpleSettingRow(basic,"Приветствие",c.optString("welcome").isEmpty()?"Не задано":c.optString("welcome"),valueText("›"));welcome.setOnClickListener(v->editCommunityText(kind,c,"welcome","Приветствие",160,name));
        Switch approval=cardSwitch(basic,"Вход по заявке","Новые участники ждут одобрения",c.optBoolean("join_approval"),"community_join_approval");approval.setOnCheckedChangeListener((b,on)->{try{c.put("join_approval",on);saveCommunity(kind,c);}catch(Exception ignored){}});
        gap(content,12);LinearLayout privacy=settingsCard();cardCaption(privacy,"История и участники");
        Switch history=cardSwitch(privacy,"История чата","Показывать прошлые сообщения новым участникам",c.optBoolean("history_visible",true),"community_history_visible");history.setOnCheckedChangeListener((b,on)->{try{c.put("history_visible",on);saveCommunity(kind,c);}catch(Exception ignored){}});
        Switch hidden=cardSwitch(privacy,"Скрыть участников","Список участников видят только администраторы",c.optBoolean("members_hidden",false),"community_members_hidden");hidden.setOnCheckedChangeListener((b,on)->{try{c.put("members_hidden",on);saveCommunity(kind,c);}catch(Exception ignored){}});
        gap(content,12);LinearLayout perms=settingsCard();cardCaption(perms,"Разрешения участников");
        communitySwitch(perms,c,kind,"allow_text","Текстовые сообщения","Отправка обычного текста");
        communitySwitch(perms,c,kind,"allow_media","Фото, видео, музыка и файлы","Медиафайлы");
        communitySwitch(perms,c,kind,"allow_stickers","Стикеры и GIF","Стикеры и анимации");
        communitySwitch(perms,c,kind,"allow_voice","Голосовые сообщения","Аудиосообщения");
        communitySwitch(perms,c,kind,"allow_video_messages","Видеосообщения","Видео от участников");
        communitySwitch(perms,c,kind,"allow_links","Предпросмотр ссылок","Ссылки и карточки");
        communitySwitch(perms,c,kind,"allow_polls","Опросы","Создание опросов");
        communitySwitch(perms,c,kind,"allow_reactions","Реакции","Реакции на сообщения");
        communitySwitch(perms,c,kind,"allow_invites","Добавление участников","Приглашения");
        communitySwitch(perms,c,kind,"allow_pin","Закрепление сообщений","Участники могут закреплять");
        communitySwitch(perms,c,kind,"allow_profile_edit","Изменение профиля группы","Название и описание");
        gap(content,12);LinearLayout rate=settingsCard();cardCaption(rate,"Медленный режим");final int[] seconds={0,5,10,30,60,300,900,3600};final String[] labels={"Выключен","5 секунд","10 секунд","30 секунд","1 минута","5 минут","15 минут","1 час"};int currentIndex=slowModeIndex(c.optInt("slow_mode",0),seconds);LinearLayout slow=simpleSettingRow(rate,"Интервал между сообщениями",labels[currentIndex],valueText("›"));slow.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Медленный режим").setItems(labels,(d,w)->{try{c.put("slow_mode",seconds[w]);saveCommunity(kind,c);showCommunitySettings(kind,id,name);}catch(Exception e){error(e);}}).show());
        gap(content,12);LinearLayout invites=settingsCard();cardCaption(invites,"Пригласительная ссылка");String invite=communityInviteLink(c);TextView linkText=label(invite,13,accent);linkText.setTextIsSelectable(true);linkText.setPadding(dp(10),dp(8),dp(10),dp(8));invites.addView(linkText);LinearLayout copyLink=simpleSettingRow(invites,"Скопировать ссылку","Приглашение в Muwahid",valueText("›"));copyLink.setOnClickListener(v->copy(invite));LinearLayout reset=simpleSettingRow(invites,"Создать новую ссылку","Старая ссылка заменяется",valueText("↻"));reset.setOnClickListener(v->{try{c.put("invite_token",UUID.randomUUID().toString().replace("-","").substring(0,16));saveCommunity(kind,c);showCommunitySettings(kind,id,name);}catch(Exception e){error(e);}});
        gap(content,12);LinearLayout danger=settingsCard();LinearLayout leave=simpleSettingRow(danger,"Покинуть "+("group".equals(kind)?"группу":"канал"),"Удалить из своего списка",valueText("›"));leave.setOnClickListener(v->removeLocalCommunity(kind,id,false));LinearLayout delete=simpleSettingRow(danger,"Удалить "+("group".equals(kind)?"группу":"канал"),"Действие владельца",valueText("›"));delete.setOnClickListener(v->removeLocalCommunity(kind,id,true));
    }
    private int slowModeIndex(int value,int[] seconds){for(int i=0;i<seconds.length;i++)if(seconds[i]==value)return i;return 0;}
    private void communitySwitch(LinearLayout card,JSONObject c,String kind,String key,String title,String subtitle){Switch sw=cardSwitch(card,title,subtitle,c.optBoolean(key,true),"community_"+key);sw.setOnCheckedChangeListener((b,on)->{try{c.put(key,on);saveCommunity(kind,c);}catch(Exception ignored){}});}
    private void editCommunityText(String kind,JSONObject c,String key,String title,int max,String name){EditText input=new EditText(this);input.setText(c.optString(key));input.setMaxLines(4);input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});new AlertDialog.Builder(this).setTitle(title).setView(input).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{try{c.put(key,input.getText().toString().trim());saveCommunity(kind,c);showCommunitySettings(kind,c.optString("id"),name);}catch(Exception e){error(e);}}).show();}
    private String communityInviteLink(JSONObject c){return "https://muwahid.app/join/"+c.optString("id")+"?token="+c.optString("invite_token");}
    private void removeLocalCommunity(String kind,String id,boolean ownerDelete){new AlertDialog.Builder(this).setTitle(ownerDelete?"Удалить для всех?":"Покинуть?").setMessage(ownerDelete?"Сообщество будет удалено с этого телефона. Серверное удаление подключается отдельно.":"Сообщество будет удалено из вашего списка на этом телефоне.").setNegativeButton("Отмена",null).setPositiveButton(ownerDelete?"Удалить":"Покинуть",(d,w)->{JSONArray a=localCommunities(kind),out=new JSONArray();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&!id.equals(c.optString("id")))out.put(c);}saveCommunities(kind,out);showHub("group".equals(kind)?"Группы":"Каналы");}).show();}

    private void showPhoneCode(String phone,boolean register){phoneRegisterMode=register;begin("otp");toolbar(rc("auth.otp_title","Подтверждение номера"),true,null,null);scrollContent();
        String otpIntro=rc("auth.otp_intro","SMS-код отправлен на {phone}. Введите 6 цифр из сообщения.").replace("{phone}",phone);note(content,otpIntro);gap(content,20);EditText code=field(rc("auth.otp_hint","6-значный SMS-код"),false);code.setInputType(2);code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        Button verify=button(rc("auth.otp_button","Подтвердить и войти"));content.addView(verify,new LinearLayout.LayoutParams(-1,dp(54)));verify.setOnClickListener(v->{String value=code.getText().toString().trim();if(!value.matches("[0-9]{6}")){code.setError("Введите 6 цифр из SMS");return;}verify.setEnabled(false);final int stamp=generation;worker.execute(()->{try{api.verifyPhoneOtp(phone,value);try{api.rpc("mw_sync_my_phone",new JSONObject());}catch(Exception ignored){}handler.post(()->{if(stamp!=generation)return;maybeStartNotifications();showChats();});}catch(Exception ex){handler.post(()->{if(stamp==generation){verify.setEnabled(true);code.setText("");error(ex);}});}});});
        gap(content,18);TextView resend=label(rc("auth.resend_text","Получить новый код"),15,accent);resend.setGravity(Gravity.CENTER);content.addView(resend);resend.setOnClickListener(v->{worker.execute(()->{try{api.sendPhoneOtp(phone);handler.post(()->Toast.makeText(this,"Новый код отправлен",Toast.LENGTH_SHORT).show());}catch(Exception e){handler.post(()->error(e));}});});
    }
    private void showChats(){showHub("Все");}
    private void showHub(String tab){
        if("Чаты".equals(tab))tab="Все";
        if("Группы".equals(tab)&&!feature("groups",true))tab="Все";if("Каналы".equals(tab)&&!feature("channels",true))tab="Все";
        mainTab=tab;begin("chats");chatFolderFilter=prefs.getString("chat_folder","all");if(api.signedIn())maybeStartNotifications();
        GradientDrawable bgDraw=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.parseColor("#071827"),Color.parseColor("#061522"),Color.parseColor("#04101B")});root.setBackground(bgDraw);
        mainToolbar();mainTabs();
        connection=label("",11,muted);connection.setPadding(dp(18),dp(4),dp(18),dp(4));connection.setVisibility(View.GONE);root.addView(connection);
        String announcement=rc("ui.announcement","");if(!announcement.isEmpty()){TextView banner=label(announcement,13,text);banner.setPadding(dp(18),dp(10),dp(18),dp(10));banner.setBackground(shape(Color.parseColor("#12334B"),12));root.addView(banner,new LinearLayout.LayoutParams(-1,-2));}
        addActiveCallBanner();
        addVoiceRoomShortcut();
        FrameLayout frame=new FrameLayout(this);ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);sv.setClipToPadding(false);list=vertical();list.setPadding(dp(10),dp(4),dp(10),dp(92));sv.addView(list,new FrameLayout.LayoutParams(-1,-2));frame.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        TextView fab=label("+",26,Color.rgb(4,28,35));fab.setGravity(Gravity.CENTER);bold(fab);GradientDrawable fabBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{accent,cyan});fabBg.setShape(GradientDrawable.OVAL);fab.setBackground(fabBg);fab.setElevation(dp(4));FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(50),dp(50),Gravity.END|Gravity.BOTTOM);fp.rightMargin=dp(17);fp.bottomMargin=dp(16);frame.addView(fab,fp);fab.setOnClickListener(v->{if(isChatListTab(mainTab))newChat();else createCommunity("Группы".equals(mainTab)?"group":"channel");});
        root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));bottom("Чаты");filter="";
        if(isChatListTab(tab)){drawChatList();if(api.signedIn()){publishE2eeIdentity();loadChats(true);}else{connection.setText("Войдите, чтобы общаться");connection.setVisibility(View.VISIBLE);connection.setOnClickListener(v->{if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");});}}
        else drawCommunityList("Группы".equals(tab)?"group":"channel");
    }
    private void loadChats(boolean report){if(loading)return;final int stamp=generation;loading=true;worker.execute(()->{try{JSONArray result=(JSONArray)api.rpc("mw_chat_list",new JSONObject());handler.post(()->{loading=false;if(stamp!=generation)return;chats=result;if(isChatListTab(mainTab)){if(connection!=null){connection.setText("");connection.setVisibility(View.GONE);}drawChatList();}});}catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;if(connection!=null){connection.setText("Нет связи · нажмите, чтобы повторить");connection.setVisibility(View.VISIBLE);connection.setOnClickListener(v->loadChats(true));}if(report)error(e);});}});}

    private void avatar(LinearLayout row,String name,int color){avatar(row,name,color,false);}
    private void avatar(LinearLayout row,String name,int color,boolean isOnline){
        TextView a=label(name.isEmpty()?"M":name.substring(0,1).toUpperCase(Locale.ROOT),22,Color.WHITE);a.setGravity(Gravity.CENTER);bold(a);
        GradientDrawable bgAvatar=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.parseColor("#63C5F0"),Color.parseColor("#2278C2")});bgAvatar.setShape(GradientDrawable.OVAL);a.setBackground(bgAvatar);
        FrameLayout frame=new FrameLayout(this);frame.addView(a,new FrameLayout.LayoutParams(dp(54),dp(54)));
        if(isOnline){View dot=new View(this);dot.setBackground(refCircle(Color.parseColor("#39D46B")));FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(dp(12),dp(12),Gravity.END|Gravity.BOTTOM);op.rightMargin=dp(1);op.bottomMargin=dp(1);frame.addView(dot,op);}
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(56),dp(56));p.rightMargin=dp(12);row.addView(frame,p);
    }

    private void drawChatList(){
        if(list==null||!screen.equals("chats")||!isChatListTab(mainTab))return;list.removeAllViews();int shown=0;
        for(int i=0;i<chats.length();i++){
            JSONObject c=chats.optJSONObject(i);if(c==null)continue;String name=c.optString("display_name","Чат"),cid=c.optString("id");
            if("important".equals(chatFolderFilter)&&!isImportantChat(cid))continue;if(isHiddenChat(cid))continue;
            if(!name.toLowerCase(Locale.ROOT).contains(filter)&&!c.optString("username").toLowerCase(Locale.ROOT).contains(filter))continue;
            shown++;
            LinearLayout row=horizontal();row.setPadding(dp(14),dp(9),dp(14),dp(9));row.setGravity(Gravity.CENTER_VERTICAL);GradientDrawable rowBg=shape(Color.parseColor("#0A2032"),18);rowBg.setStroke(dp(1),Color.parseColor("#14364E"));row.setBackground(rowBg);
            avatar(row,name,Color.parseColor("#2E8ACC"),c.optBoolean("online",false));
            LinearLayout words=vertical();words.setGravity(Gravity.CENTER_VERTICAL);
            TextView title=label(name,17,Color.WHITE);bold(title);title.setMaxLines(1);title.setEllipsize(TextUtils.TruncateAt.END);words.addView(title,new LinearLayout.LayoutParams(-1,dp(24)));
            String last=c.isNull("last_message")?"Начните переписку":c.optString("last_message","Начните переписку");if(last==null||last.trim().isEmpty())last="Начните переписку";
            TextView preview=label(last,13,last.contains("Фото")||last.contains("Видео")||last.contains("Аудио")?Color.parseColor("#37D7E3"):Color.parseColor("#A9B8C7"));preview.setMaxLines(1);preview.setEllipsize(TextUtils.TruncateAt.END);preview.setGravity(Gravity.CENTER_VERTICAL);words.addView(preview,new LinearLayout.LayoutParams(-1,dp(22)));
            row.addView(words,new LinearLayout.LayoutParams(0,dp(50),1));
            LinearLayout meta=vertical();meta.setGravity(Gravity.END);TextView time=label(time(c.optString("updated_at")),11,Color.parseColor("#899BAE"));time.setGravity(Gravity.END);meta.addView(time,new LinearLayout.LayoutParams(-1,dp(20)));
            int unread=c.optInt("unread_count",0);
            if(unread>0){TextView badge=label(String.valueOf(Math.min(unread,99)),11,Color.parseColor("#05202A"));bold(badge);badge.setGravity(Gravity.CENTER);badge.setBackground(refCircle(Color.parseColor("#18C7D7")));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(22),dp(22));bp.gravity=Gravity.END;bp.topMargin=dp(4);meta.addView(badge,bp);}
            else{Space sp=new Space(this);meta.addView(sp,new LinearLayout.LayoutParams(dp(22),dp(22)));}
            row.addView(meta,new LinearLayout.LayoutParams(dp(55),dp(50)));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(74));rp.setMargins(dp(2),dp(4),dp(2),dp(4));list.addView(row,rp);
            final float[] downX={0};row.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN)downX[0]=e.getX();else if(e.getAction()==MotionEvent.ACTION_UP&&downX[0]-e.getX()>dp(70)){performChatSwipe(c,name);return true;}return false;});
            row.setOnClickListener(v->{chatPeerOnline=c.optBoolean("online",false);chatPeerLastSeen=c.optString("last_seen","");showChat(c.optString("id"),name);});
            row.setOnLongClickListener(v->{String id=c.optString("id");boolean important=isImportantChat(id);new AlertDialog.Builder(this).setItems(new String[]{important?"Убрать из важных":"В важные","Скрыть чат"},(d,w)->{if(w==0)setImportantChat(id,!important);else hideChat(id);drawChatList();}).show();return true;});
        }
        if(shown==0){LinearLayout empty=vertical();empty.setGravity(Gravity.CENTER);TextView title=label(filter.isEmpty()?"Чатов пока нет":"Ничего не найдено",17,Color.parseColor("#C5D0DB"));bold(title);title.setGravity(Gravity.CENTER);empty.addView(title);TextView sub=label(filter.isEmpty()?"Начните новый разговор кнопкой +":"Измените запрос поиска",13,Color.parseColor("#72869A"));sub.setGravity(Gravity.CENTER);sub.setPadding(0,dp(7),0,0);empty.addView(sub);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(180)));}
    }

    private Set<String> hiddenChats(){Set<String> out=new HashSet<>();String raw=prefs.getString("hidden_chats","");if(raw!=null&&!raw.isEmpty())for(String x:raw.split(","))if(!x.isEmpty())out.add(x);return out;}
    private boolean isHiddenChat(String id){return hiddenChats().contains(id);}
    private void hideChat(String id){Set<String> set=hiddenChats();set.add(id);StringBuilder b=new StringBuilder();for(String v:set){if(b.length()>0)b.append(',');b.append(v);}prefs.edit().putString("hidden_chats",b.toString()).apply();}
    private void performChatSwipe(JSONObject c,String name){String action=prefs.getString("chat_swipe_action","folder"),id=c.optString("id");if("pin".equals(action)){setImportantChat(id,true);Toast.makeText(this,"Чат закреплён в «Важных»",Toast.LENGTH_SHORT).show();drawChatList();}else if("delete".equals(action)){new AlertDialog.Builder(this).setTitle("Убрать чат из списка?").setMessage("Переписка на сервере не удаляется. Чат будет скрыт только на этом телефоне.").setNegativeButton("Отмена",null).setPositiveButton("Скрыть",(d,w)->{hideChat(id);drawChatList();}).show();}else{boolean important=isImportantChat(id);setImportantChat(id,!important);Toast.makeText(this,important?"Убрано из папки «Важные»":"Добавлено в папку «Важные»",Toast.LENGTH_SHORT).show();drawChatList();}}
    private void newChat(){if(!api.signedIn()){if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");return;}
        EditText user=new EditText(this);user.setSingleLine(true);user.setHint("+номер телефона или @имя");user.setPadding(dp(24),dp(16),dp(24),dp(16));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Новый чат").setView(user).setNegativeButton("Отмена",null).setPositiveButton("Найти",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(w->{String query=user.getText().toString().trim();if(query.isEmpty()){user.setError("Введите номер или имя");return;}dialog.dismiss();async(()->{
            Object found=api.rpc("mw_find_person_any",new JSONObject().put("p_query",query));if(!(found instanceof JSONObject))throw new Exception("Пользователь не найден. Проверьте номер или имя.");JSONObject person=(JSONObject)found;Object id=api.rpc("mw_start_chat",new JSONObject().put("p_person",person.getString("id")));return new JSONObject().put("id",id).put("name",person.getString("display_name"));
        },v2->{JSONObject c=(JSONObject)v2;showChat(c.getString("id"),c.getString("name"));});}));dialog.show();
    }

    private void chatToolbar(String name){
        final int cyanRef=Color.parseColor("#18C9D8");
        LinearLayout bar=horizontal();bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(7),dp(4),dp(6),dp(4));bar.setBackgroundColor(Color.parseColor("#0A2032"));
        ImageButton back=refIconButton("back",cyanRef,"Назад");back.setPadding(dp(8),dp(8),dp(8),dp(8));bar.addView(back,new LinearLayout.LayoutParams(dp(40),dp(48)));back.setOnClickListener(v->onBackPressed());
        TextView av=label(name.isEmpty()?"M":name.substring(0,1).toUpperCase(Locale.ROOT),15,Color.WHITE);av.setGravity(Gravity.CENTER);bold(av);GradientDrawable avBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.parseColor("#78D0F4"),Color.parseColor("#247CC1")});avBg.setShape(GradientDrawable.OVAL);av.setBackground(avBg);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(44),dp(44));ap.rightMargin=dp(11);bar.addView(av,ap);
        LinearLayout words=vertical();words.setGravity(Gravity.CENTER_VERTICAL);TextView title=label(name,17,Color.WHITE);bold(title);title.setMaxLines(1);title.setEllipsize(TextUtils.TruncateAt.END);words.addView(title,new LinearLayout.LayoutParams(-1,dp(23)));chatPresenceStatus=label(notesMode?"личные заметки":presenceLabel(chatPeerOnline,chatPeerLastSeen),12,notesMode?Color.parseColor("#91A8BC"):(chatPeerOnline?Color.parseColor("#5DD8E6"):Color.parseColor("#91A8BC")));chatPresenceStatus.setGravity(Gravity.TOP);words.addView(chatPresenceStatus,new LinearLayout.LayoutParams(-1,dp(19)));bar.addView(words,new LinearLayout.LayoutParams(0,dp(48),1));
        if(!notesMode){
            ImageButton call=refIconButton("phone",cyanRef,"Аудиозвонок");call.setPadding(dp(8),dp(8),dp(8),dp(8));bar.addView(call,new LinearLayout.LayoutParams(dp(40),dp(44)));call.setOnClickListener(v->startCall("audio"));
            ImageButton video=refIconButton("video",cyanRef,"Видеозвонок");video.setPadding(dp(8),dp(8),dp(8),dp(8));bar.addView(video,new LinearLayout.LayoutParams(dp(40),dp(44)));video.setOnClickListener(v->startCall("video"));
            ImageButton more=refIconButton("more",cyanRef,"Меню");more.setPadding(dp(9),dp(9),dp(9),dp(9));bar.addView(more,new LinearLayout.LayoutParams(dp(34),dp(44)));more.setOnClickListener(v->showChatMenu());
        }
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(60)));View rule=new View(this);rule.setBackgroundColor(Color.parseColor("#15374E"));root.addView(rule,new LinearLayout.LayoutParams(-1,dp(1)));
    }
    private void showChatMenu(){
        String[] items={"Видеозвонок",isImportantChat(chatId)?"Убрать из «Важных»":"Добавить в «Важные»","Профиль и настройки"};new AlertDialog.Builder(this).setTitle(chatName).setItems(items,(d,w)->{if(w==0)startCall("video");else if(w==1){setImportantChat(chatId,!isImportantChat(chatId));Toast.makeText(this,"Список «Важные» обновлён",Toast.LENGTH_SHORT).show();}else showAccountSettings();}).show();
    }

    private void showChat(String id,String name){notesMode=false;openConversation(id,name);prepareE2eeChat();}
    private void publishE2eeIdentity(){
        if(!api.signedIn()||e2eePublishing||api.uid().equals(e2eePublishedFor))return;
        e2eePublishing=true;final String uid=api.uid();
        worker.execute(()->{try{String key=crypto.publicKey(uid);api.rpc("mw_e2ee_set_key",new JSONObject().put("p_public_key",key));e2eePublishedFor=uid;}catch(Exception ignored){}finally{e2eePublishing=false;}});
    }
    private void prepareE2eeChat(){
        final int stamp=generation;final String id=chatId,uid=api.uid();loading=true;connection.setText("Подготавливаем сквозное шифрование…");
        worker.execute(()->{try{
            String own=crypto.publicKey(uid);api.rpc("mw_e2ee_set_key",new JSONObject().put("p_public_key",own));e2eePublishedFor=uid;
            Object value=api.rpc("mw_e2ee_peer_key",new JSONObject().put("p_chat",id));final String peer=value instanceof String?(String)value:"";
            handler.post(()->{loading=false;if(stamp!=generation)return;e2eeBackendReady=true;peerE2eeKey=peer;connection.setText(chatSecurityStatus());loadMessages(true);});
        }catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;e2eeBackendReady=false;peerE2eeKey="";connection.setText(chatSecurityStatus());if(e instanceof Api.MfaRequiredException)error(e);else loadMessages(true);});}});
    }
    private String chatSecurityStatus(){
        if(e2eeBackendReady&&!peerE2eeKey.isEmpty())return "🔒 Сквозное шифрование активно";
        if(e2eeBackendReady)return "🔒 Собеседник ещё не активировал E2EE";
        return "Личная переписка · E2EE на сервере ещё не готово";
    }
    private void showNotes(){notesMode=true;openConversation("local-notes","Избранное");drawNotes();}

    private void openConversation(String id,String name){
        begin("chat");chatId=id;chatName=name;history.clear();pendingNonce="";pendingText="";pendingPayload="";peerE2eeKey="";e2eeBackendReady=false;root.setBackgroundColor(Color.parseColor("#061321"));chatToolbar(name);refreshChatPresence(id);
        connection=label(notesMode?"Личные заметки · только на этом телефоне":"Загрузка сообщений…",10,Color.parseColor("#7D91A4"));connection.setPadding(dp(12),dp(3),dp(12),dp(3));connection.setVisibility(View.GONE);root.addView(connection);
        messageScroll=new ScrollView(this);messageScroll.setFillViewport(true);messageScroll.setVerticalScrollBarEnabled(false);messageScroll.setBackground(new ChatWallpaperDrawable());messages=vertical();messages.setPadding(dp(10),dp(10),dp(10),dp(10));messageScroll.addView(messages);root.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout compose=horizontal();compose.setGravity(Gravity.CENTER_VERTICAL);compose.setPadding(dp(8),dp(6),dp(8),dp(7));compose.setBackgroundColor(Color.parseColor("#071725"));
        LinearLayout fieldBox=horizontal();fieldBox.setGravity(Gravity.CENTER_VERTICAL);fieldBox.setPadding(dp(1),0,dp(2),0);GradientDrawable fieldBg=shape(Color.parseColor("#173752"),30);fieldBg.setStroke(dp(2),Color.parseColor("#2D607D"));fieldBox.setBackground(fieldBg);
        if(!notesMode){
            emojiButton=smallIconButton("","Стикеры и эмодзи");refCompoundIcon(emojiButton,"smile",Color.parseColor("#B6C5D5"),22);emojiButton.setBackgroundColor(Color.TRANSPARENT);emojiButton.setPadding(dp(8),dp(8),dp(8),dp(8));fieldBox.addView(emojiButton,new LinearLayout.LayoutParams(dp(42),dp(48)));emojiButton.setOnClickListener(v->showEmojiPicker());
        }
        composer=new EditText(this);composer.setHint("Сообщение...");composer.setHintTextColor(Color.parseColor("#899CAF"));composer.setTextColor(Color.WHITE);composer.setTextSize(16);composer.setMaxLines(4);composer.setInputType(131073);composer.setPadding(dp(4),dp(7),dp(4),dp(7));composer.setBackgroundColor(Color.TRANSPARENT);composer.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4000)});fieldBox.addView(composer,new LinearLayout.LayoutParams(0,-2,1));
        if(!notesMode){
            attachButton=smallIconButton("","Прикрепить файл или местоположение");refCompoundIcon(attachButton,"clip",Color.parseColor("#B6C5D5"),22);attachButton.setBackgroundColor(Color.TRANSPARENT);attachButton.setPadding(dp(8),dp(8),dp(8),dp(8));fieldBox.addView(attachButton,new LinearLayout.LayoutParams(dp(42),dp(48)));attachButton.setOnClickListener(v->showAttachmentSheet());
            videoMessageButton=smallIconButton("","Камера");refCompoundIcon(videoMessageButton,"camera",Color.parseColor("#B6C5D5"),22);videoMessageButton.setBackgroundColor(Color.TRANSPARENT);videoMessageButton.setPadding(dp(8),dp(8),dp(8),dp(8));fieldBox.addView(videoMessageButton,new LinearLayout.LayoutParams(dp(42),dp(48)));videoMessageButton.setOnClickListener(v->capturePhoto());
        }
        compose.addView(fieldBox,new LinearLayout.LayoutParams(0,dp(50),1));
        voicePauseButton=new Button(this);voicePauseButton.setText("Ⅱ");voicePauseButton.setTextSize(17);voicePauseButton.setTextColor(Color.WHITE);voicePauseButton.setAllCaps(false);voicePauseButton.setMinWidth(0);voicePauseButton.setMinHeight(0);voicePauseButton.setPadding(0,0,0,0);voicePauseButton.setBackground(refCircle(Color.parseColor("#286A8A")));voicePauseButton.setVisibility(View.GONE);LinearLayout.LayoutParams vpp=new LinearLayout.LayoutParams(dp(42),dp(42));vpp.leftMargin=dp(7);compose.addView(voicePauseButton,vpp);voicePauseButton.setOnClickListener(v->toggleVoicePause());
        voiceCancelButton=new Button(this);voiceCancelButton.setText("×");voiceCancelButton.setTextSize(22);voiceCancelButton.setTextColor(Color.WHITE);voiceCancelButton.setAllCaps(false);voiceCancelButton.setMinWidth(0);voiceCancelButton.setMinHeight(0);voiceCancelButton.setPadding(0,0,0,0);voiceCancelButton.setBackground(refCircle(Color.parseColor("#E34C59")));voiceCancelButton.setVisibility(View.GONE);LinearLayout.LayoutParams vcp=new LinearLayout.LayoutParams(dp(42),dp(42));vcp.leftMargin=dp(7);compose.addView(voiceCancelButton,vcp);voiceCancelButton.setOnClickListener(v->cancelVoiceRecording(true));
        sendButton=new Button(this);sendButton.setAllCaps(false);sendButton.setMinWidth(0);sendButton.setMinHeight(0);sendButton.setPadding(dp(10),dp(10),dp(10),dp(10));sendButton.setTextColor(Color.WHITE);GradientDrawable sendBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.parseColor("#19D2C1"),Color.parseColor("#12AEE4")});sendBg.setShape(GradientDrawable.OVAL);sendButton.setBackground(sendBg);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(48),dp(48));sp.leftMargin=dp(8);compose.addView(sendButton,sp);root.addView(compose,new LinearLayout.LayoutParams(-1,dp(64)));

        composer.setText(prefs.getString("draft:"+id,""));composer.setOnEditorActionListener((v,actionId,event)->{if(prefs.getBoolean("send_by_enter",false)&&composer.getText().toString().trim().length()>0){send();return true;}return false;});composer.setOnKeyListener((v,keyCode,event)->{if(prefs.getBoolean("send_by_enter",false)&&keyCode==KeyEvent.KEYCODE_ENTER&&event.getAction()==KeyEvent.ACTION_DOWN&&composer.getText().toString().trim().length()>0){send();return true;}return false;});composer.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){updateComposeAction();}public void afterTextChanged(Editable e){}});sendButton.setOnClickListener(v->{if(notesMode||composer.getText().toString().trim().length()>0)send();else toggleVoiceRecording();});sendButton.setOnLongClickListener(v->{if(voiceRecording){cancelVoiceRecording(true);return true;}return false;});updateComposeAction();updateProximityListener();
    }
    private void saveDraft(){if(composer!=null&&screen.equals("chat"))prefs.edit().putString("draft:"+chatId,composer.getText().toString()).apply();}
    private void drawNotes(){messages.removeAllViews();try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));if(notes.length()==0){note(messages,"Сохраняйте идеи, списки и важные мысли. Нажмите на заметку и удерживайте, чтобы скопировать или удалить её.");}for(int i=0;i<notes.length();i++){JSONObject n=notes.getJSONObject(i);TextView t=bubble(n.getString("body"),true,n.optString("time"));final int index=i;t.setOnLongClickListener(v->{new AlertDialog.Builder(this).setItems(new String[]{"Скопировать","Удалить"},(d,which)->{if(which==0)copy(n.optString("body"));else{notes.remove(index);prefs.edit().putString("notes",notes.toString()).apply();drawNotes();}}).show();return true;});}}catch(Exception e){error(e);}bottomScroll();}

    private TextView bubble(String body,boolean mine,String when){
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);
        LinearLayout card=vertical();card.setPadding(dp(12),dp(8),dp(10),dp(5));card.setBackground(mine?outgoingBubbleDrawable():incomingBubbleDrawable());
        TextView bodyView=label(body,16,Color.WHITE);bodyView.setMaxWidth(dp(260));bodyView.setLineSpacing(dp(1),1.02f);card.addView(bodyView,new LinearLayout.LayoutParams(-2,-2));
        TextView meta=chatMeta(when,mine);card.addView(meta,new LinearLayout.LayoutParams(-1,dp(16)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.setMargins(dp(mine?54:0),dp(3),dp(mine?0:54),dp(3));wrap.addView(card,p);messages.addView(wrap);card.setOnLongClickListener(v->{copy(body);return true;});return bodyView;
    }
    private void copy(String value){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Muwahid",value));Toast.makeText(this,"Скопировано",Toast.LENGTH_SHORT).show();}
    private void bottomScroll(){messageScroll.post(()->messageScroll.fullScroll(View.FOCUS_DOWN));}
    private void loadMessages(boolean report){fetchMessages(null,report);}
    private void fetchMessages(Long before,boolean report){if(loading)return;loading=true;final int stamp=generation;final String id=chatId;
        worker.execute(()->{try{JSONObject args=new JSONObject().put("p_chat",id);if(before!=null)args.put("p_before",before);JSONArray result=(JSONArray)api.rpc("mw_messages_get",args);handler.post(()->{loading=false;if(stamp!=generation)return;
            boolean changed=false;for(int i=0;i<result.length();i++){JSONObject m=result.optJSONObject(i);if(m!=null&&!history.containsKey(m.optLong("id"))){history.put(m.optLong("id"),m);changed=true;}}
            if(before!=null||history.size()<=100)olderAvailable=result.length()==100;
            connection.setText(chatSecurityStatus());connection.setOnClickListener(null);
            if(changed||messages.getChildCount()==0)drawMessages(before==null);
        });}catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;connection.setText("Нет связи · нажмите для повтора");connection.setOnClickListener(v->loadMessages(true));if(report)error(e);});}});
    }
    private void drawMessages(boolean newest){int oldY=messageScroll.getScrollY();boolean nearBottom=messages.getHeight()-messageScroll.getHeight()-oldY<dp(100);messages.removeAllViews();
        if(olderAvailable&&!history.isEmpty()){TextView older=label("Загрузить предыдущие сообщения",14,accent);older.setGravity(Gravity.CENTER);older.setPadding(0,dp(12),0,dp(16));messages.addView(older);older.setOnClickListener(v->fetchMessages(history.firstKey(),true));}
        if(history.isEmpty())note(messages,"Пока сообщений нет. Напишите первым.");
        for(JSONObject m:history.values())drawMessage(m);
        if(newest&&(nearBottom||oldY==0))bottomScroll();
    }
    private String readableBody(JSONObject message){
        String body=message.optString("body");
        if(!body.startsWith("mw1:"))return body;
        if(peerE2eeKey.isEmpty())return "🔒 Зашифрованное сообщение · ключ собеседника недоступен";
        try{return crypto.decryptText(api.uid(),chatId,peerE2eeKey,body);}catch(Exception e){return "🔒 Не удалось расшифровать это сообщение";}
    }
    private void drawMessage(JSONObject m){
        boolean mine=m.optString("sender_id").equals(api.uid());String plain=readableBody(m);String when=time(m.optString("created_at"));
        try{if(plain.startsWith("{")&&plain.contains("\"mw_kind\":\"media\"")){
            JSONObject meta=new JSONObject(plain);String type=meta.optString("media_type","file");
            if("image".equals(type)){if(meta.optBoolean("sticker",false))drawStickerMessage(meta,mine,when);else drawImageMessage(meta,mine,when);return;}
            if("voice".equals(type)||"audio".equals(type)){drawVoiceMessage(meta,mine,when);return;}
            if("location".equals(type)){drawLocationMessage(meta,mine,when);return;}
            if("contact".equals(type)){drawContactMessage(meta,mine,when);return;}
            if("poll".equals(type)){drawPollMessage(meta,mine,when);return;}
            drawGenericMediaMessage(meta,mine,when);return;
        }}catch(Exception ignored){}
        bubble(plain,mine,when);
    }

    private GradientDrawable outgoingBubbleDrawable(){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.parseColor("#16B8A7"),Color.parseColor("#139FD5")});d.setCornerRadii(new float[]{dp(18),dp(18),dp(18),dp(18),dp(5),dp(5),dp(18),dp(18)});return d;
    }

    private GradientDrawable incomingBubbleDrawable(){
        GradientDrawable d=new GradientDrawable();d.setColor(Color.parseColor("#1A334B"));d.setCornerRadii(new float[]{dp(18),dp(18),dp(18),dp(18),dp(18),dp(18),dp(5),dp(5)});d.setStroke(dp(1),Color.parseColor("#294B65"));return d;
    }

    private TextView chatMeta(String when,boolean mine){
        TextView meta=label((when==null?"":when)+(mine?"  ✓✓":""),10,mine?Color.parseColor("#E2FFF9"):Color.parseColor("#9FB2C3"));meta.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);meta.setPadding(dp(7),0,dp(1),0);return meta;
    }
    private void drawStickerMessage(JSONObject meta,boolean mine,String when){
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);LinearLayout column=vertical();FrameLayout frame=new FrameLayout(this);
        int stickerId=AnimatedStickerView.catalogId(meta);
        if(stickerId>=0){AnimatedStickerView image=stickerImage(stickerId);frame.addView(image,new FrameLayout.LayoutParams(dp(190),dp(190)));frame.setOnClickListener(v->image.replay());frame.setOnLongClickListener(v->{previewSticker(stickerId,false,null);return true;});}
        else{ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setContentDescription("Стикер: "+meta.optString("name",""));frame.addView(image,new FrameLayout.LayoutParams(dp(190),dp(190)));TextView loading=label("Стикер · загрузка…",13,muted);loading.setGravity(Gravity.CENTER);frame.addView(loading,new FrameLayout.LayoutParams(-1,-1));frame.setOnClickListener(v->downloadMedia(meta));frame.setOnLongClickListener(v->{String assetId=meta.optString("sticker_asset_id","");if(!assetId.isEmpty())new AlertDialog.Builder(this).setTitle("Стикер").setItems(new String[]{"Сохранить в избранное","Скачать файл"},(d,w)->{if(w==0)setCloudStickerFavoriteById(assetId,true);else downloadMedia(meta);}).show();return true;});loadInlineSticker(meta,image,loading);}
        column.addView(frame);column.addView(chatMeta(when,mine));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(dp(8),dp(4),dp(8),dp(4));wrap.addView(column,lp);messages.addView(wrap);
    }

    private void drawImageMessage(JSONObject meta,boolean mine,String when){
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);FrameLayout frame=new FrameLayout(this);GradientDrawable border=shape(Color.parseColor("#10243B"),15);border.setStroke(dp(1),mine?Color.parseColor("#17C9D8"):Color.parseColor("#28445D"));frame.setBackground(border);frame.setPadding(dp(2),dp(2),dp(2),dp(2));
        ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Color.parseColor("#0C2034"));frame.addView(image,new FrameLayout.LayoutParams(dp(220),dp(138)));
        TextView loading=label("Фото",13,Color.parseColor("#B9C8DA"));loading.setGravity(Gravity.CENTER);frame.addView(loading,new FrameLayout.LayoutParams(-1,-1));
        TextView stamp=chatMeta(when,mine);stamp.setTextColor(Color.WHITE);stamp.setBackground(shape(Color.argb(135,0,0,0),8));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-2,dp(22),Gravity.END|Gravity.BOTTOM);mp.rightMargin=dp(6);mp.bottomMargin=dp(5);frame.addView(stamp,mp);
        LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-2,-2);wp.setMargins(dp(mine?62:0),dp(3),dp(mine?0:62),dp(3));wrap.addView(frame,wp);messages.addView(wrap);frame.setOnClickListener(v->downloadMedia(meta));loadInlineImage(meta,image,loading);
    }
    private void loadInlineImage(JSONObject meta,ImageView image,TextView loading){final int stamp=generation;worker.execute(()->{try{byte[] encrypted=api.downloadMedia(meta.getString("path"));byte[] raw=crypto.decryptBytes(api.uid(),chatId,peerE2eeKey,encrypted);Bitmap bitmap=BitmapFactory.decodeByteArray(raw,0,raw.length);if(bitmap==null)throw new Exception("decode");handler.post(()->{if(stamp!=generation)return;image.setImageBitmap(bitmap);loading.setVisibility(View.GONE);});}catch(Exception e){handler.post(()->{if(stamp!=generation)return;loading.setText(meta.optBoolean("sticker",false)?"Стикер · нажмите, чтобы открыть":"Фото · нажмите, чтобы открыть");});}});}
    private void loadInlineSticker(JSONObject meta,ImageView image,TextView loading){final int stamp=generation;worker.execute(()->{try{byte[] encrypted=api.downloadMedia(meta.getString("path"));byte[] raw=crypto.decryptBytes(api.uid(),chatId,peerE2eeKey,encrypted);Drawable drawable=decodeStickerDrawable(raw,meta.optString("mime","image/webp"));if(drawable==null)throw new Exception("decode");handler.post(()->{if(stamp!=generation)return;image.setImageDrawable(drawable);loading.setVisibility(View.GONE);if(Build.VERSION.SDK_INT>=28&&drawable instanceof android.graphics.drawable.AnimatedImageDrawable)((android.graphics.drawable.AnimatedImageDrawable)drawable).start();});}catch(Exception e){handler.post(()->{if(stamp!=generation)return;loading.setText("Стикер · нажмите, чтобы открыть");});}});}

    private void drawVoiceMessage(JSONObject meta,boolean mine,String when){
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);LinearLayout card=horizontal();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(8),dp(7),dp(8),dp(7));card.setBackground(mine?outgoingBubbleDrawable():incomingBubbleDrawable());
        TextView play=label("▶",18,mine?Color.parseColor("#12AFA8"):Color.parseColor("#1A3A55"));play.setGravity(Gravity.CENTER);bold(play);play.setBackground(refCircle(Color.WHITE));card.addView(play,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout center=vertical();center.setPadding(dp(9),0,dp(5),0);WaveformView wave=new WaveformView(this,mine);center.addView(wave,new LinearLayout.LayoutParams(dp(118),dp(20)));long duration=meta.optLong("duration_ms",0);TextView dur=label(duration>0?formatDuration(duration):"0:00",9,mine?Color.parseColor("#E6FFF9"):Color.parseColor("#AEBFD0"));center.addView(dur,new LinearLayout.LayoutParams(-1,dp(14)));card.addView(center,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView speed=label("1x",10,Color.WHITE);speed.setGravity(Gravity.CENTER);speed.setBackground(shape(Color.argb(60,255,255,255),12));card.addView(speed,new LinearLayout.LayoutParams(dp(34),dp(28)));TextView mt=chatMeta(when,mine);card.addView(mt,new LinearLayout.LayoutParams(dp(50),dp(22)));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(270),-2);cp.setMargins(dp(mine?42:0),dp(3),dp(mine?0:42),dp(3));wrap.addView(card,cp);messages.addView(wrap);
        String path=meta.optString("path","");View.OnClickListener open=v->playInlineVoice(meta,play,dur,duration,speed);card.setOnClickListener(open);play.setOnClickListener(open);speed.setOnClickListener(v->cycleInlineVoiceSpeed(path,speed));prefetchInlineVoice(meta);
    }
    private void prefetchInlineVoice(JSONObject meta){
        String path=meta.optString("path","");if(path.isEmpty()||inlineVoiceCache.containsKey(path)||inlineVoiceLoading.contains(path)||peerE2eeKey.isEmpty())return;
        inlineVoiceLoading.add(path);final int stamp=generation;final String id=chatId,peer=peerE2eeKey,uid=api.uid();
        worker.execute(()->{try{byte[] encrypted=api.downloadMedia(path);byte[] raw=crypto.decryptBytes(uid,id,peer,encrypted);File dir=new File(getCacheDir(),"voice_playback");dir.mkdirs();File f=new File(dir,Integer.toHexString(path.hashCode())+".m4a");try(FileOutputStream out=new FileOutputStream(f)){out.write(raw);}inlineVoiceCache.put(path,f);}catch(Exception ignored){}finally{inlineVoiceLoading.remove(path);}});
    }
    private void playInlineVoice(JSONObject meta,TextView play,TextView dur,long knownDuration,TextView speed){
        String path=meta.optString("path","");if(path.isEmpty())return;
        if(path.equals(inlineVoicePath)&&inlineVoicePlayer!=null){
            try{if(inlineVoicePlayer.isPlaying()){inlineVoicePlayer.pause();play.setText("▶");handler.removeCallbacks(inlineVoiceTicker);}else{inlineVoicePlayer.start();play.setText("Ⅱ");inlineVoiceButton=play;inlineVoiceDuration=dur;handler.post(inlineVoiceTicker);}return;}catch(Exception ignored){stopInlineVoice();}
        }
        stopInlineVoice();play.setText("…");dur.setText("Загрузка…");inlineVoiceKnownDuration=knownDuration;final int stamp=generation;final String id=chatId,peer=peerE2eeKey,uid=api.uid();
        worker.execute(()->{try{
            File f=inlineVoiceCache.get(path);if(f==null||!f.exists()){byte[] encrypted=api.downloadMedia(path);byte[] raw=crypto.decryptBytes(uid,id,peer,encrypted);File dir=new File(getCacheDir(),"voice_playback");dir.mkdirs();f=new File(dir,Integer.toHexString(path.hashCode())+".m4a");try(FileOutputStream out=new FileOutputStream(f)){out.write(raw);}inlineVoiceCache.put(path,f);}
            if(prefs.getBoolean("pause_music_media",false))requestVoiceAudioFocus();MediaPlayer player=new MediaPlayer();player.setDataSource(f.getAbsolutePath());player.prepare();
            handler.post(()->{if(stamp!=generation){player.release();return;}stopInlineVoice();inlineVoicePlayer=player;inlineVoicePath=path;inlineVoiceButton=play;inlineVoiceDuration=dur;inlineVoiceSpeed=1f;inlineVoiceSpeedButton=speed;speed.setText("1x");try{player.setPlaybackParams(new android.media.PlaybackParams().setSpeed(1f).setPitch(1f));}catch(Exception ignored){}player.setOnCompletionListener(mp->{handler.removeCallbacks(inlineVoiceTicker);try{mp.seekTo(0);}catch(Exception ignored){}if(inlineVoiceButton!=null)inlineVoiceButton.setText("▶");if(inlineVoiceDuration!=null)inlineVoiceDuration.setText(knownDuration>0?formatDuration(knownDuration):formatDuration(mp.getDuration()));});player.start();play.setText("Ⅱ");handler.post(inlineVoiceTicker);});
        }catch(Exception e){handler.post(()->{if(stamp!=generation)return;play.setText("▶");dur.setText(knownDuration>0?formatDuration(knownDuration):"Аудио");notice("Не удалось воспроизвести голосовое сообщение внутри Muwahid.");});}});
    }
    private void stopInlineVoice(){handler.removeCallbacks(inlineVoiceTicker);if(inlineVoiceButton!=null)inlineVoiceButton.setText("▶");if(inlineVoiceDuration!=null&&inlineVoiceKnownDuration>0)inlineVoiceDuration.setText(formatDuration(inlineVoiceKnownDuration));if(inlineVoicePlayer!=null){try{inlineVoicePlayer.stop();}catch(Exception ignored){}try{inlineVoicePlayer.release();}catch(Exception ignored){}}abandonVoiceAudioFocus();if(audioManager!=null)try{audioManager.setMode(AudioManager.MODE_NORMAL);}catch(Exception ignored){}if(inlineVoiceSpeedButton!=null)inlineVoiceSpeedButton.setText("1x");inlineVoicePlayer=null;inlineVoicePath="";inlineVoiceButton=null;inlineVoiceDuration=null;inlineVoiceKnownDuration=0;inlineVoiceSpeed=1f;inlineVoiceSpeedButton=null;}
    private void cycleInlineVoiceSpeed(String path,TextView speed){
        if(inlineVoicePlayer==null||!path.equals(inlineVoicePath)){Toast.makeText(this,"Сначала запустите голосовое сообщение",Toast.LENGTH_SHORT).show();return;}inlineVoiceSpeed=inlineVoiceSpeed<1.25f?1.5f:inlineVoiceSpeed<1.75f?2f:1f;try{inlineVoicePlayer.setPlaybackParams(new android.media.PlaybackParams().setSpeed(inlineVoiceSpeed).setPitch(1f));speed.setText(inlineVoiceSpeed==1f?"1x":inlineVoiceSpeed==1.5f?"1.5x":"2x");inlineVoiceSpeedButton=speed;}catch(Exception e){speed.setText("1x");inlineVoiceSpeed=1f;}
    }
    private void drawLocationMessage(JSONObject meta,boolean mine,String when){
        double lat=meta.optDouble("lat",0),lon=meta.optDouble("lon",0);String address=meta.optString("address","");String title=address.isEmpty()?"Моё местоположение":address;
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);LinearLayout card=horizontal();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(7),dp(7),dp(9),dp(7));card.setBackground(mine?outgoingBubbleDrawable():incomingBubbleDrawable());
        MiniMapView map=new MiniMapView(this);GradientDrawable clip=shape(Color.parseColor("#DDE7DD"),10);map.setBackground(clip);card.addView(map,new LinearLayout.LayoutParams(dp(62),dp(52)));
        LinearLayout words=vertical();words.setPadding(dp(9),0,0,0);TextView t=label(title,13,Color.WHITE);bold(t);t.setMaxLines(1);t.setEllipsize(TextUtils.TruncateAt.END);words.addView(t);TextView sub=label(String.format(Locale.US,"%.4f, %.4f",lat,lon),10,mine?Color.parseColor("#E4FFF8"):Color.parseColor("#A8BACA"));words.addView(sub);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));card.addView(chatMeta(when,mine),new LinearLayout.LayoutParams(dp(52),dp(22)));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(250),-2);cp.setMargins(dp(mine?68:0),dp(2),dp(mine?0:68),dp(2));wrap.addView(card,cp);messages.addView(wrap);card.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:"+lat+","+lon+"?q="+lat+","+lon)));}catch(Exception e){Toast.makeText(this,"Карта недоступна",Toast.LENGTH_SHORT).show();}});
    }
    private void drawContactMessage(JSONObject meta,boolean mine,String when){String name=meta.optString("name","Контакт"),phone=meta.optString("phone","");TextView t=bubble("👤  "+name+"\n"+phone,mine,when);t.setOnClickListener(v->{if(phone.isEmpty())return;try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(phone))));}catch(Exception e){Toast.makeText(this,"Не удалось открыть номер",Toast.LENGTH_SHORT).show();}});}
    private void drawPollMessage(JSONObject meta,boolean mine,String when){
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);LinearLayout card=vertical();card.setPadding(dp(14),dp(12),dp(14),dp(10));card.setBackground(mine?outgoingBubbleDrawable():incomingBubbleDrawable());TextView q=label("📊  "+meta.optString("question","Опрос"),16,Color.WHITE);bold(q);card.addView(q);JSONArray options=meta.optJSONArray("options");if(options!=null)for(int i=0;i<options.length();i++){String value=options.optString(i);TextView option=label("○  "+value,14,Color.WHITE);option.setPadding(dp(10),dp(9),dp(10),dp(9));option.setBackground(shape(Color.argb(45,255,255,255),12));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,-2);op.topMargin=dp(7);card.addView(option,op);option.setOnClickListener(v->{option.setText("●  "+value);if(composer!=null){composer.setText("Ответ на опрос: "+value);composer.setSelection(composer.length());}});}card.addView(chatMeta(when,mine));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(300),-2);cp.setMargins(dp(mine?26:0),dp(6),dp(mine?0:26),dp(6));wrap.addView(card,cp);messages.addView(wrap);
    }

    private void drawGenericMediaMessage(JSONObject meta,boolean mine,String when){
        String type=meta.optString("media_type","file"),title="video_message".equals(type)?"Видеосообщение":meta.optString("name","Файл");
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);LinearLayout card=horizontal();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(8),dp(7),dp(9),dp(7));card.setBackground(mine?outgoingBubbleDrawable():incomingBubbleDrawable());
        String icon=("video".equals(type)||"video_message".equals(type))?"video":"document";ImageView iv=refIcon(icon,Color.WHITE);iv.setBackground(shape("document".equals(icon)?Color.parseColor("#2E84ED"):Color.parseColor("#2A91D8"),10));card.addView(iv,new LinearLayout.LayoutParams(dp(36),dp(36)));
        LinearLayout words=vertical();words.setPadding(dp(9),0,0,0);TextView n=label(title,14,Color.WHITE);bold(n);n.setMaxLines(1);n.setEllipsize(TextUtils.TruncateAt.END);words.addView(n);String detail=meta.optLong("size",0)>0?(Math.max(1,meta.optLong("size",0)/1024)+" KB · "+type.toUpperCase(Locale.ROOT)):type;TextView d=label(detail,11,mine?Color.parseColor("#E5FFF8"):Color.parseColor("#A9B9C9"));words.addView(d);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));card.addView(chatMeta(when,mine),new LinearLayout.LayoutParams(dp(52),dp(22)));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(238),-2);cp.setMargins(dp(mine?68:0),dp(2),dp(mine?0:68),dp(2));wrap.addView(card,cp);messages.addView(wrap);card.setOnClickListener(v->downloadMedia(meta));
    }
    private void chooseCall(){
        if(!api.signedIn()){notice("Войдите в аккаунт");return;}
        new AlertDialog.Builder(this).setTitle("Позвонить "+chatName).setItems(new String[]{"Аудиозвонок","Видеозвонок"},(d,w)->startCall(w==0?"audio":"video")).show();
    }
    private void startCall(String kind){Intent i=new Intent(this,CallActivity.class);i.putExtra("chat_id",chatId);i.putExtra("peer_name",chatName);i.putExtra("kind",kind);i.putExtra("incoming",false);startActivity(i);}

    private void addActiveCallBanner(){
        activeCallBanner=label("",14,Color.WHITE);
        activeCallBanner.setPadding(dp(16),dp(10),dp(16),dp(10));
        activeCallBanner.setGravity(Gravity.CENTER_VERTICAL);
        activeCallBanner.setBackground(shape(Color.parseColor("#0D5B50"),14));
        activeCallBanner.setVisibility(View.GONE);
        activeCallBanner.setOnClickListener(v->returnToActiveCall());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));
        lp.setMargins(dp(10),dp(4),dp(10),dp(4));
        root.addView(activeCallBanner,lp);
        String id=prefs.getString("active_call_id","");
        if(!id.isEmpty()){
            String peer=prefs.getString("active_call_peer","Muwahid");
            activeCallBanner.setText("↩  Вернуться к звонку · "+peer);
            activeCallBanner.setVisibility(View.VISIBLE);
        }
        syncActiveCallBanner();
    }
    private void syncActiveCallBanner(){
        if(api==null||!api.signedIn()||worker==null)return;
        worker.execute(()->{try{
            Object raw=api.rpc("mw_active_call",new JSONObject());
            JSONObject c=raw instanceof JSONObject?(JSONObject)raw:new JSONObject();
            handler.post(()->{
                if(isFinishing()||isDestroyed()||!"chats".equals(screen))return;
                String id=c.optString("id","");
                if(id.isEmpty()){
                    prefs.edit().remove("active_call_id").remove("active_call_kind").remove("active_call_peer").remove("active_call_chat_id").remove("active_call_incoming").apply();
                    if(activeCallBanner!=null)activeCallBanner.setVisibility(View.GONE);
                    return;
                }
                String peer=c.optString("peer_name","Muwahid");
                prefs.edit()
                    .putString("active_call_id",id)
                    .putString("active_call_kind",c.optString("kind","audio"))
                    .putString("active_call_peer",peer)
                    .putString("active_call_chat_id",c.optString("chat_id",""))
                    .putBoolean("active_call_incoming",c.optBoolean("incoming",false))
                    .apply();
                if(activeCallBanner!=null){
                    String status="accepted".equals(c.optString("status"))?"Идёт звонок":"Звонок";
                    activeCallBanner.setText("↩  "+status+" · "+peer+" · нажмите, чтобы вернуться");
                    activeCallBanner.setVisibility(View.VISIBLE);
                }
            });
        }catch(Exception ignored){}});
    }
    private void returnToActiveCall(){
        String id=prefs.getString("active_call_id","");
        if(id.isEmpty()){syncActiveCallBanner();return;}
        Intent i=new Intent(this,CallActivity.class);
        i.putExtra("call_id",id);
        i.putExtra("chat_id",prefs.getString("active_call_chat_id",""));
        i.putExtra("peer_name",prefs.getString("active_call_peer","Muwahid"));
        i.putExtra("kind",prefs.getString("active_call_kind","audio"));
        i.putExtra("incoming",prefs.getBoolean("active_call_incoming",false));
        i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }
    private void addVoiceRoomShortcut(){
        if(!feature("voice_rooms",true))return;
        LinearLayout row=horizontal();
        row.setPadding(dp(14),dp(8),dp(14),dp(8));
        row.setBackground(shape(Color.parseColor("#10283B"),16));
        TextView icon=label("◉",21,accent);icon.setGravity(Gravity.CENTER);row.addView(icon,new LinearLayout.LayoutParams(dp(34),dp(40)));
        LinearLayout words=vertical();
        TextView title=label("Голосовые комнаты",15,Color.WHITE);bold(title);words.addView(title);
        words.addView(label("8 мест с микрофоном · слушатели входят сразу",11,Color.parseColor("#9AB1C5")));
        row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView enter=label("›",28,accent);enter.setGravity(Gravity.CENTER);row.addView(enter,new LinearLayout.LayoutParams(dp(28),dp(40)));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(dp(10),dp(3),dp(10),dp(5));
        root.addView(row,lp);
        row.setOnClickListener(v->showVoiceRooms());
    }

    private void showAttachmentSheet(){
        if(!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для защищённой отправки собеседник должен использовать актуальную версию Muwahid с E2EE.");return;}
        Dialog dialog=new Dialog(this);dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout sheet=vertical();sheet.setPadding(dp(12),dp(5),dp(12),dp(12));sheet.setBackground(shape(Color.parseColor("#102337"),24));
        View handle=new View(this);handle.setBackground(shape(Color.parseColor("#607487"),3));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(dp(42),dp(4));hp.gravity=Gravity.CENTER_HORIZONTAL;hp.topMargin=dp(5);hp.bottomMargin=dp(10);sheet.addView(handle,hp);
        GridLayout grid=new GridLayout(this);grid.setColumnCount(3);grid.setUseDefaultMargins(false);
        attachmentTile(grid,"image","Галерея",Color.parseColor("#8B55CC"),()->pickMediaType("image/*",REQ_IMAGE),dialog);
        attachmentTile(grid,"camera","Камера",Color.parseColor("#EF4D5D"),this::capturePhoto,dialog);
        attachmentTile(grid,"video","Видео",Color.parseColor("#2D85EC"),this::captureVideo,dialog);
        attachmentTile(grid,"document","Документ",Color.parseColor("#2C80E8"),this::pickDocument,dialog);
        attachmentTile(grid,"location","Местоположение",Color.parseColor("#39B85A"),this::sendCurrentLocation,dialog);
        attachmentTile(grid,"contacts","Контакт",Color.parseColor("#F49B36"),this::pickContact,dialog);
        attachmentTile(grid,"audio","Аудио",Color.parseColor("#EA3F6B"),()->pickMediaType("audio/*",REQ_AUDIO),dialog);
        attachmentTile(grid,"poll","Опрос",Color.parseColor("#6555D9"),this::createPoll,dialog);
        attachmentTile(grid,"more","Ещё",Color.parseColor("#60758A"),()->new AlertDialog.Builder(this).setTitle("Ещё").setItems(new String[]{"Стикеры","Видеосообщение","Видео из галереи"},(d,w)->{if(w==0)showStickerPicker();else if(w==1)recordVideoMessage();else pickMediaType("video/*",REQ_VIDEO);}).show(),dialog);
        sheet.addView(grid,new LinearLayout.LayoutParams(-1,-2));dialog.setContentView(sheet);
        Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.48f);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setGravity(Gravity.BOTTOM);}
        dialog.setOnShowListener(x->{Window win=dialog.getWindow();if(win!=null)win.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT);});dialog.show();
    }

    private void attachmentTile(GridLayout grid,String icon,String title,int color,Runnable action,Dialog dialog){
        LinearLayout tile=vertical();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(2),dp(5),dp(2),dp(2));
        ImageView badge=refIcon(icon,Color.WHITE);badge.setPadding(dp(8),dp(8),dp(8),dp(8));badge.setBackground(refCircle(color));tile.addView(badge,new LinearLayout.LayoutParams(dp(60),dp(60)));
        TextView caption=label(title,12,Color.WHITE);caption.setGravity(Gravity.CENTER);caption.setMaxLines(1);caption.setPadding(0,dp(4),0,0);tile.addView(caption,new LinearLayout.LayoutParams(-1,dp(28)));
        GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(90);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(tile,gp);tile.setOnClickListener(v->{dialog.dismiss();action.run();});
    }
    private void pickMediaType(String mime,int requestCode){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,requestCode);}
    private void pickDocument(){startActivityForResult(new Intent(this,MuwahidDocumentActivity.class),REQ_MW_DOCUMENT);}
    private void capturePhoto(){if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(android.Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{android.Manifest.permission.CAMERA},REQ_CAMERA_PHOTO_PERMISSION);return;}startPhotoCapture();}
    private void startPhotoCapture(){Intent i=new Intent(this,MuwahidCameraActivity.class);i.putExtra("mode","photo");startActivityForResult(i,REQ_MW_CAMERA);}
    private void captureVideo(){if(Build.VERSION.SDK_INT>=23&&(checkSelfPermission(android.Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED||checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)){requestPermissions(new String[]{android.Manifest.permission.CAMERA,android.Manifest.permission.RECORD_AUDIO},REQ_CAMERA_VIDEO_PERMISSION);return;}startCameraVideoCapture();}
    private void startCameraVideoCapture(){Intent i=new Intent(this,MuwahidCameraActivity.class);i.putExtra("mode","video");startActivityForResult(i,REQ_MW_CAMERA);}
    private void sendCurrentLocation(){if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED&&checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,android.Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION_PERMISSION);return;}locateAndConfirm();}
    private void locateAndConfirm(){
        try{LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);if(lm==null){notice("Служба местоположения недоступна.");return;}Location best=null;for(String provider:new String[]{LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER,LocationManager.PASSIVE_PROVIDER}){try{Location x=lm.getLastKnownLocation(provider);if(x!=null&&(best==null||x.getAccuracy()<best.getAccuracy()))best=x;}catch(SecurityException ignored){}}if(best==null){notice("Не удалось получить местоположение. Включите геолокацию и попробуйте ещё раз.");return;}Intent i=new Intent(this,LocationShareActivity.class);i.putExtra("lat",best.getLatitude());i.putExtra("lon",best.getLongitude());startActivityForResult(i,REQ_MW_LOCATION);}catch(Exception e){notice("Не удалось получить местоположение.");}
    }
    private void sendLocationMessage(double lat,double lon,String address){try{JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type","location").put("name",address==null||address.trim().isEmpty()?"Моё местоположение":address).put("address",address==null?"":address).put("lat",lat).put("lon",lon);sendStructuredMessage(meta,"Шифруем и отправляем местоположение…");}catch(Exception e){error(e);}}
    private void pickContact(){try{Intent i=new Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI);startActivityForResult(i,REQ_CONTACT);}catch(Exception e){notice("Не удалось открыть контакты.");}}
    private void sendContactFromUri(Uri uri){
        Cursor c=null;try{c=getContentResolver().query(uri,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null);if(c==null||!c.moveToFirst())throw new Exception("Контакт не выбран");String name=c.getString(0),phone=c.getString(1);JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type","contact").put("name",name==null?"Контакт":name).put("phone",phone==null?"":phone);sendStructuredMessage(meta,"Отправляем контакт…");}catch(Exception e){error(e);}finally{if(c!=null)c.close();}
    }
    private void createPoll(){
        LinearLayout box=vertical();box.setPadding(dp(22),0,dp(22),0);EditText q=new EditText(this);q.setHint("Вопрос");EditText a=new EditText(this);a.setHint("Вариант 1");EditText b=new EditText(this);b.setHint("Вариант 2");box.addView(q);box.addView(a);box.addView(b);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Новый опрос").setView(box).setNegativeButton("Отмена",null).setPositiveButton("Отправить",null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String question=q.getText().toString().trim(),first=a.getText().toString().trim(),second=b.getText().toString().trim();if(question.isEmpty()){q.setError("Введите вопрос");return;}if(first.isEmpty()){a.setError("Введите вариант");return;}if(second.isEmpty()){b.setError("Введите вариант");return;}d.dismiss();sendPoll(question,first,second);}));d.show();
    }
    private void sendPoll(String question,String first,String second){try{JSONArray options=new JSONArray().put(first).put(second);JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type","poll").put("question",question).put("options",options);sendStructuredMessage(meta,"Отправляем опрос…");}catch(Exception e){error(e);}}
    private void sendStructuredMessage(JSONObject meta,String progress){
        if(sending)return;final String id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;setComposeEnabled(false);if(sendButton!=null)sendButton.setEnabled(false);if(connection!=null)connection.setText(progress);worker.execute(()->{try{String payload=crypto.encryptText(uid,id,peer,meta.toString());JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",UUID.randomUUID().toString()));handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);if(connection!=null)connection.setText(chatSecurityStatus());history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});}catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);if(connection!=null)connection.setText(chatSecurityStatus());updateComposeAction();error(e);});}});
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if((requestCode==REQ_IMAGE||requestCode==REQ_VIDEO||requestCode==REQ_AUDIO)&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadMedia(data.getData(),null);
        else if((requestCode==REQ_DOCUMENT||requestCode==REQ_MW_DOCUMENT)&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadMedia(data.getData(),"file");
        else if(requestCode==REQ_MW_CAMERA&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadMedia(data.getData(),data.getStringExtra("media_type"));
        else if(requestCode==REQ_CAMERA_PHOTO&&resultCode==RESULT_OK&&pendingCameraPhotoUri!=null){Uri photo=pendingCameraPhotoUri;pendingCameraPhotoUri=null;uploadMedia(photo,"image");}
        else if(requestCode==REQ_CAMERA_VIDEO&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadMedia(data.getData(),"video");
        else if(requestCode==REQ_MW_LOCATION&&resultCode==RESULT_OK&&data!=null)sendLocationMessage(data.getDoubleExtra("lat",0),data.getDoubleExtra("lon",0),data.getStringExtra("address"));
        else if(requestCode==REQ_CONTACT&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)sendContactFromUri(data.getData());
        else if(requestCode==REQ_VIDEO_MESSAGE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadMedia(data.getData(),"video_message");
        else if(requestCode==REQ_STICKER_IMPORT&&resultCode==RESULT_OK&&data!=null){ArrayList<Uri> uris=new ArrayList<>();if(data.getData()!=null)uris.add(data.getData());ClipData clip=data.getClipData();if(clip!=null)for(int i=0;i<clip.getItemCount();i++){Uri u=clip.getItemAt(i).getUri();if(u!=null&&!uris.contains(u))uris.add(u);}for(Uri u:uris)try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}String pack=pendingStickerPackId;pendingStickerPackId="";importStickerUris(uris,pack,"user_import");}
        else if(requestCode==REQ_CHAT_WALLPAPER&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}prefs.edit().putString("chat_wallpaper_uri",uri.toString()).putInt("wallpaper_preset",-2).apply();showWallpaperSettings();}
        else if(requestCode==REQ_CALL_RINGTONE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}prefs.edit().putString("call_ringtone_mode","custom").putString("call_ringtone_uri",uri.toString()).putString("call_ringtone_name",fileName(uri)).apply();Toast.makeText(this,"Мелодия звонка сохранена",Toast.LENGTH_SHORT).show();if("notifications".equals(screen))showNotificationSettings();}
        else if(requestCode==REQ_PROFILE_BACKGROUND&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}prefs.edit().putString("profile_background_uri",uri.toString()).apply();Toast.makeText(this,"Фон профиля сохранён",Toast.LENGTH_SHORT).show();showAccountSettings();}
    }
    private void uploadMedia(Uri uri,String forcedType){
        if(sending)return;final String id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;setComposeEnabled(false);if(sendButton!=null)sendButton.setEnabled(false);connection.setText("Шифруем и загружаем файл…");
        worker.execute(()->{try{
            String mime=getContentResolver().getType(uri);if(mime==null)mime="application/octet-stream";String name=fileName(uri);byte[] raw=readUri(uri,24*1024*1024);byte[] encrypted=crypto.encryptBytes(uid,id,peer,raw);String path=id+"/"+UUID.randomUUID()+".bin";api.uploadMedia(path,encrypted);
            String type=forcedType!=null?forcedType:(mime.startsWith("image/")?"image":mime.startsWith("video/")?"video":mime.startsWith("audio/")?"audio":"file");
            JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type",type).put("name",type.equals("video_message")?"Видеосообщение.mp4":name).put("mime",mime).put("path",path).put("size",raw.length);
            String payload=crypto.encryptText(uid,id,peer,meta.toString());String nonce=UUID.randomUUID().toString();JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",nonce));
            handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});
        }catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());updateComposeAction();error(e);});}});
    }

    private void updateComposeAction(){
        if(sendButton==null||composer==null)return;
        if(notesMode){if(voiceCancelButton!=null)voiceCancelButton.setVisibility(View.GONE);if(voicePauseButton!=null)voicePauseButton.setVisibility(View.GONE);setComposeButtonIcon("send");sendButton.setContentDescription("Отправить сообщение");return;}
        if(voiceRecording){if(voiceCancelButton!=null)voiceCancelButton.setVisibility(View.VISIBLE);if(voicePauseButton!=null){voicePauseButton.setVisibility(View.VISIBLE);voicePauseButton.setText(voicePaused?"▶":"Ⅱ");voicePauseButton.setContentDescription(voicePaused?"Продолжить запись":"Поставить запись на паузу");}sendButton.setCompoundDrawables(null,null,null,null);sendButton.setText("✓");sendButton.setTextSize(18);sendButton.setContentDescription("Завершить запись и прослушать");return;}
        if(voiceCancelButton!=null)voiceCancelButton.setVisibility(View.GONE);if(voicePauseButton!=null)voicePauseButton.setVisibility(View.GONE);boolean hasText=composer.getText().toString().trim().length()>0;setComposeButtonIcon(hasText?"send":"mic");sendButton.setContentDescription(hasText?"Отправить сообщение":"Записать голосовое сообщение");
    }
    private void showEmojiPicker(){showStickerPicker();}
    private void showPlainEmojiPicker(){loadStickerCloud(false,c->showPlainEmojiPickerWithCatalog(c),()->showPlainEmojiPickerWithCatalog(new JSONObject()));}
    private void showPlainEmojiPickerWithCatalog(JSONObject catalog){LinkedHashSet<String> values=new LinkedHashSet<>();JSONArray reactions=catalog==null?null:catalog.optJSONArray("reactions");if(reactions!=null)for(int i=0;i<reactions.length();i++){String e=reactions.optJSONObject(i)==null?"":reactions.optJSONObject(i).optString("unicode","");if(!e.isEmpty())values.add(e);}Collections.addAll(values,"😀","😂","😊","😍","🥰","😎","🤔","😢","😭","😡","👍","👎","👏","🙏","❤️","💚","🔥","✨","🎉","✅","💯","🤝","👋","🌙","⭐","☕","📌","📎","🎤","📹");final String[] emojis=values.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("Смайлики и реакции").setItems(emojis,(d,which)->{if(composer==null)return;int start=Math.max(composer.getSelectionStart(),0);composer.getText().insert(start,emojis[which]);composer.requestFocus();}).show();}
    private void toggleVoiceRecording(){if(voiceRecording)stopVoiceRecording(true);else ensureVoicePermission();}
    private void ensureVoicePermission(){
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=getPackageManager().PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},REQ_RECORD_AUDIO_PERMISSION);return;
        }
        startVoiceRecording();
    }
    private void startVoiceRecording(){
        if(notesMode||voiceRecording||sending)return;
        if(!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для защищённой отправки голосового сообщения собеседник должен использовать актуальную версию Muwahid с E2EE.");return;}
        try{
            File dir=new File(getCacheDir(),"voice");dir.mkdirs();voiceFile=new File(dir,"voice_"+UUID.randomUUID()+".m4a");
            if(prefs.getBoolean("pause_music_recording",false))requestVoiceAudioFocus();voiceRecorder=new MediaRecorder();voiceRecorder.setAudioSource(prefs.getString("microphone_source","built_in").equals("system")?MediaRecorder.AudioSource.DEFAULT:MediaRecorder.AudioSource.MIC);voiceRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);voiceRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);voiceRecorder.setAudioEncodingBitRate(64000);voiceRecorder.setAudioSamplingRate(44100);voiceRecorder.setOutputFile(voiceFile.getAbsolutePath());voiceRecorder.prepare();voiceRecorder.start();
            voiceRecording=true;voicePaused=false;voicePausedTotal=0;voicePauseStartedAt=0;voiceStartedAt=System.currentTimeMillis();setComposeEnabled(false);updateComposeAction();handler.removeCallbacks(voiceTicker);handler.post(voiceTicker);
        }catch(Exception e){releaseVoiceRecorder();voiceRecording=false;voicePaused=false;if(voiceFile!=null)voiceFile.delete();voiceFile=null;setComposeEnabled(true);updateComposeAction();notice("Не удалось начать запись. Проверьте доступ к микрофону.");}
    }
    private void toggleVoicePause(){
        if(!voiceRecording||voiceRecorder==null)return;
        if(Build.VERSION.SDK_INT<24){Toast.makeText(this,"Пауза записи поддерживается на Android 7 и новее",Toast.LENGTH_SHORT).show();return;}
        try{
            if(voicePaused){voiceRecorder.resume();voicePausedTotal+=Math.max(0,System.currentTimeMillis()-voicePauseStartedAt);voicePauseStartedAt=0;voicePaused=false;}
            else{voiceRecorder.pause();voicePauseStartedAt=System.currentTimeMillis();voicePaused=true;}
            updateComposeAction();handler.removeCallbacks(voiceTicker);handler.post(voiceTicker);
        }catch(Exception e){Toast.makeText(this,"Не удалось переключить паузу",Toast.LENGTH_SHORT).show();}
    }
    private void stopVoiceRecording(boolean previewAfter){
        if(!voiceRecording)return;handler.removeCallbacks(voiceTicker);long now=System.currentTimeMillis();long paused=voicePausedTotal+(voicePaused?Math.max(0,now-voicePauseStartedAt):0);long duration=Math.max(0,now-voiceStartedAt-paused);boolean ok=true;
        try{voiceRecorder.stop();}catch(Exception e){ok=false;}releaseVoiceRecorder();abandonVoiceAudioFocus();voiceRecording=false;voicePaused=false;voicePauseStartedAt=0;voicePausedTotal=0;setComposeEnabled(true);updateComposeAction();
        File recorded=voiceFile;voiceFile=null;if(!ok||recorded==null||!recorded.exists()||duration<700){if(recorded!=null)recorded.delete();if(connection!=null)connection.setText(chatSecurityStatus());if(previewAfter)Toast.makeText(this,"Запись слишком короткая",Toast.LENGTH_SHORT).show();return;}
        if(previewAfter)showVoicePreview(recorded,duration);else{recorded.delete();if(connection!=null)connection.setText(chatSecurityStatus());}
    }
    private void showVoicePreview(File recorded,long duration){
        if(recorded==null||!recorded.exists())return;
        Dialog dialog=new Dialog(this);dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);dialog.setCanceledOnTouchOutside(false);
        LinearLayout box=vertical();box.setPadding(dp(22),dp(20),dp(22),dp(18));box.setBackground(shape(Color.parseColor("#10283B"),22));TextView title=label("Голосовое сообщение",20,Color.WHITE);bold(title);box.addView(title);TextView info=label("Длительность "+formatDuration(duration)+" · прослушайте перед отправкой",13,Color.parseColor("#AFC2D4"));info.setPadding(0,dp(7),0,dp(15));box.addView(info);
        final MediaPlayer[] player={null};Button play=button("▶  Прослушать");box.addView(play,new LinearLayout.LayoutParams(-1,dp(50)));play.setOnClickListener(v->{try{if(player[0]!=null&&player[0].isPlaying()){player[0].pause();play.setText("▶  Продолжить");return;}if(player[0]==null){MediaPlayer mp=new MediaPlayer();mp.setDataSource(recorded.getAbsolutePath());mp.prepare();mp.setOnCompletionListener(x->play.setText("▶  Прослушать"));player[0]=mp;}player[0].start();play.setText("Ⅱ  Пауза");}catch(Exception e){Toast.makeText(this,"Не удалось воспроизвести запись",Toast.LENGTH_SHORT).show();}});
        gap(box,10);Button send=button("Отправить");box.addView(send,new LinearLayout.LayoutParams(-1,dp(50)));send.setOnClickListener(v->{if(player[0]!=null){try{player[0].stop();}catch(Exception ignored){}try{player[0].release();}catch(Exception ignored){}player[0]=null;}dialog.dismiss();uploadRecordedVoice(recorded,duration);});
        gap(box,10);Button again=button("Перезаписать");box.addView(again,new LinearLayout.LayoutParams(-1,dp(48)));again.setOnClickListener(v->{if(player[0]!=null){try{player[0].release();}catch(Exception ignored){}player[0]=null;}recorded.delete();dialog.dismiss();ensureVoicePermission();});
        gap(box,8);Button cancel=button("Удалить запись");box.addView(cancel,new LinearLayout.LayoutParams(-1,dp(46)));cancel.setOnClickListener(v->{if(player[0]!=null){try{player[0].release();}catch(Exception ignored){}player[0]=null;}recorded.delete();dialog.dismiss();if(connection!=null)connection.setText(chatSecurityStatus());});
        dialog.setOnCancelListener(d->{if(player[0]!=null){try{player[0].release();}catch(Exception ignored){}}recorded.delete();});dialog.setContentView(box);Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setLayout(-1,-2);}dialog.show();if(w!=null)w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.90f),-2);
    }
    private void cancelVoiceRecording(boolean showToast){
        if(!voiceRecording)return;handler.removeCallbacks(voiceTicker);try{voiceRecorder.stop();}catch(Exception ignored){}releaseVoiceRecorder();abandonVoiceAudioFocus();voiceRecording=false;voicePaused=false;voicePauseStartedAt=0;voicePausedTotal=0;File recorded=voiceFile;voiceFile=null;if(recorded!=null)recorded.delete();setComposeEnabled(true);updateComposeAction();if(connection!=null)connection.setText(chatSecurityStatus());if(showToast)Toast.makeText(this,"Запись отменена",Toast.LENGTH_SHORT).show();
    }
    private void releaseVoiceRecorder(){if(voiceRecorder!=null){try{voiceRecorder.reset();}catch(Exception ignored){}try{voiceRecorder.release();}catch(Exception ignored){}voiceRecorder=null;}}
    private void requestVoiceAudioFocus(){if(audioManager==null||voiceAudioFocus)return;try{voiceAudioFocus=audioManager.requestAudioFocus(null,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;}catch(Exception ignored){}}
    private void abandonVoiceAudioFocus(){if(audioManager==null||!voiceAudioFocus)return;try{audioManager.abandonAudioFocus(null);}catch(Exception ignored){}voiceAudioFocus=false;}
    private void updateProximityListener(){unregisterProximity();if(!foreground||!"chat".equals(screen)||proximitySensor==null||sensorManager==null)return;if(prefs.getBoolean("raise_listen",true)||prefs.getBoolean("raise_speak",false))sensorManager.registerListener(this,proximitySensor,SensorManager.SENSOR_DELAY_NORMAL);}
    private void unregisterProximity(){if(sensorManager!=null)try{sensorManager.unregisterListener(this);}catch(Exception ignored){}}
    @Override public void onSensorChanged(SensorEvent event){if(event.sensor.getType()!=Sensor.TYPE_PROXIMITY||!"chat".equals(screen))return;boolean near=event.values.length>0&&event.values[0]<event.sensor.getMaximumRange();if(near){if(prefs.getBoolean("raise_listen",true)&&inlineVoicePlayer!=null&&inlineVoicePlayer.isPlaying()&&audioManager!=null){try{audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);audioManager.setSpeakerphoneOn(false);}catch(Exception ignored){}}if(prefs.getBoolean("raise_speak",false)&&!notesMode&&!voiceRecording&&!sending&&composer!=null&&composer.getText().toString().trim().isEmpty()){proximityStartedRecording=true;ensureVoicePermission();}}else{if(audioManager!=null)try{audioManager.setMode(AudioManager.MODE_NORMAL);}catch(Exception ignored){}if(proximityStartedRecording&&voiceRecording){proximityStartedRecording=false;stopVoiceRecording(true);}}}
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
    private void setComposeEnabled(boolean enabled){if(composer!=null)composer.setEnabled(enabled);if(attachButton!=null)attachButton.setEnabled(enabled);if(emojiButton!=null)emojiButton.setEnabled(enabled);if(videoMessageButton!=null)videoMessageButton.setEnabled(enabled);}
    private void uploadRecordedVoice(File recorded,long duration){
        if(sending){recorded.delete();return;}final String id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;if(sendButton!=null)sendButton.setEnabled(false);if(attachButton!=null)attachButton.setEnabled(false);if(videoMessageButton!=null)videoMessageButton.setEnabled(false);if(emojiButton!=null)emojiButton.setEnabled(false);connection.setText("Шифруем и отправляем голосовое сообщение…");
        worker.execute(()->{try{
            byte[] raw=readFile(recorded,24*1024*1024);byte[] encrypted=crypto.encryptBytes(uid,id,peer,raw);String path=id+"/"+UUID.randomUUID()+".bin";api.uploadMedia(path,encrypted);
            JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type","voice").put("name","Голосовое сообщение.m4a").put("mime","audio/mp4").put("path",path).put("size",raw.length).put("duration_ms",duration);
            String payload=crypto.encryptText(uid,id,peer,meta.toString());String nonce=UUID.randomUUID().toString();JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",nonce));recorded.delete();
            handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});
        }catch(Exception e){recorded.delete();handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());updateComposeAction();error(e);});}});
    }
    private byte[] readFile(File file,int max) throws Exception{if(file.length()>max)throw new Exception("Максимальный размер файла — 24 МБ");ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=new FileInputStream(file)){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}return out.toByteArray();}
    private String formatDuration(long ms){long total=Math.max(0,ms/1000),m=total/60,s=total%60;return String.format(Locale.getDefault(),"%d:%02d",m,s);}
    private void recordVideoMessage(){
        if(sending||voiceRecording)return;if(!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для защищённой отправки видеосообщения собеседник должен использовать актуальную версию Muwahid с E2EE.");return;}
        if(Build.VERSION.SDK_INT>=23&&(checkSelfPermission(android.Manifest.permission.CAMERA)!=getPackageManager().PERMISSION_GRANTED||checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=getPackageManager().PERMISSION_GRANTED)){
            requestPermissions(new String[]{android.Manifest.permission.CAMERA,android.Manifest.permission.RECORD_AUDIO},REQ_VIDEO_MESSAGE_PERMISSION);return;
        }
        startVideoMessageCapture();
    }
    private void startVideoMessageCapture(){
        try{Intent i=new Intent(MediaStore.ACTION_VIDEO_CAPTURE);i.putExtra(MediaStore.EXTRA_DURATION_LIMIT,60);i.putExtra(MediaStore.EXTRA_VIDEO_QUALITY,0);startActivityForResult(i,REQ_VIDEO_MESSAGE);}catch(Exception e){notice("На телефоне не найдено приложение камеры для записи видео.");}
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_RECORD_AUDIO_PERMISSION){if(grantResults.length>0&&grantResults[0]==getPackageManager().PERMISSION_GRANTED)startVoiceRecording();else notice("Без доступа к микрофону голосовое сообщение записать нельзя.");}
        else if(requestCode==REQ_VIDEO_MESSAGE_PERMISSION){boolean ok=grantResults.length>=2;for(int value:grantResults)ok&=value==getPackageManager().PERMISSION_GRANTED;if(ok)startVideoMessageCapture();else notice("Для видеосообщения нужен доступ к камере и микрофону.");}
        else if(requestCode==REQ_CAMERA_PHOTO_PERMISSION){if(grantResults.length>0&&grantResults[0]==getPackageManager().PERMISSION_GRANTED)startPhotoCapture();else notice("Для фото нужен доступ к камере.");}
        else if(requestCode==REQ_CAMERA_VIDEO_PERMISSION){boolean ok=grantResults.length>=2;for(int value:grantResults)ok&=value==getPackageManager().PERMISSION_GRANTED;if(ok)startCameraVideoCapture();else notice("Для видео нужен доступ к камере и микрофону.");}
        else if(requestCode==REQ_LOCATION_PERMISSION){boolean ok=false;for(int value:grantResults)ok|=value==getPackageManager().PERMISSION_GRANTED;if(ok)locateAndConfirm();else notice("Местоположение не отправлено: доступ к геолокации не предоставлен.");}
    }
    private String fileName(Uri uri){String name="Файл";try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())name=c.getString(0);}catch(Exception ignored){}return name==null?"Файл":name.replaceAll("[\r\n]"," ");}
    private byte[] readUri(Uri uri,int max) throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new Exception("Не удалось открыть файл");byte[] b=new byte[16384];int n,total=0;while((n=in.read(b))!=-1){total+=n;if(total>max)throw new Exception("Максимальный размер файла — 24 МБ");out.write(b,0,n);}}return out.toByteArray();}
    private void downloadMedia(JSONObject meta){final int stamp=generation;connection.setText("Скачиваем и расшифровываем файл…");worker.execute(()->{try{byte[] encrypted=api.downloadMedia(meta.getString("path"));byte[] raw=crypto.decryptBytes(api.uid(),chatId,peerE2eeKey,encrypted);File dir=new File(getCacheDir(),"media");dir.mkdirs();String safe=meta.optString("name","file").replaceAll("[^A-Za-zА-Яа-я0-9._ -]","_");File f=new File(dir,UUID.randomUUID()+"_"+safe);try(FileOutputStream out=new FileOutputStream(f)){out.write(raw);}Uri content=FileProvider.getUriForFile(this,getPackageName()+".files",f);Intent open=new Intent(Intent.ACTION_VIEW);open.setDataAndType(content,meta.optString("mime","application/octet-stream"));open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);handler.post(()->{if(stamp!=generation)return;connection.setText(chatSecurityStatus());try{startActivity(open);}catch(Exception x){notice("На телефоне нет приложения для открытия этого файла.");}});}catch(Exception e){handler.post(()->{if(stamp!=generation)return;connection.setText(chatSecurityStatus());error(e);});}});}
    private void send(){if(sending)return;String body=composer.getText().toString().trim();if(body.isEmpty())return;
        if(notesMode){try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));notes.put(new JSONObject().put("body",body).put("time",new SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new Date())));if(!prefs.edit().putString("notes",notes.toString()).commit())throw new Exception("Не удалось сохранить заметку");composer.setText("");saveDraft();drawNotes();}catch(Exception e){error(e);}return;}
        if(!e2eeBackendReady){notice("Защищённая отправка ещё не готова на сервере Muwahid. Проверьте серверные функции E2EE в Supabase.");return;}
        if(peerE2eeKey.isEmpty()){notice("Собеседник ещё не активировал E2EE в Muwahid. Незашифрованная отправка заблокирована, чтобы не снижать защиту.");return;}
        if(!body.equals(pendingText)){pendingText=body;pendingNonce=UUID.randomUUID().toString();pendingPayload="";}
        final String nonce=pendingNonce,id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;setComposeEnabled(false);sendButton.setEnabled(false);
        worker.execute(()->{try{
            String payload=pendingPayload;if(payload.isEmpty()){payload=crypto.encryptText(uid,id,peer,body);pendingPayload=payload;}
            JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",nonce));
            handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);composer.setText("");saveDraft();pendingNonce="";pendingText="";pendingPayload="";history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});
        }catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);updateComposeAction();error(e);});}});
    }
    private String time(String source){if(source==null||source.isEmpty()||source.equals("null"))return "";try{String s=source.substring(0,19);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(d);}catch(Exception e){return "";}}
    private final int profileBlue=Color.rgb(123,190,239);
    private void profileCaption(LinearLayout card,String value){TextView t=label(value,14,profileBlue);bold(t);t.setPadding(dp(12),dp(10),dp(12),dp(12));card.addView(t);}
    private EditText profileInput(LinearLayout card,String hint,String value,int max){EditText e=new EditText(this);e.setTextSize(18);e.setTextColor(text);e.setHintTextColor(muted);e.setHint(hint);e.setText(value);e.setSingleLine(true);e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});e.setBackgroundColor(Color.TRANSPARENT);e.setPadding(dp(14),dp(8),dp(14),dp(8));card.addView(e,new LinearLayout.LayoutParams(-1,dp(54)));return e;}
    private void profileRow(LinearLayout card,String icon,int color,String title,String subtitle,Runnable action){
        LinearLayout row=horizontal();row.setPadding(dp(12),dp(10),dp(12),dp(10));TextView badge=label(icon,22,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setBackground(shape(color,10));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(30),dp(30));bp.rightMargin=dp(18);row.addView(badge,bp);
        LinearLayout words=vertical();words.addView(label(title,17,text));if(subtitle!=null){TextView sub=label(subtitle,12,muted);sub.setPadding(0,dp(5),0,0);words.addView(sub);}row.addView(words,new LinearLayout.LayoutParams(0,-2,1));card.addView(row,new LinearLayout.LayoutParams(-1,-2));row.setOnClickListener(v->action.run());
    }
    private void editProfileDetail(String key,String title,int max){EditText input=new EditText(this);input.setText(prefs.getString(key,""));input.setSingleLine(true);input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});new AlertDialog.Builder(this).setTitle(title).setView(input).setMessage("Сохраняется на этом телефоне.").setPositiveButton("Сохранить",(d,w)->{prefs.edit().putString(key,input.getText().toString().trim()).apply();showAccountSettings();}).setNegativeButton("Отмена",null).show();}
    private String profileStatusText(){
        long until=prefs.getLong("profile_status_until",0);
        if(until>0&&System.currentTimeMillis()>until){prefs.edit().remove("profile_status_text").remove("profile_status_emoji").remove("profile_status_until").apply();return "Статус не установлен";}
        String t=prefs.getString("profile_status_text","").trim(),e=prefs.getString("profile_status_emoji","").trim();
        return t.isEmpty()?"Статус не установлен":(e.isEmpty()?t:e+"  "+t);
    }
    private void chooseProfileBackground(){
        try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_PROFILE_BACKGROUND);}
        catch(Exception e){notice("Не удалось открыть галерею.");}
    }
    private void showProfileStatusPicker(){
        String[] labels={"💼 На работе","😴 Сплю","✈ В пути","🧳 В командировке","🔕 Не беспокоить","🏠 Дома","✏ Свой статус","Очистить статус"};
        new AlertDialog.Builder(this).setTitle("Статус").setItems(labels,(d,w)->{
            if(w==7){prefs.edit().remove("profile_status_text").remove("profile_status_emoji").remove("profile_status_until").apply();showAccountSettings();return;}
            if(w==6){EditText input=new EditText(this);input.setHint("Например: занят до вечера");input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(60)});new AlertDialog.Builder(this).setTitle("Свой статус").setView(input).setNegativeButton("Отмена",null).setPositiveButton("Далее",(x,y)->saveProfileStatus("",input.getText().toString().trim())).show();return;}
            String raw=labels[w],emoji=raw.substring(0,raw.indexOf(' ')),txt=raw.substring(raw.indexOf(' ')+1);saveProfileStatus(emoji,txt);
        }).show();
    }
    private void saveProfileStatus(String emoji,String value){
        if(value.isEmpty()){showAccountSettings();return;}
        String[] times={"1 час","До завтра","7 дней","Пока не уберу"};
        new AlertDialog.Builder(this).setTitle("Срок статуса").setItems(times,(d,w)->{
            long now=System.currentTimeMillis(),until=w==0?now+3600000L:w==1?now+86400000L:w==2?now+7L*86400000L:0;
            prefs.edit().putString("profile_status_text",value).putString("profile_status_emoji",emoji).putLong("profile_status_until",until).apply();
            if(api.signedIn())worker.execute(()->{try{JSONObject args=new JSONObject().put("p_status_text",value).put("p_status_emoji",emoji);if(until==0)args.put("p_expires_at",JSONObject.NULL);else args.put("p_expires_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US).format(new Date(until)));api.rpc("mw_update_profile_status",args);}catch(Exception ignored){}});
            showAccountSettings();
        }).show();
    }
    private void addProfileHeader(){
        FrameLayout hero=new FrameLayout(this);GradientDrawable fallback=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.parseColor("#123D56"),Color.parseColor("#126F73")});fallback.setCornerRadius(dp(24));hero.setBackground(fallback);
        String raw=prefs.getString("profile_background_uri","");
        if(!raw.isEmpty()){ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);try{image.setImageURI(Uri.parse(raw));}catch(Exception ignored){}hero.addView(image,new FrameLayout.LayoutParams(-1,-1));}
        LinearLayout overlay=vertical();overlay.setGravity(Gravity.BOTTOM);overlay.setPadding(dp(18),dp(18),dp(18),dp(16));
        TextView n=label(prefs.getString("name","Пользователь Muwahid"),22,Color.WHITE);bold(n);overlay.addView(n);
        TextView st=label(profileStatusText(),13,Color.parseColor("#D7F6F1"));st.setPadding(0,dp(5),0,0);overlay.addView(st);hero.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(170));hp.setMargins(dp(12),dp(6),dp(12),dp(10));root.addView(hero,hp);
    }
    private void showMyProfile(){
        begin("profile");String name=prefs.getString("name","Пользователь Muwahid");toolbar(name,false,"⋮",()->new AlertDialog.Builder(this).setItems(new String[]{"Изменить профиль","Недавние звонки"},(d,w)->{if(w==0)showAccountSettings();else showRecentCalls();}).show());addProfileHeader();
        LinearLayout tabs=horizontal();tabs.setPadding(dp(18),dp(8),dp(18),dp(8));TextView posts=label("Публикации",15,profileBlue),archive=label("Архив публикаций",15,muted);posts.setGravity(Gravity.CENTER);archive.setGravity(Gravity.CENTER);posts.setBackground(shape(panel,22));tabs.addView(posts,new LinearLayout.LayoutParams(0,dp(38),1));tabs.addView(archive,new LinearLayout.LayoutParams(0,dp(38),1));root.addView(tabs);
        LinearLayout empty=vertical();empty.setGravity(Gravity.CENTER);TextView title=label("Публикаций пока нет…",20,text);bold(title);empty.addView(title);TextView sub=label("Публикуйте фотографии и видео в своём профиле",14,muted);sub.setGravity(Gravity.CENTER);sub.setPadding(dp(30),dp(12),dp(30),0);empty.addView(sub);root.addView(empty,new LinearLayout.LayoutParams(-1,0,1));
        posts.setOnClickListener(v->{title.setText("Публикаций пока нет…");posts.setTextColor(profileBlue);archive.setTextColor(muted);});archive.setOnClickListener(v->{title.setText("Архив публикаций пуст");archive.setTextColor(profileBlue);posts.setTextColor(muted);});
        TextView add=label("▣  Добавить",16,Color.WHITE);bold(add);add.setGravity(Gravity.CENTER);add.setBackground(shape(Color.rgb(36,153,231),25));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(150),dp(44));ap.gravity=Gravity.CENTER;ap.bottomMargin=dp(12);root.addView(add,ap);add.setOnClickListener(v->notice("Публикации профиля пока не подключены к серверу."));bottom("Профиль");
    }
    private void showAccountSettings(){begin("account");toolbar("Аккаунт",true,null,null);scrollContent();content.setPadding(dp(12),dp(8),dp(12),dp(24));
        LinearLayout names=settingsCard();profileCaption(names,"Ваше имя");EditText nameField=profileInput(names,"Имя",prefs.getString("name","Пользователь Muwahid"),60);EditText surname=profileInput(names,"Фамилия",prefs.getString("surname",""),60);gap(content,12);
        LinearLayout about=settingsCard();EditText bio=profileInput(about,"«О себе»",prefs.getString("bio",""),70);TextView count=label("70",14,muted);count.setGravity(Gravity.RIGHT);about.addView(count);bio.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int c){count.setText(String.valueOf(70-s.length()));}public void afterTextChanged(Editable e){}});count.setText(String.valueOf(70-bio.length()));gap(content,8);note(content,"Напишите немного о себе.");gap(content,12);
        LinearLayout presence=settingsCard();profileCaption(presence,"Статус и оформление");
        profileRow(presence,"●",Color.rgb(35,170,151),profileStatusText(),"На работе, сплю, в пути или свой статус",this::showProfileStatusPicker);
        profileRow(presence,"▧",Color.rgb(66,126,201),prefs.getString("profile_background_uri","").isEmpty()?"Фон профиля":"Фон профиля выбран","Выбрать свою фотографию",this::chooseProfileBackground);
        gap(content,18);
        LinearLayout info=settingsCard();profileCaption(info,"Информация о Вас");String phone=profile.optString("phone_e164",prefs.getString("phone",""));profileRow(info,"☎",Color.rgb(63,184,66),phone.isEmpty()?"Номер телефона":phone,"Номер подтверждённого аккаунта",()->notice("Смена номера телефона пока не подключена."));
        EditText username=profileInput(info,"Добавить имя пользователя",prefs.getString("username",""),32);username.setEnabled(api.signedIn());profileRow(info,"♙",Color.rgb(32,156,220),prefs.getString("birthday","").isEmpty()?"Указать день рождения":prefs.getString("birthday",""),null,()->editProfileDetail("birthday","День рождения",30));gap(content,10);note(content,"День рождения пока сохраняется только на этом телефоне.");gap(content,18);
        LinearLayout extra=settingsCard();profileRow(extra,"◧",Color.rgb(232,151,23),"Личный канал",null,()->notice("Личные каналы пока не подключены."));profileRow(extra,"Ai",Color.rgb(178,91,223),"Автоматизация чатов",null,()->notice("Подключение ботов пока не реализовано."));gap(content,10);note(content,"Подключите бота, который будет отвечать на сообщения от Вашего имени.");gap(content,18);
        Button save=button("Сохранить профиль");content.addView(save,new LinearLayout.LayoutParams(-1,dp(48)));save.setOnClickListener(v->{String n=nameField.getText().toString().trim(),u=username.getText().toString().trim().toLowerCase(Locale.ROOT);if(n.isEmpty()){nameField.setError("Введите имя");return;}Runnable saved=()->{prefs.edit().putString("name",n).putString("username",u).putString("surname",surname.getText().toString().trim()).putString("bio",bio.getText().toString().trim()).apply();Toast.makeText(this,"Профиль сохранён",Toast.LENGTH_SHORT).show();};if(api.signedIn()){async(()->{try{return api.rpc("mw_update_profile_extended",new JSONObject().put("p_name",n).put("p_username",u).put("p_bio",bio.getText().toString().trim()));}catch(Exception ignored){return api.rpc("mw_update_profile",new JSONObject().put("p_name",n).put("p_username",u));}},r->{saved.run();save.setEnabled(true);});}else saved.run();});gap(content,18);
        LinearLayout actions=settingsCard();profileRow(actions,"◎",Color.rgb(46,132,183),"Добавить аккаунт",null,()->notice("Несколько аккаунтов пока не поддерживаются."));profileRow(actions,"↪",Color.rgb(206,99,118),"Выход",null,()->new AlertDialog.Builder(this).setTitle("Выйти из аккаунта?").setNegativeButton("Отмена",null).setPositiveButton("Выйти",(d,w)->{worker.execute(()->{try{api.logout();}catch(Exception ignored){}handler.post(()->{NotificationService.stop(this);chats=new JSONArray();showWelcome();});});}).show());
        if(api.signedIn())async(()->api.rpc("mw_me",new JSONObject()),r->{if(r instanceof JSONObject){profile=(JSONObject)r;nameField.setText(profile.optString("display_name",prefs.getString("name","")));username.setText(profile.optString("username",prefs.getString("username","")));String serverBio=profile.optString("bio","");if(!serverBio.isEmpty())bio.setText(serverBio);String serverStatus=profile.optString("status_text","");if(!serverStatus.isEmpty())prefs.edit().putString("profile_status_text",serverStatus).putString("profile_status_emoji",profile.optString("status_emoji","")).apply();}});
    }
    private void showSecurity(){startActivity(new Intent(this,PrivacyActivity.class));}
    private void showTwoFactor(){
        begin("security");toolbar("Двухэтапная проверка",true,null,null);scrollContent();
        note(content,"Проверяем защиту аккаунта…");
        async(()->new JSONObject().put("factors",api.factors()).put("owner",api.rpc("mw_owner_status",new JSONObject())), result->{
            JSONObject data=(JSONObject)result;JSONArray factors=data.getJSONArray("factors");JSONObject owner=data.getJSONObject("owner");content.removeAllViews();
            note(content,owner.optBoolean("is_owner")?"Ваш аккаунт закреплён как единственный владелец Muwahid. Панель владельца открывается только после проверки второго фактора.":"Код из приложения-аутентификатора защищает вход в переписку после подключения второго фактора.");gap(content,18);
            boolean verified=false;
            for(int i=0;i<factors.length();i++){JSONObject f=factors.getJSONObject(i);if("verified".equals(f.optString("status"))&&"totp".equals(f.optString("factor_type"))){verified=true;final String id=f.getString("id");Button confirm=button("Подтвердить кодом аутентификатора");content.addView(confirm,new LinearLayout.LayoutParams(-1,dp(58)));confirm.setOnClickListener(v->showTotpCode(id,null));gap(content,12);}}
            if(!verified){note(content,"Второй фактор ещё не включён. Добавьте ключ в приложение-аутентификатор на своём телефоне, сохраните резервную копию ключа в надёжном месте и подтвердите первый код. Если потерять аутентификатор и резервную копию, доступ придётся восстанавливать через службу поддержки.");gap(content,18);Button enable=button("Подключить второй фактор");content.addView(enable,new LinearLayout.LayoutParams(-1,dp(58)));enable.setOnClickListener(v->{enable.setEnabled(false);async(()->api.enrollTotp(),res->{JSONObject f=(JSONObject)res;showTotpCode(f.getString("id"),f.getJSONObject("totp"));});});}
            if(owner.optBoolean("owner_access")){gap(content,22);Button dashboard=button("Открыть панель владельца");content.addView(dashboard,new LinearLayout.LayoutParams(-1,dp(54)));dashboard.setOnClickListener(v->showOwner());}
            gap(content,20);Button retry=button("Обновить состояние защиты");content.addView(retry,new LinearLayout.LayoutParams(-1,dp(54)));retry.setOnClickListener(v->showTwoFactor());
        });
    }
    private void showTotpCode(String factor,JSONObject totp){
        begin("mfa");getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);toolbar("Второй фактор",true,null,null);scrollContent();
        if(totp!=null){note(content,"Добавьте этот секретный ключ в аутентификатор: тип — по времени (TOTP), название — Muwahid. Не отправляйте ключ или коды в чат. Сохраните резервную копию ключа у себя.");gap(content,14);TextView key=label(totp.optString("secret"),18,text);key.setTextIsSelectable(true);content.addView(key);gap(content,14);
            Button open=button("Открыть аутентификатор");content.addView(open,new LinearLayout.LayoutParams(-1,dp(54)));open.setOnClickListener(v->{try{android.net.Uri uri=android.net.Uri.parse(totp.optString("uri"));if(!"otpauth".equals(uri.getScheme()))throw new Exception();startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){notice("Откройте свой аутентификатор и добавьте показанный ключ вручную.");}});gap(content,20);
        }else note(content,"Введите текущий шестизначный код из аутентификатора для Muwahid.");
        EditText code=field("Код из 6 цифр",true);code.setInputType(18);code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});code.setSaveEnabled(false);
        Button verify=button("Подтвердить");content.addView(verify,new LinearLayout.LayoutParams(-1,dp(54)));verify.setOnClickListener(v->{String value=code.getText().toString().trim();if(!value.matches("[0-9]{6}")){code.setError("Нужны 6 цифр");return;}verify.setEnabled(false);final int stamp=generation;worker.execute(()->{try{api.verifyTotp(factor,value);handler.post(()->{if(stamp!=generation)return;code.setText("");showTwoFactor();notice("Второй фактор подтверждён.");});}catch(Exception ex){handler.post(()->{if(stamp!=generation)return;verify.setEnabled(true);code.setText("");error(ex);});}});});
    }
    private void showOwner(){begin("owner");toolbar("Панель владельца",true,null,null);scrollContent();note(content,"Проверяем доступ на сервере…");async(()->api.rpc("mw_owner_overview",new JSONObject()),result->{JSONObject stats=(JSONObject)result;content.removeAllViews();note(content,"Доступ владельца подтверждён вторым фактором.");gap(content,22);note(content,"Пользователей: "+stats.optLong("users")+"\nЛичных чатов: "+stats.optLong("chats")+"\nСообщений: "+stats.optLong("messages")+"\nОткрытых жалоб: "+stats.optLong("open_complaints"));gap(content,22);note(content,"Раздел владельца доступен только аккаунту, закреплённому на сервере, и только после второго фактора.");});}
    @Override public void onBackPressed(){
        if(screen.equals("mfa")||screen.equals("owner")){showTwoFactor();}
        else if(screen.equals("security")){showSettings();}
        else if(screen.equals("privacy_blocks")||screen.equals("privacy_contacts")){showSecurity();}
        else if(screen.equals("chat")){if(voiceRecording){cancelVoiceRecording(true);return;}if(sending){Toast.makeText(this,"Дождитесь отправки сообщения",Toast.LENGTH_SHORT).show();return;}showChats();}
        else if(screen.equals("stickers")||screen.equals("chat_wallpaper")||screen.equals("chat_name_color")){showChatSettings();}
        else if(screen.equals("account")||screen.equals("chat_settings")||screen.equals("notifications")||screen.equals("data_settings")||screen.equals("folders")||screen.equals("devices")||screen.equals("energy")||screen.equals("language")||screen.equals("premium")||screen.equals("business")||screen.equals("gift"))showSettings();
        else if(screen.equals("profile")){showChats();}
        else if(screen.equals("settings")||screen.equals("menu")||screen.equals("calls")||screen.equals("contacts")||screen.equals("voice_rooms")||screen.equals("admins"))showChats();
        else if(screen.equals("community"))showHub(mainTab);
        else if(screen.equals("community_settings"))showHub(mainTab);
        else if(screen.equals("otp"))showAuth(phoneRegisterMode);
        else if(screen.equals("auth"))showWelcome();
        else if(screen.equals("chats")||screen.equals("welcome")){
            // Exit the Activity without logging out. The encrypted Supabase session stays
            // on the device, so the next launch opens chats directly.
            finish();
        }else super.onBackPressed();
    }
    private final class ChatWallpaperDrawable extends Drawable {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private Bitmap bitmap;private final int base;
        ChatWallpaperDrawable(){base=prefs.getInt("chat_wallpaper_color",Color.parseColor("#061321"));String raw=prefs.getString("chat_wallpaper_uri","");if(raw!=null&&!raw.isEmpty())try(InputStream in=getContentResolver().openInputStream(Uri.parse(raw))){bitmap=BitmapFactory.decodeStream(in);}catch(Exception ignored){bitmap=null;}}
        @Override public void draw(Canvas c){Rect b=getBounds();if(bitmap!=null){float scale=Math.max(b.width()/(float)bitmap.getWidth(),b.height()/(float)bitmap.getHeight());float w=bitmap.getWidth()*scale,h=bitmap.getHeight()*scale;RectF dst=new RectF((b.width()-w)/2f,(b.height()-h)/2f,(b.width()+w)/2f,(b.height()+h)/2f);c.drawBitmap(bitmap,null,dst,paint);paint.setColor(Color.argb(45,0,0,0));c.drawRect(b,paint);return;}c.drawColor(base);int preset=prefs.getInt("wallpaper_preset",0);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(Color.argb(preset<0?4:7,120,190,210));int step=dp(74);for(int y=dp(18);y<b.bottom;y+=step){for(int x=((y/step)%2==0?dp(16):dp(58));x<b.right;x+=step){c.drawCircle(x,y,dp(7+(Math.abs(preset)%2)),paint);c.drawLine(x-dp(5),y,x+dp(5),y,paint);c.drawCircle(x+dp(16),y+dp(17),dp(4),paint);}}paint.setStyle(Paint.Style.FILL);}
        @Override public void setAlpha(int a){}@Override public void setColorFilter(android.graphics.ColorFilter f){}@Override public int getOpacity(){return android.graphics.PixelFormat.OPAQUE;}
    }
    private final class WaveformView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private final boolean mine;private final int[] bars={5,9,14,8,18,12,7,16,20,10,6,15,11,18,8,13,19,7,12,16,9,5,14,10,17,8,13,6,11,15};
        WaveformView(Context c,boolean mine){super(c);this.mine=mine;}
        @Override protected void onDraw(Canvas c){super.onDraw(c);paint.setColor(mine?Color.argb(185,230,255,249):Color.parseColor("#66DCC8"));paint.setStrokeWidth(dp(2));paint.setStrokeCap(Paint.Cap.ROUND);float gap=getWidth()/(float)bars.length;float cy=getHeight()/2f;for(int i=0;i<bars.length;i++){float h=dp(bars[i])*.55f;float x=i*gap+gap/2;c.drawLine(x,cy-h/2,x,cy+h/2,paint);}}
    }
    private final class Logo extends View {
        private final boolean landscape;
        private final Paint p=new Paint(3);
        Logo(Context c,boolean landscape){super(c);this.landscape=landscape;setContentDescription("Логотип Muwahid");}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight();
            if(landscape){p.setShader(new LinearGradient(0,0,w,h,new int[]{Color.rgb(8,17,38),Color.rgb(7,75,102),Color.rgb(6,33,46)},null,Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h,p);p.setShader(null);
                mountain(canvas,w,h,.70f,Color.rgb(26,92,119));mountain(canvas,w,h,.79f,Color.rgb(17,60,84));mountain(canvas,w,h,.89f,Color.rgb(9,32,52));
                float size=Math.min(w*.30f,h*.25f);logo(canvas,(w-size)/2,h*.22f,size);
                p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextSize(dp(40));p.setTextAlign(Paint.Align.CENTER);canvas.drawText("Muwahid",w/2,h*.22f+size+dp(54),p);p.setTypeface(Typeface.create("sans-serif",0));p.setTextSize(dp(16));p.setColor(Color.rgb(177,221,233));canvas.drawText("Ближе друг к другу",w/2,h*.22f+size+dp(86),p);
            }else{float size=Math.min(w,h)*.86f;logo(canvas,(w-size)/2,(h-size)/2,size);}
        }
        private void mountain(Canvas c,float w,float h,float level,int color){p.setColor(color);Path path=new Path();path.moveTo(0,h);path.lineTo(0,h*level);path.lineTo(w*.18f,h*(level-.05f));path.lineTo(w*.42f,h*(level-.25f));path.lineTo(w*.53f,h*(level-.13f));path.lineTo(w*.64f,h*(level-.18f));path.lineTo(w*.88f,h*(level-.02f));path.lineTo(w,h*(level-.08f));path.lineTo(w,h);path.close();c.drawPath(path,p);}
        private void logo(Canvas c,float x,float y,float s){c.save();c.translate(x,y);c.scale(s/100,s/100);p.setShader(new LinearGradient(0,15,95,80,new int[]{accent,cyan},null,Shader.TileMode.CLAMP));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(18);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);Path m=new Path();m.moveTo(15,85);m.lineTo(15,18);m.lineTo(50,48);m.lineTo(85,18);m.lineTo(85,85);c.drawPath(m,p);p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);Path plane=new Path();plane.moveTo(45,65);plane.lineTo(95,44);plane.lineTo(79,94);plane.lineTo(68,77);plane.lineTo(85,55);plane.lineTo(60,72);plane.close();c.drawPath(plane,p);c.restore();}
    }
}
