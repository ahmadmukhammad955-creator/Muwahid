Muwahid 0.13.26

Fix: sending an invitation/message immediately after opening a chat now waits for E2EE preparation and sends automatically instead of showing a false Supabase E2EE error.

Upload this GITHUB_READY zip to the repository root and replace .github/workflows/build-apk.yml with the included workflow.
