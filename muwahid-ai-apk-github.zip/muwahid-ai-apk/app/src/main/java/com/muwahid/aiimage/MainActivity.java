package com.muwahid.aiimage;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int STORAGE_REQUEST = 7001;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText endpointInput;
    private EditText promptInput;
    private Button generateButton;
    private Button saveButton;
    private ProgressBar progressBar;
    private ImageView imageView;
    private TextView statusText;
    private Bitmap currentBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, float size, int color) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(color);
        return tv;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(30));
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Muwahid AI", 28, Color.rgb(20, 20, 20));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView subtitle = text("Генератор изображений • без встроенного дневного лимита", 14, Color.DKGRAY);
        subtitle.setPadding(0, dp(6), 0, dp(20));
        root.addView(subtitle);

        TextView endpointLabel = text("Адрес AI-сервера", 13, Color.DKGRAY);
        root.addView(endpointLabel);

        endpointInput = new EditText(this);
        endpointInput.setSingleLine(true);
        endpointInput.setText("https://YOUR-SERVER.example.com/generate");
        endpointInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        endpointInput.setSelectAllOnFocus(true);
        root.addView(endpointInput, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView promptLabel = text("Описание изображения", 13, Color.DKGRAY);
        promptLabel.setPadding(0, dp(16), 0, 0);
        root.addView(promptLabel);

        promptInput = new EditText(this);
        promptInput.setHint("Например: cinematic portrait, soft light, detailed...");
        promptInput.setMinLines(4);
        promptInput.setGravity(Gravity.TOP | Gravity.START);
        promptInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(promptInput, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        generateButton = new Button(this);
        generateButton.setText("СГЕНЕРИРОВАТЬ");
        LinearLayout.LayoutParams generateParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        generateParams.topMargin = dp(18);
        root.addView(generateButton, generateParams);

        progressBar = new ProgressBar(this);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(44), dp(44));
        progressParams.gravity = Gravity.CENTER_HORIZONTAL;
        progressParams.topMargin = dp(16);
        root.addView(progressBar, progressParams);

        statusText = text("Готово к работе", 13, Color.DKGRAY);
        statusText.setGravity(Gravity.CENTER_HORIZONTAL);
        statusText.setPadding(0, dp(10), 0, dp(10));
        root.addView(statusText);

        imageView = new ImageView(this);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setBackgroundColor(Color.rgb(245, 245, 245));
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(420));
        root.addView(imageView, imageParams);

        saveButton = new Button(this);
        saveButton.setText("СОХРАНИТЬ В ГАЛЕРЕЮ");
        saveButton.setEnabled(false);
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        saveParams.topMargin = dp(14);
        root.addView(saveButton, saveParams);

        TextView note = text(
                "Приложение само не ограничивает число генераций. Скорость и фактический объём зависят от вашего AI-сервера/GPU.",
                12,
                Color.GRAY);
        note.setPadding(0, dp(16), 0, 0);
        root.addView(note);

        generateButton.setOnClickListener(v -> generate());
        saveButton.setOnClickListener(v -> saveImage());

        setContentView(scroll);
    }

    private void setLoading(boolean loading, String message) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        generateButton.setEnabled(!loading);
        statusText.setText(message);
    }

    private void generate() {
        final String endpoint = endpointInput.getText().toString().trim();
        final String prompt = promptInput.getText().toString().trim();

        if (endpoint.isEmpty() || endpoint.contains("YOUR-SERVER")) {
            Toast.makeText(this, "Сначала укажи адрес AI-сервера.", Toast.LENGTH_LONG).show();
            return;
        }
        if (prompt.isEmpty()) {
            Toast.makeText(this, "Напиши описание изображения.", Toast.LENGTH_SHORT).show();
            return;
        }

        setLoading(true, "Генерация...");
        saveButton.setEnabled(false);

        executor.execute(() -> {
            try {
                JSONObject payload = new JSONObject();
                payload.put("prompt", prompt);
                payload.put("width", 768);
                payload.put("height", 1024);
                payload.put("steps", 4);
                payload.put("seed", System.currentTimeMillis() & 0x7fffffff);

                Bitmap bitmap = postForImage(endpoint, payload.toString());
                if (bitmap == null) throw new Exception("Сервер не вернул изображение.");

                runOnUiThread(() -> {
                    currentBitmap = bitmap;
                    imageView.setImageBitmap(bitmap);
                    saveButton.setEnabled(true);
                    setLoading(false, "Готово ✅");
                });
            } catch (Exception e) {
                final String message = e.getMessage() == null ? e.toString() : e.getMessage();
                runOnUiThread(() -> {
                    setLoading(false, "Ошибка");
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private Bitmap postForImage(String endpoint, String json) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(30_000);
        connection.setReadTimeout(180_000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        connection.setRequestProperty("Accept", "image/*, application/json");

        try (OutputStream out = connection.getOutputStream()) {
            out.write(json.getBytes(StandardCharsets.UTF_8));
        }

        int code = connection.getResponseCode();
        InputStream stream = code >= 200 && code < 300
                ? connection.getInputStream()
                : connection.getErrorStream();
        byte[] body = readAll(stream);
        String contentType = connection.getContentType();
        connection.disconnect();

        if (code < 200 || code >= 300) {
            String error = new String(body, StandardCharsets.UTF_8);
            throw new Exception("HTTP " + code + ": " + error);
        }

        if (contentType != null && contentType.toLowerCase(Locale.US).startsWith("image/")) {
            return BitmapFactory.decodeByteArray(body, 0, body.length);
        }

        String response = new String(body, StandardCharsets.UTF_8);
        JSONObject object = new JSONObject(response);

        String b64 = object.optString("image_base64", object.optString("base64", ""));
        if (!b64.isEmpty()) {
            int comma = b64.indexOf(',');
            if (comma >= 0) b64 = b64.substring(comma + 1);
            byte[] decoded = Base64.decode(b64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
        }

        String imageUrl = object.optString("image_url", object.optString("url", ""));
        if (!imageUrl.isEmpty()) return downloadBitmap(imageUrl);

        throw new Exception("Неизвестный формат ответа сервера.");
    }

    private Bitmap downloadBitmap(String imageUrl) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(imageUrl).openConnection();
        connection.setConnectTimeout(30_000);
        connection.setReadTimeout(120_000);
        connection.setRequestProperty("Accept", "image/*");
        if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 300) {
            throw new Exception("Не удалось скачать изображение.");
        }
        byte[] bytes = readAll(connection.getInputStream());
        connection.disconnect();
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
    }

    private byte[] readAll(InputStream input) throws Exception {
        if (input == null) return new byte[0];
        try (InputStream in = input; ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[8192];
            int read;
            while ((read = in.read(chunk)) != -1) buffer.write(chunk, 0, read);
            return buffer.toByteArray();
        }
    }

    private void saveImage() {
        if (currentBitmap == null) return;

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST);
            return;
        }

        executor.execute(() -> {
            try {
                String fileName = "MuwahidAI_" + System.currentTimeMillis() + ".png";
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MuwahidAI");
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("Не удалось создать файл.");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null || !currentBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                            throw new Exception("Не удалось сохранить изображение.");
                        }
                    }
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MuwahidAI");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("Не удалось создать папку.");
                    File file = new File(dir, fileName);
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        if (!currentBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                            throw new Exception("Не удалось сохранить изображение.");
                        }
                    }
                    sendBroadcast(new android.content.Intent(android.content.Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
                }

                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Сохранено в галерею ✅", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_REQUEST && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            saveImage();
        }
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
