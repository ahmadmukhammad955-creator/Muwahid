# Muwahid 0.13.7 — Messenger UI implementation

Version: 0.13.7 (versionCode 41)

Implemented in the Android source:
- Chat list with inline search, All / Private / Groups / Channels filters, unread counters and bottom navigation for Chats / Calls / Contacts / Settings.
- Conversation header with avatar, online status, audio call, video call and menu controls.
- Media messages for photos, documents, location, contacts, polls and voice notes.
- Attachment sheet: Gallery, Camera, Video, Document, Location, Contact, Audio, Poll, More.
- In-app camera screen for photo/video with preview, mode switch and camera flip.
- Location share screen with OpenStreetMap preview, selected point, resolved address and Send button.
- Document picker screen with PDF / Word / Excel / Other filters using Android Storage Access Framework.
- Voice note recording with explicit cancel control and playback speed 1x / 1.5x / 2x.
- Incoming call screen and active call screen with timer, microphone, camera, speaker, add, chat, more and end call.

The GitHub workflow is pinned to Muwahid_0.13.7_PROJECT.zip and verifies versionCode 41/versionName 0.13.7 before building.
