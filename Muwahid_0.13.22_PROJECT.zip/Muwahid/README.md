# Muwahid 0.13.22 — Supabase stickers + import bridge

Версия 0.13.16 исправляет перегруженный интерфейс 0.13.14. Иконки больше не огромные: используется единый тонкий outline-стиль, умеренные контейнеры и одинаковая визуальная толщина.


## 0.13.22 — реальные инструменты аудиокомнаты
- интерфейс комнаты переработан под компактную сцену 4×2 с 8 микрофонными местами и подсветкой активного голоса
- WebRTC остаётся настоящим: несколько спикеров слышат друг друга в реальном времени, слушатели могут поднять руку, модератор — поднять/опустить, удалить или заблокировать
- добавлен реальный Web Audio микшер: громкость микрофона, локальное прослушивание, 6 акустических эффектов, 6 EQ-пресетов и 6 вариантов тембра
- добавлена локальная музыка: выбор аудиофайла Android, воспроизведение, пауза, повтор и громкость; трек смешивается с исходящим аудио спикера
- добавлен встроенный soundboard (звонок, аплодисменты, барабан, уведомления и эффекты), который слышат участники
- добавлена запись смешанного звука комнаты через MediaRecorder с сохранением в Music/Muwahid на Android 10+
- добавлены инструменты комнаты: пользователи, комментарии, управление, стикеры, совместное чтение, темы оформления и статус WebRTC

## Что изменено

- Верхние кнопки камеры и создания чата: 42dp вместо 50dp.
- Нижняя навигация: иконки 32dp с внутренними отступами, общая высота 64dp.
- В чате кнопки назад/звонок/видео уменьшены до 40dp-контейнеров.
- Phone/video/camera/back/more отрисованы в более тонком rounded outline-стиле.
- Толщина основных line-icons уменьшена до 1.65 виртуальных px.
- Поле ввода: 50dp, панель композера 64dp, кнопка микрофона/отправки 48dp.
- Карточка чата и аватар уменьшены до более аккуратных размеров.
- Runtime smoke-test проверяет не только наличие иконок, но и допустимый диапазон размеров, чтобы снова не получить слишком мелкие или слишком крупные элементы.

## Версия

- versionName: `0.13.22`
- versionCode: `56`

## Сборка

Workflow `.github/workflows/build-apk.yml` собирает только `Muwahid_0.13.22_PROJECT.zip` и перед сборкой проверяет `versionName 0.13.22` / `versionCode 56`.


## 0.13.22 stickers and emoji bridge
- sticker packs, favorites, recents and custom emoji are read from Supabase through `mw_sticker_catalog`
- users can create a pack and import PNG/JPG/WebP/GIF/WebM/TGS files from Android storage
- Android Share (`Поделиться`) accepts compatible sticker files from other apps and saves them into an `Импортированные` pack
- remote stickers are copied into encrypted chat media before sending, so chat delivery remains E2EE
- received Supabase stickers can be saved to favorites; existing 12 built-in animated stickers remain as an offline fallback
- reaction emoji are loaded from the Supabase reaction catalog with the built-in emoji list as fallback

## 0.13.16 stage 1
- update APK downloads inside Muwahid with SHA-256 verification; browser/GitHub login is not part of the update flow
- incoming-call ringtone loops until answer/reject; users can select system sound, silence, or their own audio file
- voice-message recording has pause/resume, cancel, preview, re-record and send
- presence/last-seen backend migration and open-listener voice-room migration are included in `backend/023_presence_and_open_voice_rooms.sql`


## 0.13.18 stage 2
Profile status/background and expanded group/channel management UI. Run `backend/024_profile_status.sql` after the existing migrations to sync profile bio/status. Community settings are still local-only in this stage.


## 0.13.19 fix
- active call stays reachable from the main screen through a «Вернуться к звонку» banner
- ongoing Android call notification returns to the existing call screen
- voice rooms are visible on the main messenger screen again
- ordinary users enter voice rooms immediately as listeners; 8 microphone seats remain for speakers
- Supabase RPC `mw_active_call` and live presence/profile status backend were deployed
