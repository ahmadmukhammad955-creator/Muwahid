const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const html = fs.readFileSync('app/src/main/assets/voice_room.html','utf8');
const match = html.match(/window\.mwResult=([\s\S]*?)\nfunction banner\(/);
assert(match, 'RPC method declaration missing');
// Execute precisely the production RPC bridge functions in an isolated context.
const methods = 'window.mwResult=' + match[1];
let lastId;
const timers = new Map();let nextTimer = 1;
const context = {window:{}, pending:{}, Date, Math, JSON, Error,
  setTimeout:(cb)=>{const id=nextTimer++;timers.set(id,cb);return id;},
  clearTimeout:(id)=>timers.delete(id),
  MuwahidNative:{rpc:(id)=>{lastId=id;}}
};
vm.createContext(context);
vm.runInContext(methods+';globalThis.callRpc=rpc;',context);
(async()=>{
 const ok=context.callRpc('mw_room_state',{});
 assert.ok(lastId && timers.size===1);
 context.window.mwResult(lastId,'{"ok":true}',null);
 assert.equal((await ok).ok,true);
 assert.equal(timers.size,0);
 const fail=context.callRpc('mw_room_state',{});
 context.window.mwResult(lastId,null,'Нет связи');
 await assert.rejects(fail,/Нет связи/);
 assert.equal(timers.size,0);
 const timeout=context.callRpc('mw_room_state',{});
 const callback=timers.values().next().value;
 callback();
 await assert.rejects(timeout,/Сервер LIVE не отвечает/);
 assert.equal(Object.keys(context.pending).length,0);
 const after=context.callRpc('mw_room_state',{});
 context.window.mwResult(lastId,'null',null);
 assert.equal(await after,null);
 console.log('MW_LIVE_RPC_OK 0.13.28 rev2');
})().catch(e=>{console.error(e);process.exitCode=1;});
