
package com.muwahid.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG = Color.rgb(7,27,41), PANEL = Color.rgb(13,38,55),
              ACCENT = Color.rgb(20,217,165), CYAN = Color.rgb(32,201,232),
              WHITE = Color.WHITE, MUTED = Color.rgb(157,176,189);
    LinearLayout root, content;
    TextView title;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showWelcome();
    }

    TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(18,12,18,12);
        return t;
    }
    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(BG); b.setTextSize(15);
        b.setAllCaps(false); b.setBackgroundColor(ACCENT);
        return b;
    }
    void base(String screenTitle) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(8,8,8,4);
        TextView back = tv("‹", 34, WHITE); back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> showChats());
        bar.addView(back, new LinearLayout.LayoutParams(54,64));
        title = tv(screenTitle,22,WHITE); title.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(title, new LinearLayout.LayoutParams(0,64,1));
        root.addView(bar);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }
    void showWelcome() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER); root.setPadding(34,20,34,30); root.setBackgroundColor(BG);
        setContentView(root);
        TextView logo=tv("M",72,ACCENT); logo.setTypeface(Typeface.DEFAULT_BOLD); logo.setGravity(Gravity.CENTER);
        root.addView(logo,new LinearLayout.LayoutParams(-1,130));
        TextView name=tv("Muwahid",36,WHITE); name.setGravity(Gravity.CENTER); name.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(name);
        TextView sub=tv("Ближе друг к другу",18,MUTED); sub.setGravity(Gravity.CENTER);
        root.addView(sub);
        Space sp=new Space(this); root.addView(sp,new LinearLayout.LayoutParams(1,0,1));
        Button start=btn("Начать"); start.setOnClickListener(v->showChats());
        root.addView(start,new LinearLayout.LayoutParams(-1,58));
        TextView info=tv("Первая версия • локальный прототип",13,MUTED); info.setGravity(Gravity.CENTER);
        root.addView(info);
    }
    void showChats() {
        base("Muwahid");
        LinearLayout tabs=new LinearLayout(this);
        String[] ts={"Чаты","Группы","Каналы"};
        for(String s:ts){ TextView x=tv(s,15,s.equals("Чаты")?ACCENT:MUTED); x.setGravity(Gravity.CENTER);
            tabs.addView(x,new LinearLayout.LayoutParams(0,54,1)); }
        content.addView(tabs);
        String[][] chats={{"Альбек","Привет! Как дела?","09:32"},{"Семья","Хорошо, спасибо!","08:45"},{"Друзья ✈","Давай сегодня встретимся","08:20"},{"Путешествия","Новые фото с поездки","07:30"},{"Технологии","Новый телефон уже в продаже","Вчера"}};
        for(String[] c:chats){
            LinearLayout row=new LinearLayout(this); row.setPadding(10,8,10,8); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView avatar=tv(c[0].substring(0,1),22,WHITE); avatar.setGravity(Gravity.CENTER); avatar.setBackgroundColor(PANEL);
            row.addView(avatar,new LinearLayout.LayoutParams(58,58));
            LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
            TextView n=tv(c[0],17,WHITE); n.setTypeface(Typeface.DEFAULT_BOLD);
            TextView m=tv(c[1],14,MUTED); texts.addView(n); texts.addView(m);
            row.addView(texts,new LinearLayout.LayoutParams(0,76,1));
            TextView tm=tv(c[2],12,MUTED); row.addView(tm);
            row.setOnClickListener(v->showChat(c[0]));
            content.addView(row);
            View line=new View(this); line.setBackgroundColor(Color.rgb(25,55,70)); content.addView(line,new LinearLayout.LayoutParams(-1,1));
        }
        Button profile=btn("Профиль и настройки"); profile.setOnClickListener(v->showProfile()); content.addView(profile);
    }
    void showChat(String person) {
        base(person);
        TextView online=tv("● в сети",13,ACCENT); content.addView(online);
        bubble("Привет! Как дела?",false);
        bubble("Здравствуйте! Всё отлично, спасибо! А у тебя?",true);
        bubble("Тоже хорошо. Сейчас на работе, потом созвонимся.",false);
        Space sp=new Space(this); content.addView(sp,new LinearLayout.LayoutParams(1,0,1));
        EditText input=new EditText(this); input.setHint("Сообщение"); input.setHintTextColor(MUTED); input.setTextColor(WHITE);
        Button send=btn("Отправить"); send.setOnClickListener(v->{ if(input.getText().length()>0){ bubble(input.getText().toString(),true); input.setText(""); }});
        root.addView(input,new LinearLayout.LayoutParams(-1,56));
        root.addView(send,new LinearLayout.LayoutParams(-1,58));
    }
    void bubble(String s, boolean mine) {
        TextView b=tv(s,16,WHITE); b.setBackgroundColor(mine?Color.rgb(10,120,103):PANEL);
        b.setGravity(mine?Gravity.RIGHT:Gravity.LEFT); b.setPadding(18,14,18,14);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(10,8,10,8);
        content.addView(b,p);
    }
    void showProfile() {
        base("Профиль");
        TextView a=tv("М",54,ACCENT); a.setGravity(Gravity.CENTER); a.setTypeface(Typeface.DEFAULT_BOLD); content.addView(a,new LinearLayout.LayoutParams(-1,110));
        TextView n=tv("Пользователь Muwahid",22,WHITE); n.setGravity(Gravity.CENTER); content.addView(n);
        content.addView(tv("+49 • номер телефона",15,MUTED));
        content.addView(tv("Мой профиль",18,WHITE));
        content.addView(tv("Избранное",18,WHITE));
        content.addView(tv("Уведомления",18,WHITE));
        content.addView(tv("Конфиденциальность",18,WHITE));
        content.addView(tv("Безопасность",18,WHITE));
        Button logout=btn("Выйти"); logout.setOnClickListener(v->showWelcome()); content.addView(logout);
    }
}
