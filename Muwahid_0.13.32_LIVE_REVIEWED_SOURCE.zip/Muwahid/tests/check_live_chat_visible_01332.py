from pathlib import Path
s=Path('app/src/main/assets/voice_room.html').read_text(encoding='utf-8')
assert '<div class="section" id="chatSection">' in s
assert 'class="section auxiliary hidden" id="chatSection"' not in s
assert '#chatSection{position:fixed' in s
assert 'id="chatInput"' in s
assert 'onclick="sendChat()"' in s
assert 'mw_room_message_send' in s
assert 'mw_room_messages_get' in s
assert 'function toolComments(){closeTools();document.getElementById' in s
print('Live chat visibility contract OK')
