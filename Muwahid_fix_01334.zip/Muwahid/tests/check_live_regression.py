"""Static release-blocking checks for LIVE session recovery and exit paths."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/muwahid/app/MainActivity.java').read_text(encoding='utf-8')
voice = (root / 'app/src/main/java/com/muwahid/app/VoiceRoomActivity.java').read_text(encoding='utf-8')
html = (root / 'app/src/main/assets/voice_room.html').read_text(encoding='utf-8')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
workflow = (root / '.github/workflows/build-apk.yml').read_text(encoding='utf-8')
assert 'private boolean liveRoomLaunchPending;' in main
assert 'if(!liveRoomLaunchPending && api!=null&&api.signedIn()&&savedRoom!=null' in main
assert 'liveRoomLaunchPending=true;\n        handler.post(()->openVoiceRoom(room,' in main
assert 'if(api!=null && api.signedIn() && "welcome".equals(screen)){showChats();}' in main
assert 'prefs.edit().putBoolean("live_active",false).apply(); // one attempt' not in main
assert 'private void clearSavedLiveRoom()' in voice
assert 'if("mw_room_leave".equals(function)||"mw_room_end".equals(function)){' in voice
assert 'else {clearSavedLiveRoom();new AlertDialog.Builder(this)' in voice
assert 'catch(Exception e){clearSavedLiveRoom();new AlertDialog.Builder(this)' in voice
assert 'window.leaveRoom=async function' in html
leave=html[html.index('window.leaveRoom=async function'):]
assert leave.index('t.stop();') < leave.index("rpc('mw_room_leave'")
assert '3500' in leave and 'setTimeout' in leave
assert "reject(new Error('Сервер LIVE не отвечает." in html
assert 'android:scheme="muwahid" android:host="live"' in manifest
assert "PROJECT_ZIP: Muwahid_0.13.34_LIVE_CHAT_AND_LOBBY_FIX.zip" in workflow
assert "EXPECTED_VERSION_CODE: '69'" in workflow
assert "inputs.publish == true" in workflow
assert 'github.event_name == \'workflow_dispatch\'' in workflow
print('MW_LIVE_CONTRACT_OK 0.13.34 regression')
