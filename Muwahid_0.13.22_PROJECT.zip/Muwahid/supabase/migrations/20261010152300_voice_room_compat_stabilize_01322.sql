create or replace function public.mw_room_join(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  s integer;
  room_title text;
  my_rank integer;
  current_seat integer;
  current_allowed boolean;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  perform mw_private.room_cleanup(p_room);

  select title into room_title
  from public.mw_voice_rooms
  where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта или не существует'; end if;

  if exists(select 1 from public.mw_voice_room_bans where room_id=p_room and user_id=auth.uid()) then
    raise exception 'MW:Вы заблокированы в этой комнате';
  end if;

  my_rank:=mw_private.room_rank(auth.uid(),p_room);

  select seat,mic_allowed into current_seat,current_allowed
  from public.mw_voice_room_members
  where room_id=p_room and user_id=auth.uid();

  if found then
    if my_rank>=20 and current_seat is null then
      select g into s
      from generate_series(1,8) g
      where not exists(
        select 1 from public.mw_voice_room_members m
        where m.room_id=p_room and m.seat=g
      )
      order by g
      limit 1;
      if s is not null then
        update public.mw_voice_room_members
           set seat=s,
               mic_allowed=true,
               mic_enabled=false,
               mic_updated_at=now(),
               last_seen=now()
         where room_id=p_room and user_id=auth.uid();
        current_seat:=s;
        current_allowed:=true;
      else
        update public.mw_voice_room_members set last_seen=now()
         where room_id=p_room and user_id=auth.uid();
      end if;
    else
      update public.mw_voice_room_members set last_seen=now()
       where room_id=p_room and user_id=auth.uid();
    end if;

    delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
    return jsonb_build_object(
      'room_id',p_room,
      'title',room_title,
      'status',case when current_seat is not null then 'speaker' else 'listener' end,
      'seat',current_seat,
      'mic_allowed',coalesce(current_allowed,false)
    );
  end if;

  if my_rank>=20 then
    select g into s
    from generate_series(1,8) g
    where not exists(
      select 1 from public.mw_voice_room_members m
      where m.room_id=p_room and m.seat=g
    )
    order by g
    limit 1;
  end if;

  delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();

  insert into public.mw_voice_room_members(room_id,user_id,seat,mic_allowed,mic_enabled,last_seen,mic_updated_at)
  values(p_room,auth.uid(),s,(my_rank>=20 and s is not null),false,now(),now())
  on conflict(room_id,user_id) do update
    set seat=excluded.seat,
        last_seen=now(),
        mic_allowed=excluded.mic_allowed,
        mic_enabled=false,
        mic_updated_at=now();

  return jsonb_build_object(
    'room_id',p_room,
    'title',room_title,
    'status',case when s is null then 'listener' else 'speaker' end,
    'seat',s,
    'mic_allowed',(my_rank>=20 and s is not null)
  );
end
$$;

create or replace function public.mw_room_mic_moderate(p_room uuid,p_user uuid,p_allowed boolean)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  caller_rank integer;
  target_rank integer;
  new_seat integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;

  caller_rank:=mw_private.room_rank(auth.uid(),p_room);
  target_rank:=mw_private.room_rank(p_user,p_room);
  if caller_rank<20 then raise exception 'MW:Нет прав модератора'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_user) then
    raise exception 'MW:Участник уже вышел';
  end if;
  if caller_rank<=target_rank and auth.uid()<>p_user then
    raise exception 'MW:Нельзя управлять участником с равной или более высокой ролью';
  end if;

  if p_allowed then
    select seat into new_seat
    from public.mw_voice_room_members
    where room_id=p_room and user_id=p_user;

    if new_seat is null then
      select g into new_seat
      from generate_series(1,8) g
      where not exists(
        select 1 from public.mw_voice_room_members m
        where m.room_id=p_room and m.seat=g
      )
      order by g
      limit 1;
      if new_seat is null then raise exception 'MW:Все 8 мест заняты'; end if;
    end if;

    update public.mw_voice_room_members
       set seat=new_seat,
           mic_allowed=true,
           mic_enabled=false,
           mic_updated_at=now(),
           last_seen=now()
     where room_id=p_room and user_id=p_user;
    delete from public.mw_voice_room_hands where room_id=p_room and user_id=p_user;
  else
    update public.mw_voice_room_members
       set seat=null,
           mic_allowed=false,
           mic_enabled=false,
           mic_updated_at=now(),
           last_seen=now()
     where room_id=p_room and user_id=p_user;
  end if;

  return jsonb_build_object(
    'user_id',p_user,
    'mic_allowed',p_allowed,
    'seat',case when p_allowed then new_seat else null end
  );
end
$$;
