package com.muwahid.app;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

/** Local progress tone for the caller while a 1:1 call is ringing on the server.
 *  425 Hz, 1 s on / 4 s off, played through the call-volume audio route.
 *  Not sent to the remote party over WebRTC, and never used for incoming calls.
 */
public final class CallRingback {
    private static final String TAG="MW-CallRingback";
    private static final int RATE=16000;
    private static final int CYCLE_SECONDS=5;
    private static final int TONE_SAMPLES=RATE;
    private static final int CYCLE_SAMPLES=RATE*CYCLE_SECONDS;
    private AudioTrack track;
    private ToneGenerator fallback;
    private final Handler timer=new Handler(Looper.getMainLooper());
    private final Runnable timeout=this::stop;
    private boolean active;

    public synchronized void start(){
        if(active)return;
        stop();
        AudioTrack candidate=null;
        try{
            short[] samples=new short[CYCLE_SAMPLES];
            // Fade in/out over 12 ms to avoid audible clicks at cadence boundaries.
            final int fade=RATE*12/1000;
            for(int i=0;i<TONE_SAMPLES;i++){
                double envelope=Math.min(1.0,Math.min((double)i/fade,
                    (double)(TONE_SAMPLES-1-i)/fade));
                samples[i]=(short)Math.round(Math.sin(2.0*Math.PI*425.0*i/RATE)
                    *Short.MAX_VALUE*0.24*Math.max(0.0,envelope));
            }
            candidate=new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setTransferMode(AudioTrack.MODE_STATIC)
                .setBufferSizeInBytes(CYCLE_SAMPLES*2)
                .build();
            if(candidate.getState()!=AudioTrack.STATE_INITIALIZED
                ||candidate.write(samples,0,samples.length,AudioTrack.WRITE_BLOCKING)!=samples.length
                ||candidate.setLoopPoints(0,samples.length,-1)!=AudioTrack.SUCCESS){
                throw new IllegalStateException("Could not initialize repeating ringback tone");
            }
            candidate.play();
            track=candidate;
            active=true;
        }catch(Exception error){
            Log.w(TAG,"PCM ringback unavailable; trying system call progress tone",error);
            if(candidate!=null)try{candidate.release();}catch(Exception ignored){}
            try{
                fallback=new ToneGenerator(AudioManager.STREAM_VOICE_CALL,65);
                active=fallback.startTone(ToneGenerator.TONE_SUP_RINGTONE);
                if(!active){fallback.release();fallback=null;}
            }catch(Exception fallbackError){
                Log.w(TAG,"Device ringback fallback unavailable",fallbackError);
                if(fallback!=null)try{fallback.release();}catch(Exception ignored){}
                fallback=null;
            }
        }
        // Server marks unanswered calls missed at 90 seconds; this independent
        // guard stops audio even if Android suspends the WebView polling timer.
        if(active)timer.postDelayed(timeout,92000L);
    }

    public synchronized void stop(){
        timer.removeCallbacks(timeout);
        active=false;
        AudioTrack old=track;
        track=null;
        if(old!=null){
            try{old.pause();}catch(Exception ignored){}
            try{old.stop();}catch(Exception ignored){}
            try{old.release();}catch(Exception ignored){}
        }
        ToneGenerator tone=fallback;
        fallback=null;
        if(tone!=null){
            try{tone.stopTone();}catch(Exception ignored){}
            try{tone.release();}catch(Exception ignored){}
        }
    }
}
