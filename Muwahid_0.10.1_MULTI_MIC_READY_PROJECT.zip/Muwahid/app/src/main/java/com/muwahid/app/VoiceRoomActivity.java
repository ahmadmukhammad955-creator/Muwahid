package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import androidx.core.content.FileProvider;
import android.graphics.Color;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class VoiceRoomActivity extends Activity {
    private static final int REQ_MIC=7301, REQ_ROOM_IMAGE=7401, REQ_ROOM_VIDEO=7402;
    private WebView web;
    private Api api;
    private final ExecutorService worker=Executors.newFixedThreadPool(4);
    private String roomId,roomTitle;
    private volatile boolean joined;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#06111E"));
        getWindow().setNavigationBarColor(Color.parseColor("#06111E"));
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        api=new Api(new SecureStore(this));
        Intent i=getIntent();roomId=i.getStringExtra("room_id");roomTitle=i.getStringExtra("room_title");
        if(roomTitle==null||roomTitle.trim().isEmpty())roomTitle="Голосовая комната";
        if(!api.signedIn()||roomId==null||roomId.isEmpty()){finish();return;}
        if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)setup();
        else requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},REQ_MIC);
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r==REQ_MIC){
            if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)setup();
            else new AlertDialog.Builder(this).setMessage("Для голосовой комнаты нужен доступ к микрофону.").setPositiveButton("Закрыть",(d,w)->finish()).show();
        }
    }

    @SuppressWarnings("SetJavaScriptEnabled") private void setup(){
        if(web!=null)return;
        web=new WebView(this);web.setBackgroundColor(Color.parseColor("#06111E"));
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setDomStorageEnabled(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest r){runOnUiThread(()->{
            ArrayList<String> allow=new ArrayList<>();
            for(String x:r.getResources())if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x)&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)allow.add(x);
            if(allow.isEmpty())r.deny();else r.grant(allow.toArray(new String[0]));
        });}});
        web.addJavascriptInterface(new Bridge(),"MuwahidNative");setContentView(web);
        try{
            String html=readAsset("voice_room.html");
            String init="window.MW={roomId:"+JSONObject.quote(roomId)+",roomTitle:"+JSONObject.quote(roomTitle)+",selfId:"+JSONObject.quote(api.uid())+"};";
            html=html.replace("/*__MW_INIT__*/",init);
            web.loadDataWithBaseURL("https://muwahid.local/",html,"text/html","UTF-8",null);
        }catch(Exception e){new AlertDialog.Builder(this).setMessage("Не удалось открыть голосовую комнату.").setPositiveButton("Закрыть",(d,w)->finish()).show();}
    }

    private String readAsset(String name) throws Exception{
        StringBuilder b=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(getAssets().open(name),"UTF-8"))){String line;while((line=r.readLine())!=null)b.append(line).append('\n');}return b.toString();
    }

    private final class Bridge {
        private final Set<String> allowed=new HashSet<>(Arrays.asList(
            "mw_room_join","mw_room_leave","mw_room_state","mw_room_raise_hand","mw_room_mic_set_self","mw_room_mic_moderate",
            "mw_room_kick","mw_room_end","mw_room_signal_send","mw_room_signal_poll",
            "mw_room_moderator_set","mw_room_admit","mw_room_message_send","mw_room_messages_get"
        ));
        @JavascriptInterface public void rpc(String requestId,String function,String argsJson){
            if(!allowed.contains(function)){deliver(requestId,null,"Недоступная операция");return;}
            worker.execute(()->{try{
                Object result=api.rpc(function,new JSONObject(argsJson));
                if("mw_room_join".equals(function))joined=true;
                if("mw_room_leave".equals(function))joined=false;
                deliver(requestId,result==null?"null":result.toString(),null);
            }catch(Exception e){deliver(requestId,null,e.getMessage()==null?"Ошибка связи":e.getMessage());}});
        }

        @JavascriptInterface public void pickMedia(String kind){runOnUiThread(()->{
            try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
                if("image".equals(kind)){i.setType("image/*");startActivityForResult(i,REQ_ROOM_IMAGE);}
                else if("video".equals(kind)){i.setType("video/*");startActivityForResult(i,REQ_ROOM_VIDEO);}
            }catch(Exception e){toast("Не удалось открыть выбор файла");}
        });}
        @JavascriptInterface public void openMedia(String path,String mime,String name){
            worker.execute(()->{try{byte[] raw=api.downloadRoomMedia(path);File dir=new File(getCacheDir(),"room_media");dir.mkdirs();String safe=(name==null?"file":name).replaceAll("[^A-Za-zА-Яа-я0-9._ -]","_");File f=new File(dir,UUID.randomUUID()+"_"+safe);try(FileOutputStream out=new FileOutputStream(f)){out.write(raw);}Uri u=FileProvider.getUriForFile(VoiceRoomActivity.this,getPackageName()+".files",f);Intent open=new Intent(Intent.ACTION_VIEW);open.setDataAndType(u,mime==null?"application/octet-stream":mime);open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);runOnUiThread(()->{try{startActivity(open);}catch(Exception ex){toast("На телефоне нет приложения для открытия этого файла");}});}catch(Exception e){runOnUiThread(()->toast(e.getMessage()==null?"Не удалось открыть файл":e.getMessage()));}});
        }

        @JavascriptInterface public void close(){runOnUiThread(VoiceRoomActivity.this::finish);}
    }

    private void deliver(String requestId,String json,String error){runOnUiThread(()->{
        if(web==null)return;
        String js="window.mwResult("+JSONObject.quote(requestId)+","+(json==null?"null":JSONObject.quote(json))+","+(error==null?"null":JSONObject.quote(error))+");";
        web.evaluateJavascript(js,null);
    });}


    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if((requestCode!=REQ_ROOM_IMAGE&&requestCode!=REQ_ROOM_VIDEO)||resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        final Uri uri=data.getData();final String kind=requestCode==REQ_ROOM_IMAGE?"image":"video";
        worker.execute(()->{try{
            byte[] raw=readUri(uri,24*1024*1024);String mime=getContentResolver().getType(uri);if(mime==null)mime=kind.equals("image")?"image/jpeg":"video/mp4";
            String name=kind.equals("image")?"Фото":"Видео";String path=roomId+"/"+UUID.randomUUID()+".bin";api.uploadRoomMedia(path,raw);
            JSONObject media=new JSONObject().put("path",path).put("mime",mime).put("name",name).put("size",raw.length);
            api.rpc("mw_room_message_send",new JSONObject().put("p_room",roomId).put("p_kind",kind).put("p_body","").put("p_media",media));
            runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.mwRoomMediaSent&&window.mwRoomMediaSent();",null);});
        }catch(Exception e){runOnUiThread(()->toast(e.getMessage()==null?"Не удалось отправить файл":e.getMessage()));}});
    }

    private byte[] readUri(Uri uri,int max) throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new Exception("Не удалось открыть файл");byte[] b=new byte[16384];int n,total=0;while((n=in.read(b))!=-1){total+=n;if(total>max)throw new Exception("Максимальный размер файла — 24 МБ");out.write(b,0,n);}}return out.toByteArray();}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("window.leaveRoom && window.leaveRoom();",null);else super.onBackPressed();}

    @Override public void onDestroy(){
        if(joined){try{worker.submit(()->{try{api.rpc("mw_room_leave",new JSONObject().put("p_room",roomId));}catch(Exception ignored){}}).get(1200,TimeUnit.MILLISECONDS);}catch(Exception ignored){}}
        if(web!=null){web.loadUrl("about:blank");web.destroy();web=null;}
        worker.shutdownNow();super.onDestroy();
    }
}
