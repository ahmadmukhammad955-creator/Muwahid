# Muwahid 0.13.32 — LIVE creation and rooms

Current application build: **0.13.32** (`versionCode 67`). This repository is the Android source project, **not** an already compiled APK.

## Approved LIVE behavior

1. Press **LIVE**: stage 1 offers **Аудиокомната** (4–12 seats) or **Видеоэфир** (4–9 seats), with an explicit seat-count selection. No room is created until confirmation.
2. Press **Далее**: stage 2 lets the creator review seats, set a title and choose **Открытый** / **Закрытый**.
3. Press **Создать эфир** (with mic/camera icon): only then call server RPC `mw_live_room_create`. The selected seat count is enforced by migration `backend/032_live_two_stage_capacity.sql`.
4. Each chosen seat is displayed inside the running room; participants can share invitations within Muwahid and via the standard Android sharing interface.
5. The room owner can end the session for everyone via `mw_room_end`. The backend rejects subsequent `mw_room_join` for an inactive room.
6. The owner can upload a photo or a 15–60-second silent looping video as a room background, subject to the previous private storage rules. Server migration `backend/031_live_background_restore.sql` is required for full history-independent background restoration.

## Deployment dependencies

* Apply server migrations `backend/031_live_background_restore.sql` and `backend/032_live_two_stage_capacity.sql` to the Muwahid Supabase project **before** testing the new seat counts on real users.
* Build with `.github/workflows/build-apk.yml` and stable release signing secrets. Never treat the ZIP as an APK.
* Verify installation, entry with two devices, both modes, audio/video transmission, invitations, background syncing, and invalidity of closed-room links before publishing `updates/latest.json`.
* The historical version labels preserved in numbered backend migration paths are immutable migration identifiers, **not** the Android release version.


## v0.13.33 — background calls / FCM

Android app includes optional Firebase Cloud Messaging receiver and secured Supabase device registration; legacy polling remains as fallback. **FCM is not enabled by simply building the APK**: follow `CALL_PUSH_SETUP_01333.md` to configure Firebase, Edge Function secrets and webhook. LIVE background RPC was restored in the server on 2026-11-08. Keep unchanged release signing certificate for upgrades.
