Muwahid 0.13.24 fixed build package.
Fix: VoiceRoomActivity now imports android.media.AudioManager, resolving compileDebugJavaWithJavac errors.
Use .github/workflows/build-apk.yml as the repository workflow and keep this bundle at repository root if using the BUNDLE_ZIP workflow.
