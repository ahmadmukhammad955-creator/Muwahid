# Muwahid 0.8.6

Android prototype of the Muwahid messenger.

## Current 0.8.6 features

## 0.8.6 concept UI implementation

- Welcome screen rebuilt around the Muwahid logo, dark mountain hero and the slogan «Ближе друг к другу».
- Home screen now follows the concept: header menu, Chats / Groups / Channels tabs, search, chat folders and four-item bottom navigation.
- Chat header now includes avatar, online state, call and more actions.
- Composer follows the concept layout with emoji, attachment, video-message and microphone/send controls.
- New Muwahid menu mirrors the reference: profile, Favorites, recent calls, invite, settings, channels, groups and dark theme.
- Calls and Contacts sections are present in the bottom navigation.
- Groups and Channels have complete navigation/UI shells; their multi-user server data model is still intentionally not faked and remains backend work.


- Encrypted photo, video and audio/file attachments in direct chats.
  - media bytes are AES-GCM encrypted on the sender device before upload;
  - the private Supabase Storage bucket stores only encrypted bytes;
  - attachment metadata is carried inside the existing E2EE text envelope;
  - the recipient downloads and decrypts the file locally before opening it.
- Audio and video calls using WebRTC in Android WebView.
  - Supabase is used only for offer/answer/ICE signalling;
  - media transport uses WebRTC DTLS-SRTP;
  - Google STUN is configured for the prototype; a TURN server is still needed for reliable connectivity on all NAT/mobile networks.
- Background notifications for:
  - new direct messages;
  - incoming audio calls;
  - incoming video calls.
- A foreground notification service polls the protected RPC endpoint every 5 seconds while the user is signed in. This avoids adding Firebase credentials to this prototype, but production should move to true push notifications (FCM/APNs equivalent) to reduce battery/network usage.


## 0.8.2 owner-access hardening

- Ordinary signed-in users no longer see any owner-access wording in the profile UI.
- The owner dashboard remains server-gated by the single owner UUID and MFA.
- Owner statistics now include the number of open complaints.
- The owner mapping table and internal RLS helper are not executable/readable by public client roles.

## Existing security

- Email/password auth through Supabase Auth.
- TOTP second factor and MFA-gated messaging/owner functions.
- E2EE v1 for new direct text messages using P-256 ECDH + HKDF-SHA256 + AES-256-GCM.
- Device private key is encrypted at rest with an Android Keystore AES-GCM wrapping key.
- Legacy plaintext messages remain readable, while plaintext downgrade is blocked for new E2EE chats.

## Required server migrations

For a fresh backend, apply the existing migrations in order:

`001_messenger.sql` → `002_verify.sql` → `003_owner.sql` → `004_enforce_mfa.sql` → `005_verify_owner.sql` → `006_verify_mfa.sql` → `007_e2ee.sql` → `008_media_calls_notifications.sql` → `009_phone_auth.sql` → `010_owner_access_lockdown.sql` → **`011_complaints.sql`**

The 0.6 migration creates the private media bucket policies, call signalling table/RPCs and the notification polling RPC.

## Current limitations

- Direct chats only; groups/channels/bots are still separate work.
- E2EE v1 is not yet a Signal Double Ratchet and does not provide full forward secrecy or multi-device key sync.
- WebRTC calls currently use STUN only. Some carrier/enterprise NATs require TURN, so calls may fail until a TURN service is configured.
- Background notifications use a foreground polling service, not Firebase Cloud Messaging. Android may still stop background work under aggressive battery-management settings.
- Media files are capped at 24 MiB in the client; encrypted uploads remain below the 25 MiB private-bucket limit.

## Build

The GitHub workflow extracts the project ZIP and builds the debug APK with Gradle / Android SDK 35.

## Muwahid 0.7 server activation
After migrations 001..007, run `backend/000_RUN_AFTER_007_FULL_0.7.sql` in the Supabase SQL editor.
Then enable **Authentication -> Providers -> Phone** and configure an SMS provider in Supabase. Without this provider, phone OTP cannot send SMS. The SQL migration creates the media bucket, call signalling RPCs, notification polling RPC, and exact phone-number profile lookup.

## 0.8.6 chat composer
- Emoji picker in personal chats.
- Microphone action when the text field is empty; tap to start and tap the stop button to send an encrypted AAC/M4A voice message. Long-press stop cancels the recording.
- Video-message camera button with runtime camera + microphone permissions and a 60 second capture limit.
- Voice/video-message metadata is encrypted with the existing E2EE layer; media bytes are encrypted before upload to the private `mw-media` bucket.
