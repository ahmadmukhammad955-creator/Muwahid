-- Restrict story metadata, viewing, and original media consistently.
alter table public.mfresh_profiles add column if not exists story_visibility text not null default 'public' check (story_visibility in ('public','private'));
alter table public.mfresh_stories add column if not exists visibility text not null default 'public' check (visibility in ('public','private'));
drop policy if exists "mfresh stories visible or owner" on public.mfresh_stories;
create policy "mfresh stories visible or owner" on public.mfresh_stories for select to authenticated
 using(user_id=(select auth.uid()) or (visibility='public' and (expires_at>now() or pinned)));
drop policy if exists "mfresh story views signed-in insert" on public.mfresh_story_views;
create policy "mfresh story views signed-in insert" on public.mfresh_story_views for insert to authenticated
 with check(viewer_id=(select auth.uid()) and exists(select 1 from public.mfresh_stories s
 where s.id=story_id and (s.user_id=(select auth.uid()) or (s.visibility='public' and (s.expires_at>now() or s.pinned)))));
drop policy if exists "mfresh story read by owner or active audience" on storage.objects;
create policy "mfresh story read by owner or active audience" on storage.objects for select to authenticated
 using(bucket_id='mfresh-stories' and (name like ((select auth.uid())::text || '/stories/%')
 or exists(select 1 from public.mfresh_stories s where s.object_path=name and s.visibility='public' and (s.expires_at>now() or s.pinned))));
