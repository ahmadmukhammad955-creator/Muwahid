from pathlib import Path
import re
base=Path(__file__).resolve().parents[1]
app=base/'app/src/main'
code=(app/'java/com/muwahid/app/UpdateManager.java').read_text()
job=(app/'java/com/muwahid/app/UpdateCheckJobService.java').read_text()
main=(app/'java/com/muwahid/app/MainActivity.java').read_text()
lock=(app/'java/com/muwahid/app/AppLock.java').read_text()
manifest=(app/'AndroidManifest.xml').read_text()
assert 'setPeriodic(PERIOD_MS)' in job and '15L*60L*1000L' in job
assert '.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)' in job
assert '.setPersisted(true)' in job
assert 'UpdateManager.checkAndNotify(this,false,' in job and 'jobFinished(params,false)' in job
assert 'UpdateCheckJobService.ensureScheduled(this)' in lock
assert 'UpdateManager.checkOnLaunch(this)' in main and 'UpdateManager.checkInForeground(this)' in main
assert 'POST_NOTIFICATIONS' in main and 'update_permission_prompted' in main
assert 'android.permission.RECEIVE_BOOT_COMPLETED' in manifest
assert 'android.permission.BIND_JOB_SERVICE' in manifest
assert '"notify_updates",true' in code
assert 'notifyIfNeeded(app,p,release)' in code
assert 'r.sha256.matches("[0-9a-f]{64}")' in code
assert 'https://github.com/ahmadmukhammad955-creator/Muwahid/releases/download/' in code
assert "versionCode 70" in (base/'app/build.gradle').read_text()
assert "versionName '0.13.35'" in (base/'app/build.gradle').read_text()
print('MW_UPDATE_ALERTS_SOURCE_OK')
