-- Muwahid 0.7: phone identity and exact phone-number discovery.
-- Requires Supabase Auth -> Phone enabled with an SMS provider.
begin;

alter table public.mw_profiles add column if not exists phone_e164 text;
create unique index if not exists mw_profiles_phone_e164_uidx
  on public.mw_profiles(phone_e164) where phone_e164 is not null;

do $$
begin
 if not exists (
  select 1 from pg_constraint
  where conname='mw_profiles_phone_e164_check'
    and conrelid='public.mw_profiles'::regclass
 ) then
  alter table public.mw_profiles
   add constraint mw_profiles_phone_e164_check
   check (phone_e164 is null or phone_e164 ~ '^\+[1-9][0-9]{7,14}$');
 end if;
end $$;

-- Keep phone identity on new users while preserving the existing generated username.
create or replace function public.mw_create_profile() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 insert into public.mw_profiles(id,username,display_name,phone_e164)
 values(
  new.id,
  'u_' || replace(new.id::text,'-',''),
  left(coalesce(nullif(btrim(new.raw_user_meta_data->>'display_name'),''),'Пользователь'),60),
  case when coalesce(new.phone,'') ~ '^\+[1-9][0-9]{7,14}$' then new.phone else null end
 );
 return new;
end $$;

-- Backfill phone numbers for accounts that existed before this migration.
update public.mw_profiles p
set phone_e164=u.phone
from auth.users u
where p.id=u.id
  and p.phone_e164 is null
  and coalesce(u.phone,'') ~ '^\+[1-9][0-9]{7,14}$';

create or replace function public.mw_sync_my_phone() returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_phone text;
begin
 perform mw_private.require_mfa();
 select phone into v_phone from auth.users where id=auth.uid();
 if coalesce(v_phone,'') !~ '^\+[1-9][0-9]{7,14}$' then
  raise exception 'MW:Номер телефона не подтверждён';
 end if;
 update public.mw_profiles set phone_e164=v_phone where id=auth.uid();
 return public.mw_me();
end $$;

-- Exact lookup only. The returned object deliberately does not expose the peer phone number.
create or replace function public.mw_find_person_any(p_query text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare q text; normalized_phone text; result jsonb;
begin
 perform mw_private.require_mfa();
 q:=btrim(coalesce(p_query,''));
 if char_length(q) < 4 or char_length(q) > 40 then
  raise exception 'MW:Введите номер телефона или имя пользователя';
 end if;
 normalized_phone:=regexp_replace(q,'[[:space:]()\-]','','g');
 if normalized_phone ~ '^\+[1-9][0-9]{7,14}$' then
  select jsonb_build_object('id',p.id,'display_name',p.display_name,'username',p.username)
   into result
  from public.mw_profiles p
  where p.phone_e164=normalized_phone and p.id<>auth.uid();
 else
  q:=lower(regexp_replace(q,'^@','',''));
  select jsonb_build_object('id',p.id,'display_name',p.display_name,'username',p.username)
   into result
  from public.mw_profiles p
  where p.username=q and p.id<>auth.uid();
 end if;
 return result;
end $$;

revoke all on function public.mw_sync_my_phone(), public.mw_find_person_any(text)
 from public,anon,authenticated;
grant execute on function public.mw_sync_my_phone(), public.mw_find_person_any(text)
 to authenticated;

commit;
