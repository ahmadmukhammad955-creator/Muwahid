# Muwahid 0.13.14 deep check

Key fix: `UiIconDrawable` has a 24 px intrinsic size. `ImageView.ScaleType.CENTER_INSIDE` never upscaled it, so increasing a 42dp/50dp button did not make the icon itself larger on high-density phones. Main UI icon helpers now use `FIT_CENTER`, which scales the drawable into the available padded area.

Additional fixes:
- composer field height raised to 56dp so 54dp emoji/attachment/camera controls are not clipped;
- compose bar raised to 72dp and send/mic action to 54dp;
- direct icon views in camera, document, and location screens also use FIT_CENTER;
- Android instrumentation checks runtime icon width + scale type and composer clipping.

Version: 0.13.14, versionCode 48.
