-- Muwahid 0.13.20
-- Supabase-backed stickers, sticker packs, favorites, recents, custom emoji and reactions.

create table if not exists public.mw_sticker_assets (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null unique,
  original_name text not null default '',
  mime_type text not null,
  file_size_bytes bigint not null default 0 check (file_size_bytes between 0 and 10485760),
  width integer null check (width is null or width > 0),
  height integer null check (height is null or height > 0),
  animated boolean not null default false,
  source_kind text not null default 'user_upload' check (source_kind in ('user_upload','shared_app','imported_file','web_download','received_message')),
  source_ref text not null default '',
  sha256 text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.mw_sticker_packs (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 64),
  description text not null default '' check (char_length(description) <= 256),
  is_public boolean not null default false,
  cover_asset_id uuid null references public.mw_sticker_assets(id) on delete set null,
  source_kind text not null default 'user_created' check (source_kind in ('user_created','imported','shared','official')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.mw_sticker_pack_items (
  pack_id uuid not null references public.mw_sticker_packs(id) on delete cascade,
  sticker_id uuid not null references public.mw_sticker_assets(id) on delete cascade,
  added_by uuid not null references auth.users(id) on delete cascade,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  primary key (pack_id, sticker_id)
);

create table if not exists public.mw_sticker_favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  sticker_id uuid not null references public.mw_sticker_assets(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, sticker_id)
);

create table if not exists public.mw_sticker_recents (
  user_id uuid not null references auth.users(id) on delete cascade,
  sticker_id uuid not null references public.mw_sticker_assets(id) on delete cascade,
  use_count integer not null default 1 check (use_count > 0),
  last_used_at timestamptz not null default now(),
  primary key (user_id, sticker_id)
);

create table if not exists public.mw_custom_emoji (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  sticker_id uuid not null references public.mw_sticker_assets(id) on delete cascade,
  shortcode text not null check (char_length(shortcode) between 1 and 32),
  is_public boolean not null default false,
  created_at timestamptz not null default now(),
  unique (owner_id, shortcode)
);

create table if not exists public.mw_reaction_catalog (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  label text not null default '',
  unicode_value text null,
  sticker_id uuid null references public.mw_sticker_assets(id) on delete set null,
  enabled boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  check (unicode_value is not null or sticker_id is not null)
);

alter table public.mw_sticker_assets enable row level security;
alter table public.mw_sticker_packs enable row level security;
alter table public.mw_sticker_pack_items enable row level security;
alter table public.mw_sticker_favorites enable row level security;
alter table public.mw_sticker_recents enable row level security;
alter table public.mw_custom_emoji enable row level security;
alter table public.mw_reaction_catalog enable row level security;

drop policy if exists mw_sticker_assets_read on public.mw_sticker_assets;
create policy mw_sticker_assets_read on public.mw_sticker_assets for select to authenticated using (true);
drop policy if exists mw_sticker_assets_insert_own on public.mw_sticker_assets;
create policy mw_sticker_assets_insert_own on public.mw_sticker_assets for insert to authenticated with check (owner_id=auth.uid());
drop policy if exists mw_sticker_assets_update_own on public.mw_sticker_assets;
create policy mw_sticker_assets_update_own on public.mw_sticker_assets for update to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());
drop policy if exists mw_sticker_assets_delete_own on public.mw_sticker_assets;
create policy mw_sticker_assets_delete_own on public.mw_sticker_assets for delete to authenticated using (owner_id=auth.uid());

drop policy if exists mw_sticker_packs_read on public.mw_sticker_packs;
create policy mw_sticker_packs_read on public.mw_sticker_packs for select to authenticated using (is_public or owner_id=auth.uid());
drop policy if exists mw_sticker_packs_insert_own on public.mw_sticker_packs;
create policy mw_sticker_packs_insert_own on public.mw_sticker_packs for insert to authenticated with check (owner_id=auth.uid());
drop policy if exists mw_sticker_packs_update_own on public.mw_sticker_packs;
create policy mw_sticker_packs_update_own on public.mw_sticker_packs for update to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());
drop policy if exists mw_sticker_packs_delete_own on public.mw_sticker_packs;
create policy mw_sticker_packs_delete_own on public.mw_sticker_packs for delete to authenticated using (owner_id=auth.uid());

drop policy if exists mw_sticker_pack_items_read on public.mw_sticker_pack_items;
create policy mw_sticker_pack_items_read on public.mw_sticker_pack_items for select to authenticated using (
  exists(select 1 from public.mw_sticker_packs p where p.id=pack_id and (p.is_public or p.owner_id=auth.uid()))
);
drop policy if exists mw_sticker_pack_items_insert on public.mw_sticker_pack_items;
create policy mw_sticker_pack_items_insert on public.mw_sticker_pack_items for insert to authenticated with check (
  added_by=auth.uid() and exists(select 1 from public.mw_sticker_packs p where p.id=pack_id and p.owner_id=auth.uid())
);
drop policy if exists mw_sticker_pack_items_delete on public.mw_sticker_pack_items;
create policy mw_sticker_pack_items_delete on public.mw_sticker_pack_items for delete to authenticated using (
  exists(select 1 from public.mw_sticker_packs p where p.id=pack_id and p.owner_id=auth.uid())
);

drop policy if exists mw_sticker_favorites_self on public.mw_sticker_favorites;
create policy mw_sticker_favorites_self on public.mw_sticker_favorites for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
drop policy if exists mw_sticker_recents_self on public.mw_sticker_recents;
create policy mw_sticker_recents_self on public.mw_sticker_recents for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

drop policy if exists mw_custom_emoji_read on public.mw_custom_emoji;
create policy mw_custom_emoji_read on public.mw_custom_emoji for select to authenticated using (is_public or owner_id=auth.uid());
drop policy if exists mw_custom_emoji_insert_own on public.mw_custom_emoji;
create policy mw_custom_emoji_insert_own on public.mw_custom_emoji for insert to authenticated with check (owner_id=auth.uid());
drop policy if exists mw_custom_emoji_update_own on public.mw_custom_emoji;
create policy mw_custom_emoji_update_own on public.mw_custom_emoji for update to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());
drop policy if exists mw_custom_emoji_delete_own on public.mw_custom_emoji;
create policy mw_custom_emoji_delete_own on public.mw_custom_emoji for delete to authenticated using (owner_id=auth.uid());

drop policy if exists mw_reaction_catalog_read on public.mw_reaction_catalog;
create policy mw_reaction_catalog_read on public.mw_reaction_catalog for select to authenticated using (enabled=true);

insert into storage.buckets(id,name,public,file_size_limit)
values('mw-stickers','mw-stickers',false,10485760)
on conflict(id) do update set file_size_limit=excluded.file_size_limit;

drop policy if exists mw_stickers_storage_read on storage.objects;
create policy mw_stickers_storage_read on storage.objects for select to authenticated using (bucket_id='mw-stickers');
drop policy if exists mw_stickers_storage_insert_own on storage.objects;
create policy mw_stickers_storage_insert_own on storage.objects for insert to authenticated with check (bucket_id='mw-stickers' and split_part(name,'/',1)=auth.uid()::text);
drop policy if exists mw_stickers_storage_update_own on storage.objects;
create policy mw_stickers_storage_update_own on storage.objects for update to authenticated using (bucket_id='mw-stickers' and split_part(name,'/',1)=auth.uid()::text) with check (bucket_id='mw-stickers' and split_part(name,'/',1)=auth.uid()::text);
drop policy if exists mw_stickers_storage_delete_own on storage.objects;
create policy mw_stickers_storage_delete_own on storage.objects for delete to authenticated using (bucket_id='mw-stickers' and split_part(name,'/',1)=auth.uid()::text);

create or replace function public.mw_sticker_create_pack(p_title text,p_description text default '',p_is_public boolean default false)
returns uuid language plpgsql set search_path to 'public' as $$
declare v_uid uuid:=auth.uid(); v_id uuid;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if trim(coalesce(p_title,''))='' then raise exception 'invalid_title'; end if;
  insert into public.mw_sticker_packs(owner_id,title,description,is_public)
  values(v_uid,trim(p_title),coalesce(p_description,''),coalesce(p_is_public,false)) returning id into v_id;
  return v_id;
end;$$;

create or replace function public.mw_sticker_register_asset(
  p_storage_path text,p_original_name text,p_mime_type text,p_file_size_bytes bigint,
  p_width integer default null,p_height integer default null,p_animated boolean default false,
  p_source_kind text default 'user_upload',p_source_ref text default '',p_sha256 text default '')
returns uuid language plpgsql set search_path to 'public' as $$
declare v_uid uuid:=auth.uid(); v_id uuid;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if split_part(p_storage_path,'/',1)<>v_uid::text then raise exception 'invalid_storage_owner'; end if;
  insert into public.mw_sticker_assets(owner_id,storage_path,original_name,mime_type,file_size_bytes,width,height,animated,source_kind,source_ref,sha256)
  values(v_uid,p_storage_path,coalesce(p_original_name,''),p_mime_type,coalesce(p_file_size_bytes,0),p_width,p_height,coalesce(p_animated,false),coalesce(p_source_kind,'user_upload'),coalesce(p_source_ref,''),coalesce(p_sha256,''))
  returning id into v_id;
  return v_id;
end;$$;

create or replace function public.mw_sticker_add_to_pack(p_pack uuid,p_sticker uuid,p_sort_order integer default 0)
returns boolean language plpgsql set search_path to 'public' as $$
declare v_uid uuid:=auth.uid();
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if not exists(select 1 from public.mw_sticker_packs where id=p_pack and owner_id=v_uid) then raise exception 'pack_not_owned'; end if;
  if not exists(select 1 from public.mw_sticker_assets where id=p_sticker) then raise exception 'sticker_not_found'; end if;
  insert into public.mw_sticker_pack_items(pack_id,sticker_id,added_by,sort_order)
  values(p_pack,p_sticker,v_uid,coalesce(p_sort_order,0))
  on conflict(pack_id,sticker_id) do update set sort_order=excluded.sort_order;
  return true;
end;$$;

create or replace function public.mw_sticker_set_favorite(p_sticker uuid,p_favorite boolean default true)
returns boolean language plpgsql set search_path to 'public' as $$
declare v_uid uuid:=auth.uid();
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if coalesce(p_favorite,true) then
    insert into public.mw_sticker_favorites(user_id,sticker_id) values(v_uid,p_sticker) on conflict(user_id,sticker_id) do nothing;
  else
    delete from public.mw_sticker_favorites where user_id=v_uid and sticker_id=p_sticker;
  end if;
  return true;
end;$$;

create or replace function public.mw_sticker_mark_recent(p_sticker uuid)
returns boolean language plpgsql set search_path to 'public' as $$
declare v_uid uuid:=auth.uid();
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  insert into public.mw_sticker_recents(user_id,sticker_id,use_count,last_used_at) values(v_uid,p_sticker,1,now())
  on conflict(user_id,sticker_id) do update set use_count=public.mw_sticker_recents.use_count+1,last_used_at=now();
  return true;
end;$$;

create or replace function public.mw_custom_emoji_create(p_sticker uuid,p_shortcode text,p_is_public boolean default false)
returns uuid language plpgsql set search_path to 'public' as $$
declare v_uid uuid:=auth.uid(); v_id uuid; v_code text:=trim(both ':' from trim(coalesce(p_shortcode,'')));
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if v_code='' then raise exception 'invalid_shortcode'; end if;
  if not exists(select 1 from public.mw_sticker_assets where id=p_sticker) then raise exception 'sticker_not_found'; end if;
  insert into public.mw_custom_emoji(owner_id,sticker_id,shortcode,is_public)
  values(v_uid,p_sticker,v_code,coalesce(p_is_public,false))
  on conflict(owner_id,shortcode) do update set sticker_id=excluded.sticker_id,is_public=excluded.is_public
  returning id into v_id;
  return v_id;
end;$$;

create or replace function public.mw_sticker_catalog()
returns jsonb language sql set search_path to 'public' as $$
  select jsonb_build_object(
    'packs',coalesce((select jsonb_agg(jsonb_build_object(
      'id',p.id,'owner_id',p.owner_id,'title',p.title,'description',p.description,'is_public',p.is_public,
      'cover_asset_id',p.cover_asset_id,'updated_at',p.updated_at,
      'items',coalesce((select jsonb_agg(jsonb_build_object(
        'id',a.id,'storage_path',a.storage_path,'original_name',a.original_name,'mime_type',a.mime_type,
        'file_size_bytes',a.file_size_bytes,'width',a.width,'height',a.height,'animated',a.animated,'source_kind',a.source_kind,'sort_order',i.sort_order
      ) order by i.sort_order,i.created_at) from public.mw_sticker_pack_items i join public.mw_sticker_assets a on a.id=i.sticker_id where i.pack_id=p.id),'[]'::jsonb)
    ) order by p.updated_at desc) from public.mw_sticker_packs p where p.is_public or p.owner_id=auth.uid()),'[]'::jsonb),
    'favorite_items',coalesce((select jsonb_agg(jsonb_build_object(
      'id',a.id,'storage_path',a.storage_path,'original_name',a.original_name,'mime_type',a.mime_type,
      'file_size_bytes',a.file_size_bytes,'width',a.width,'height',a.height,'animated',a.animated,'source_kind',a.source_kind
    ) order by f.created_at desc) from public.mw_sticker_favorites f join public.mw_sticker_assets a on a.id=f.sticker_id where f.user_id=auth.uid()),'[]'::jsonb),
    'recent_items',coalesce((select jsonb_agg(jsonb_build_object(
      'id',a.id,'storage_path',a.storage_path,'original_name',a.original_name,'mime_type',a.mime_type,
      'file_size_bytes',a.file_size_bytes,'width',a.width,'height',a.height,'animated',a.animated,'source_kind',a.source_kind,
      'last_used_at',r.last_used_at,'use_count',r.use_count
    ) order by r.last_used_at desc) from public.mw_sticker_recents r join public.mw_sticker_assets a on a.id=r.sticker_id where r.user_id=auth.uid()),'[]'::jsonb),
    'custom_emoji_items',coalesce((select jsonb_agg(jsonb_build_object(
      'emoji_id',e.id,'shortcode',e.shortcode,'is_public',e.is_public,'id',a.id,'storage_path',a.storage_path,
      'original_name',a.original_name,'mime_type',a.mime_type,'file_size_bytes',a.file_size_bytes,'width',a.width,'height',a.height,
      'animated',a.animated,'source_kind',a.source_kind
    ) order by e.created_at desc) from public.mw_custom_emoji e join public.mw_sticker_assets a on a.id=e.sticker_id where e.is_public or e.owner_id=auth.uid()),'[]'::jsonb),
    'reactions',coalesce((select jsonb_agg(jsonb_build_object('code',code,'label',label,'unicode',unicode_value,'sticker_id',sticker_id,'sort_order',sort_order) order by sort_order) from public.mw_reaction_catalog where enabled=true),'[]'::jsonb)
  );
$$;

insert into public.mw_reaction_catalog(code,label,unicode_value,sort_order)
values
('like','Нравится','👍',10),('heart','Сердце','❤️',20),('laugh','Смех','😂',30),('wow','Удивление','😮',40),
('sad','Грусть','😢',50),('pray','Спасибо','🙏',60),('fire','Огонь','🔥',70),('party','Праздник','🎉',80)
on conflict(code) do update set label=excluded.label,unicode_value=excluded.unicode_value,sort_order=excluded.sort_order,enabled=true;

-- Enable client feature flags through existing remote config without forcing an APK rebuild for future catalog changes.
update public.mw_app_remote_config
set config=jsonb_set(
  jsonb_set(
    jsonb_set(
      jsonb_set(
        jsonb_set(config,'{features,stickers}','true'::jsonb,true),
        '{features,sticker_packs}','true'::jsonb,true),
      '{features,sticker_import}','true'::jsonb,true),
    '{features,sticker_favorites}','true'::jsonb,true),
  '{features,custom_emoji}','true'::jsonb,true),
  updated_at=now()
where id=1;
