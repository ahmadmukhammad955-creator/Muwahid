# Muwahid 0.13.10 — reference messenger UI

This build replaces the old chat/list presentation with the dark navy + cyan messenger UI from the approved 9-screen reference.

Implemented reference blocks:
1. Chat list: search, All/Private/Groups/Channels filters, avatars, preview, time, unread badge, bottom navigation.
2. Chat: avatar/name/online header, audio/video/menu actions, compact incoming/outgoing bubbles, media/document/location/voice cards, composer.
3. Attachment sheet: Gallery, Camera, Video, Document, Location, Contact, Audio, Poll, More.
4. Camera: photo/video modes, flash, camera flip, live preview, shutter.
5. Location: map, selected point/address, send action.
6. Documents: in-app recent document list with PDF/Word/Excel/Other filters plus system document picker.
7. Voice: record/cancel/send, waveform player, speed control.
8. Incoming call: decline/answer screen.
9. Active call: timer, microphone, camera, speaker, add, chat, more, end.

Build identity: versionName 0.13.10, versionCode 44.


## 0.13.10 visual polish
Reduced chat toolbar and composer height, compacted message bubbles and voice cards, enlarged attachment icons relative to their circles, and softened/reduced the wallpaper motif to match the approved reference more closely.
