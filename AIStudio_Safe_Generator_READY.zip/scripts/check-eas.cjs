const { getConfig } = require('expo/config');
const { exp } = getConfig(process.cwd());
if (!exp.extra?.eas?.projectId) {
  console.error('EAS project is not linked. Set the EAS_PROJECT_ID GitHub Actions variable to the UUID from your Expo project settings, or link the project with eas init and save extra.eas.projectId in app.json.');
  process.exit(1);
}
console.log('EAS project ID is configured. Signing credentials must already exist in EAS for non-interactive builds.');
