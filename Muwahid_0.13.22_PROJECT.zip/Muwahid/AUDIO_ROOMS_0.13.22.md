# Muwahid 0.13.22 — real audio rooms

Implemented from the supplied audio-room reference:

- 8 live speaker seats in a 4×2 stage layout; listeners remain outside the stage.
- WebRTC room audio with multiple simultaneous microphones.
- Host/moderator controls: raise hand, admit, promote/demote speaker, mute permission, moderator assignment, kick/ban and close room.
- Live active-speaker indication.
- Room mixer built on Web Audio: mic level, EQ, room effects, voice timbre presets and local processed-mic preview.
- Local music picker. Selected audio is mixed into the speaker's outgoing room stream with volume and loop controls.
- Soundboard effects generated locally and mixed into the outgoing room stream.
- Karaoke workflow by combining room music with the karaoke mixer preset.
- Room chat, media, stickers, participant list and shared PDF reading.
- Room themes, live participant/connection status and room elapsed time.
- Real room recording with MediaRecorder. The local mixed output plus received remote room audio is recorded and saved to Music/Muwahid on Android 10+.

Production note: peer media currently uses public STUN servers. A dedicated TURN service should be configured before relying on connectivity across every carrier/NAT combination.

Not represented as completed: proprietary BIGO services such as its own live-program catalogue, platform YouTube relay, and screen-broadcast infrastructure. Those require separate video/relay integrations and are intentionally not implemented as fake buttons.
