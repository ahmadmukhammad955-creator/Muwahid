import React, { useState } from 'react';
import {
  StatusBar,
  StyleSheet,
  Text,
  View,
  Pressable,
  ScrollView,
  Alert,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';

import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

const gap = 12;

const gallery = [
  { title: 'Портрет', subtitle: 'Мягкий свет', emoji: '🧑‍🎨' },
  { title: 'Кино-кадр', subtitle: 'Тёплая сцена', emoji: '🎬' },
  { title: 'Путешествие', subtitle: 'Горный город', emoji: '🏔️' },
  { title: 'Фэнтези', subtitle: 'Неоновый мир', emoji: '✨' },
  { title: 'Аватар', subtitle: 'Студийный стиль', emoji: '📸' },
  { title: 'Архитектура', subtitle: 'Современный дом', emoji: '🏙️' },
];

const modes = ['Создать', 'Редактировать', 'Апскейл', 'Ракурс'];
const bottom = [
  ['◉', 'Обзор'],
  ['◌', 'Чат'],
  ['✦', 'Генерация'],
  ['＋', 'Создать'],
  ['▣', 'Игра'],
  ['♙', 'Профиль'],
];

function Chip({ label, active, onPress }) {
  return (
    <Pressable onPress={onPress} style={[styles.chip, active && styles.chipActive]}>
      <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
    </Pressable>
  );
}

function GalleryCard({ item, i, onRemove }) {
  const bg = i % 4;
  return (
    <View style={[styles.card, styles[`card${bg}`]]}>
      <Text style={styles.cardEmoji}>{item.emoji}</Text>
      <View style={styles.cardFade} />
      <View style={styles.cardTextWrap}>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.cardSubtitle}>{item.subtitle}</Text>
      </View>
      <Pressable accessibilityRole="button" accessibilityLabel={`Удалить пример: ${item.title}`} hitSlop={10} onPress={onRemove} style={styles.closeMini}><Text style={styles.closeMiniText}>×</Text></Pressable>
    </View>
  );
}

export default function App() {
  return <SafeAreaProvider><GeneratorScreen /></SafeAreaProvider>;
}

function GeneratorScreen() {
  const [tab, setTab] = useState('Изображение');
  const [mode, setMode] = useState('Создать');
  const [nav, setNav] = useState('Генерация');
  const [quality, setQuality] = useState('Стандарт');
  const [items, setItems] = useState(gallery);
  const [prompt, setPrompt] = useState('');

  function unavailable(feature) {
    Alert.alert(feature, 'Эта функция пока не подключена в проекте.');
  }

  function generate() {
    if (!prompt.trim()) {
      Alert.alert('Добавьте описание', 'Напишите, что вы хотите создать.');
      return;
    }
    Alert.alert('Генератор не подключён', 'В проекте пока нет AI-сервиса. Описание никуда не отправлено. Для генерации нужно подключить сервер.');
  }

  function navigate(label) {
    if (['Обзор', 'Генерация', 'Создать'].includes(label)) {
      setNav(label);
      if (label === 'Создать') setMode('Создать');
    } else {
      unavailable(label);
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#08070a" />

      <View style={styles.header}>
        <View style={styles.brandWrap}>
          <Text style={styles.brandMark}>✦</Text>
          <Text style={styles.brand}>aistudio.ai</Text>
        </View>
        <Pressable onPress={() => Alert.alert("О проекте", "Это демонстрационный интерфейс. AI-сервис ещё не подключён.")} style={styles.filterBtn}>
          <Text style={styles.filterText}>Демо</Text>
        </Pressable>
        <Pressable onPress={() => unavailable("Premium")} style={styles.premiumBtn}>
          <Text style={styles.premiumText}>♛ Premium</Text>
        </Pressable>
      </View>

      <KeyboardAvoidingView style={styles.content} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.panel}>
        <View style={styles.topTabsRow}>
          {['Изображение', 'Видео'].map((name) => (
            <Pressable
              key={name}
              onPress={() => setTab(name)}
              style={[styles.topTab, tab === name && styles.topTabActive]}
            >
              <Text style={[styles.topTabText, tab === name && styles.topTabTextActive]}>
                {name === 'Изображение' ? '▧ ' : '▻ '}{name}
              </Text>
            </Pressable>
          ))}
          <Pressable onPress={() => setQuality(quality === 'Стандарт' ? 'HD' : 'Стандарт')} style={styles.moreBox}>
            <Text style={styles.moreSmall}>Режим</Text>
            <Text style={styles.moreText}>{quality} ✧</Text>
          </Pressable>
        </View>

        <ScrollView style={styles.chipsScroll} horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipsRow}>
          {modes.map((m) => (
            <Chip key={m} label={m} active={mode === m} onPress={() => { if (m === "Создать") setMode(m); else unavailable(m); }} />
          ))}
        </ScrollView>

        <View style={styles.separator} />

        <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.gallery}>
          <Text style={styles.notice}>{nav === 'Обзор' ? 'Обзор примеров' : 'Демонстрационный режим'} · {tab}</Text>
          <Text style={styles.hint}>Карточки ниже — примеры оформления, а не созданные AI изображения.</Text>
          {nav !== 'Обзор' && <>
            <Text style={styles.inputLabel}>Что хотите создать?</Text>
            <TextInput
              accessibilityLabel="Описание для генерации"
              value={prompt}
              onChangeText={setPrompt}
              placeholder="Например: горный город на закате"
              placeholderTextColor="#a39ba8"
              multiline
              maxLength={2000}
              textAlignVertical="top"
              style={styles.prompt}
            />
          </>}
          <Pressable onPress={() => setItems(gallery)} style={styles.restore} accessibilityRole="button">
            <Text style={styles.chipTextActive}>Восстановить примеры</Text>
          </Pressable>
          <View style={styles.grid}>
            {items.map((item, i) => <GalleryCard key={item.title} item={item} i={i} onRemove={() => setItems(current => current.filter(card => card.title !== item.title))} />)}
          </View>
          {items.length === 0 && <Text style={styles.hint}>Все примеры удалены. Можно восстановить их кнопкой выше.</Text>}
        </ScrollView>
      </View>

      <View style={styles.generateWrap}>
        <Pressable accessibilityRole="button" onPress={generate} style={styles.generateBtn}>
          <Text style={styles.generateText}>{tab === 'Видео' ? '▻  Сгенерировать видео' : '▧  Сгенерировать изображение'}</Text>
        </Pressable>
      </View>

      </KeyboardAvoidingView>

      <View style={styles.bottomBar}>
        {bottom.map(([icon, label]) => {
          const active = nav === label;
          return (
            <Pressable key={label} onPress={() => navigate(label)} style={styles.bottomItem}>
              <Text style={[styles.bottomIcon, active && styles.bottomActive]}>{icon}</Text>
              <Text style={[styles.bottomLabel, active && styles.bottomActive]}>{label}</Text>
            </Pressable>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#050507' },
  content: { flex: 1 },
  notice: { color: '#ff6875', fontWeight: '700', marginBottom: 8 },
  hint: { color: '#c7bec8', lineHeight: 20, marginBottom: 12 },
  inputLabel: { color: '#fff', marginBottom: 8 },
  prompt: { color: '#fff', minHeight: 86, backgroundColor: '#1b171f', borderWidth: 1, borderColor: '#4a2635', borderRadius: 12, padding: 12, marginBottom: 10 },
  restore: { paddingVertical: 12, alignSelf: 'flex-start' },
  chipsScroll: { flexGrow: 0, flexShrink: 0 },
  header: {
    minHeight: 76, paddingVertical: 10, paddingHorizontal: 12, flexWrap: 'wrap', flexDirection: 'row', alignItems: 'center',
    borderBottomWidth: 1, borderBottomColor: '#23151b', backgroundColor: '#08070a', gap: 10,
  },
  brandWrap: { flexDirection: 'row', alignItems: 'center', marginRight: 'auto' },
  brandMark: { color: '#ff354f', fontSize: 23, marginRight: 8 },
  brand: { color: '#fff', fontWeight: '800', fontSize: 19 },
  filterBtn: { paddingHorizontal: 13, paddingVertical: 11, borderRadius: 22, backgroundColor: '#2a1318' },
  filterText: { color: '#ff6b78', fontWeight: '700', fontSize: 12 },
  premiumBtn: { paddingHorizontal: 14, paddingVertical: 12, borderRadius: 22, backgroundColor: '#ff3b49' },
  premiumText: { color: '#fff', fontWeight: '800', fontSize: 12 },

  panel: { flex: 1, marginTop: 18, marginHorizontal: 12, borderRadius: 22, borderWidth: 1, borderColor: '#28212b', backgroundColor: '#0a080c', overflow: 'hidden' },
  topTabsRow: { flexDirection: 'row', padding: 10, gap: 6, alignItems: 'stretch' },
  topTab: { flex: 1, height: 43, borderRadius: 8, backgroundColor: '#1b171f', alignItems: 'center', justifyContent: 'center' },
  topTabActive: { backgroundColor: '#ff3c45' },
  topTabText: { color: '#8e8894', fontWeight: '800', fontSize: 12 },
  topTabTextActive: { color: '#fff' },
  moreBox: { width: 78, borderRadius: 10, borderWidth: 1, borderColor: '#4a2635', backgroundColor: '#17131b', alignItems: 'center', justifyContent: 'center' },
  moreSmall: { color: '#817981', fontSize: 10 },
  moreText: { color: '#fff', fontSize: 14, fontWeight: '800', marginTop: 2 },

  chipsRow: { paddingHorizontal: 14, paddingBottom: 15, gap: 9 },
  chip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 19, borderWidth: 1, borderColor: '#34303a', backgroundColor: '#1b1820' },
  chipActive: { borderColor: '#9f343f', backgroundColor: '#311218' },
  chipText: { color: '#aaa4ae', fontWeight: '700', fontSize: 13 },
  chipTextActive: { color: '#ff6875' },
  separator: { height: 1, backgroundColor: '#252129', marginHorizontal: 14 },

  gallery: { padding: 12 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap },
  card: { flexBasis: '46%', flexGrow: 1, maxWidth: '49%', aspectRatio: 0.8, borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: '#5d2530', justifyContent: 'center', alignItems: 'center' },
  card0: { backgroundColor: '#30243f' },
  card1: { backgroundColor: '#3b202d' },
  card2: { backgroundColor: '#1b3340' },
  card3: { backgroundColor: '#2b2137' },
  cardEmoji: { fontSize: 66 },
  cardFade: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.12)' },
  cardTextWrap: { position: 'absolute', left: 10, right: 10, bottom: 10 },
  cardTitle: { color: '#fff', fontWeight: '900', fontSize: 15 },
  cardSubtitle: { color: '#c7bec8', marginTop: 2, fontSize: 11 },
  closeMini: { position: 'absolute', right: 7, top: 7, width: 22, height: 22, borderRadius: 11, backgroundColor: '#050507', alignItems: 'center', justifyContent: 'center' },
  closeMiniText: { color: '#fff', fontSize: 15, lineHeight: 17 },

  generateWrap: { paddingHorizontal: 12, paddingVertical: 10 },
  generateBtn: { width: '100%', minHeight: 58, paddingVertical: 12, borderRadius: 30, backgroundColor: '#f93443', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18, shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 14, elevation: 8 },
  generateText: { color: '#fff', fontWeight: '900', fontSize: 15, textAlign: 'center', flexShrink: 1 },
  creditBadge: { marginLeft: 12, backgroundColor: '#c72e38', borderRadius: 16, paddingHorizontal: 11, paddingVertical: 7 },
  creditText: { color: '#fff', fontWeight: '900', fontSize: 12 },

  bottomBar: { height: 79, flexDirection: 'row', borderTopWidth: 1, borderTopColor: '#272127', backgroundColor: '#09080a', paddingHorizontal: 6 },
  bottomItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  bottomIcon: { color: '#fff', fontSize: 22, marginBottom: 4 },
  bottomLabel: { color: '#ded9df', fontSize: 10 },
  bottomActive: { color: '#ff4050' },
});
