"""Source contract only; device behavior needs an APK build and multi-device checks."""
from pathlib import Path
import re, subprocess
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/muwahid/app/MainActivity.java').read_text()
voice=(root/'app/src/main/java/com/muwahid/app/VoiceRoomActivity.java').read_text()
room=(root/'app/src/main/assets/voice_room.html').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
workflow=(root/'.github/workflows/build-apk.yml').read_text()
sql=(root/'backend/033_live_theme_restore.sql').read_text()
assert 'liveTheme={"violet"}' in main and 'liveDecor={"circle"}' in main
assert '"video".equals(mode[0])?new String[]{"grid"}' in main
assert 'i.putExtra("room_theme",theme)' in main and 'i.putExtra("room_layout",layout)' in main
assert 'roomTheme=safeChoice(' in voice and 'roomWaves=safeChoice(' in voice
assert 'roomTheme:' in voice and 'roomDecor:' in voice
assert 'windowSoftInputMode="adjustResize"' in manifest
assert 'showLiveSharePanel(invitation,httpsLink.toString())' in voice
for txt in ('"Поделиться"','"Последние"','"Друзья"','"Фанаты"','"Группы"','shareLiveWithPackage','showInviteContacts(invitation)','shareToOtherApps(invitation)'):
    assert txt in voice,txt
assert '#chatSection{position:fixed' in room and 'id="chatInput"' in room
assert '.controls{position:fixed;left:0;right:0;bottom:0;' in room
assert 'function applyThemeMessage(m)' in room and "m.sender_id!==stateData.created_by" in room
assert 'publishRoomLook()' in room and "rpc('mw_room_message_send'" in room
assert 'layout-ring' in room and 'waves-glow' in room and 'renderSeatLook()' in room
assert 'const ring=!IS_VIDEO' in room
assert 'mw_room_theme_get' in voice and 'mw_room_theme_get' in room
assert 'r.active=true' in sql and 'm.sender_id' in sql and 'from public.mw_voice_room_messages' in sql
assert 'Muwahid_0.13.32_LIVE_REVIEWED_SOURCE.zip' in workflow
assert '0.13.31' not in workflow and '0.13.28' not in workflow
scripts=re.findall(r'<script>(.*?)</script>',room,re.S)
assert scripts
for script in scripts:
    p=subprocess.run(['node','--check','-'],text=True,input=script,capture_output=True)
    assert p.returncode==0,p.stderr
print('MW_01332_LIVE_UI_REVIEW_SOURCE_OK')
