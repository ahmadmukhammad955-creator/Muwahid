-- Muwahid: private direct messages. Run in a NEW dedicated Supabase project.
begin;
create table public.mw_profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique check (username ~ '^[a-z0-9_]{4,32}$'),
 display_name text not null check (char_length(display_name) between 1 and 60)
);
create table public.mw_chats (
 id uuid primary key default gen_random_uuid(),
 member_a uuid not null references public.mw_profiles(id) on delete cascade,
 member_b uuid not null references public.mw_profiles(id) on delete cascade,
 created_at timestamptz not null default now(),
 check (member_a < member_b), unique(member_a,member_b)
);
create table public.mw_messages (
 id bigint generated always as identity primary key,
 chat_id uuid not null references public.mw_chats(id) on delete cascade,
 sender_id uuid not null references public.mw_profiles(id) on delete cascade,
 client_nonce uuid not null,
 body text not null check (char_length(btrim(body)) between 1 and 4000),
 created_at timestamptz not null default now(),
 unique(sender_id,client_nonce)
);
create index on public.mw_chats(member_b);
create index on public.mw_messages(chat_id,id desc);
alter table public.mw_profiles enable row level security;
alter table public.mw_chats enable row level security;
alter table public.mw_messages enable row level security;
-- No table grants or permissive policies: all access goes through checked RPCs.
revoke all on public.mw_profiles,public.mw_chats,public.mw_messages from anon,authenticated;
revoke all on sequence public.mw_messages_id_seq from anon,authenticated;
create function public.mw_create_profile() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.mw_profiles(id,username,display_name) values(new.id,
 'u_' || replace(new.id::text,'-',''),
 left(coalesce(nullif(btrim(new.raw_user_meta_data->>'display_name'),''),'Пользователь'),60));
 return new;
end $$;
-- UUID-derived username uses 34 characters; allow 34 for generated names.
alter table public.mw_profiles drop constraint mw_profiles_username_check;
alter table public.mw_profiles add constraint mw_profiles_username_check check(username ~ '^[a-z0-9_]{4,34}$');
create trigger mw_new_user after insert on auth.users for each row execute function public.mw_create_profile();
create function public.mw_me() returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 select to_jsonb(p) into result from public.mw_profiles p where id=auth.uid();
 return result;
end $$;
create function public.mw_update_profile(p_name text,p_username text) returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 if p_username !~ '^[a-z0-9_]{4,32}$' then raise exception 'MW:Имя: 4–32 латинские буквы, цифры или знак _'; end if;
 if char_length(btrim(p_name)) not between 1 and 60 then raise exception 'MW:Укажите имя до 60 символов'; end if;
 update public.mw_profiles set username=p_username,display_name=btrim(p_name) where id=auth.uid();
 return public.mw_me();
end $$;
create function public.mw_find_person(p_username text) returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 select to_jsonb(p) into result from public.mw_profiles p where username=lower(btrim(p_username)) and id<>auth.uid();
 return result;
end $$;
create function public.mw_start_chat(p_person uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid; a uuid; b uuid;
begin
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 if p_person=auth.uid() or not exists(select 1 from public.mw_profiles where id=p_person) then raise exception 'MW:Пользователь не найден'; end if;
 a:=least(auth.uid(),p_person); b:=greatest(auth.uid(),p_person);
 insert into public.mw_chats(member_a,member_b) values(a,b) on conflict(member_a,member_b) do nothing;
 select id into result from public.mw_chats where member_a=a and member_b=b;
 return result;
end $$;
create function public.mw_chat_list() returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 select coalesce(jsonb_agg(to_jsonb(x) order by x.updated_at desc),'[]'::jsonb) into result from (
 select c.id,p.display_name,p.username,p.id as person_id,m.body as last_message,
 coalesce(m.created_at,c.created_at) as updated_at
 from public.mw_chats c join public.mw_profiles p on p.id=case when c.member_a=auth.uid() then c.member_b else c.member_a end
 left join lateral(select body,created_at from public.mw_messages where chat_id=c.id order by id desc limit 1) m on true
 where auth.uid() in(c.member_a,c.member_b)) x;
 return result;
end $$;
create function public.mw_messages_get(p_chat uuid,p_before bigint default null) returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null or not exists(select 1 from public.mw_chats where id=p_chat and auth.uid() in(member_a,member_b)) then raise exception 'MW:Нет доступа к этому чату'; end if;
 select coalesce(jsonb_agg(to_jsonb(x) order by x.id),'[]'::jsonb) into result from (
 select id,sender_id,body,created_at,client_nonce from public.mw_messages where chat_id=p_chat and (p_before is null or id<p_before) order by id desc limit 100) x;
 return result;
end $$;
create function public.mw_send(p_chat uuid,p_body text,p_nonce uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null or not exists(select 1 from public.mw_chats where id=p_chat and auth.uid() in(member_a,member_b)) then raise exception 'MW:Нет доступа к этому чату'; end if;
 if char_length(btrim(p_body)) not between 1 and 4000 then raise exception 'MW:Сообщение должно содержать от 1 до 4000 символов'; end if;
 if p_nonce is null then raise exception 'MW:Некорректный идентификатор сообщения'; end if;
 -- Retry is idempotent; reusing a nonce for different content is rejected.
 select to_jsonb(m) into result from public.mw_messages m where sender_id=auth.uid() and client_nonce=p_nonce;
 if result is not null then
  if result->>'chat_id' <> p_chat::text or result->>'body' <> btrim(p_body) then raise exception 'MW:Конфликт повторной отправки'; end if;
  return result;
 end if;
 if (select count(*) from public.mw_messages where sender_id=auth.uid() and created_at>now()-interval '1 minute')>=60 then raise exception 'MW:Слишком много сообщений. Подождите минуту.'; end if;
 insert into public.mw_messages(chat_id,sender_id,client_nonce,body) values(p_chat,auth.uid(),p_nonce,btrim(p_body)) on conflict(sender_id,client_nonce) do nothing;
 select to_jsonb(m) into result from public.mw_messages m where sender_id=auth.uid() and client_nonce=p_nonce;
 if result->>'chat_id' <> p_chat::text or result->>'body' <> btrim(p_body) then raise exception 'MW:Конфликт повторной отправки'; end if;
 return result;
end $$;
revoke all on function public.mw_create_profile(),public.mw_me(),public.mw_update_profile(text,text),public.mw_find_person(text),public.mw_start_chat(uuid),public.mw_chat_list(),public.mw_messages_get(uuid,bigint),public.mw_send(uuid,text,uuid) from public,anon,authenticated;
grant execute on function public.mw_me(),public.mw_update_profile(text,text),public.mw_find_person(text),public.mw_start_chat(uuid),public.mw_chat_list(),public.mw_messages_get(uuid,bigint),public.mw_send(uuid,text,uuid) to authenticated;
commit;
