# Muwahid 0.13.22 — live UI refresh, stage 1

This stage keeps the existing messenger logic and server contracts while replacing the most visible chat UI with the approved modern reference direction.

Implemented:
- adaptive light/dark chat list palette;
- branded Muwahid toolbar with modern search and navigation chips;
- cleaner chat rows, unread emphasis, online indicator and refined avatars;
- updated bottom navigation and floating compose button;
- modern personal-chat header, composer and message bubbles;
- native Android Unicode emoji grid with a direct route to stickers;
- existing swipe, long-press, chat, attachment, call and sticker actions preserved.

Release policy:
- this is a design implementation stage, not a Google Play release;
- keep versionName/versionCode at 0.13.22/56 until device verification is complete;
- increment versionCode only when preparing the tested Play build.
