-- Muwahid LIVE: persist six room gradients for all participants.
-- Run on Supabase once; apply to active room themes without exposing write access.
create table if not exists public.mw_voice_room_themes (
  room_id uuid primary key references public.mw_voice_rooms(id) on delete cascade,
  theme text not null check (theme in ('violet','midnight','ocean','emerald','sunset','graphite')),
  updated_by uuid not null,
  updated_at timestamptz not null default now()
);

alter table public.mw_voice_room_themes enable row level security;
revoke all on public.mw_voice_room_themes from public, anon, authenticated;

create or replace function public.mw_room_theme_get(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare selected_theme text; selected_at timestamptz;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null or not exists (
    select 1 from public.mw_voice_rooms r
    where r.id=p_room and r.active=true
    and (
      exists (select 1 from public.mw_voice_room_members m where m.room_id=r.id and m.user_id=auth.uid())
      or exists (select 1 from public.mw_voice_room_waiting w where w.room_id=r.id and w.user_id=auth.uid())
    )
  ) then
    raise exception 'MW:Эфир закрыт или доступ запрещён';
  end if;
  select t.theme, t.updated_at into selected_theme, selected_at
  from public.mw_voice_room_themes t where t.room_id=p_room;
  return jsonb_build_object('theme',selected_theme,'updated_at',selected_at);
end;
$$;

create or replace function public.mw_room_theme_set(p_room uuid, p_theme text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare selected_at timestamptz;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if p_theme is null or p_theme not in ('violet','midnight','ocean','emerald','sunset','graphite') then
    raise exception 'MW:Неподдерживаемый фон комнаты';
  end if;
  if not exists (
    select 1 from public.mw_voice_rooms r
    join public.mw_voice_room_members m on m.room_id=r.id and m.user_id=auth.uid()
    where r.id=p_room and r.active=true
    and (r.created_by=auth.uid() or mw_private.room_rank(auth.uid(),p_room)>=20)
  ) then
    raise exception 'MW:Менять фон может только ведущий или модератор';
  end if;
  insert into public.mw_voice_room_themes(room_id,theme,updated_by,updated_at)
  values (p_room,p_theme,auth.uid(),clock_timestamp())
  on conflict(room_id) do update
    set theme=excluded.theme,updated_by=excluded.updated_by,updated_at=excluded.updated_at
  returning updated_at into selected_at;
  return jsonb_build_object('theme',p_theme,'updated_at',selected_at);
end;
$$;

revoke all on function public.mw_room_theme_get(uuid) from public,anon,authenticated;
revoke all on function public.mw_room_theme_set(uuid,text) from public,anon,authenticated;
grant execute on function public.mw_room_theme_get(uuid) to authenticated;
grant execute on function public.mw_room_theme_set(uuid,text) to authenticated;
