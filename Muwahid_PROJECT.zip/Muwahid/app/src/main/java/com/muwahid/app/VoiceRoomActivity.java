package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import androidx.core.content.FileProvider;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class VoiceRoomActivity extends Activity {
    private static final int REQ_MIC=7301, REQ_ROOM_IMAGE=7401, REQ_ROOM_VIDEO=7402, REQ_ROOM_BOOK=7403;
    private WebView web;
    private Api api;
    private final ExecutorService worker=Executors.newFixedThreadPool(4);
    private final ConcurrentHashMap<String,File> bookCache=new ConcurrentHashMap<>();
    private String roomId,roomTitle;
    private volatile boolean joined;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#06111E"));
        getWindow().setNavigationBarColor(Color.parseColor("#06111E"));
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        api=new Api(new SecureStore(this));
        Intent i=getIntent();roomId=i.getStringExtra("room_id");roomTitle=i.getStringExtra("room_title");
        if(roomTitle==null||roomTitle.trim().isEmpty())roomTitle="Голосовая комната";
        if(!api.signedIn()||roomId==null||roomId.isEmpty()){finish();return;}
        if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)setup();
        else requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},REQ_MIC);
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r==REQ_MIC){
            if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)setup();
            else new AlertDialog.Builder(this).setMessage("Для голосовой комнаты нужен доступ к микрофону.").setPositiveButton("Закрыть",(d,w)->finish()).show();
        }
    }

    @SuppressWarnings("SetJavaScriptEnabled") private void setup(){
        if(web!=null)return;
        web=new WebView(this);web.setBackgroundColor(Color.parseColor("#06111E"));
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setDomStorageEnabled(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest r){runOnUiThread(()->{
            ArrayList<String> allow=new ArrayList<>();
            for(String x:r.getResources())if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x)&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)allow.add(x);
            if(allow.isEmpty())r.deny();else r.grant(allow.toArray(new String[0]));
        });}});
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
                return interceptLocal(request==null?null:request.getUrl());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,String url){
                try{return interceptLocal(url==null?null:Uri.parse(url));}catch(Exception e){return null;}
            }
        });
        web.addJavascriptInterface(new Bridge(),"MuwahidNative");setContentView(web);
        try{
            String html=readAsset("voice_room.html");
            String init="window.MW={roomId:"+JSONObject.quote(roomId)+",roomTitle:"+JSONObject.quote(roomTitle)+",selfId:"+JSONObject.quote(api.uid())+"};";
            html=html.replace("/*__MW_INIT__*/",init);
            web.loadDataWithBaseURL("https://muwahid.local/",html,"text/html","UTF-8",null);
        }catch(Exception e){new AlertDialog.Builder(this).setMessage("Не удалось открыть голосовую комнату.").setPositiveButton("Закрыть",(d,w)->finish()).show();}
    }

    private WebResourceResponse interceptLocal(Uri uri){
        if(uri==null||!"muwahid.local".equals(uri.getHost())||!"/book-page".equals(uri.getPath()))return null;
        try{
            String path=uri.getQueryParameter("path");
            int page=Integer.parseInt(uri.getQueryParameter("page"));
            byte[] image=renderBookPage(path,page);
            WebResourceResponse r=new WebResourceResponse("image/jpeg",null,new ByteArrayInputStream(image));
            Map<String,String> h=new HashMap<>();h.put("Cache-Control","no-store");r.setResponseHeaders(h);return r;
        }catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));}
    }

    private String readAsset(String name) throws Exception{
        StringBuilder b=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(getAssets().open(name),"UTF-8"))){String line;while((line=r.readLine())!=null)b.append(line).append('\n');}return b.toString();
    }

    private final class Bridge {
        private final Set<String> allowed=new HashSet<>(Arrays.asList(
            "mw_room_join","mw_room_leave","mw_room_state","mw_room_raise_hand","mw_room_mic_set_self","mw_room_mic_moderate",
            "mw_room_kick","mw_room_end","mw_room_signal_send","mw_room_signal_poll",
            "mw_room_moderator_set","mw_room_admit","mw_room_message_send","mw_room_messages_get",
            "mw_room_book_start","mw_room_book_page","mw_room_book_controller","mw_room_book_stop","mw_room_book_state"
        ));
        @JavascriptInterface public void rpc(String requestId,String function,String argsJson){
            if(!allowed.contains(function)){deliver(requestId,null,"Недоступная операция");return;}
            worker.execute(()->{try{
                Object result=api.rpc(function,new JSONObject(argsJson));
                if("mw_room_join".equals(function))joined=true;
                if("mw_room_leave".equals(function))joined=false;
                deliver(requestId,result==null?"null":result.toString(),null);
            }catch(Exception e){deliver(requestId,null,e.getMessage()==null?"Ошибка связи":e.getMessage());}});
        }

        @JavascriptInterface public void pickMedia(String kind){runOnUiThread(()->{
            try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
                if("image".equals(kind)){i.setType("image/*");startActivityForResult(i,REQ_ROOM_IMAGE);}
                else if("video".equals(kind)){i.setType("video/*");startActivityForResult(i,REQ_ROOM_VIDEO);}
            }catch(Exception e){toast("Не удалось открыть выбор файла");}
        });}

        @JavascriptInterface public void pickBook(){runOnUiThread(()->{
            try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");startActivityForResult(i,REQ_ROOM_BOOK);}
            catch(Exception e){toast("Не удалось открыть выбор PDF");}
        });}

        @JavascriptInterface public void openMedia(String path,String mime,String name){
            worker.execute(()->{try{byte[] raw=api.downloadRoomMedia(path);File dir=new File(getCacheDir(),"room_media");dir.mkdirs();String safe=(name==null?"file":name).replaceAll("[^A-Za-zА-Яа-я0-9._ -]","_");File f=new File(dir,UUID.randomUUID()+"_"+safe);try(FileOutputStream out=new FileOutputStream(f)){out.write(raw);}Uri u=FileProvider.getUriForFile(VoiceRoomActivity.this,getPackageName()+".files",f);Intent open=new Intent(Intent.ACTION_VIEW);open.setDataAndType(u,mime==null?"application/octet-stream":mime);open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);runOnUiThread(()->{try{startActivity(open);}catch(Exception ex){toast("На телефоне нет приложения для открытия этого файла");}});}catch(Exception e){runOnUiThread(()->toast(e.getMessage()==null?"Не удалось открыть файл":e.getMessage()));}});
        }

        @JavascriptInterface public void close(){runOnUiThread(VoiceRoomActivity.this::finish);}
    }

    private void deliver(String requestId,String json,String error){runOnUiThread(()->{
        if(web==null)return;
        String js="window.mwResult("+JSONObject.quote(requestId)+","+(json==null?"null":JSONObject.quote(json))+","+(error==null?"null":JSONObject.quote(error))+");";
        web.evaluateJavascript(js,null);
    });}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        final Uri uri=data.getData();
        if(requestCode==REQ_ROOM_BOOK){handleBookSelected(uri);return;}
        if(requestCode!=REQ_ROOM_IMAGE&&requestCode!=REQ_ROOM_VIDEO)return;
        final String kind=requestCode==REQ_ROOM_IMAGE?"image":"video";
        worker.execute(()->{try{
            byte[] raw=readUri(uri,24*1024*1024);String mime=getContentResolver().getType(uri);if(mime==null)mime=kind.equals("image")?"image/jpeg":"video/mp4";
            String name=kind.equals("image")?"Фото":"Видео";String path=roomId+"/"+UUID.randomUUID()+".bin";api.uploadRoomMedia(path,raw);
            JSONObject media=new JSONObject().put("path",path).put("mime",mime).put("name",name).put("size",raw.length);
            api.rpc("mw_room_message_send",new JSONObject().put("p_room",roomId).put("p_kind",kind).put("p_body","").put("p_media",media));
            runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.mwRoomMediaSent&&window.mwRoomMediaSent();",null);});
        }catch(Exception e){runOnUiThread(()->toast(e.getMessage()==null?"Не удалось отправить файл":e.getMessage()));}});
    }

    private void handleBookSelected(Uri uri){
        worker.execute(()->{try{
            byte[] raw=readUri(uri,48*1024*1024);
            String name=queryDisplayName(uri);if(name==null||name.trim().isEmpty())name="Книга.pdf";name=name.trim();if(name.length()>180)name=name.substring(0,180);
            File tmp=new File(getCacheDir(),"selected_"+UUID.randomUUID()+".pdf");try(FileOutputStream out=new FileOutputStream(tmp)){out.write(raw);}
            int pages=pdfPageCount(tmp);if(pages<1)throw new Exception("PDF не содержит страниц");if(pages>5000)throw new Exception("В книге слишком много страниц");
            String objectPath=roomId+"/books/"+UUID.randomUUID()+".pdf";
            api.uploadRoomBook(objectPath,raw);
            bookCache.put(objectPath,tmp);
            Object result=api.rpc("mw_room_book_start",new JSONObject().put("p_room",roomId).put("p_path",objectPath).put("p_file_name",name).put("p_total_pages",pages));
            final String json=result==null?"{}":result.toString();
            runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.mwBookStarted&&window.mwBookStarted("+json+");",null);});
        }catch(Exception e){runOnUiThread(()->toast(e.getMessage()==null?"Не удалось открыть книгу":e.getMessage()));}});
    }

    private String queryDisplayName(Uri uri){
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst())return c.getString(0);
        }catch(Exception ignored){}
        return null;
    }

    private int pdfPageCount(File file) throws Exception{
        try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer r=new PdfRenderer(fd)){
            return r.getPageCount();
        }
    }

    private byte[] renderBookPage(String path,int pageIndex) throws Exception{
        if(path==null||!path.startsWith(roomId+"/books/")||!path.endsWith(".pdf"))throw new Exception("Некорректная книга");
        File file=ensureBookFile(path);
        try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(fd)){
            if(pageIndex<0||pageIndex>=renderer.getPageCount())throw new Exception("Страница не существует");
            try(PdfRenderer.Page page=renderer.openPage(pageIndex)){
                int baseW=Math.max(1,page.getWidth()),baseH=Math.max(1,page.getHeight());
                float scale=Math.min(2.4f,1280f/baseW);
                if(baseH*scale>2100f)scale=2100f/baseH;
                int w=Math.max(1,Math.round(baseW*scale)),h=Math.max(1,Math.round(baseH*scale));
                Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);bmp.eraseColor(Color.WHITE);
                Matrix matrix=new Matrix();matrix.setScale(scale,scale);
                page.render(bmp,null,matrix,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                ByteArrayOutputStream out=new ByteArrayOutputStream();bmp.compress(Bitmap.CompressFormat.JPEG,90,out);bmp.recycle();return out.toByteArray();
            }
        }
    }

    private File ensureBookFile(String path) throws Exception{
        File cached=bookCache.get(path);if(cached!=null&&cached.exists()&&cached.length()>0)return cached;
        File dir=new File(getCacheDir(),"room_books");dir.mkdirs();
        File f=new File(dir,sha256(path)+".pdf");
        if(!f.exists()||f.length()==0){byte[] raw=api.downloadRoomBook(path);File t=new File(dir,f.getName()+".tmp");try(FileOutputStream out=new FileOutputStream(t)){out.write(raw);}if(!t.renameTo(f)){try(FileInputStream in=new FileInputStream(t);FileOutputStream out=new FileOutputStream(f)){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}t.delete();}}
        bookCache.put(path,f);return f;
    }

    private String sha256(String s) throws Exception{
        MessageDigest d=MessageDigest.getInstance("SHA-256");byte[] b=d.digest(s.getBytes("UTF-8"));StringBuilder out=new StringBuilder();for(byte x:b)out.append(String.format(Locale.US,"%02x",x&255));return out.toString();
    }

    private byte[] readUri(Uri uri,int max) throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new Exception("Не удалось открыть файл");byte[] b=new byte[16384];int n,total=0;while((n=in.read(b))!=-1){total+=n;if(total>max)throw new Exception("Файл слишком большой");out.write(b,0,n);}}return out.toByteArray();}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("window.leaveRoom && window.leaveRoom();",null);else super.onBackPressed();}

    @Override public void onDestroy(){
        if(joined){try{worker.submit(()->{try{api.rpc("mw_room_leave",new JSONObject().put("p_room",roomId));}catch(Exception ignored){}}).get(1200,TimeUnit.MILLISECONDS);}catch(Exception ignored){}}
        if(web!=null){web.loadUrl("about:blank");web.destroy();web=null;}
        worker.shutdownNow();super.onDestroy();
    }
}
