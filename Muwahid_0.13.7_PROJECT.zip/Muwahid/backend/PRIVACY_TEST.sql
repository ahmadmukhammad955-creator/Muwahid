begin;
select set_config('mw.test_a',gen_random_uuid()::text,true),set_config('mw.test_b',gen_random_uuid()::text,true);
insert into auth.users(id,raw_user_meta_data) values(current_setting('mw.test_a')::uuid,'{"display_name":"Privacy test A"}'),(current_setting('mw.test_b')::uuid,'{"display_name":"Privacy test B"}');
update public.mw_profiles set phone_e164='+99912345678901' where id=current_setting('mw.test_b')::uuid;
select set_config('request.jwt.claims',jsonb_build_object('sub',current_setting('mw.test_b'),'aal','aal1','role','authenticated')::text,true);
set local role authenticated;
select public.mw_privacy_set('messages','nobody');
select public.mw_privacy_set('calls','nobody');
select public.mw_privacy_set('phone_search','nobody');
select set_config('request.jwt.claims',jsonb_build_object('sub',current_setting('mw.test_a'),'aal','aal1','role','authenticated')::text,true);
do $$ begin
 if public.mw_find_person_any('+99912345678901') is not null then raise exception 'Hidden phone discoverable'; end if;
 begin perform public.mw_start_chat(current_setting('mw.test_b')::uuid);raise exception 'Message restriction bypassed'; exception when others then if sqlerrm<>'MW:Пользователь ограничил сообщения' then raise; end if;end;
 begin perform public.mw_privacy_set('messages','invalid');raise exception 'Invalid value accepted'; exception when others then if sqlerrm<>'MW:Некорректная настройка' then raise; end if;end;
end $$;
select set_config('request.jwt.claims',jsonb_build_object('sub',current_setting('mw.test_b'),'aal','aal1','role','authenticated')::text,true);
select public.mw_privacy_set('messages','contacts');
select public.mw_privacy_set('calls','contacts');
select public.mw_privacy_set('phone_search','contacts');
select public.mw_privacy_person_set('contacts',current_setting('mw.test_a')::uuid,true);
select set_config('request.jwt.claims',jsonb_build_object('sub',current_setting('mw.test_a'),'aal','aal1','role','authenticated')::text,true);
select set_config('mw.test_chat',public.mw_start_chat(current_setting('mw.test_b')::uuid)::text,true);
do $$ begin
 if public.mw_find_person_any('+99912345678901') is null then raise exception 'Trusted contact cannot find phone'; end if;
 if public.mw_privacy_get()->>'messages'<>'everyone' then raise exception 'Settings leaked between accounts';end if;
 perform public.mw_send(current_setting('mw.test_chat')::uuid,'privacy test',gen_random_uuid());
 perform public.mw_call_start(current_setting('mw.test_chat')::uuid,'audio',repeat('test',10));
end $$;
select public.mw_privacy_person_set('blocks',current_setting('mw.test_b')::uuid,true);
do $$ begin
 begin perform public.mw_send(current_setting('mw.test_chat')::uuid,'must fail',gen_random_uuid());raise exception 'Block bypassed for messages'; exception when others then if sqlerrm<>'MW:Пользователь ограничил сообщения' then raise; end if;end;
 begin perform public.mw_call_start(current_setting('mw.test_chat')::uuid,'audio',repeat('test',10));raise exception 'Block bypassed for calls'; exception when others then if sqlerrm<>'MW:Пользователь ограничил звонки' then raise; end if;end;
 if public.mw_privacy_get()->>'blocked_count'<>'1' then raise exception 'Block count incorrect';end if;
 if has_table_privilege('authenticated','public.mw_privacy','SELECT') then raise exception 'Direct table access allowed';end if;
 if has_function_privilege('anon','public.mw_privacy_get()','EXECUTE') then raise exception 'Anonymous execution allowed';end if;
end $$;
select set_config('request.jwt.claims',jsonb_build_object('sub',current_setting('mw.test_b'),'aal','aal1','role','authenticated')::text,true);
do $$ begin
 begin perform public.mw_send(current_setting('mw.test_chat')::uuid,'must fail reverse',gen_random_uuid());raise exception 'Reverse block bypassed'; exception when others then if sqlerrm<>'MW:Пользователь ограничил сообщения' then raise; end if;end;
 if public.mw_privacy_get()->>'blocked_count'<>'0' then raise exception 'Block list leaked';end if;
end $$;
reset role;
select 'MW_PRIVACY_TEST_OK' as result;
rollback;
