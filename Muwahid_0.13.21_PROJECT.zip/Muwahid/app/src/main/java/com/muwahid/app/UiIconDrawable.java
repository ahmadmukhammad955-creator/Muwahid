package com.muwahid.app;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Lightweight line-icon drawable used by the reference Muwahid messenger UI. */
public final class UiIconDrawable extends Drawable {
    private final String name;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int color;
    private int alpha = 255;

    public UiIconDrawable(String name, int color) {
        this.name = name == null ? "" : name;
        this.color = color;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override public int getIntrinsicWidth() { return 24; }
    @Override public int getIntrinsicHeight() { return 24; }

    @Override public void draw(Canvas c) {
        Rect b = getBounds();
        float w=b.width(), h=b.height(), cx=b.left+w/2f, cy=b.top+h/2f;
        float s=Math.min(w,h)/24f;
        c.save(); c.translate(cx-12*s,cy-12*s); c.scale(s,s);
        p.setColor(color); p.setAlpha(alpha); p.setStrokeWidth(1.65f); p.setStyle(Paint.Style.STROKE);
        Path q=new Path();
        switch(name){
            case "back":
                q.moveTo(14.2f,5.8f);q.lineTo(8.0f,12);q.lineTo(14.2f,18.2f);c.drawPath(q,p);break;
            case "search":
                c.drawCircle(10.5f,10.5f,5.4f,p);c.drawLine(14.6f,14.6f,19.2f,19.2f,p);break;
            case "plus":
                c.drawLine(12,5.5f,12,18.5f,p);c.drawLine(5.5f,12,18.5f,12,p);break;
            case "camera":
                c.drawRoundRect(4.2f,7.2f,19.8f,18.4f,3.0f,3.0f,p);c.drawCircle(12,12.8f,3.15f,p);q.moveTo(8.2f,7.2f);q.lineTo(9.7f,5.2f);q.lineTo(14.3f,5.2f);q.lineTo(15.8f,7.2f);c.drawPath(q,p);break;
            case "video":
                c.drawRoundRect(4.0f,7.0f,15.3f,17.0f,2.7f,2.7f,p);q.moveTo(15.3f,10.0f);q.lineTo(19.8f,7.9f);q.lineTo(19.8f,16.1f);q.lineTo(15.3f,14.0f);c.drawPath(q,p);break;
            case "phone":
                q.moveTo(7.2f,4.6f);
                q.cubicTo(6.2f,4.5f,5.3f,5.2f,5.3f,6.3f);
                q.cubicTo(5.5f,12.1f,11.9f,18.5f,17.7f,18.7f);
                q.cubicTo(18.8f,18.7f,19.5f,17.8f,19.4f,16.8f);
                q.lineTo(19.1f,14.9f);
                q.cubicTo(19.0f,14.2f,18.4f,13.7f,17.7f,13.8f);
                q.lineTo(14.7f,14.1f);
                q.cubicTo(13.0f,13.1f,10.9f,11.0f,9.9f,9.3f);
                q.lineTo(10.2f,6.3f);
                q.cubicTo(10.3f,5.6f,9.8f,5.0f,9.1f,4.9f);
                q.close();c.drawPath(q,p);break;
            case "more":
                p.setStyle(Paint.Style.FILL);c.drawCircle(6.5f,12,1.25f,p);c.drawCircle(12,12,1.25f,p);c.drawCircle(17.5f,12,1.25f,p);break;
            case "smile":
                c.drawCircle(12,12,8,p);c.drawCircle(9,10,0.7f,p);c.drawCircle(15,10,0.7f,p);q.moveTo(8.3f,14);q.cubicTo(10.4f,16.4f,13.6f,16.4f,15.7f,14);c.drawPath(q,p);break;
            case "clip":
                q.moveTo(9.1f,12.4f);q.lineTo(14.9f,6.6f);q.cubicTo(16.6f,4.9f,19.1f,5,20.5f,6.4f);q.cubicTo(22,7.9f,22,10.2f,20.3f,11.9f);q.lineTo(12.2f,20);q.cubicTo(9.8f,22.4f,6.2f,22.4f,3.9f,20.1f);q.cubicTo(1.6f,17.8f,1.7f,14.2f,4,11.9f);q.lineTo(11.6f,4.3f);c.drawPath(q,p);q.reset();q.moveTo(7.1f,14.9f);q.lineTo(13.4f,8.6f);q.cubicTo(14.3f,7.7f,15.6f,7.8f,16.3f,8.5f);q.cubicTo(17.1f,9.3f,17.1f,10.5f,16.2f,11.4f);q.lineTo(10,17.6f);c.drawPath(q,p);break;
            case "mic":
                c.drawRoundRect(9,3.6f,15,14.2f,3,3,p);q.moveTo(6.6f,11.5f);q.cubicTo(6.6f,15.1f,8.9f,17.5f,12,17.5f);q.cubicTo(15.1f,17.5f,17.4f,15.1f,17.4f,11.5f);c.drawPath(q,p);c.drawLine(12,17.5f,12,20.5f,p);c.drawLine(8.6f,20.5f,15.4f,20.5f,p);break;
            case "send":
                q.moveTo(3.7f,11.1f);q.lineTo(20.5f,4.2f);q.lineTo(14,20.1f);q.lineTo(10.8f,13.2f);q.close();c.drawPath(q,p);c.drawLine(10.8f,13.2f,16.5f,8,p);break;
            case "chat":
                c.drawRoundRect(4,5,20,17,3,3,p);q.moveTo(8,17);q.lineTo(6.3f,20);q.lineTo(11,17);c.drawPath(q,p);break;
            case "contacts":
                c.drawCircle(12,8.3f,3.4f,p);q.moveTo(5.2f,19);q.cubicTo(5.9f,14.8f,8.2f,13,12,13);q.cubicTo(15.8f,13,18.1f,14.8f,18.8f,19);c.drawPath(q,p);break;
            case "settings":
                c.drawCircle(12,12,3.2f,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=(float)(12+6.2*Math.cos(a)),y1=(float)(12+6.2*Math.sin(a)),x2=(float)(12+8.2*Math.cos(a)),y2=(float)(12+8.2*Math.sin(a));c.drawLine(x1,y1,x2,y2,p);}c.drawCircle(12,12,8,p);break;
            case "image":
                c.drawRoundRect(3.5f,5,20.5f,19,2.4f,2.4f,p);c.drawCircle(9,10,1.5f,p);q.moveTo(5.5f,17);q.lineTo(10.3f,12.2f);q.lineTo(13.2f,15.1f);q.lineTo(15.5f,12.8f);q.lineTo(19,16.3f);c.drawPath(q,p);break;
            case "document":
                q.moveTo(6,3.5f);q.lineTo(14.5f,3.5f);q.lineTo(19,8);q.lineTo(19,20.5f);q.lineTo(6,20.5f);q.close();c.drawPath(q,p);c.drawLine(14.5f,3.7f,14.5f,8.2f,p);c.drawLine(14.5f,8.2f,19,8.2f,p);c.drawLine(9,12,16,12,p);c.drawLine(9,15,16,15,p);break;
            case "location":
                q.moveTo(12,21);q.cubicTo(9.4f,17.4f,6.5f,14.3f,6.5f,10.5f);q.cubicTo(6.5f,7.2f,8.9f,4.5f,12,4.5f);q.cubicTo(15.1f,4.5f,17.5f,7.2f,17.5f,10.5f);q.cubicTo(17.5f,14.3f,14.6f,17.4f,12,21);c.drawPath(q,p);c.drawCircle(12,10.5f,2.2f,p);break;
            case "audio":
                c.drawLine(10,5,10,16,p);c.drawLine(10,5,17,3.5f,p);c.drawLine(17,3.5f,17,14.5f,p);c.drawCircle(7.3f,17,2.7f,p);c.drawCircle(14.3f,15.5f,2.7f,p);break;
            case "poll":
                c.drawLine(5,18,5,12,p);c.drawLine(10,18,10,7,p);c.drawLine(15,18,15,10,p);c.drawLine(20,18,20,4.5f,p);break;
            case "speaker":
                q.moveTo(4,10);q.lineTo(8,10);q.lineTo(13,6);q.lineTo(13,18);q.lineTo(8,14);q.lineTo(4,14);q.close();c.drawPath(q,p);q.reset();q.moveTo(16,9);q.cubicTo(18,10.5f,18,13.5f,16,15);c.drawPath(q,p);q.reset();q.moveTo(18,6.5f);q.cubicTo(22,9,22,15,18,17.5f);c.drawPath(q,p);break;
            case "personplus":
                c.drawCircle(9,8,3,p);q.moveTo(3.5f,18);q.cubicTo(4.2f,14.5f,6.2f,13,9,13);q.cubicTo(11.8f,13,13.7f,14.5f,14.5f,18);c.drawPath(q,p);c.drawLine(18,8,18,14,p);c.drawLine(15,11,21,11,p);break;
            case "close":
                c.drawLine(6,6,18,18,p);c.drawLine(18,6,6,18,p);break;
            case "flash":
                q.moveTo(13,2.5f);q.lineTo(6.5f,13);q.lineTo(11.2f,13);q.lineTo(9.8f,21.5f);q.lineTo(17.5f,10.5f);q.lineTo(12.6f,10.5f);q.close();c.drawPath(q,p);break;
            case "flip":
                q.moveTo(5,9);q.cubicTo(7.2f,4.7f,13.1f,3.4f,17.1f,6.4f);q.lineTo(19.2f,8);q.moveTo(19,4.5f);q.lineTo(19.2f,8);q.lineTo(15.7f,8.4f);c.drawPath(q,p);q.reset();q.moveTo(19,15);q.cubicTo(16.8f,19.3f,10.9f,20.6f,6.9f,17.6f);q.lineTo(4.8f,16);q.moveTo(5,19.5f);q.lineTo(4.8f,16);q.lineTo(8.3f,15.6f);c.drawPath(q,p);break;
            case "trash":
                c.drawRoundRect(7,8,17,20,1.5f,1.5f,p);c.drawLine(5,6.5f,19,6.5f,p);c.drawLine(9.5f,4,14.5f,4,p);c.drawLine(10,10,10,17.5f,p);c.drawLine(14,10,14,17.5f,p);break;
            case "lock":
                c.drawRoundRect(5.5f,10,18.5f,20,2.5f,2.5f,p);q.moveTo(8.5f,10);q.lineTo(8.5f,7.8f);q.cubicTo(8.5f,5.5f,10,4,12,4);q.cubicTo(14,4,15.5f,5.5f,15.5f,7.8f);q.lineTo(15.5f,10);c.drawPath(q,p);break;
            default:
                c.drawCircle(12,12,7,p);break;
        }
        c.restore();
    }

    @Override public void setAlpha(int a){alpha=a;invalidateSelf();}
    @Override public void setColorFilter(ColorFilter f){p.setColorFilter(f);invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    public void setColor(int c){color=c;invalidateSelf();}
}
