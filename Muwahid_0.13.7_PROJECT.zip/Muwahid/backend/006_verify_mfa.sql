begin;
insert into auth.users(id,raw_user_meta_data) values('44444444-4444-4444-8444-444444444444','{"display_name":"MFA test"}');
insert into auth.mfa_factors(id,user_id,friendly_name,factor_type,status,created_at,updated_at,secret) values('55555555-5555-4555-8555-555555555555','44444444-4444-4444-8444-444444444444','Disposable transaction-only test','totp','verified',now(),now(),'not-a-real-secret');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"44444444-4444-4444-8444-444444444444","aal":"aal1"}',true);
do $$ begin
 begin perform public.mw_me();raise exception 'FAIL MFA bypass';
 exception when raise_exception then if SQLERRM<>'MW:MFA_REQUIRED' then raise;end if;end;
end $$;
select set_config('request.jwt.claims','{"sub":"44444444-4444-4444-8444-444444444444","aal":"aal2"}',true);
do $$ begin
 if public.mw_me()->>'display_name'<>'MFA test' then raise exception 'FAIL MFA access';end if;
end $$;
reset role;
do $$ begin
 if (select count(*) from pg_proc where pronamespace='public'::regnamespace and proname in ('mw_me','mw_update_profile','mw_find_person','mw_start_chat','mw_chat_list','mw_messages_get','mw_send') and position('perform mw_private.require_mfa();' in prosrc)>0)<>7 then raise exception 'FAIL missing MFA guard';end if;
end $$;
select 'PASS: MFA required after enrollment; AAL2 allowed; all seven messaging functions guarded' as verification;
rollback;
