package com.muwahid.app;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Small offline map-style preview for location message cards. */
public final class MiniMapView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    public MiniMapView(Context c){super(c);setContentDescription("Предпросмотр местоположения");}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(224,231,220));c.drawRect(0,0,w,h,p);p.setColor(Color.rgb(198,219,190));c.drawRect(0,h*.15f,w*.35f,h*.55f,p);p.setColor(Color.rgb(210,226,203));c.drawRect(w*.58f,0,w,h*.32f,p);p.setColor(Color.rgb(206,222,230));c.drawRect(w*.62f,h*.64f,w,h,p);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(Math.max(2,w*.035f));p.setColor(Color.WHITE);Path road=new Path();road.moveTo(-w*.1f,h*.8f);road.cubicTo(w*.2f,h*.48f,w*.4f,h*.58f,w*.63f,h*.25f);road.cubicTo(w*.77f,h*.05f,w*.9f,h*.16f,w*1.1f,h*.05f);c.drawPath(road,p);p.setStrokeWidth(Math.max(1,w*.012f));p.setColor(Color.rgb(245,201,128));Path secondary=new Path();secondary.moveTo(w*.08f,-h*.1f);secondary.cubicTo(w*.2f,h*.3f,w*.5f,h*.34f,w*.95f,h*.74f);c.drawPath(secondary,p);p.setStyle(Paint.Style.FILL);float cx=w*.55f,cy=h*.48f,r=Math.min(w,h)*.12f;p.setColor(Color.rgb(244,77,82));c.drawCircle(cx,cy-r*.18f,r,p);Path tip=new Path();tip.moveTo(cx-r*.55f,cy+r*.25f);tip.lineTo(cx,cy+r*1.15f);tip.lineTo(cx+r*.55f,cy+r*.25f);tip.close();c.drawPath(tip,p);p.setColor(Color.WHITE);c.drawCircle(cx,cy-r*.18f,r*.34f,p);}
}
