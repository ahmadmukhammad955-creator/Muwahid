# Muwahid 0.4.0

Android messenger with Supabase, private direct chats, local notes, TOTP setup and owner statistics.
Only the server-bound owner with AAL2 can read aggregate owner statistics. No administration of other users or private-message reading is provided.
The owner binding lives in a private, RLS-enabled table with no client privileges. Public SQL templates omit the real owner identifiers.
All messaging RPCs enforce AAL2 for users who have a verified MFA factor. Users enroll and verify TOTP themselves in Profile > Account protection. No factors are enabled merely by installing this APK. Keep a secure backup of the enrollment secret; self-service factor recovery is not implemented.
The APK includes only the public publishable key.
Debug signing is for testing; release signing is not configured.
No voice, video, groups, channels, bots, phone lookup, SMS registration or end-to-end encryption yet.
