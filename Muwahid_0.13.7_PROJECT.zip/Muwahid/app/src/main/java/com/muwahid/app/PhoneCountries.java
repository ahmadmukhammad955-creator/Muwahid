package com.muwahid.app;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.text.Collator;
import java.util.*;

/** Offline dialling directory with optional server additions. No account data. */
final class PhoneCountries {
    static final Locale RU = new Locale("ru");
    static JSONArray load(Context context) {
        try (InputStream in = context.getAssets().open("phone_countries.json")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096]; int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return merge(new JSONArray(out.toString("UTF-8")), new JSONArray());
        } catch (Exception e) { return new JSONArray(); }
    }
    static String name(JSONObject c) {
        String iso = c.optString("iso2");
        String local = new Locale("", iso).getDisplayCountry(RU);
        return local.isEmpty() || local.equals(iso) ? c.optString("name_en", iso) : local;
    }
    static JSONArray merge(JSONArray base, JSONArray server) {
        Map<String, JSONObject> map = new LinkedHashMap<>();
        for (JSONArray source : new JSONArray[]{base, server}) {
            for (int i = 0; i < source.length(); i++) {
                JSONObject c = source.optJSONObject(i);
                if (c != null && c.optString("iso2").matches("[A-Z]{2}") &&
                    c.optString("calling_code").matches("\\+[1-9][0-9]{0,3}"))
                    map.put(c.optString("iso2"), c);
            }
        }
        ArrayList<JSONObject> sorted = new ArrayList<>(map.values());
        Collator collator = Collator.getInstance(RU);
        Collections.sort(sorted, (a,b) -> collator.compare(name(a),name(b)));
        JSONArray result = new JSONArray();
        for (JSONObject c : sorted) result.put(c);
        return result;
    }
    static ArrayList<JSONObject> search(JSONArray countries, String query) {
        String q = query.trim().toLowerCase(RU).replace('ё','е');
        ArrayList<JSONObject> result = new ArrayList<>();
        for (int i=0; i<countries.length(); i++) {
            JSONObject c = countries.optJSONObject(i);
            if (c == null) continue;
            String haystack = (name(c)+" "+c.optString("name_en")+" "+c.optString("iso2")+" "+c.optString("calling_code")).toLowerCase(RU).replace('ё','е');
            if (haystack.contains(q)) result.add(c);
        }
        return result;
    }
}
