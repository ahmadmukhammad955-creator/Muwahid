package com.muwahid.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.View;
import org.json.JSONObject;

/** Locally rendered, versioned vector animation; encrypted metadata selects only known artwork. */
public final class AnimatedStickerView extends View {
    private final int stickerId;
    private long started=SystemClock.uptimeMillis();
    private final Rect visible=new Rect();
    public AnimatedStickerView(Context context,int id){
        super(context);StickerCatalog.name(id);stickerId=id;
        setContentDescription("Стикер: "+StickerCatalog.name(id));
    }
    public static int catalogId(JSONObject meta){
        int id=meta.optInt("sticker_id",-1);
        if(!meta.optBoolean("sticker",false)||id<0||id>=12)return -1;
        String format=meta.optString("sticker_animation","");
        if("muwahid-vector-v1".equals(format))return id;
        // Animate our previously sent 0.13.2 stickers too. Unknown versions stay PNG.
        return format.isEmpty()&&(StickerCatalog.name(id)+".png").equals(meta.optString("name"))?id:-1;
    }
    public void replay(){started=SystemClock.uptimeMillis();invalidate();}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float width=getWidth()-getPaddingLeft()-getPaddingRight(),height=getHeight()-getPaddingTop()-getPaddingBottom();
        float size=Math.min(width,height);if(size<=0)return;
        boolean animate=getContext().getSharedPreferences("muwahid",0).getBoolean("chat_animations",true);
        canvas.save();canvas.translate(getPaddingLeft()+(width-size)/2,getPaddingTop()+(height-size)/2);canvas.scale(size/256f,size/256f);
        StickerCatalog.draw(canvas,stickerId,animate?SystemClock.uptimeMillis()-started:-1);canvas.restore();
        if(animate&&isAttachedToWindow()&&getWindowVisibility()==VISIBLE&&isShown()&&getGlobalVisibleRect(visible))postInvalidateDelayed(40);
    }
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();invalidate();}
    @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);if(visibility==VISIBLE)invalidate();}
}
