-- Muwahid: one-time defaults for the existing MW remote configuration service.
-- Deploying this migration does not replace any existing app settings.
-- Only whitelisted plain data values are read by the Android LIVE client.
UPDATE public.mw_app_remote_config
SET config=jsonb_set(config,'{live}',
  coalesce(config->'live', '{}'::jsonb) ||
  jsonb_build_object(
    'notice', coalesce(config->'live'->>'notice',''),
    'theme_controls_enabled', coalesce((config->'live'->>'theme_controls_enabled')::boolean,true),
    'theme_refresh_seconds', coalesce((config->'live'->>'theme_refresh_seconds')::integer,5),
    'theme_titles', coalesce(config->'live'->'theme_titles','{}'::jsonb),
    'theme_colors', coalesce(config->'live'->'theme_colors','{}'::jsonb)
  ),true),updated_at=now()
WHERE id=1;
