"""Executable source and release-contract checks for approved two-stage LIVE flow."""
from pathlib import Path
import re
import subprocess

root=Path(__file__).resolve().parents[1]
java=(root/'app/src/main/java/com/muwahid/app/MainActivity.java').read_text()
html=(root/'app/src/main/assets/voice_room.html').read_text()
migration=(root/'backend/032_live_two_stage_capacity.sql').read_text()
workflow=(root/'.github/workflows/build-apk.yml').read_text()
build=(root/'app/build.gradle').read_text()

start=java.index('private void showLiveCreateSheet()')
end=java.index('private void createLiveRoom(',start)
flow=java[start:end]
assert 'step[0]==1?' in flow and 'step[0]=2;' in flow and 'step[0]=1;' in flow
assert 'mode={null}' in flow and 'seats={0}' in flow
assert '"Аудиокомната","От 4 до 8 мест"' in flow
assert '"Видеоэфир","От 4 до 8 мест"' in flow
assert 'final int min=4,max=8;' in flow
assert 'for(int n=min;n<=max;n+=3)' in flow
assert '"Создать эфир"' in flow
assert flow.count('createLiveRoom(roomTitle,mode[0],cap,access[0])')==1
assert 'if(mode[0]==null||cap<4||cap>8)' in flow
assert flow.index('step[0]=2;') < flow.index('createLiveRoom(roomTitle,mode[0],cap,access[0])')
assert 'create.setEnabled(false)' in flow  # protect against duplicate RPC on double tap
assert "for(let position=1;position<=seatCount;position++)" in html
assert "Math.min(12,capacity)" in html  # Keep legacy 9-12-person rooms visible
assert 'ordered.slice(0,5)' not in html
assert "if(!m){html+=`<div class=\"seat empty\"" in html
assert "stage.style.gridTemplateColumns='repeat(2,minmax(0,1fr))'" in html
assert "id=\"chatAction\"" in html and "id=\"moreAction\"" in html
assert "id=\"participantsAction\"" in html and "id=\"exitRoomBtn\"" in html
assert "'mw_room_end'" in html and 'requestExitRoom()' in html
assert 'openLiveBackgroundPanel' in html and 'inviteRoom()' in html
assert "capacity BETWEEN 4 AND 12" in migration
assert "capacity BETWEEN 4 AND 9" in migration
assert "normalized_capacity not between 4 and 12" in migration
assert "normalized_capacity not between 4 and 9" in migration
assert "versionName '0.13.33'" in build and 'versionCode 68' in build
assert "EXPECTED_VERSION_NAME: '0.13.33'" in workflow and "EXPECTED_VERSION_CODE: '68'" in workflow
assert 'Muwahid_0.13.33_CALL_PUSH_READY.zip' in workflow
js=re.findall(r'<script>(.*?)</script>',html,re.S)[-1]
proc=subprocess.run(['node','--check','-'],text=True,input=js,capture_output=True)
assert proc.returncode==0,proc.stderr
print('MW_LIVE_01332_TWO_STAGE_CONTRACT_OK')
