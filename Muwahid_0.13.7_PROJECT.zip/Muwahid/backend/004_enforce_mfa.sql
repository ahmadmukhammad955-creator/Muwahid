-- Require verified MFA for all messaging RPCs once a user enrolls a factor.
begin;
create function mw_private.require_mfa() returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
 if exists(select 1 from auth.mfa_factors where user_id=auth.uid() and status='verified') and coalesce(auth.jwt()->>'aal','')<>'aal2' then
  raise exception 'MW:MFA_REQUIRED';
 end if;
end $$;
revoke all on function mw_private.require_mfa() from public,anon,authenticated;
do $$
declare p record; definition text;
begin
 for p in select oid from pg_proc where pronamespace='public'::regnamespace and proname in ('mw_me','mw_update_profile','mw_find_person','mw_start_chat','mw_chat_list','mw_messages_get','mw_send') loop
  definition:=pg_get_functiondef(p.oid);
  if position('perform mw_private.require_mfa();' in definition)=0 then
   definition:=regexp_replace(definition,'\mbegin\M',E'begin\n perform mw_private.require_mfa();','i');
   execute definition;
  end if;
 end loop;
end $$;
commit;
