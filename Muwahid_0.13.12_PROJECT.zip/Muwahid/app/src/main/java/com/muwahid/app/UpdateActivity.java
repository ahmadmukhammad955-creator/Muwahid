package com.muwahid.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

public final class UpdateActivity extends Activity {
    private Button update;
    private TextView status;
    private String url, versionName;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        versionName=getIntent().getStringExtra("version_name");
        url=getIntent().getStringExtra("apk_url");
        String notes=getIntent().getStringExtra("notes");
        if(versionName==null)versionName="новая версия";
        if(notes==null||notes.trim().isEmpty())notes="Исправления и улучшения Muwahid.";

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24),dp(28),dp(24),dp(24));
        root.setBackgroundColor(Color.rgb(7,19,33));

        TextView title=text("Обновление Muwahid",25,Color.WHITE);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        root.addView(title);
        gap(root,10);
        root.addView(text("Версия "+versionName,17,Color.rgb(16,214,171)));
        gap(root,18);
        TextView n=text(notes,15,Color.rgb(210,222,234));
        n.setLineSpacing(dp(4),1f);
        root.addView(n);
        gap(root,18);
        status=text("Обновление откроется в браузере. Muwahid не устанавливает APK самостоятельно.",13,Color.rgb(143,166,188));
        root.addView(status);
        gap(root,24);

        update=new Button(this);
        update.setText("Открыть страницу обновления");
        update.setAllCaps(false);
        update.setTextSize(16);
        root.addView(update,new LinearLayout.LayoutParams(-1,dp(54)));
        update.setOnClickListener(v->openUpdatePage());

        gap(root,12);
        Button later=new Button(this);
        later.setText("Позже");
        later.setAllCaps(false);
        root.addView(later,new LinearLayout.LayoutParams(-1,dp(50)));
        later.setOnClickListener(v->finish());
        setContentView(root);
    }

    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private void gap(LinearLayout l,int h){l.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(h)));}

    private void openUpdatePage(){
        String page=releasePage(url);
        if(page==null){toast("Некорректная ссылка обновления");return;}
        try{
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(page));
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(i);
            status.setText("Страница обновления открыта в браузере.");
        }catch(Exception e){
            toast("Не удалось открыть страницу обновления");
        }
    }

    private String releasePage(String assetUrl){
        if(assetUrl==null)return null;
        final String prefix="https://github.com/ahmadmukhammad955-creator/Muwahid/releases/download/";
        if(!assetUrl.startsWith(prefix))return null;
        String tail=assetUrl.substring(prefix.length());
        int slash=tail.indexOf('/');
        if(slash<=0)return null;
        String tag=tail.substring(0,slash);
        if(!tag.matches("v[0-9A-Za-z._-]+"))return null;
        return "https://github.com/ahmadmukhammad955-creator/Muwahid/releases/tag/"+tag;
    }

    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
