from pathlib import Path
import json,subprocess,tempfile
src=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/muwahid/app/CallActivity.java').read_text()
lines=src[src.index('private static final String JS=""+'):].splitlines()[1:]
parts=[]
for line in lines:
 line=line.strip()
 if line=='}':break
 parts.append(json.loads(line[:-1]))
js=''.join(parts)
harness='''
(async()=>{
const events=[],timers=[],names={};let status='ringing',closed=0;
const element=id=>names[id]||(names[id]={id,style:{},classList:{add(){},remove(){},toggle(){}},addEventListener(){},querySelector(){return {textContent:''}},textContent:'',videoWidth:0,videoHeight:0,paused:true,play(){return Promise.resolve()}});
const document={body:{classList:{add(){}}},getElementById:element};
const window={MW:{kind:'audio',chatId:'chat-1',callId:'',peer:'Друг',initial:'Д',incoming:false}};
const setTimeout=(cb,delay)=>{timers.push({cb,delay});return timers.length};
const clearTimeout=()=>{};
const navigator={mediaDevices:{getUserMedia:async()=>({getTracks:()=>[],getAudioTracks:()=>[],getVideoTracks:()=>[]})}};
const MuwahidNative={ringback(value){events.push(value)},close(){closed++},speaker(){},action(){},rpc(id,fn,args){
let result;if(fn==='mw_call_start')result={id:'call-1'};
else if(fn==='mw_call_get')result={status,answer:'remote-sdp',caller_ice:[],callee_ice:[]};
else result={ok:true};
queueMicrotask(()=>window.mwResult(id,JSON.stringify(result),null));
}};
class RTCPeerConnection{
 addTrack(){} async createOffer(){return {sdp:'fake-sdp'}} async setLocalDescription(){} async setRemoteDescription(){} async addIceCandidate(){} close(){}
}
const MediaStream=class{};
eval(SOURCE);
const spin=async()=>{for(let i=0;i<100;i++)await Promise.resolve()};
await spin();
if(events[0]!==true)throw new Error('Ringback did not start for the outgoing call: '+JSON.stringify(events));
const t=timers.find(t=>t.delay===1100);if(!t)throw new Error('RPC polling did not start');
status='accepted';t.cb();await spin();
if(events[events.length-1]!==false)throw new Error('Ringback did not stop when call was accepted');
await window.hangup();await spin();
if(closed!==1)throw new Error('Call native close missing');
if(events[events.length-1]!==false)throw new Error('Ringback continued on hangup');
console.log('MW_RINGBACK_JS_STATE_TRANSITIONS_OK');
})().catch(e=>{console.error(e);process.exit(1)});
'''
with tempfile.NamedTemporaryFile(mode='w',suffix='.js') as f:
 f.write('const SOURCE='+json.dumps(js,ensure_ascii=False)+';\n'+harness);f.flush()
 x=subprocess.run(['node',f.name],capture_output=True,text=True,timeout=10)
 print(x.stdout.strip());
 if x.returncode:print(x.stderr)
 if x.returncode:raise SystemExit(x.returncode)
