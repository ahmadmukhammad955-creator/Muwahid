package com.muwahid.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;

/** Keeps an incoming-call ringtone alive even when Android shows only a notification. */
public final class CallRingtone {
    private static MediaPlayer player;
    private static String callId="";
    private CallRingtone(){}

    public static synchronized void start(Context context,String id){
        if(context==null||id==null||id.isEmpty())return;
        if(id.equals(callId)&&player!=null&&player.isPlaying())return;
        stop();
        SharedPreferences p=context.getSharedPreferences("muwahid",Context.MODE_PRIVATE);
        String mode=p.getString("call_ringtone_mode","default");
        callId=id;
        if("silent".equals(mode))return;
        Uri sound=null;
        if("custom".equals(mode)){
            String raw=p.getString("call_ringtone_uri","");
            if(raw!=null&&!raw.isEmpty())try{sound=Uri.parse(raw);}catch(Exception ignored){}
        }
        if(sound==null)sound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        if(sound==null)sound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if(sound==null)return;
        if(!play(context,sound)&&"custom".equals(mode)){
            Uri fallback=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            if(fallback!=null)play(context,fallback);
        }
    }

    private static boolean play(Context context,Uri sound){
        try{
            MediaPlayer mp=new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            mp.setDataSource(context.getApplicationContext(),sound);
            mp.setLooping(true);mp.prepare();mp.start();player=mp;return true;
        }catch(Exception e){return false;}
    }

    public static synchronized void stop(){
        MediaPlayer mp=player;player=null;callId="";
        if(mp!=null){try{mp.stop();}catch(Exception ignored){}try{mp.release();}catch(Exception ignored){}}
    }
    public static synchronized boolean isFor(String id){return id!=null&&id.equals(callId);}
}
