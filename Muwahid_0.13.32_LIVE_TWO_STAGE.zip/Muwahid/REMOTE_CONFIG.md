# Muwahid Remote Config (Supabase)

Version 0.12.6 reads `public.mw_app_remote_config` through `public.mw_app_config()`.

Remote-controlled without rebuilding the APK:
- registration/login titles and explanatory text;
- phone field labels and SMS/OTP button labels;
- default country;
- Google button visibility;
- groups/channels visibility;
- voice rooms/admin section visibility;
- owner chat/Premium/Business/Gifts visibility;
- main tab labels, app label/subtitle, announcement banner;
- country/calling-code list via `mw_phone_country_list()`.

The client caches the last valid config so temporary network failures do not break startup.

Security boundary: Supabase remote config cannot safely add Android permissions, native libraries, a new WebView capability, a new cryptographic primitive, or arbitrary executable code. Those changes require a signed APK update.

## 0.12.7 phone screen

The video-matched native phone form uses fixed Russian screen copy and starts with an explicit country choice. Legacy `auth.intro`, `auth.default_country`, `auth.registration_title`, `auth.login_title`, `auth.country_button`, `auth.phone_hint`, `auth.sms_button`, and login/register switching labels do not control this new form. The `auth.enabled` and `auth.phone_enabled` gates still apply, and `auth.google_enabled` controls the alternate sign-in menu. OTP and welcome copy remain remotely configured. Country data augments the bundled 245-country directory. Active phone entry is never reset by a remote-config refresh.

## LIVE Studio configuration (one-time Android update)

The LIVE WebView reads `mw_app_config()` at entry and every 45 seconds while open.
It supports **data only**, not remotely downloaded JavaScript or arbitrary CSS.
Example of the `live` JSON key in `mw_app_remote_config.config`:

```json
{
  "live": {
    "notice": "",
    "theme_controls_enabled": true,
    "theme_refresh_seconds": 5,
    "theme_titles": {"ocean": "Океан", "violet": "Фиолетовый"},
    "theme_colors": {
      "ocean": {"top": "#1a6d99", "mid": "#17456f", "bottom": "#0a2449", "seat": "#1d5375"}
    }
  }
}
```

- `notice` (up to 180 characters) displays on the LIVE screen.
- `theme_controls_enabled` shows or hides selection of room background presets; this is a UI feature flag, **not authorization**. Server permissions continue to be checked by `mw_room_theme_set`.
- `theme_refresh_seconds` selects the polling period (clamped to 3–60 seconds) for receiving the currently selected room theme.
- `theme_titles` lets admins rename the six pre-installed choices; each string is 1–32 chars.
- `theme_colors` supports colors only when specified as `#RRGGBB`; invalid CSS or URLs are ignored.

Changes to these existing keys take effect without publishing another APK **after** the client including this support is installed. New application capabilities, Android permissions, native WebRTC changes, and entirely new UI actions still require a signed APK build. Do not inject arbitrary JavaScript into remotely fetched configuration.
