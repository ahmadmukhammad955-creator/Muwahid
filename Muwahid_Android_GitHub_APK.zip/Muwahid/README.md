# Muwahid 0.2

Native Android messenger UI matching the supplied navy/turquoise M + paper-plane concept.

## Current usable features
- Personal notes: create, persist across restarts, copy, delete.
- Local profile name and light/dark theme.
- Navigation, message drafts, proper density-based layout, launcher icon.

## Not connected yet
The distributed build deliberately has no server configured. It cannot register users or exchange messages between phones. It does not show fake contacts or fake online status.

The source includes an **unverified, undeployed** email-auth / private-text-chat client and a Supabase SQL schema as one possible backend implementation. The owner declined Supabase, so it is not provisioned. Another reachable hosting provider must be selected before enabling network messaging. Do not present this APK as a production messenger.

Photos, voice, calls, groups, channels, push notifications and end-to-end encryption are not implemented.

## Build
Java 17, Gradle 8.7, Android SDK 35. `gradle assembleDebug`.
GitHub's current workflow extracts `Muwahid_Android_GitHub_APK.zip` and builds it. The archive must be regenerated from the current source. Codemagic uses `codemagic.yaml`.

## Security
HTTPS only; refresh tokens are stored using Android Keystore AES-GCM; backups disabled. Server API keys in the client must only be public/publishable keys. Never embed a service-role key. Schema RPCs check participant membership. Backend requires a real deployed integration test before enabling it.
