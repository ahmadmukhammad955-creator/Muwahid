# Muwahid release hardening.
# R8 may optimize the app, but JavaScriptInterface method names must stay stable.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep JSON exception diagnostics useful without exposing app internals.
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*
