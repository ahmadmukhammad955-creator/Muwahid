// CI can link an existing EAS project without hard-coding an account ID.
module.exports = ({ config }) => {
  const projectId = process.env.EAS_PROJECT_ID?.trim() || config.extra?.eas?.projectId;
  if (projectId && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(projectId)) {
    throw new Error('EAS_PROJECT_ID должен быть UUID проекта из Expo → Project settings.');
  }
  return {
    ...config,
    ...(projectId ? { extra: { ...config.extra, eas: { ...config.extra?.eas, projectId } } } : {}),
  };
};
