package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.media.MediaRecorder;
import androidx.core.content.FileProvider;
import java.io.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String OWNER_UUID="025a8bd0-c7ff-4e39-802a-f1c39ab76a9c";
    private int bg, panel, text, muted, line;
    private final int accent=Color.rgb(16,214,171), cyan=Color.rgb(22,191,231);
    private LinearLayout root, content, list, messages;
    private ScrollView messageScroll;
    private TextView connection;
    private EditText composer;
    private Button sendButton, attachButton, emojiButton, videoMessageButton;
    private static final int REQ_IMAGE=6101, REQ_VIDEO=6102, REQ_AUDIO=6103, REQ_VIDEO_MESSAGE=6104;
    private static final int REQ_RECORD_AUDIO_PERMISSION=6201, REQ_VIDEO_MESSAGE_PERMISSION=6202;
    private MediaRecorder voiceRecorder;
    private File voiceFile;
    private boolean voiceRecording;
    private long voiceStartedAt;
    private final Runnable voiceTicker=new Runnable(){public void run(){
        if(!voiceRecording)return;
        long elapsed=System.currentTimeMillis()-voiceStartedAt;
        if(connection!=null)connection.setText("🎙 Запись "+formatDuration(elapsed)+" · нажмите ■ для отправки");
        if(elapsed>=120000){stopVoiceRecording(true);return;}
        handler.postDelayed(this,1000);
    }};
    private Api api;
    private CryptoBox crypto;
    private android.content.SharedPreferences prefs;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private String screen="welcome", chatId="", chatName="", filter="";
    private String chatFolderFilter="all";
    private boolean phoneRegisterMode;
    private String pendingText="", pendingNonce="", peerE2eeKey="";
    private volatile String pendingPayload="", e2eePublishedFor="";
    private volatile boolean e2eePublishing;
    private boolean e2eeBackendReady;
    private JSONArray chats=new JSONArray();
    private final TreeMap<Long,JSONObject> history=new TreeMap<>();
    private JSONObject profile=new JSONObject();
    private int generation=0;
    private boolean foreground, loading, sending, notesMode, olderAvailable;
    private final Runnable poll=new Runnable(){public void run(){
        if(!foreground)return;
        if(!loading&&!sending&&api.signedIn()){
            if(screen.equals("chats"))loadChats(false);
            else if(screen.equals("chat")&&!notesMode)loadMessages(false);
        }
        handler.postDelayed(this,prefs.getBoolean("energy_saver",false)?12000:5000);
    }};
    interface Task { Object run() throws Exception; }
    interface Done { void accept(Object result) throws Exception; }
    @Override public void onCreate(Bundle b){
        super.onCreate(b); prefs=getSharedPreferences("muwahid",MODE_PRIVATE); api=new Api(new SecureStore(this)); crypto=new CryptoBox(this); colors();
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        if(handleOAuthIntent(getIntent()))return;
        if(api.signedIn()){maybeStartNotifications();String id=getIntent().getStringExtra("open_chat_id");String name=getIntent().getStringExtra("open_chat_name");if(id!=null&&!id.isEmpty())showChat(id,name==null?"Чат":name);else showChats();}else showWelcome();
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(handleOAuthIntent(intent))return;if(api.signedIn()){String id=intent.getStringExtra("open_chat_id");if(id!=null&&!id.isEmpty())showChat(id,intent.getStringExtra("open_chat_name"));}}
    private boolean handleOAuthIntent(Intent intent){
        Uri data=intent==null?null:intent.getData();
        if(data==null||!"muwahid".equalsIgnoreCase(data.getScheme())||!"auth-callback".equalsIgnoreCase(data.getHost()))return false;
        begin("oauth");toolbar("Вход через Google",false,null,null);scrollContent();note(content,"Завершаем безопасный вход через Google…");
        final int stamp=generation;final String fragment=data.getFragment();
        worker.execute(()->{try{api.acceptOAuthCallback(fragment);handler.post(()->{if(stamp!=generation)return;maybeStartNotifications();showChats();});}catch(Exception ex){handler.post(()->{if(stamp!=generation)return;error(ex);showAuth(false);});}});
        return true;
    }
    private void maybeStartNotifications(){
        boolean messages=prefs.getBoolean("notify_messages",true),calls=prefs.getBoolean("notify_calls",true);
        if(!messages&&!calls){try{NotificationService.stop(this);}catch(Exception ignored){}return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=getPackageManager().PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},7001);
        try{NotificationService.ensureStarted(this);}catch(Exception ignored){}
    }
    @Override protected void onResume(){
        super.onResume();foreground=true;handler.removeCallbacks(poll);
        // If Android restored an already authenticated task on the public welcome screen,
        // return the user to the messenger instead of showing registration again.
        if(api!=null && api.signedIn() && "welcome".equals(screen)){showChats();return;}
        handler.postDelayed(poll,prefs.getBoolean("energy_saver",false)?12000:5000);
    }
    @Override protected void onPause(){saveDraft();foreground=false;handler.removeCallbacks(poll);if(voiceRecording)cancelVoiceRecording(false);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);worker.shutdownNow();super.onDestroy();}
    private void colors(){boolean dark=prefs.getBoolean("dark",true);bg=Color.parseColor(dark?"#091322":"#F3F6FA");panel=Color.parseColor(dark?"#122238":"#FFFFFF");text=Color.parseColor(dark?"#EDF4FC":"#132033");muted=Color.parseColor(dark?"#91A3BA":"#60728A");line=Color.parseColor(dark?"#203047":"#DDE5EE");}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    private void bold(TextView t){t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable gradient(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{accent,cyan});d.setCornerRadius(dp(18));return d;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(16);b.setTextColor(Color.rgb(3,27,39));b.setBackground(gradient());b.setMinHeight(dp(50));return b;}
    private void gap(LinearLayout l,int h){l.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(h)));}
    private void note(LinearLayout l,String s){TextView t=label(s,13,muted);t.setLineSpacing(dp(3),1);l.addView(t);}
    private void notice(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("Понятно",null).show();}
    private void error(Exception e){if(e instanceof Api.MfaRequiredException){showSecurity();return;}String s=e.getMessage();if(e instanceof java.io.IOException)s="Нет связи с сервером. Проверьте интернет и попробуйте снова.";notice(s==null?"Не удалось выполнить действие":s);}
    private void async(Task task,Done done){final int stamp=generation;loading=true;
        worker.execute(()->{Object value=null;Exception error=null;try{value=task.run();}catch(Exception e){error=e;}final Object v=value;final Exception err=error;
            handler.post(()->{loading=false;if(isFinishing()||isDestroyed()||stamp!=generation)return;try{if(err!=null)throw err;done.accept(v);}catch(Exception e){error(e);}});
        });
    }
    private void begin(String name){getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);saveDraft();screen=name;generation++;colors();root=vertical();root.setBackgroundColor(bg);setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        root.requestApplyInsets();composer=null;sendButton=null;attachButton=null;emojiButton=null;videoMessageButton=null;
    }
    private void toolbar(String title,boolean back,String action,Runnable onAction){
        LinearLayout bar=horizontal();bar.setPadding(dp(16),dp(8),dp(16),dp(8));
        if(back){TextView b=label("‹",36,text);b.setGravity(Gravity.CENTER);b.setContentDescription("Назад");bar.addView(b,new LinearLayout.LayoutParams(dp(40),dp(46)));b.setOnClickListener(v->onBackPressed());}
        else{Logo logo=new Logo(this,false);bar.addView(logo,new LinearLayout.LayoutParams(dp(34),dp(40)));}
        TextView t=label(title,21,text);bold(t);t.setPadding(dp(10),0,0,0);bar.addView(t,new LinearLayout.LayoutParams(0,dp(44),1));t.setGravity(Gravity.CENTER_VERTICAL);
        if(action!=null){TextView a=label(action,25,accent);a.setGravity(Gravity.CENTER);bar.addView(a,new LinearLayout.LayoutParams(dp(44),dp(44)));a.setOnClickListener(v->onAction.run());}
        root.addView(bar);View rule=new View(this);rule.setBackgroundColor(line);root.addView(rule,new LinearLayout.LayoutParams(-1,dp(1)));
    }
    private void scrollContent(){ScrollView s=new ScrollView(this);s.setFillViewport(true);content=vertical();content.setPadding(dp(22),dp(20),dp(22),dp(24));s.addView(content);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));}
    private void bottom(String selected){LinearLayout nav=horizontal();nav.setPadding(dp(8),dp(10),dp(8),dp(12));nav.setBackgroundColor(panel);
        String[] names={"Чаты","Избранное","Настройки"};String[] marks={"◉","☆","⚙"};
        for(int i=0;i<3;i++){final int index=i;TextView item=label(marks[i]+"\n"+names[i],13,selected.equals(names[i])?accent:muted);item.setGravity(Gravity.CENTER);item.setLineSpacing(dp(5),1);nav.addView(item,new LinearLayout.LayoutParams(0,dp(48),1));item.setOnClickListener(v->{if(index==0)showChats();else if(index==1)showNotes();else showSettings();});}root.addView(nav);
    }
    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setTextSize(16);e.setTextColor(text);e.setHintTextColor(muted);e.setHint(hint);e.setSingleLine(true);e.setPadding(dp(16),dp(14),dp(16),dp(14));e.setBackground(shape(panel,14));if(password)e.setInputType(129);else e.setInputType(1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.bottomMargin=dp(12);content.addView(e,p);return e;}
    private LinearLayout settingsCard(){LinearLayout card=vertical();card.setBackground(shape(panel,22));card.setPadding(dp(8),dp(7),dp(8),dp(7));content.addView(card,new LinearLayout.LayoutParams(-1,-2));return card;}
    private void settingRow(LinearLayout card,String icon,int iconColor,String title,String subtitle,Runnable action){
        LinearLayout row=horizontal();row.setPadding(dp(10),dp(9),dp(8),dp(9));row.setBackground(shape(Color.TRANSPARENT,16));
        TextView badge=label(icon,22,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setBackground(shape(iconColor,13));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(42),dp(42));bp.rightMargin=dp(14);row.addView(badge,bp);
        LinearLayout words=vertical();TextView t=label(title,17,text);bold(t);words.addView(t);if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=label(subtitle,13,muted);sub.setMaxLines(2);sub.setEllipsize(TextUtils.TruncateAt.END);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(3);words.addView(sub,sp);}row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=label("›",29,muted);arrow.setGravity(Gravity.CENTER);row.addView(arrow,new LinearLayout.LayoutParams(dp(28),dp(42)));card.addView(row,new LinearLayout.LayoutParams(-1,-2));row.setOnClickListener(v->action.run());
    }
    private void sectionTitle(String value){TextView t=label(value,13,muted);bold(t);t.setPadding(dp(5),0,0,dp(9));content.addView(t);}
    private Switch settingSwitch(String title,String subtitle,boolean checked){
        LinearLayout wrap=vertical();wrap.setPadding(dp(4),dp(4),dp(4),dp(4));Switch sw=new Switch(this);sw.setText(title);sw.setTextColor(text);sw.setTextSize(16);sw.setChecked(checked);wrap.addView(sw,new LinearLayout.LayoutParams(-1,dp(52)));if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=label(subtitle,13,muted);sub.setPadding(dp(4),0,dp(4),dp(10));wrap.addView(sub);}content.addView(wrap);return sw;
    }
    private long folderSize(File f){if(f==null||!f.exists())return 0;if(f.isFile())return f.length();long n=0;File[] files=f.listFiles();if(files!=null)for(File x:files)n+=folderSize(x);return n;}
    private String humanBytes(long n){if(n<1024)return n+" Б";if(n<1024*1024)return String.format(Locale.ROOT,"%.1f КБ",n/1024.0);return String.format(Locale.ROOT,"%.1f МБ",n/(1024.0*1024.0));}
    private boolean deleteTree(File f){if(f==null||!f.exists())return true;boolean ok=true;if(f.isDirectory()){File[] files=f.listFiles();if(files!=null)for(File x:files)ok&=deleteTree(x);}return f.delete()&&ok;}
    private Set<String> importantChats(){Set<String> out=new HashSet<>();String raw=prefs.getString("important_chats","");if(raw!=null&&!raw.trim().isEmpty())for(String id:raw.split(","))if(!id.trim().isEmpty())out.add(id.trim());return out;}
    private boolean isImportantChat(String id){return importantChats().contains(id);}
    private void setImportantChat(String id,boolean on){Set<String> set=importantChats();if(on)set.add(id);else set.remove(id);StringBuilder b=new StringBuilder();for(String v:set){if(b.length()>0)b.append(',');b.append(v);}prefs.edit().putString("important_chats",b.toString()).apply();}
    private void showSettings(){
        begin("settings");toolbar("Настройки",false,null,null);scrollContent();
        String name=prefs.getString("name","Пользователь Muwahid"),user=prefs.getString("username","");
        sectionTitle("ОСНОВНЫЕ");
        LinearLayout main=settingsCard();
        settingRow(main,"●",Color.rgb(32,151,225),"Аккаунт",user.isEmpty()?name:name+" · @"+user,this::showAccountSettings);
        settingRow(main,"✦",Color.rgb(235,155,24),"Настройки чатов","Тема, размер текста, вид сообщений",this::showChatSettings);
        settingRow(main,"◆",Color.rgb(42,190,91),"Конфиденциальность","Защита аккаунта и второй фактор",this::showSecurity);
        settingRow(main,"♪",Color.rgb(235,70,95),"Уведомления","Сообщения, звонки и системные настройки",this::showNotificationSettings);
        settingRow(main,"▣",Color.rgb(71,111,225),"Данные и память","Кэш расшифрованных медиафайлов",this::showDataSettings);
        settingRow(main,"□",Color.rgb(31,161,214),"Папки с чатами","Все чаты и папка «Важные»",this::showFolderSettings);
        settingRow(main,"▤",Color.rgb(38,171,190),"Устройства","Текущий телефон и другие сеансы",this::showDevices);
        settingRow(main,"▱",Color.rgb(239,119,31),"Энергосбережение",prefs.getBoolean("energy_saver",false)?"Включено":"Выключено",this::showEnergySettings);
        settingRow(main,"◎",Color.rgb(165,73,217),"Язык","Русский",this::showLanguageSettings);
        gap(content,22);sectionTitle("MUWAHID");
        LinearLayout services=settingsCard();
        settingRow(services,"★",Color.rgb(126,87,235),"Premium Muwahid","Дополнительные возможности",this::showPremium);
        settingRow(services,"★",Color.rgb(237,155,20),"Чат с владельцем","Прямая переписка с владельцем Muwahid",this::openOwnerChat);
        settingRow(services,"▦",Color.rgb(227,70,86),"Business Muwahid","Инструменты для бизнес-профиля",this::showBusiness);
        settingRow(services,"■",Color.rgb(236,119,40),"Отправить подарок","Подарки Muwahid",this::showGift);
        bottom("Настройки");
    }
    private void showChatSettings(){
        begin("chat_settings");toolbar("Настройки чатов",true,null,null);scrollContent();
        Switch dark=settingSwitch("Тёмная тема","Меняет оформление всего приложения.",prefs.getBoolean("dark",true));
        dark.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("dark",on).apply();b.post(this::showChatSettings);});
        gap(content,10);
        LinearLayout card=settingsCard();
        String size=String.valueOf(prefs.getInt("message_text_size",16));
        settingRow(card,"Aa",Color.rgb(31,161,214),"Размер текста сообщений",size+" sp",()->{
            String[] values={"Мелкий · 14","Обычный · 16","Крупный · 18"};
            new AlertDialog.Builder(this).setTitle("Размер текста").setItems(values,(d,w)->{int v=w==0?14:w==1?16:18;prefs.edit().putInt("message_text_size",v).apply();showChatSettings();}).show();
        });
        gap(content,14);
        Switch compact=settingSwitch("Компактные сообщения","Уменьшает внутренние отступы в сообщениях.",prefs.getBoolean("compact_bubbles",false));
        compact.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean("compact_bubbles",on).apply());
    }
    private void showNotificationSettings(){
        begin("notifications");toolbar("Уведомления",true,null,null);scrollContent();
        Switch messages=settingSwitch("Уведомления о сообщениях","Показывать уведомления о новых сообщениях.",prefs.getBoolean("notify_messages",true));
        Switch calls=settingSwitch("Уведомления о звонках","Показывать входящие аудио- и видеозвонки.",prefs.getBoolean("notify_calls",true));
        messages.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("notify_messages",on).apply();maybeStartNotifications();});
        calls.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("notify_calls",on).apply();maybeStartNotifications();});
        gap(content,18);Button system=button("Системные настройки уведомлений");content.addView(system,new LinearLayout.LayoutParams(-1,dp(54)));system.setOnClickListener(v->{
            try{Intent i=new Intent("android.settings.APP_NOTIFICATION_SETTINGS");i.putExtra("android.provider.extra.APP_PACKAGE",getPackageName());startActivity(i);}catch(Exception e){notice("Не удалось открыть системные настройки уведомлений.");}
        });
    }
    private void showDataSettings(){
        begin("data_settings");toolbar("Данные и память",true,null,null);scrollContent();
        File media=new File(getCacheDir(),"media");long bytes=folderSize(media);
        note(content,"Кэш медиа: "+humanBytes(bytes)+"\nСюда временно сохраняются расшифрованные файлы, которые вы открывали в чатах.");gap(content,18);
        Button clear=button("Очистить кэш медиа");content.addView(clear,new LinearLayout.LayoutParams(-1,dp(54)));clear.setEnabled(bytes>0);clear.setOnClickListener(v->{
            boolean ok=deleteTree(media);Toast.makeText(this,ok?"Кэш очищен":"Не удалось полностью очистить кэш",Toast.LENGTH_SHORT).show();showDataSettings();
        });
        gap(content,18);note(content,"Сообщения на сервере этим действием не удаляются. Черновики, заметки и данные входа также сохраняются.");
    }
    private void showFolderSettings(){
        begin("folders");toolbar("Папки с чатами",true,null,null);scrollContent();
        int count=importantChats().size();note(content,"Папка «Важные» содержит "+count+" чат(ов). Чтобы добавить или убрать чат, удерживайте его в списке чатов.");gap(content,18);
        Button open=button("Открыть папку «Важные»");content.addView(open,new LinearLayout.LayoutParams(-1,dp(54)));open.setOnClickListener(v->{chatFolderFilter="important";prefs.edit().putString("chat_folder","important").apply();showChats();});
        gap(content,12);Button all=button("Показать все чаты");content.addView(all,new LinearLayout.LayoutParams(-1,dp(54)));all.setOnClickListener(v->{chatFolderFilter="all";prefs.edit().putString("chat_folder","all").apply();showChats();});
        if(count>0){gap(content,12);Button clear=button("Очистить папку «Важные»");content.addView(clear,new LinearLayout.LayoutParams(-1,dp(54)));clear.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Убрать все чаты из папки «Важные»?").setNegativeButton("Отмена",null).setPositiveButton("Очистить",(d,w)->{prefs.edit().remove("important_chats").apply();showFolderSettings();}).show());}
    }
    private void showDevices(){
        begin("devices");toolbar("Устройства",true,null,null);scrollContent();
        String model=Build.MANUFACTURER+" "+Build.MODEL;note(content,"Текущий сеанс\n"+model+"\nAndroid "+Build.VERSION.RELEASE);gap(content,20);
        if(!api.signedIn()){note(content,"Войдите в аккаунт, чтобы управлять активными сеансами.");return;}
        Button others=button("Завершить другие сеансы");content.addView(others,new LinearLayout.LayoutParams(-1,dp(54)));others.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Завершить все другие сеансы Muwahid? Текущий телефон останется в аккаунте.").setNegativeButton("Отмена",null).setPositiveButton("Завершить",(d,w)->{
            others.setEnabled(false);async(()->{api.logoutOthers();return Boolean.TRUE;},r->{Toast.makeText(this,"Другие сеансы завершены",Toast.LENGTH_SHORT).show();showDevices();});
        }).show());
    }
    private void showEnergySettings(){
        begin("energy");toolbar("Энергосбережение",true,null,null);scrollContent();
        Switch saver=settingSwitch("Экономить заряд","Уменьшает частоту фонового обновления чатов и уведомлений.",prefs.getBoolean("energy_saver",false));
        saver.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("energy_saver",on).apply();try{NotificationService.stop(this);}catch(Exception ignored){}maybeStartNotifications();});
        gap(content,18);note(content,"В режиме энергосбережения обновление списка чатов выполняется реже. Входящие события могут появляться с небольшой дополнительной задержкой.");
    }
    private void showLanguageSettings(){
        begin("language");toolbar("Язык",true,null,null);scrollContent();
        LinearLayout card=settingsCard();settingRow(card,"RU",Color.rgb(165,73,217),"Русский","Текущий язык интерфейса",()->Toast.makeText(this,"Русский уже выбран",Toast.LENGTH_SHORT).show());
        gap(content,18);note(content,"Другие языки появятся после полной локализации интерфейса. Приложение не будет притворяться переведённым частично.");
    }
    private void showPremium(){
        begin("premium");toolbar("Premium Muwahid",true,null,null);scrollContent();
        note(content,"Раздел Premium подготовлен в настройках. Покупка пока не включена: в версии 0.8.4 нет подключённой платёжной системы и серверной проверки подписки.");gap(content,18);
        note(content,"Когда Premium будет подключён, оплата и статус подписки будут проверяться через официальный механизм магазина приложений, а не локальным переключателем.");
    }
    private void showBusiness(){
        begin("business");toolbar("Business Muwahid",true,null,null);scrollContent();
        note(content,"Раздел Business Muwahid добавлен в меню. Публичные бизнес-профили, категории и права для сотрудников требуют отдельной серверной модели и пока не включены в 0.8.4.");
    }
    private void showGift(){
        begin("gift");toolbar("Отправить подарок",true,null,null);scrollContent();
        note(content,"Подарки появятся после подключения Premium и безопасной оплаты. Сейчас списание денег или фиктивная отправка подарка не выполняются.");
    }
    private void openOwnerChat(){
        if(!api.signedIn()){showAuth(false);return;}
        if(OWNER_UUID.equals(api.uid())){notice("Вы вошли в аккаунт владельца Muwahid.");return;}
        async(()->{Object id=api.rpc("mw_start_chat",new JSONObject().put("p_person",OWNER_UUID));return id;},r->showChat(String.valueOf(r),"Владелец Muwahid"));
    }
    private void showWelcome(){begin("welcome");FrameLayout scene=new FrameLayout(this);scene.setBackgroundColor(Color.parseColor("#06101B"));ImageView hero=new ImageView(this);hero.setImageResource(R.drawable.muwahid_main_logo);hero.setScaleType(ImageView.ScaleType.CENTER_INSIDE);hero.setAdjustViewBounds(true);hero.setContentDescription("Логотип Muwahid");int heroPad=dp(18);hero.setPadding(heroPad,heroPad,heroPad,heroPad);scene.addView(hero,new FrameLayout.LayoutParams(-1,-1));root.addView(scene,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=vertical();actions.setPadding(dp(28),dp(8),dp(28),dp(26));Button start=button("Начать общение");actions.addView(start,new LinearLayout.LayoutParams(-1,dp(54)));start.setOnClickListener(v->{if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён. Сейчас можно использовать «Избранное» для личных заметок. Регистрация и переписка появятся после подключения сервера.");});
        TextView saved=label("Открыть личные заметки",15,accent);saved.setGravity(Gravity.CENTER);saved.setPadding(0,dp(19),0,dp(15));actions.addView(saved);saved.setOnClickListener(v->showNotes());
        TextView state=label(api.configured()?"Muwahid 0.8.4 • телефон, Google, медиа, звонки и уведомления":"Muwahid 0.8.4 • сервер пока не подключён",12,muted);state.setGravity(Gravity.CENTER);actions.addView(state);root.addView(actions);
    }
    private void showAuth(boolean register){phoneRegisterMode=register;begin("auth");toolbar(register?"Регистрация":"Вход",true,null,null);scrollContent();
        note(content,"Вход по номеру телефона. Введите номер в международном формате, например +491701234567. Muwahid отправит одноразовый SMS-код.");gap(content,24);
        EditText name=register?field("Ваше имя",false):null;EditText phone=field("Номер телефона: +...",false);phone.setInputType(3);
        Button submit=button("Получить SMS-код");content.addView(submit,new LinearLayout.LayoutParams(-1,dp(54)));submit.setOnClickListener(v->{String number=normalizePhone(phone.getText().toString());
            if(number==null){phone.setError("Введите номер в формате +кодстранынoмер");return;}if(register&&name.getText().toString().trim().isEmpty()){name.setError("Укажите имя");return;}
            String enteredName=register?name.getText().toString().trim():"";submit.setEnabled(false);final int stamp=generation;worker.execute(()->{try{api.sendPhoneOtp(number,enteredName,register);handler.post(()->{if(stamp!=generation)return;showPhoneCode(number,enteredName,register);});}catch(Exception ex){handler.post(()->{if(stamp==generation){submit.setEnabled(true);error(ex);}});}});
        });
        gap(content,16);TextView or=label("или",14,muted);or.setGravity(Gravity.CENTER);content.addView(or);gap(content,12);
        Button google=button("Продолжить с Google");content.addView(google,new LinearLayout.LayoutParams(-1,dp(54)));google.setOnClickListener(v->openGoogleLogin());
        gap(content,20);TextView change=label(register?"Уже есть аккаунт? Войти":"Нет аккаунта? Зарегистрироваться",15,accent);change.setGravity(Gravity.CENTER);content.addView(change);change.setOnClickListener(v->showAuth(!register));gap(content,22);
        note(content,"После подтверждения номера Muwahid создаёт защищённую учётную запись. Текст и медиа в личных чатах шифруются на телефоне.");
    }
    private void openGoogleLogin(){
        final int stamp=generation;
        worker.execute(()->{try{
            if(!api.googleProviderEnabled())throw new Exception("Google сейчас не активен на живом Auth-сервере Supabase. Проверьте Client ID, Client Secret и Save в провайдере Google.");
            final Uri url=Uri.parse(api.googleOAuthUrl());
            handler.post(()->{if(stamp!=generation)return;try{startActivity(new Intent(Intent.ACTION_VIEW,url));}catch(Exception e){error(e);}});
        }catch(Exception e){handler.post(()->{if(stamp==generation)error(e);});}});
    }
    private String normalizePhone(String raw){if(raw==null)return null;String p=raw.trim().replaceAll("[\\s()\\-]","");if(!p.matches("\\+[1-9][0-9]{7,14}"))return null;return p;}
    private void showPhoneCode(String phone,String name,boolean register){phoneRegisterMode=register;begin("otp");toolbar("Подтверждение номера",true,null,null);scrollContent();
        note(content,"SMS-код отправлен на "+phone+". Введите код из сообщения.");gap(content,20);EditText code=field("SMS-код",false);code.setInputType(2);code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        Button verify=button("Подтвердить и войти");content.addView(verify,new LinearLayout.LayoutParams(-1,dp(54)));verify.setOnClickListener(v->{String value=code.getText().toString().trim();if(!value.matches("[0-9]{4,8}")){code.setError("Введите код из SMS");return;}verify.setEnabled(false);final int stamp=generation;worker.execute(()->{try{api.verifyPhoneOtp(phone,value);try{api.rpc("mw_sync_my_phone",new JSONObject());}catch(Exception ignored){}handler.post(()->{if(stamp!=generation)return;maybeStartNotifications();showChats();});}catch(Exception ex){handler.post(()->{if(stamp==generation){verify.setEnabled(true);code.setText("");error(ex);}});}});});
        gap(content,18);TextView resend=label("Получить новый код",15,accent);resend.setGravity(Gravity.CENTER);content.addView(resend);resend.setOnClickListener(v->{worker.execute(()->{try{api.sendPhoneOtp(phone,name,register);handler.post(()->Toast.makeText(this,"Новый код отправлен",Toast.LENGTH_SHORT).show());}catch(Exception e){handler.post(()->error(e));}});});
    }
    private void showChats(){begin("chats");chatFolderFilter=prefs.getString("chat_folder","all");if(api.signedIn())maybeStartNotifications();toolbar("Muwahid",false,"+",this::newChat);
        LinearLayout searchWrap=vertical();searchWrap.setPadding(dp(18),dp(14),dp(18),dp(8));EditText search=new EditText(this);search.setSingleLine(true);search.setTextSize(15);search.setTextColor(text);search.setHintTextColor(muted);search.setHint("Поиск по вашим чатам");search.setBackground(shape(panel,16));search.setPadding(dp(16),dp(10),dp(16),dp(10));searchWrap.addView(search,new LinearLayout.LayoutParams(-1,dp(46)));root.addView(searchWrap);
        LinearLayout folderBar=horizontal();folderBar.setPadding(dp(18),0,dp(18),dp(10));
        TextView allFolder=label("Все",14,"all".equals(chatFolderFilter)?Color.WHITE:muted);allFolder.setGravity(Gravity.CENTER);allFolder.setBackground(shape("all".equals(chatFolderFilter)?Color.rgb(7,119,104):panel,15));folderBar.addView(allFolder,new LinearLayout.LayoutParams(0,dp(38),1));
        Space fs=new Space(this);folderBar.addView(fs,new LinearLayout.LayoutParams(dp(8),1));
        TextView importantFolder=label("★ Важные",14,"important".equals(chatFolderFilter)?Color.WHITE:muted);importantFolder.setGravity(Gravity.CENTER);importantFolder.setBackground(shape("important".equals(chatFolderFilter)?Color.rgb(7,119,104):panel,15));folderBar.addView(importantFolder,new LinearLayout.LayoutParams(0,dp(38),1));
        allFolder.setOnClickListener(v->{chatFolderFilter="all";prefs.edit().putString("chat_folder","all").apply();showChats();});
        importantFolder.setOnClickListener(v->{chatFolderFilter="important";prefs.edit().putString("chat_folder","important").apply();showChats();});
        root.addView(folderBar);
        connection=label(api.signedIn()?"Обновляем переписку…":"Войдите, чтобы общаться",12,muted);connection.setPadding(dp(22),0,dp(20),dp(8));root.addView(connection);
        ScrollView sv=new ScrollView(this);list=vertical();sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));bottom("Чаты");filter="";drawChatList();
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){filter=s.toString().toLowerCase(Locale.ROOT);drawChatList();}public void afterTextChanged(Editable e){}});
        if(api.signedIn()){publishE2eeIdentity();loadChats(true);}else connection.setOnClickListener(v->{if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");});
    }
    private void loadChats(boolean report){if(loading)return;final int stamp=generation;loading=true;worker.execute(()->{try{JSONArray result=(JSONArray)api.rpc("mw_chat_list",new JSONObject());handler.post(()->{loading=false;if(stamp!=generation)return;chats=result;connection.setText(prefs.getBoolean("energy_saver",false)?"Личные чаты · энергосбережение включено":"Личные чаты · обновление каждые 5 секунд");drawChatList();});}catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;connection.setText("Нет связи · нажмите, чтобы повторить");connection.setOnClickListener(v->loadChats(true));if(report)error(e);});}});}
    private void avatar(LinearLayout row,String name,int color){TextView a=label(name.isEmpty()?"M":name.substring(0,1).toUpperCase(Locale.ROOT),23,Color.WHITE);a.setGravity(Gravity.CENTER);bold(a);a.setBackground(shape(color,27));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(52),dp(52));p.rightMargin=dp(13);row.addView(a,p);}
    private void drawChatList(){if(list==null||!screen.equals("chats"))return;list.removeAllViews();int shown=0;
        for(int i=0;i<chats.length();i++){JSONObject c=chats.optJSONObject(i);if(c==null)continue;String name=c.optString("display_name"),cid=c.optString("id");if("important".equals(chatFolderFilter)&&!isImportantChat(cid))continue;if(!name.toLowerCase(Locale.ROOT).contains(filter)&&!c.optString("username").contains(filter))continue;shown++;
            LinearLayout row=horizontal();row.setPadding(dp(20),dp(13),dp(20),dp(13));avatar(row,name,Color.rgb(26,111+(i%3)*22,132));LinearLayout words=vertical();TextView title=label(name,17,text);bold(title);words.addView(title);gap(words,5);TextView preview=label(c.isNull("last_message")?"Начните переписку":c.optString("last_message"),14,muted);preview.setMaxLines(1);preview.setEllipsize(TextUtils.TruncateAt.END);words.addView(preview);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));TextView time=label(time(c.optString("updated_at")),11,muted);row.addView(time);list.addView(row);row.setOnClickListener(v->showChat(c.optString("id"),name));row.setOnLongClickListener(v->{String id=c.optString("id");boolean important=isImportantChat(id);new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{important?"Убрать из «Важных»":"Добавить в «Важные»"},(d,w)->{setImportantChat(id,!important);drawChatList();}).show();return true;});
        }
        if(shown==0){LinearLayout empty=vertical();empty.setPadding(dp(30),dp(60),dp(30),dp(30));TextView mark=label("✦",48,accent);mark.setGravity(Gravity.CENTER);empty.addView(mark);gap(empty,20);TextView title=label(filter.isEmpty()?("important".equals(chatFolderFilter)?"В папке «Важные» пока пусто":"Здесь начнётся общение"):"Чаты не найдены",21,text);bold(title);title.setGravity(Gravity.CENTER);empty.addView(title);gap(empty,12);TextView desc=label(api.signedIn()?("important".equals(chatFolderFilter)?"Удерживайте нужный чат и добавьте его в «Важные».":"Нажмите + и введите номер телефона или имя пользователя друга."):"Для переписки нужен вход в аккаунт. Личные заметки доступны без интернета.",15,muted);desc.setGravity(Gravity.CENTER);desc.setLineSpacing(dp(4),1);empty.addView(desc);list.addView(empty);}
    }
    private void newChat(){if(!api.signedIn()){if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");return;}
        EditText user=new EditText(this);user.setSingleLine(true);user.setHint("+номер телефона или @имя");user.setPadding(dp(24),dp(16),dp(24),dp(16));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Новый чат").setView(user).setNegativeButton("Отмена",null).setPositiveButton("Найти",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(w->{String query=user.getText().toString().trim();if(query.isEmpty()){user.setError("Введите номер или имя");return;}dialog.dismiss();async(()->{
            Object found=api.rpc("mw_find_person_any",new JSONObject().put("p_query",query));if(!(found instanceof JSONObject))throw new Exception("Пользователь не найден. Проверьте номер или имя.");JSONObject person=(JSONObject)found;Object id=api.rpc("mw_start_chat",new JSONObject().put("p_person",person.getString("id")));return new JSONObject().put("id",id).put("name",person.getString("display_name"));
        },v2->{JSONObject c=(JSONObject)v2;showChat(c.getString("id"),c.getString("name"));});}));dialog.show();
    }
    private void showChat(String id,String name){notesMode=false;openConversation(id,name);prepareE2eeChat();}
    private void publishE2eeIdentity(){
        if(!api.signedIn()||e2eePublishing||api.uid().equals(e2eePublishedFor))return;
        e2eePublishing=true;final String uid=api.uid();
        worker.execute(()->{try{String key=crypto.publicKey(uid);api.rpc("mw_e2ee_set_key",new JSONObject().put("p_public_key",key));e2eePublishedFor=uid;}catch(Exception ignored){}finally{e2eePublishing=false;}});
    }
    private void prepareE2eeChat(){
        final int stamp=generation;final String id=chatId,uid=api.uid();loading=true;connection.setText("Подготавливаем сквозное шифрование…");
        worker.execute(()->{try{
            String own=crypto.publicKey(uid);api.rpc("mw_e2ee_set_key",new JSONObject().put("p_public_key",own));e2eePublishedFor=uid;
            Object value=api.rpc("mw_e2ee_peer_key",new JSONObject().put("p_chat",id));final String peer=value instanceof String?(String)value:"";
            handler.post(()->{loading=false;if(stamp!=generation)return;e2eeBackendReady=true;peerE2eeKey=peer;connection.setText(chatSecurityStatus());loadMessages(true);});
        }catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;e2eeBackendReady=false;peerE2eeKey="";connection.setText(chatSecurityStatus());if(e instanceof Api.MfaRequiredException)error(e);else loadMessages(true);});}});
    }
    private String chatSecurityStatus(){
        if(e2eeBackendReady&&!peerE2eeKey.isEmpty())return "🔒 Сквозное шифрование активно";
        if(e2eeBackendReady)return "🔒 Собеседник ещё не активировал E2EE";
        return "Личная переписка · E2EE на сервере ещё не готово";
    }
    private void showNotes(){notesMode=true;openConversation("local-notes","Избранное");drawNotes();}
    private void openConversation(String id,String name){begin("chat");chatId=id;chatName=name;history.clear();pendingNonce="";pendingText="";pendingPayload="";peerE2eeKey="";e2eeBackendReady=false;toolbar(name,true,notesMode?null:"☎",notesMode?null:this::chooseCall);
        connection=label(notesMode?"Личные заметки · только на этом телефоне":"Загрузка сообщений…",12,muted);connection.setPadding(dp(22),dp(10),dp(16),dp(10));root.addView(connection);
        messageScroll=new ScrollView(this);messageScroll.setFillViewport(true);messages=vertical();messages.setPadding(dp(12),dp(10),dp(12),dp(14));messageScroll.addView(messages);root.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout compose=horizontal();compose.setPadding(dp(10),dp(8),dp(10),dp(10));compose.setBackgroundColor(panel);
        if(!notesMode){
            emojiButton=button("😀");emojiButton.setContentDescription("Смайлики");emojiButton.setTextSize(20);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(dp(44),dp(48));ep.rightMargin=dp(6);compose.addView(emojiButton,ep);emojiButton.setOnClickListener(v->showEmojiPicker());
        }
        composer=new EditText(this);composer.setHint("Сообщение");composer.setHintTextColor(muted);composer.setTextColor(text);composer.setTextSize(16);composer.setMaxLines(5);composer.setInputType(131073);composer.setPadding(dp(14),dp(10),dp(14),dp(10));composer.setBackground(shape(bg,20));composer.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4000)});compose.addView(composer,new LinearLayout.LayoutParams(0,-2,1));
        if(!notesMode){
            attachButton=button("📎");attachButton.setContentDescription("Прикрепить фото, видео или аудио");attachButton.setTextSize(20);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(44),dp(48));ap.leftMargin=dp(6);compose.addView(attachButton,ap);attachButton.setOnClickListener(v->pickMedia());
            videoMessageButton=button("📹");videoMessageButton.setContentDescription("Записать видеосообщение");videoMessageButton.setTextSize(19);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(dp(44),dp(48));vp.leftMargin=dp(5);compose.addView(videoMessageButton,vp);videoMessageButton.setOnClickListener(v->recordVideoMessage());
        }
        sendButton=button(notesMode?"↑":"🎤");sendButton.setContentDescription(notesMode?"Отправить сообщение":"Записать голосовое сообщение");sendButton.setTextSize(20);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(48),dp(48));p.leftMargin=dp(6);compose.addView(sendButton,p);root.addView(compose);composer.setText(prefs.getString("draft:"+id,""));
        composer.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){updateComposeAction();}public void afterTextChanged(Editable e){}});
        sendButton.setOnClickListener(v->{if(notesMode||composer.getText().toString().trim().length()>0)send();else toggleVoiceRecording();});
        sendButton.setOnLongClickListener(v->{if(voiceRecording){cancelVoiceRecording(true);return true;}return false;});
        updateComposeAction();
    }
    private void saveDraft(){if(composer!=null&&screen.equals("chat"))prefs.edit().putString("draft:"+chatId,composer.getText().toString()).apply();}
    private void drawNotes(){messages.removeAllViews();try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));if(notes.length()==0){note(messages,"Сохраняйте идеи, списки и важные мысли. Нажмите на заметку и удерживайте, чтобы скопировать или удалить её.");}for(int i=0;i<notes.length();i++){JSONObject n=notes.getJSONObject(i);TextView t=bubble(n.getString("body"),true,n.optString("time"));final int index=i;t.setOnLongClickListener(v->{new AlertDialog.Builder(this).setItems(new String[]{"Скопировать","Удалить"},(d,which)->{if(which==0)copy(n.optString("body"));else{notes.remove(index);prefs.edit().putString("notes",notes.toString()).apply();drawNotes();}}).show();return true;});}}catch(Exception e){error(e);}bottomScroll();}
    private TextView bubble(String body,boolean mine,String when){LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);int font=prefs.getInt("message_text_size",16);boolean compact=prefs.getBoolean("compact_bubbles",false);TextView t=label(body+"\n"+when,font,mine?Color.WHITE:text);t.setMaxWidth(dp(290));t.setPadding(dp(compact?10:14),dp(compact?7:11),dp(compact?10:14),dp(compact?6:9));t.setLineSpacing(dp(2),1);t.setBackground(shape(mine?Color.rgb(7,119,104):panel,17));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.setMargins(dp(mine?38:0),dp(compact?2:4),dp(mine?0:38),dp(compact?2:4));wrap.addView(t,p);messages.addView(wrap);t.setOnLongClickListener(v->{copy(body);return true;});return t;}
    private void copy(String value){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Muwahid",value));Toast.makeText(this,"Скопировано",Toast.LENGTH_SHORT).show();}
    private void bottomScroll(){messageScroll.post(()->messageScroll.fullScroll(View.FOCUS_DOWN));}
    private void loadMessages(boolean report){fetchMessages(null,report);}
    private void fetchMessages(Long before,boolean report){if(loading)return;loading=true;final int stamp=generation;final String id=chatId;
        worker.execute(()->{try{JSONObject args=new JSONObject().put("p_chat",id);if(before!=null)args.put("p_before",before);JSONArray result=(JSONArray)api.rpc("mw_messages_get",args);handler.post(()->{loading=false;if(stamp!=generation)return;
            boolean changed=false;for(int i=0;i<result.length();i++){JSONObject m=result.optJSONObject(i);if(m!=null&&!history.containsKey(m.optLong("id"))){history.put(m.optLong("id"),m);changed=true;}}
            if(before!=null||history.size()<=100)olderAvailable=result.length()==100;
            connection.setText(chatSecurityStatus());connection.setOnClickListener(null);
            if(changed||messages.getChildCount()==0)drawMessages(before==null);
        });}catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;connection.setText("Нет связи · нажмите для повтора");connection.setOnClickListener(v->loadMessages(true));if(report)error(e);});}});
    }
    private void drawMessages(boolean newest){int oldY=messageScroll.getScrollY();boolean nearBottom=messages.getHeight()-messageScroll.getHeight()-oldY<dp(100);messages.removeAllViews();
        if(olderAvailable&&!history.isEmpty()){TextView older=label("Загрузить предыдущие сообщения",14,accent);older.setGravity(Gravity.CENTER);older.setPadding(0,dp(12),0,dp(16));messages.addView(older);older.setOnClickListener(v->fetchMessages(history.firstKey(),true));}
        if(history.isEmpty())note(messages,"Пока сообщений нет. Напишите первым.");
        for(JSONObject m:history.values())drawMessage(m);
        if(newest&&(nearBottom||oldY==0))bottomScroll();
    }
    private String readableBody(JSONObject message){
        String body=message.optString("body");
        if(!body.startsWith("mw1:"))return body;
        if(peerE2eeKey.isEmpty())return "🔒 Зашифрованное сообщение · ключ собеседника недоступен";
        try{return crypto.decryptText(api.uid(),chatId,peerE2eeKey,body);}catch(Exception e){return "🔒 Не удалось расшифровать это сообщение";}
    }
    private void drawMessage(JSONObject m){
        boolean mine=m.optString("sender_id").equals(api.uid());String plain=readableBody(m);String when=time(m.optString("created_at"));
        try{if(plain.startsWith("{")&&plain.contains("\"mw_kind\":\"media\"")){
            JSONObject meta=new JSONObject(plain);String type=meta.optString("media_type","file");
            String icon=type.equals("image")?"🖼":type.equals("video")?"🎬":type.equals("video_message")?"📹":type.equals("voice")?"🎤":type.equals("audio")?"🎵":"📎";
            String title=type.equals("voice")?"Голосовое сообщение":type.equals("video_message")?"Видеосообщение":meta.optString("name","Файл");
            long duration=meta.optLong("duration_ms",0);if(duration>0)title+=" · "+formatDuration(duration);
            TextView t=bubble(icon+" "+title+"\n▶ Нажмите, чтобы открыть",mine,when);t.setOnClickListener(v->downloadMedia(meta));return;
        }}catch(Exception ignored){}
        bubble(plain,mine,when);
    }
    private void chooseCall(){
        if(!api.signedIn()){notice("Войдите в аккаунт");return;}
        new AlertDialog.Builder(this).setTitle("Позвонить "+chatName).setItems(new String[]{"Аудиозвонок","Видеозвонок"},(d,w)->startCall(w==0?"audio":"video")).show();
    }
    private void startCall(String kind){Intent i=new Intent(this,CallActivity.class);i.putExtra("chat_id",chatId);i.putExtra("peer_name",chatName);i.putExtra("kind",kind);i.putExtra("incoming",false);startActivity(i);}
    private void pickMedia(){
        if(!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для защищённой отправки файла собеседник должен использовать актуальную версию Muwahid с E2EE.");return;}
        new AlertDialog.Builder(this).setTitle("Отправить").setItems(new String[]{"Фото","Видео","Аудио"},(d,which)->{
            if(which==0)pickMediaType("image/*",REQ_IMAGE);
            else if(which==1)pickMediaType("video/*",REQ_VIDEO);
            else pickMediaType("audio/*",REQ_AUDIO);
        }).show();
    }
    private void pickMediaType(String mime,int requestCode){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);startActivityForResult(i,requestCode);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if((requestCode==REQ_IMAGE||requestCode==REQ_VIDEO||requestCode==REQ_AUDIO)&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadMedia(data.getData(),null);
        else if(requestCode==REQ_VIDEO_MESSAGE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadMedia(data.getData(),"video_message");
    }
    private void uploadMedia(Uri uri,String forcedType){
        if(sending)return;final String id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;setComposeEnabled(false);if(sendButton!=null)sendButton.setEnabled(false);connection.setText("Шифруем и загружаем файл…");
        worker.execute(()->{try{
            String mime=getContentResolver().getType(uri);if(mime==null)mime="application/octet-stream";String name=fileName(uri);byte[] raw=readUri(uri,24*1024*1024);byte[] encrypted=crypto.encryptBytes(uid,id,peer,raw);String path=id+"/"+UUID.randomUUID()+".bin";api.uploadMedia(path,encrypted);
            String type=forcedType!=null?forcedType:(mime.startsWith("image/")?"image":mime.startsWith("video/")?"video":mime.startsWith("audio/")?"audio":"file");
            JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type",type).put("name",type.equals("video_message")?"Видеосообщение.mp4":name).put("mime",mime).put("path",path).put("size",raw.length);
            String payload=crypto.encryptText(uid,id,peer,meta.toString());String nonce=UUID.randomUUID().toString();JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",nonce));
            handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});
        }catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());updateComposeAction();error(e);});}});
    }
    private void updateComposeAction(){
        if(sendButton==null||composer==null)return;
        if(notesMode){sendButton.setText("↑");sendButton.setContentDescription("Отправить сообщение");return;}
        if(voiceRecording){sendButton.setText("■");sendButton.setContentDescription("Остановить и отправить голосовое сообщение");return;}
        boolean hasText=composer.getText().toString().trim().length()>0;
        sendButton.setText(hasText?"↑":"🎤");sendButton.setContentDescription(hasText?"Отправить сообщение":"Записать голосовое сообщение");
    }
    private void showEmojiPicker(){
        final String[] emojis={"😀","😂","😊","😍","🥰","😎","🤔","😢","😭","😡","👍","👎","👏","🙏","❤️","💚","🔥","✨","🎉","✅","💯","🤝","👋","🌙","⭐","☕","📌","📎","🎤","📹"};
        new AlertDialog.Builder(this).setTitle("Смайлики").setItems(emojis,(d,which)->{
            if(composer==null)return;int start=Math.max(composer.getSelectionStart(),0);composer.getText().insert(start,emojis[which]);composer.requestFocus();
        }).show();
    }
    private void toggleVoiceRecording(){if(voiceRecording)stopVoiceRecording(true);else ensureVoicePermission();}
    private void ensureVoicePermission(){
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=getPackageManager().PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},REQ_RECORD_AUDIO_PERMISSION);return;
        }
        startVoiceRecording();
    }
    private void startVoiceRecording(){
        if(notesMode||voiceRecording||sending)return;
        if(!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для защищённой отправки голосового сообщения собеседник должен использовать актуальную версию Muwahid с E2EE.");return;}
        try{
            File dir=new File(getCacheDir(),"voice");dir.mkdirs();voiceFile=new File(dir,"voice_"+UUID.randomUUID()+".m4a");
            voiceRecorder=new MediaRecorder();voiceRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);voiceRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);voiceRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);voiceRecorder.setAudioEncodingBitRate(64000);voiceRecorder.setAudioSamplingRate(44100);voiceRecorder.setOutputFile(voiceFile.getAbsolutePath());voiceRecorder.prepare();voiceRecorder.start();
            voiceRecording=true;voiceStartedAt=System.currentTimeMillis();setComposeEnabled(false);updateComposeAction();handler.removeCallbacks(voiceTicker);handler.post(voiceTicker);
        }catch(Exception e){releaseVoiceRecorder();voiceRecording=false;if(voiceFile!=null)voiceFile.delete();voiceFile=null;setComposeEnabled(true);updateComposeAction();notice("Не удалось начать запись. Проверьте доступ к микрофону.");}
    }
    private void stopVoiceRecording(boolean sendAfter){
        if(!voiceRecording)return;handler.removeCallbacks(voiceTicker);long duration=System.currentTimeMillis()-voiceStartedAt;boolean ok=true;
        try{voiceRecorder.stop();}catch(Exception e){ok=false;}releaseVoiceRecorder();voiceRecording=false;setComposeEnabled(true);updateComposeAction();
        File recorded=voiceFile;voiceFile=null;if(!ok||recorded==null||!recorded.exists()||duration<700){if(recorded!=null)recorded.delete();if(connection!=null)connection.setText(chatSecurityStatus());if(sendAfter)Toast.makeText(this,"Запись слишком короткая",Toast.LENGTH_SHORT).show();return;}
        if(sendAfter)uploadRecordedVoice(recorded,duration);else{recorded.delete();if(connection!=null)connection.setText(chatSecurityStatus());}
    }
    private void cancelVoiceRecording(boolean showToast){
        if(!voiceRecording)return;handler.removeCallbacks(voiceTicker);try{voiceRecorder.stop();}catch(Exception ignored){}releaseVoiceRecorder();voiceRecording=false;File recorded=voiceFile;voiceFile=null;if(recorded!=null)recorded.delete();setComposeEnabled(true);updateComposeAction();if(connection!=null)connection.setText(chatSecurityStatus());if(showToast)Toast.makeText(this,"Запись отменена",Toast.LENGTH_SHORT).show();
    }
    private void releaseVoiceRecorder(){if(voiceRecorder!=null){try{voiceRecorder.reset();}catch(Exception ignored){}try{voiceRecorder.release();}catch(Exception ignored){}voiceRecorder=null;}}
    private void setComposeEnabled(boolean enabled){if(composer!=null)composer.setEnabled(enabled);if(attachButton!=null)attachButton.setEnabled(enabled);if(emojiButton!=null)emojiButton.setEnabled(enabled);if(videoMessageButton!=null)videoMessageButton.setEnabled(enabled);}
    private void uploadRecordedVoice(File recorded,long duration){
        if(sending){recorded.delete();return;}final String id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;if(sendButton!=null)sendButton.setEnabled(false);if(attachButton!=null)attachButton.setEnabled(false);if(videoMessageButton!=null)videoMessageButton.setEnabled(false);if(emojiButton!=null)emojiButton.setEnabled(false);connection.setText("Шифруем и отправляем голосовое сообщение…");
        worker.execute(()->{try{
            byte[] raw=readFile(recorded,24*1024*1024);byte[] encrypted=crypto.encryptBytes(uid,id,peer,raw);String path=id+"/"+UUID.randomUUID()+".bin";api.uploadMedia(path,encrypted);
            JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type","voice").put("name","Голосовое сообщение.m4a").put("mime","audio/mp4").put("path",path).put("size",raw.length).put("duration_ms",duration);
            String payload=crypto.encryptText(uid,id,peer,meta.toString());String nonce=UUID.randomUUID().toString();JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",nonce));recorded.delete();
            handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});
        }catch(Exception e){recorded.delete();handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());updateComposeAction();error(e);});}});
    }
    private byte[] readFile(File file,int max) throws Exception{if(file.length()>max)throw new Exception("Максимальный размер файла — 24 МБ");ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=new FileInputStream(file)){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}return out.toByteArray();}
    private String formatDuration(long ms){long total=Math.max(0,ms/1000),m=total/60,s=total%60;return String.format(Locale.getDefault(),"%d:%02d",m,s);}
    private void recordVideoMessage(){
        if(sending||voiceRecording)return;if(!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для защищённой отправки видеосообщения собеседник должен использовать актуальную версию Muwahid с E2EE.");return;}
        if(Build.VERSION.SDK_INT>=23&&(checkSelfPermission(android.Manifest.permission.CAMERA)!=getPackageManager().PERMISSION_GRANTED||checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=getPackageManager().PERMISSION_GRANTED)){
            requestPermissions(new String[]{android.Manifest.permission.CAMERA,android.Manifest.permission.RECORD_AUDIO},REQ_VIDEO_MESSAGE_PERMISSION);return;
        }
        startVideoMessageCapture();
    }
    private void startVideoMessageCapture(){
        try{Intent i=new Intent(MediaStore.ACTION_VIDEO_CAPTURE);i.putExtra(MediaStore.EXTRA_DURATION_LIMIT,60);i.putExtra(MediaStore.EXTRA_VIDEO_QUALITY,0);startActivityForResult(i,REQ_VIDEO_MESSAGE);}catch(Exception e){notice("На телефоне не найдено приложение камеры для записи видео.");}
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_RECORD_AUDIO_PERMISSION){if(grantResults.length>0&&grantResults[0]==getPackageManager().PERMISSION_GRANTED)startVoiceRecording();else notice("Без доступа к микрофону голосовое сообщение записать нельзя.");}
        else if(requestCode==REQ_VIDEO_MESSAGE_PERMISSION){boolean ok=grantResults.length>=2;for(int value:grantResults)ok&=value==getPackageManager().PERMISSION_GRANTED;if(ok)startVideoMessageCapture();else notice("Для видеосообщения нужен доступ к камере и микрофону.");}
    }
    private String fileName(Uri uri){String name="Файл";try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())name=c.getString(0);}catch(Exception ignored){}return name==null?"Файл":name.replaceAll("[\r\n]"," ");}
    private byte[] readUri(Uri uri,int max) throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new Exception("Не удалось открыть файл");byte[] b=new byte[16384];int n,total=0;while((n=in.read(b))!=-1){total+=n;if(total>max)throw new Exception("Максимальный размер файла — 24 МБ");out.write(b,0,n);}}return out.toByteArray();}
    private void downloadMedia(JSONObject meta){final int stamp=generation;connection.setText("Скачиваем и расшифровываем файл…");worker.execute(()->{try{byte[] encrypted=api.downloadMedia(meta.getString("path"));byte[] raw=crypto.decryptBytes(api.uid(),chatId,peerE2eeKey,encrypted);File dir=new File(getCacheDir(),"media");dir.mkdirs();String safe=meta.optString("name","file").replaceAll("[^A-Za-zА-Яа-я0-9._ -]","_");File f=new File(dir,UUID.randomUUID()+"_"+safe);try(FileOutputStream out=new FileOutputStream(f)){out.write(raw);}Uri content=FileProvider.getUriForFile(this,getPackageName()+".files",f);Intent open=new Intent(Intent.ACTION_VIEW);open.setDataAndType(content,meta.optString("mime","application/octet-stream"));open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);handler.post(()->{if(stamp!=generation)return;connection.setText(chatSecurityStatus());try{startActivity(open);}catch(Exception x){notice("На телефоне нет приложения для открытия этого файла.");}});}catch(Exception e){handler.post(()->{if(stamp!=generation)return;connection.setText(chatSecurityStatus());error(e);});}});}
    private void send(){if(sending)return;String body=composer.getText().toString().trim();if(body.isEmpty())return;
        if(notesMode){try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));notes.put(new JSONObject().put("body",body).put("time",new SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new Date())));if(!prefs.edit().putString("notes",notes.toString()).commit())throw new Exception("Не удалось сохранить заметку");composer.setText("");saveDraft();drawNotes();}catch(Exception e){error(e);}return;}
        if(!e2eeBackendReady){notice("Защищённая отправка ещё не готова на сервере Muwahid. Проверьте серверные функции E2EE в Supabase.");return;}
        if(peerE2eeKey.isEmpty()){notice("Собеседник ещё не активировал E2EE в Muwahid. Незашифрованная отправка заблокирована, чтобы не снижать защиту.");return;}
        if(!body.equals(pendingText)){pendingText=body;pendingNonce=UUID.randomUUID().toString();pendingPayload="";}
        final String nonce=pendingNonce,id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;setComposeEnabled(false);sendButton.setEnabled(false);
        worker.execute(()->{try{
            String payload=pendingPayload;if(payload.isEmpty()){payload=crypto.encryptText(uid,id,peer,body);pendingPayload=payload;}
            JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",nonce));
            handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);composer.setText("");saveDraft();pendingNonce="";pendingText="";pendingPayload="";history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});
        }catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);updateComposeAction();error(e);});}});
    }
    private String time(String source){if(source==null||source.isEmpty()||source.equals("null"))return "";try{String s=source.substring(0,19);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(d);}catch(Exception e){return "";}}
    private void showAccountSettings(){begin("account");toolbar("Аккаунт",true,null,null);scrollContent();
        String name=prefs.getString("name","Пользователь Muwahid");TextView a=label(name.substring(0,1).toUpperCase(Locale.ROOT),44,accent);a.setGravity(Gravity.CENTER);a.setBackground(shape(panel,40));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(82),dp(82));ap.gravity=Gravity.CENTER;content.addView(a,ap);gap(content,20);
        EditText nameField=field("Ваше имя",false);nameField.setText(name);EditText username=field("Имя пользователя",false);username.setText(prefs.getString("username",""));username.setInputType(1|524288);username.setEnabled(api.signedIn());
        Button save=button("Сохранить профиль");content.addView(save,new LinearLayout.LayoutParams(-1,dp(50)));save.setOnClickListener(v->{String n=nameField.getText().toString().trim(),u=username.getText().toString().trim().toLowerCase(Locale.ROOT);if(n.isEmpty()||n.length()>60){nameField.setError("От 1 до 60 символов");return;}if(api.signedIn()){async(()->api.rpc("mw_update_profile",new JSONObject().put("p_name",n).put("p_username",u)),result->{prefs.edit().putString("name",n).putString("username",u).apply();Toast.makeText(this,"Профиль сохранён",Toast.LENGTH_SHORT).show();});}else{prefs.edit().putString("name",n).apply();Toast.makeText(this,"Имя сохранено на телефоне",Toast.LENGTH_SHORT).show();}});
        if(api.signedIn())async(()->api.rpc("mw_me",new JSONObject()),result->{if(result instanceof JSONObject){profile=(JSONObject)result;nameField.setText(profile.optString("display_name"));username.setText(profile.optString("username"));prefs.edit().putString("name",profile.optString("display_name")).putString("username",profile.optString("username")).apply();}});
        gap(content,16);if(api.signedIn()){TextView share=label("Поделиться моим именем пользователя",15,accent);share.setPadding(0,dp(10),0,dp(10));content.addView(share);share.setOnClickListener(v->{String u=prefs.getString("username","");if(u.isEmpty())return;Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("text/plain");intent.putExtra(Intent.EXTRA_TEXT,"Найди меня в Muwahid: @"+u);startActivity(Intent.createChooser(intent,"Поделиться"));});}else note(content,api.configured()?"Войдите в аккаунт, чтобы получать сообщения.":"Сервер пока не подключён. Профиль и заметки сохраняются на этом телефоне.");
        if(api.signedIn()) {gap(content,18);Button security=button("Защита аккаунта");content.addView(security,new LinearLayout.LayoutParams(-1,dp(58)));security.setOnClickListener(v->showSecurity());}
        gap(content,20);Switch dark=new Switch(this);dark.setText("Тёмная тема");dark.setTextColor(text);dark.setTextSize(16);dark.setChecked(prefs.getBoolean("dark",true));content.addView(dark,new LinearLayout.LayoutParams(-1,dp(52)));dark.setOnCheckedChangeListener((b,checked)->{prefs.edit().putBoolean("dark",checked).apply();b.post(this::showAccountSettings);});
        gap(content,18);note(content,"Muwahid 0.8.5\nРегистрация по телефону, личные E2EE-чаты, голосовые и видеосообщения, смайлики, отправка фото, видео и аудио, аудио- и видеозвонки, а также уведомления.");gap(content,20);note(content,"Текст и медиа шифруются на телефоне AES-GCM. WebRTC-звонки защищены DTLS-SRTP. Для надёжной связи в некоторых мобильных и корпоративных сетях позже понадобится TURN-сервер.");gap(content,24);
        Button exit=button(api.signedIn()?"Выйти из аккаунта":"К началу");content.addView(exit,new LinearLayout.LayoutParams(-1,dp(50)));exit.setOnClickListener(v->{if(api.signedIn()){exit.setEnabled(false);worker.execute(()->{try{api.logout();}catch(Exception ignored){}handler.post(()->{NotificationService.stop(this);chats=new JSONArray();showWelcome();});});}else showWelcome();});
    }
    private void showSecurity(){
        begin("security");toolbar("Конфиденциальность",true,null,null);scrollContent();
        note(content,"Проверяем защиту аккаунта…");
        async(()->new JSONObject().put("factors",api.factors()).put("owner",api.rpc("mw_owner_status",new JSONObject())), result->{
            JSONObject data=(JSONObject)result;JSONArray factors=data.getJSONArray("factors");JSONObject owner=data.getJSONObject("owner");content.removeAllViews();
            note(content,owner.optBoolean("is_owner")?"Ваш аккаунт закреплён как единственный владелец Muwahid. Панель владельца открывается только после проверки второго фактора.":"Код из приложения-аутентификатора защищает вход в переписку после подключения второго фактора.");gap(content,18);
            boolean verified=false;
            for(int i=0;i<factors.length();i++){JSONObject f=factors.getJSONObject(i);if("verified".equals(f.optString("status"))&&"totp".equals(f.optString("factor_type"))){verified=true;final String id=f.getString("id");Button confirm=button("Подтвердить кодом аутентификатора");content.addView(confirm,new LinearLayout.LayoutParams(-1,dp(58)));confirm.setOnClickListener(v->showTotpCode(id,null));gap(content,12);}}
            if(!verified){note(content,"Второй фактор ещё не включён. Добавьте ключ в приложение-аутентификатор на своём телефоне, сохраните резервную копию ключа в надёжном месте и подтвердите первый код. Если потерять аутентификатор и резервную копию, доступ придётся восстанавливать через службу поддержки.");gap(content,18);Button enable=button("Подключить второй фактор");content.addView(enable,new LinearLayout.LayoutParams(-1,dp(58)));enable.setOnClickListener(v->{enable.setEnabled(false);async(()->api.enrollTotp(),res->{JSONObject f=(JSONObject)res;showTotpCode(f.getString("id"),f.getJSONObject("totp"));});});}
            if(owner.optBoolean("owner_access")){gap(content,22);Button dashboard=button("Открыть панель владельца");content.addView(dashboard,new LinearLayout.LayoutParams(-1,dp(54)));dashboard.setOnClickListener(v->showOwner());}
            gap(content,20);Button retry=button("Обновить состояние защиты");content.addView(retry,new LinearLayout.LayoutParams(-1,dp(54)));retry.setOnClickListener(v->showSecurity());
        });
    }
    private void showTotpCode(String factor,JSONObject totp){
        begin("mfa");getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);toolbar("Второй фактор",true,null,null);scrollContent();
        if(totp!=null){note(content,"Добавьте этот секретный ключ в аутентификатор: тип — по времени (TOTP), название — Muwahid. Не отправляйте ключ или коды в чат. Сохраните резервную копию ключа у себя.");gap(content,14);TextView key=label(totp.optString("secret"),18,text);key.setTextIsSelectable(true);content.addView(key);gap(content,14);
            Button open=button("Открыть аутентификатор");content.addView(open,new LinearLayout.LayoutParams(-1,dp(54)));open.setOnClickListener(v->{try{android.net.Uri uri=android.net.Uri.parse(totp.optString("uri"));if(!"otpauth".equals(uri.getScheme()))throw new Exception();startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){notice("Откройте свой аутентификатор и добавьте показанный ключ вручную.");}});gap(content,20);
        }else note(content,"Введите текущий шестизначный код из аутентификатора для Muwahid.");
        EditText code=field("Код из 6 цифр",true);code.setInputType(18);code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});code.setSaveEnabled(false);
        Button verify=button("Подтвердить");content.addView(verify,new LinearLayout.LayoutParams(-1,dp(54)));verify.setOnClickListener(v->{String value=code.getText().toString().trim();if(!value.matches("[0-9]{6}")){code.setError("Нужны 6 цифр");return;}verify.setEnabled(false);final int stamp=generation;worker.execute(()->{try{api.verifyTotp(factor,value);handler.post(()->{if(stamp!=generation)return;code.setText("");showSecurity();notice("Второй фактор подтверждён.");});}catch(Exception ex){handler.post(()->{if(stamp!=generation)return;verify.setEnabled(true);code.setText("");error(ex);});}});});
    }
    private void showOwner(){begin("owner");toolbar("Панель владельца",true,null,null);scrollContent();note(content,"Проверяем доступ на сервере…");async(()->api.rpc("mw_owner_overview",new JSONObject()),result->{JSONObject stats=(JSONObject)result;content.removeAllViews();note(content,"Доступ владельца подтверждён вторым фактором.");gap(content,22);note(content,"Пользователей: "+stats.optLong("users")+"\nЛичных чатов: "+stats.optLong("chats")+"\nСообщений: "+stats.optLong("messages")+"\nОткрытых жалоб: "+stats.optLong("open_complaints"));gap(content,22);note(content,"Раздел владельца доступен только аккаунту, закреплённому на сервере, и только после второго фактора.");});}
    @Override public void onBackPressed(){
        if(screen.equals("mfa")||screen.equals("owner")){showSecurity();}
        else if(screen.equals("security")){showSettings();}
        else if(screen.equals("chat")){if(voiceRecording){cancelVoiceRecording(true);return;}if(sending){Toast.makeText(this,"Дождитесь отправки сообщения",Toast.LENGTH_SHORT).show();return;}showChats();}
        else if(screen.equals("account")||screen.equals("chat_settings")||screen.equals("notifications")||screen.equals("data_settings")||screen.equals("folders")||screen.equals("devices")||screen.equals("energy")||screen.equals("language")||screen.equals("premium")||screen.equals("business")||screen.equals("gift"))showSettings();
        else if(screen.equals("settings"))showChats();
        else if(screen.equals("otp"))showAuth(phoneRegisterMode);
        else if(screen.equals("auth"))showWelcome();
        else if(screen.equals("chats")||screen.equals("welcome")){
            // Exit the Activity without logging out. The encrypted Supabase session stays
            // on the device, so the next launch opens chats directly.
            finish();
        }else super.onBackPressed();
    }
    private final class Logo extends View {
        private final boolean landscape;
        private final Paint p=new Paint(3);
        Logo(Context c,boolean landscape){super(c);this.landscape=landscape;setContentDescription("Логотип Muwahid");}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight();
            if(landscape){p.setShader(new LinearGradient(0,0,w,h,new int[]{Color.rgb(8,17,38),Color.rgb(7,75,102),Color.rgb(6,33,46)},null,Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h,p);p.setShader(null);
                mountain(canvas,w,h,.70f,Color.rgb(26,92,119));mountain(canvas,w,h,.79f,Color.rgb(17,60,84));mountain(canvas,w,h,.89f,Color.rgb(9,32,52));
                float size=Math.min(w*.30f,h*.25f);logo(canvas,(w-size)/2,h*.22f,size);
                p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextSize(dp(40));p.setTextAlign(Paint.Align.CENTER);canvas.drawText("Muwahid",w/2,h*.22f+size+dp(54),p);p.setTypeface(Typeface.create("sans-serif",0));p.setTextSize(dp(16));p.setColor(Color.rgb(177,221,233));canvas.drawText("Ближе друг к другу",w/2,h*.22f+size+dp(86),p);
            }else{float size=Math.min(w,h)*.86f;logo(canvas,(w-size)/2,(h-size)/2,size);}
        }
        private void mountain(Canvas c,float w,float h,float level,int color){p.setColor(color);Path path=new Path();path.moveTo(0,h);path.lineTo(0,h*level);path.lineTo(w*.18f,h*(level-.05f));path.lineTo(w*.42f,h*(level-.25f));path.lineTo(w*.53f,h*(level-.13f));path.lineTo(w*.64f,h*(level-.18f));path.lineTo(w*.88f,h*(level-.02f));path.lineTo(w,h*(level-.08f));path.lineTo(w,h);path.close();c.drawPath(path,p);}
        private void logo(Canvas c,float x,float y,float s){c.save();c.translate(x,y);c.scale(s/100,s/100);p.setShader(new LinearGradient(0,15,95,80,new int[]{accent,cyan},null,Shader.TileMode.CLAMP));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(18);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);Path m=new Path();m.moveTo(15,85);m.lineTo(15,18);m.lineTo(50,48);m.lineTo(85,18);m.lineTo(85,85);c.drawPath(m,p);p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);Path plane=new Path();plane.moveTo(45,65);plane.lineTo(95,44);plane.lineTo(79,94);plane.lineTo(68,77);plane.lineTo(85,55);plane.lineTo(60,72);plane.close();c.drawPath(plane,p);c.restore();}
    }
}
