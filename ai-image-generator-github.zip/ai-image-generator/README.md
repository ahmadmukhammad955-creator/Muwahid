# AI Image Generator

Простой генератор изображений на **FLUX.1-schnell** через Hugging Face Diffusers.

## Что означает «без лимита»

В приложении нет собственного ограничения вида «10/50/100 изображений в день». Реальные ограничения определяются только вашим железом, GPU-хостингом, памятью и стоимостью сервера.

GitHub хранит исходный код, но не предоставляет постоянный GPU для такого приложения.

## Запуск

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Откройте:

```text
http://localhost:7860
```

## GPU

Рекомендуется NVIDIA GPU с CUDA. На CPU генерация может быть очень медленной.

## Hugging Face

При необходимости задайте токен:

```bash
export HF_TOKEN=hf_xxxxxxxxx
```

Также можно изменить модель:

```bash
export MODEL_ID=black-forest-labs/FLUX.1-schnell
```

## Безопасность

Проект содержит базовую проверку запросов и не предназначен для обхода защит или генерации запрещённого контента.
