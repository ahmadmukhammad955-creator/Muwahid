from pathlib import Path
import re
base=Path(__file__).resolve().parents[1]
java=base/'app/src/main/java/com/muwahid/app'
manifest=(base/'app/src/main/AndroidManifest.xml').read_text()
build=(base/'app/build.gradle').read_text()
w=(base/'.github/workflows/build-apk.yml').read_text()
service=(java/'MuwahidMessagingService.java').read_text()
registration=(java/'PushRegistration.java').read_text()
notifications=(java/'CallNotifications.java').read_text()
server=(base/'backend/036_android_call_push.sql').read_text()
edge=(base/'supabase/functions/muwahid-call-push/index.ts').read_text()
assert 'versionCode 69' in build and "versionName '0.13.34'" in build
assert 'Muwahid_0.13.34_LIVE_CHAT_TOGGLE.zip' in w
assert "EXPECTED_VERSION_CODE: '69'" in w and "EXPECTED_VERSION_NAME: '0.13.34'" in w
assert 'com.google.firebase.MESSAGING_EVENT' in manifest
assert 'firebase-messaging:24.1.2' in build
for key in ('APP_ID','API_KEY','SENDER_ID','PROJECT_ID'):
    assert 'FCM_'+key in build
assert 'registerToken' in registration and 'mw_push_register' in registration
assert 'mw_push_unregister' in registration
assert 'incoming_call' in service and 'recipient.equals(api.uid())' in service
assert 'delta > 90000L' in service
assert 'setFullScreenIntent' in notifications and 'setTimeoutAfter(90000L)' in notifications
assert 'mw_device_push_tokens' in server and 'enable row level security' in server
assert 'grant execute on function public.mw_push_targets(uuid) to service_role' in server
assert 'MUWAHID_PUSH_WEBHOOK_SECRET' in edge and 'FCM_SERVICE_ACCOUNT_JSON' in edge
assert "priority:'HIGH'" in edge and "ttl:'90s'" in edge
assert 'private void notifyCall(JSONObject c)' in (java/'NotificationService.java').read_text()
assert 'PushRegistration.refresh(this)' in (java/'MainActivity.java').read_text()
assert 'mw_room_background_get' in (base/'backend/031_live_background_restore.sql').read_text()
assert 'body:not(.room-theme-active) .grid .seat.empty' in (base/'app/src/main/assets/voice_room.html').read_text()
print('MW_PUSH_ANDROID_SERVER_CONTRACT_OK 0.13.34')
