# Muwahid Fresh Native (independent from legacy Muwahid)

A separate Android Java app implementing the profile and archive UI from the owner's reference photo. Native layout, without WebView or Chrome. Distinct application ID `com.muwahid.fresh`. Public server uses Supabase Auth/Storage/PostgREST with a **new** `mfresh_*` schema, preserving the original project tables. No legacy Android code was reused.

## Implemented paths
- Sign up/log in, persistent AndroidKeyStore-encrypted login, native profile with editable name, bio, avatar, cover photo
- Authenticated media upload/storage; real JPEG/MP4 story publishing and archive past 24h; real unique view counts per authenticated user
- Story pin/unpin, owner deletion, private/public access settings with RLS enforced on metadata and stored objects
- Native messaging with other registered users found by @username; QR profile deep links, share via Android intent
- Native WebRTC 1:1 audio/video peer connection + Supabase signaling and ICE exchange, microphone/camera permissions, incoming call UI, hangup

## IMPORTANT QA / release limitations
- Android 15 emulator install/launch smoke test passed for the prior v2 build. This revision needs to pass Android CI again.
- WebRTC currently has public Google STUN servers but **no TURN relay**, so calls can fail between some mobile networks/firewalls. No proof of two real-device call success yet; caller can use buttons but function must not be called production-verified.
- Supabase auth, story upload, media viewing, and messages have **not** been verified with two independent real user accounts and devices.
- The screenshot is a design reference, not a source of fake demo data. Blank stories after first launch are correct.
- Debug builds are ephemeral-signed; production signing uses repo-configured stable owner keystore via secret if configured. Do not commit any keystore or service role secret.

## Build

The branch-level `.github/workflows/build-fresh-native-apk.yml` unzips this project ZIP and builds Android. Android SDK 35/Java 17/Gradle 8.9.

## Security

Only a Supabase publishable key is in the client. User tokens are kept encrypted by Android Keystore. Newly created tables use owner/participant Row Level Security. Server media are stored in private buckets and protected by matching policies. 1:1 chat is not end-to-end encrypted yet. Video/audio calls, if negotiated, use WebRTC secure media transport.
