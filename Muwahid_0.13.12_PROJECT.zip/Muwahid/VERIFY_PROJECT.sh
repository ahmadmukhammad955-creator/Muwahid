#!/usr/bin/env bash
set -euo pipefail
grep -Fq "versionCode 46" app/build.gradle
grep -Fq "versionName '0.13.12'" app/build.gradle
grep -Fq 'debuggable false' app/build.gradle
grep -Fq 'minifyEnabled true' app/build.gradle
grep -Fq 'shrinkResources true' app/build.gradle
grep -Fq 'assembleRelease' .github/workflows/build-apk.yml
grep -Fq 'outputs/apk/release/app-release.apk' .github/workflows/build-apk.yml
grep -Fq 'android:name=".VoiceRoomActivity"' app/src/main/AndroidManifest.xml
grep -Fq 'private void showVoiceRooms()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void showAdminManagement()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'WebView.setWebContentsDebuggingEnabled(false)' app/src/main/java/com/muwahid/app/CallActivity.java
grep -Fq 'shouldOverrideUrlLoading' app/src/main/java/com/muwahid/app/CallActivity.java
grep -Fq 'WebView.setWebContentsDebuggingEnabled(false)' app/src/main/java/com/muwahid/app/VoiceRoomActivity.java
grep -Fq 'shouldOverrideUrlLoading' app/src/main/java/com/muwahid/app/VoiceRoomActivity.java
grep -Fq 'mw_room_raise_hand' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_kick' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_mic_set_self' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_mic_moderate' app/src/main/assets/voice_room.html
grep -Fq 'create or replace function public.mw_owner_admin_set' backend/012_voice_rooms_admins.sql
grep -Fq 'create or replace function public.mw_room_signal_poll' backend/015_voice_room_performance.sql
test -f backend/016_shared_reading.sql
test -f backend/017_room_close.sql
test -f backend/018_security_hardening.sql
test -f backend/019_phone_country_auth.sql
test -f backend/020_remote_config.sql
test -f app/src/main/java/com/muwahid/app/RemoteConfig.java
grep -Fq 'mw_app_config' app/src/main/java/com/muwahid/app/MainActivity.java
! grep -RIEq 'service[_-]?role|ghp_[A-Za-z0-9]{20,}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----' app backend .github --exclude='*.png'
grep -Fq 'void people(String list)' app/src/main/java/com/muwahid/app/PrivacyActivity.java
grep -Fq 'mw_privacy_get' app/src/main/java/com/muwahid/app/PrivacyActivity.java
grep -Fq 'mw_sessions_list' app/src/main/java/com/muwahid/app/PrivacyActivity.java
grep -Fq 'create or replace function public.mw_privacy_get()' backend/022_privacy_controls.sql
grep -Fq "privacy_allows(p_person,auth.uid(),'messages')" backend/022_privacy_controls.sql
grep -Fq "privacy_allows(peer,auth.uid(),'calls')" backend/022_privacy_controls.sql

grep -Fq 'private void showWallpaperSettings()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void showNameColorSettings()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Углы блоков с сообщениями' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Смахивание влево в списке чатов' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Поднести и слушать' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Отправка по Enter' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'android:name=".LauncherNight"' app/src/main/AndroidManifest.xml
grep -Fq 'private void showAttachmentSheet()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void sendCurrentLocation()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'ACCESS_FINE_LOCATION' app/src/main/AndroidManifest.xml
! grep -Fq 'android.permission.REQUEST_INSTALL_PACKAGES' app/src/main/AndroidManifest.xml
! grep -Fq 'canRequestPackageInstalls' app/src/main/java/com/muwahid/app/UpdateActivity.java
! grep -Fq 'ACTION_MANAGE_UNKNOWN_APP_SOURCES' app/src/main/java/com/muwahid/app/UpdateActivity.java
grep -Fq 'Muwahid не устанавливает APK самостоятельно' app/src/main/java/com/muwahid/app/UpdateActivity.java
grep -Fq 'startTimer()' app/src/main/java/com/muwahid/app/CallActivity.java


grep -Fq 'android:name=".MuwahidCameraActivity"' app/src/main/AndroidManifest.xml
grep -Fq 'android:name=".LocationShareActivity"' app/src/main/AndroidManifest.xml
grep -Fq 'android:name=".MuwahidDocumentActivity"' app/src/main/AndroidManifest.xml
grep -Fq '"Все","Личные","Группы","Каналы"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq '"Чаты","Звонки","Контакты","Настройки"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"image","Галерея"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"camera","Камера"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"video","Видео"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"document","Документ"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"location","Местоположение"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"contacts","Контакт"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"audio","Аудио"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"poll","Опрос"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'attachmentTile(grid,"more","Ещё"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'cycleInlineVoiceSpeed' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq "id='add'" app/src/main/java/com/muwahid/app/CallActivity.java
grep -Fq 'MW_SMOKE_OK: 0.13.12' app/src/androidTest/java/com/muwahid/app/SmokeInstrumentation.java

# Reference UI implementation checks
test -f app/src/main/java/com/muwahid/app/UiIconDrawable.java
test -f app/src/main/java/com/muwahid/app/MiniMapView.java
grep -Fq 'refIconButton("phone"' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'composer.setTextSize(16)' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'Muwahid_0.13.12_PROJECT.zip' .github/workflows/build-apk.yml
# Compile-regression guard: long-press "Скрыть чат" must call the real helper.
! grep -Fq 'setHiddenChat(' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'else hideChat(id);drawChatList();' app/src/main/java/com/muwahid/app/MainActivity.java

# 0.13.12 visible chat redesign guards
grep -Fq 'new LinearLayout.LayoutParams(dp(270),-2)' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'gp.height=dp(90)' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'int step=dp(74)' app/src/main/java/com/muwahid/app/MainActivity.java
# 0.13.11 UI smoke-test contract: real composer uses the reference hint with ellipsis.
grep -Fq 'composer.setHint("Сообщение...")' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq '"Сообщение...".contentEquals(hint)' app/src/androidTest/java/com/muwahid/app/SmokeInstrumentation.java

# GitHub emulator-runner executes script lines independently via /usr/bin/sh -c.
# Keep the crash-log check on one physical line to avoid an unterminated if/fi block.
grep -Fq "! grep -q 'FATAL EXCEPTION' crash-log.txt || { cat crash-log.txt; exit 1; }" .github/workflows/build-apk.yml
! grep -Fq "if grep -q 'FATAL EXCEPTION' crash-log.txt; then" .github/workflows/build-apk.yml

echo 'MW_SOURCE_OK 0.13.12 CHAT_REDESIGN'
