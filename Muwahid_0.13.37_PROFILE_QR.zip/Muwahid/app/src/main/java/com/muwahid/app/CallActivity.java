package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.webkit.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class CallActivity extends Activity {
    private static final int REQ_PERMS=7201;
    private WebView web;
    private Api api;
    private ExecutorService worker=Executors.newSingleThreadExecutor();
    private String kind,chatId,callId,peerName;
    private boolean incoming,loaded;
    private AudioManager audioManager;
    private final CallRingback outgoingRingback=new CallRingback();
    private android.content.SharedPreferences callPrefs;
    private static final String CALL_CHANNEL="muwahid_active_call";
    private static final int CALL_NOTIFICATION_ID=310017;

    @Override public void onCreate(Bundle b){super.onCreate(b);if(AppLock.guard(this))return;getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        api=new Api(new SecureStore(this));audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);callPrefs=getSharedPreferences("muwahid",MODE_PRIVATE);Intent i=getIntent();kind=i.getStringExtra("kind");if(!"video".equals(kind))kind="audio";chatId=i.getStringExtra("chat_id");callId=i.getStringExtra("call_id");peerName=i.getStringExtra("peer_name");incoming=i.getBooleanExtra("incoming",false);if(peerName==null)peerName="Muwahid";
        if(!api.signedIn()){finish();return;}if(incoming){rememberActiveCall(callId,true,false);CallRingtone.start(this,callId==null?"incoming":callId);}ensurePermissions();
    }
    private void ensurePermissions(){ArrayList<String> need=new ArrayList<>();if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)need.add(android.Manifest.permission.RECORD_AUDIO);if("video".equals(kind)&&checkSelfPermission(android.Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)need.add(android.Manifest.permission.CAMERA);if(need.isEmpty())setup();else requestPermissions(need.toArray(new String[0]),REQ_PERMS);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_PERMS){for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED){new AlertDialog.Builder(this).setMessage("Для звонка нужен доступ к "+("video".equals(kind)?"микрофону и камере":"микрофону")+".").setPositiveButton("Закрыть",(d,w)->finish()).show();return;}setup();}}
    @SuppressWarnings("SetJavaScriptEnabled") private void setup(){if(loaded)return;loaded=true;FrameLayout stage=new FrameLayout(this);ImageView callBackground=new ImageView(this);callBackground.setBackgroundColor(Color.parseColor("#11161D"));callBackground.setContentDescription("Фон звонка Muwahid");stage.addView(callBackground,new FrameLayout.LayoutParams(-1,-1));WebView.setWebContentsDebuggingEnabled(false);web=new WebView(this);web.setBackgroundColor(Color.TRANSPARENT);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setDomStorageEnabled(false);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest r){runOnUiThread(()->{if(!trustedOrigin(r.getOrigin())){r.deny();return;}ArrayList<String> allow=new ArrayList<>();for(String x:r.getResources()){if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x)&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)allow.add(x);if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x)&&checkSelfPermission(android.Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)allow.add(x);}if(allow.isEmpty())r.deny();else r.grant(allow.toArray(new String[0]));});}});
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return request==null||!trustedPage(request.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){try{return !trustedPage(Uri.parse(url));}catch(Exception e){return true;}}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return blockExternal(request==null?null:request.getUrl());}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,String url){try{return blockExternal(url==null?null:Uri.parse(url));}catch(Exception e){return blocked();}}
        });
        web.addJavascriptInterface(new Bridge(),"MuwahidNative");stage.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(stage);web.loadDataWithBaseURL("https://muwahid.local/",html(),"text/html","UTF-8",null);
    }
    private boolean trustedOrigin(Uri u){return u!=null&&"https".equalsIgnoreCase(u.getScheme())&&"muwahid.local".equalsIgnoreCase(u.getHost());}
    private boolean trustedPage(Uri u){return u!=null&&(("about".equalsIgnoreCase(u.getScheme())&&"blank".equalsIgnoreCase(u.getSchemeSpecificPart()))||trustedOrigin(u));}
    private WebResourceResponse blockExternal(Uri u){if(u==null)return blocked();String scheme=u.getScheme();if("https".equalsIgnoreCase(scheme)||"http".equalsIgnoreCase(scheme))return trustedOrigin(u)?null:blocked();return null;}
    private WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));}
    private final class Bridge {
        private final Set<String> allowed=new HashSet<>(Arrays.asList("mw_call_start","mw_call_get","mw_call_answer","mw_call_ice","mw_call_end"));
        @JavascriptInterface public void rpc(String requestId,String function,String argsJson){
            if(!allowed.contains(function)){deliver(requestId,null,"Недоступная операция");return;}
            if("mw_call_answer".equals(function)||"mw_call_end".equals(function))runOnUiThread(()->{
                CallRingtone.stop();outgoingRingback.stop();
            });
            worker.execute(()->{try{
                Object result=api.rpc(function,new JSONObject(argsJson));
                if("mw_call_start".equals(function)&&result instanceof JSONObject){
                    JSONObject c=(JSONObject)result;
                    String created=c.optString("id","");
                    if(!created.isEmpty()){callId=created;runOnUiThread(()->rememberActiveCall(created,false,true));}
                }else if("mw_call_get".equals(function)&&result instanceof JSONObject){
                    String status=((JSONObject)result).optString("status","");
                    if(!"ringing".equals(status))runOnUiThread(outgoingRingback::stop);
                }else if("mw_call_answer".equals(function)){
                    runOnUiThread(()->rememberActiveCall(callId,true,true));
                }else if("mw_call_end".equals(function)){
                    runOnUiThread(this::clearActiveCallSafe);
                }
                deliver(requestId,result==null?"null":result.toString(),null);
            }catch(Exception e){deliver(requestId,null,e.getMessage()==null?"Ошибка связи":e.getMessage());}});
        }
        private void clearActiveCallSafe(){clearActiveCall();}
        @JavascriptInterface public void close(){runOnUiThread(()->{
            CallRingtone.stop();outgoingRingback.stop();clearActiveCall();finish();
        });}
        /** Ringback is local audio only. It never changes the server call state. */
        @JavascriptInterface public void ringback(boolean playing){runOnUiThread(()->{
            if(playing&&!incoming&&!isFinishing()&&!isDestroyed())outgoingRingback.start();
            else outgoingRingback.stop();
        });}
        @JavascriptInterface public void speaker(boolean on){runOnUiThread(()->{if(audioManager!=null){try{audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);audioManager.setSpeakerphoneOn(on);}catch(Exception ignored){}}});}
        @JavascriptInterface public void action(String what){runOnUiThread(()->{if("chat".equals(what)){Intent i=new Intent(CallActivity.this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("open_chat_id",chatId);i.putExtra("open_chat_name",peerName);startActivity(i);}else if("add".equals(what)){Intent i=new Intent(CallActivity.this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("open_contacts",true);startActivity(i);}else{new AlertDialog.Builder(CallActivity.this).setTitle("Ещё").setItems(new String[]{"Открыть чат","Свернуть звонок","Завершить"},(d,w)->{if(w==0){Intent i=new Intent(CallActivity.this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("open_chat_id",chatId);i.putExtra("open_chat_name",peerName);startActivity(i);}else if(w==1)moveTaskToBack(true);else if(web!=null)web.evaluateJavascript("window.hangup && window.hangup();",null);}).show();}});}
    }
    private void rememberActiveCall(String id,boolean isIncoming,boolean ongoing){
        if(id==null||id.trim().isEmpty()||callPrefs==null)return;
        callId=id;
        callPrefs.edit()
            .putString("active_call_id",id)
            .putString("active_call_kind",kind==null?"audio":kind)
            .putString("active_call_peer",peerName==null?"Muwahid":peerName)
            .putString("active_call_chat_id",chatId==null?"":chatId)
            .putBoolean("active_call_incoming",isIncoming)
            .apply();
        if(ongoing)showActiveCallNotification();
    }
    private void clearActiveCall(){
        if(callPrefs!=null)callPrefs.edit()
            .remove("active_call_id")
            .remove("active_call_kind")
            .remove("active_call_peer")
            .remove("active_call_chat_id")
            .remove("active_call_incoming")
            .apply();
        try{((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(CALL_NOTIFICATION_ID);}catch(Exception ignored){}
    }
    private void showActiveCallNotification(){
        try{
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if(Build.VERSION.SDK_INT>=26){
                NotificationChannel ch=new NotificationChannel(CALL_CHANNEL,"Активный звонок",NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Позволяет быстро вернуться к текущему звонку");
                ch.setSound(null,null);
                nm.createNotificationChannel(ch);
            }
            Intent open=new Intent(this,CallActivity.class)
                .putExtra("call_id",callId)
                .putExtra("chat_id",chatId)
                .putExtra("peer_name",peerName)
                .putExtra("kind",kind)
                .putExtra("incoming",incoming)
                .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi=PendingIntent.getActivity(this,CALL_NOTIFICATION_ID,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CALL_CHANNEL):new Notification.Builder(this);
            Notification n=b.setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(peerName==null?"Идёт звонок":"Звонок · "+peerName)
                .setContentText("Нажмите, чтобы вернуться в звонок")
                .setCategory(Notification.CATEGORY_CALL)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi)
                .build();
            nm.notify(CALL_NOTIFICATION_ID,n);
        }catch(Exception ignored){}
    }

    private void deliver(String requestId,String json,String error){runOnUiThread(()->{if(web==null)return;String js="window.mwResult("+JSONObject.quote(requestId)+","+(json==null?"null":JSONObject.quote(json))+","+(error==null?"null":JSONObject.quote(error))+");";web.evaluateJavascript(js,null);});}
    @Override protected void onResume(){super.onResume();if(!isFinishing())AppLock.guard(this);}
    @Override public void onDestroy(){outgoingRingback.stop();CallRingtone.stop();if(audioManager!=null)try{audioManager.setSpeakerphoneOn(false);audioManager.setMode(AudioManager.MODE_NORMAL);}catch(Exception ignored){}if(web!=null){web.loadUrl("about:blank");web.destroy();web=null;}worker.shutdownNow();super.onDestroy();}
    @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("window.hangup && window.hangup();",null);else super.onBackPressed();}

    private String svg(String name){
        String body;
        if("mic".equals(name))body="<rect x='9' y='3.5' width='6' height='10.5' rx='3'/><path d='M6.5 11.5c0 3.7 2.3 6 5.5 6s5.5-2.3 5.5-6M12 17.5V21M8.5 21h7'/>";
        else if("video".equals(name))body="<rect x='3.5' y='6.5' width='12' height='11' rx='2.4'/><path d='M15.5 10l5-2.5v9l-5-2.5z'/>";
        else if("flip".equals(name))body="<path d='M4 8a8 8 0 0 1 13-3l3 3M20 3v5h-5M20 16a8 8 0 0 1-13 3l-3-3M4 21v-5h5'/>";
        else if("speaker".equals(name))body="<path d='M4 10h4l5-4v12l-5-4H4zM16 9c2 1.5 2 4.5 0 6M18 6.5c4 2.5 4 8.5 0 11'/>";
        else if("add".equals(name))body="<circle cx='9' cy='8' r='3'/><path d='M3.5 18c.7-3.5 2.7-5 5.5-5s4.8 1.5 5.5 5M18 8v6M15 11h6'/>";
        else if("chat".equals(name))body="<rect x='4' y='5' width='16' height='12' rx='3'/><path d='M8 17l-2 3 5-3'/>";
        else if("more".equals(name))body="<circle cx='6' cy='12' r='1.4' fill='currentColor' stroke='none'/><circle cx='12' cy='12' r='1.4' fill='currentColor' stroke='none'/><circle cx='18' cy='12' r='1.4' fill='currentColor' stroke='none'/>";
        else body="<path d='M7 4.5c-1.5 0-2.5 1-2.3 2.6.8 6.5 6.7 12.4 13.2 13.2 1.6.2 2.6-.8 2.6-2.3l-.4-2.8c-.1-.8-.8-1.4-1.6-1.3l-3 .3a16 16 0 0 1-5.7-5.7l.3-3c.1-.8-.5-1.5-1.3-1.6z'/>";
        return "<svg viewBox='0 0 24 24' aria-hidden='true'><g fill='none' stroke='currentColor' stroke-width='1.9' stroke-linecap='round' stroke-linejoin='round'>"+body+"</g></svg>";
    }

    private String html(){
        String initial=peerName==null||peerName.isEmpty()?"M":peerName.substring(0,1).toUpperCase(Locale.ROOT);
        String init="window.MW={kind:"+JSONObject.quote(kind)+",incoming:"+incoming+",chatId:"+JSONObject.quote(chatId==null?"":chatId)+",callId:"+JSONObject.quote(callId==null?"":callId)+",peer:"+JSONObject.quote(peerName)+",initial:"+JSONObject.quote(initial)+"};";
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'>"+
        "<style>"+
        "*{box-sizing:border-box}html,body{margin:0;height:100%;overflow:hidden;background:transparent;color:#fff;font-family:system-ui,-apple-system,sans-serif}"+
        "#remote{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#07111b;visibility:hidden}"+
        ".videoCall #remote.ready{visibility:visible}"+
        "#remotePlaceholder{position:absolute;inset:0;display:none;align-items:center;justify-content:center;background:linear-gradient(165deg,#111c30,#090f1b);color:#e3ddf1;font-size:15px;text-align:center;padding:24px}"+
        ".videoCall #remotePlaceholder{display:flex}"+
        "#shade{position:absolute;inset:0;background:linear-gradient(#10161dcc 0%,#10161d33 42%,#10161d99 100%)}"+
        "#local{position:absolute;right:14px;top:66px;width:104px;height:150px;object-fit:cover;border-radius:18px;background:#10243a;border:1px solid #31516c;box-shadow:0 8px 28px #0008}"+
        "#identity{position:absolute;left:0;right:0;top:72px;display:flex;flex-direction:column;align-items:center;text-align:center;padding:0 24px}"+
        "#avatar{width:104px;height:104px;border-radius:52px;background:linear-gradient(145deg,#65b8f3,#1e6fb2);display:flex;align-items:center;justify-content:center;font-size:42px;font-weight:800;box-shadow:0 10px 30px #0008;border:2px solid #ffffff55}"+
        "#name{margin-top:16px;font-size:27px;font-weight:750;text-shadow:0 2px 8px #000}"+
        "#state{margin-top:6px;font-size:15px;color:#d0dbe7}#timer{margin-top:4px;font-size:14px;color:#a9c3d9;min-height:20px}"+
        "#controls{position:absolute;left:14px;right:14px;bottom:18px;background:#10161ddd;border:1px solid #ffffff18;border-radius:28px;padding:16px 14px 18px;backdrop-filter:blur(22px)}"+
        ".row{display:flex;justify-content:space-around;gap:12px}.row.second{margin-top:14px}.ctl{width:76px;border:0;background:transparent;color:#fff;font-size:12px;text-align:center}.round{width:58px;height:58px;margin:0 auto 7px;border-radius:29px;background:#ffffff1c;display:flex;align-items:center;justify-content:center;border:1px solid #ffffff18}.round svg{width:25px;height:25px}.ctl.on .round{background:#ffffff24;border-color:#ffffff30}.ctl.off .round{background:#e24b5a55}.end{margin-top:18px;width:100%;border:0;border-radius:26px;height:54px;background:#ef414d;color:white;font-size:17px;font-weight:700}"+
        "#videoControls{display:none;position:absolute;left:10px;right:10px;bottom:10px;background:#171717c9;border:1px solid #ffffff18;border-radius:24px;padding:12px 7px 10px;backdrop-filter:blur(22px)}#videoControls .ctl{width:72px}#videoControls .round{width:54px;height:54px;border-radius:27px;margin-bottom:6px}.videoEnd .round{background:#ff3b4e;border-color:#ff3b4e}.videoCall #controls{display:none}.videoCall #videoControls{display:block}.videoCall #identity{display:none}.videoCall #shade{background:linear-gradient(#00000025 0%,#00000005 45%,#00000055 100%)}"+
        "#incoming{position:absolute;inset:0;background:radial-gradient(circle at 50% 26%,#24313d 0%,#151b22 40%,#0d1117 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:26px}"+
        "#incAvatar{width:124px;height:124px;border-radius:62px;background:linear-gradient(145deg,#65b8f3,#1e6fb2);display:flex;align-items:center;justify-content:center;font-size:48px;font-weight:800;box-shadow:0 14px 38px #0008}"+
        "#incName{font-size:29px;font-weight:780;margin-top:22px}#incKind{font-size:15px;color:#c6d4e1;margin-top:8px}.answerRow{display:flex;gap:28px;margin-top:62px}.answerBtn{border:0;background:transparent;color:#fff;font-size:13px;min-width:76px}.answerCircle{width:68px;height:68px;border-radius:34px;display:flex;align-items:center;justify-content:center;margin:0 auto 8px}.answerCircle svg{width:28px;height:28px}.accept{background:#20c968}.decline{background:#ff3b4e}.message{background:#2b3440}.hide{display:none!important}"+
        "#videoControls .row{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:3px}#videoControls .ctl{width:100%;padding:0;font-size:11px;overflow-wrap:anywhere}#videoControls .round{width:44px;height:44px}.ctl:disabled{opacity:.45}#callNotice{position:absolute;top:12px;left:12px;right:12px;padding:10px;border-radius:12px;background:#10161de6;font-size:13px;z-index:2}#local.mirrored{transform:scaleX(-1)}"+
        "</style></head><body>"+
        "<div id='callNotice' class='hide' role='status' aria-live='polite'></div><video id='remote' autoplay playsinline></video><div id='remotePlaceholder' role='status'>Ожидание видео собеседника…</div><div id='shade'></div><video id='local' autoplay playsinline muted></video>"+
        "<div id='identity'><div id='avatar'></div><div id='name'></div><div id='state'>Подготовка…</div><div id='timer'></div></div>"+
        "<div id='controls'><div class='row'>"+
        "<button class='ctl on' id='mute'><span class='round'>"+svg("mic")+"</span><span>Микрофон</span></button>"+
        "<button class='ctl on' id='cam'><span class='round'>"+svg("video")+"</span><span>Камера</span></button>"+
        "<button class='ctl' id='speaker'><span class='round'>"+svg("speaker")+"</span><span>Динамик</span></button>"+
        "</div><div class='row second'>"+
        "<button class='ctl' id='add'><span class='round'>"+svg("add")+"</span><span>Добавить</span></button>"+
        "<button class='ctl' id='chat'><span class='round'>"+svg("chat")+"</span><span>Чат</span></button>"+
        "<button class='ctl' id='more'><span class='round'>"+svg("more")+"</span><span>Ещё</span></button>"+
        "</div><button class='end' id='end'>Завершить</button></div>"+
        "<div id='videoControls'><div class='row'>"+
        "<button class='ctl on' id='cam2'><span class='round'>"+svg("video")+"</span><span>Камера</span></button>"+
        "<button class='ctl' id='flipCamera' disabled aria-label='Переключить на заднюю камеру'><span class='round'>"+svg("flip")+"</span><span>Сменить камеру</span></button>"+
        "<button class='ctl on' id='mute2'><span class='round'>"+svg("mic")+"</span><span>Микрофон</span></button>"+
        "<button class='ctl videoEnd' id='end2'><span class='round'>"+svg("phone")+"</span><span>Завершить</span></button>"+
        "<button class='ctl' id='more2'><span class='round'>"+svg("more")+"</span><span>Ещё</span></button>"+
        "</div></div>"+
        "<div id='incoming' class='hide'><div id='incAvatar'></div><div id='incName'></div><div id='incKind'></div><div class='answerRow'>"+
        "<button class='answerBtn' id='message'><span class='answerCircle message'>"+svg("chat")+"</span>Сообщение</button>"+
        "<button class='answerBtn' id='decline'><span class='answerCircle decline'>"+svg("phone")+"</span>Отклонить</button>"+
        "<button class='answerBtn' id='answer'><span class='answerCircle accept'>"+svg("phone")+"</span>Принять</button>"+
        "</div></div><script>"+init+JS+"</script></body></html>";
    }

    private static final String JS=""+
"const S=window.MW,$=id=>document.getElementById(id);document.body.classList.add(S.kind==='video'?'videoCall':'audioCall');$('name').textContent=S.peer;$('avatar').textContent=S.initial;$('incName').textContent=S.peer;$('incAvatar').textContent=S.initial;\n"+
"$('cam').style.display=S.kind==='video'?'block':'none';$('local').style.display=S.kind==='video'?'block':'none';$('remote').style.display=S.kind==='video'?'block':'none';\n"+
"function syncRemoteVideo(){const v=$('remote');const ready=S.kind==='video'&&v.videoWidth>0&&v.videoHeight>0&&!v.paused;v.classList.toggle('ready',ready);$('remotePlaceholder').classList.toggle('hide',ready);}\n"+
"for(const eventName of ['playing','loadedmetadata','resize','waiting','stalled','emptied'])$('remote').addEventListener(eventName,syncRemoteVideo);\n"+
"let pc,local,callId=S.callId||'',remoteSet=false,iceSent=[],remoteIce=0,pollTimer,ended=false,connectedAt=0,timerTick=0,speaker=false;const pending={};\n"+
"window.mwResult=(id,json,err)=>{const p=pending[id];if(!p)return;delete pending[id];err?p.reject(new Error(err)):p.resolve(json===null?null:JSON.parse(json));};\n"+
"function rpc(fn,args){return new Promise((resolve,reject)=>{const id=Math.random().toString(36).slice(2);pending[id]={resolve,reject};MuwahidNative.rpc(id,fn,JSON.stringify(args));});}\n"+
"function state(x){$('state').textContent=x;}\n"+
"function notice(x){$('callNotice').textContent=x;$('callNotice').classList.toggle('hide',!x);}\n"+
"function startTimer(){if(connectedAt)return;MuwahidNative.ringback(false);connectedAt=Date.now();state('Соединено');const tick=()=>{if(!connectedAt||ended)return;const t=Math.floor((Date.now()-connectedAt)/1000),m=Math.floor(t/60),s=t%60;$('timer').textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');timerTick=setTimeout(tick,1000)};tick();}\n"+
"let facing='user',cameraBusy=false;\n"+
"function videoConstraints(side,exact=false){return {facingMode:exact?{exact:side}:{ideal:side},width:{ideal:1280},height:{ideal:720},frameRate:{ideal:30,max:30}};}\n"+
"function syncCamera(){const v=local&&local.getVideoTracks()[0];const live=!!v&&v.readyState!=='ended';const on=live&&v.enabled;for(const id of ['cam','cam2']){$(id).disabled=cameraBusy;$(id).className='ctl '+(on?'on':'off');$(id).querySelector('span:last-child').textContent=on?'Камера':'Камера выкл.';}const side=v&&v.getSettings?v.getSettings().facingMode:null;if(side==='user'||side==='environment')facing=side;$('local').classList.toggle('mirrored',facing==='user');$('local').style.visibility=on?'visible':'hidden';$('flipCamera').disabled=cameraBusy||!live||ended;$('flipCamera').setAttribute('aria-label',facing==='user'?'Переключить на заднюю камеру':'Переключить на переднюю камеру');}\n"+
"async function media(){local=await navigator.mediaDevices.getUserMedia({audio:true,video:S.kind==='video'?videoConstraints(facing):false});if(ended){local.getTracks().forEach(t=>t.stop());return;}$('local').srcObject=local;if(S.kind==='video')syncCamera();}\n"+
"async function configureVideoSender(){try{const sender=pc&&pc.getSenders().find(s=>s.track&&s.track.kind==='video');if(!sender||!sender.getParameters||!sender.setParameters)return;const p=sender.getParameters();if(!p.encodings||!p.encodings.length)return;for(const e of p.encodings){e.maxBitrate=2500000;e.maxFramerate=30;e.scaleResolutionDownBy=1;}p.degradationPreference='balanced';await sender.setParameters(p);}catch(e){/* Older WebViews retain WebRTC automatic bitrate control. */}}\n"+
"async function switchCamera(){if(cameraBusy||ended||!local||!pc)return;const old=local.getVideoTracks()[0],sender=pc.getSenders().find(s=>s.track===old);if(!old||!sender)return;cameraBusy=true;syncCamera();notice('');const previous=facing,target=facing==='user'?'environment':'user',enabled=old.enabled;let replacement=null;\n"+
"async function acquire(side){const stream=await navigator.mediaDevices.getUserMedia({audio:false,video:videoConstraints(side,true)});const track=stream.getVideoTracks()[0];if(ended){stream.getTracks().forEach(t=>t.stop());throw new Error('ended');}if(!track)throw new Error('no-camera');return track;}\n"+
"async function install(track){track.enabled=enabled;await sender.replaceTrack(track);if(ended){track.stop();return;}local.removeTrack(old);local.addTrack(track);$('local').srcObject=local;await configureVideoSender();}\n"+
"try{/* Android devices often cannot open two cameras at once. Audio remains live. */old.stop();replacement=await acquire(target);await install(replacement);if(!ended)facing=target;}\n"+
"catch(e){if(replacement)replacement.stop();if(!ended){try{replacement=await acquire(previous);await install(replacement);facing=previous;notice('Не удалось сменить камеру. Предыдущая камера восстановлена.');}catch(recovery){if(replacement)replacement.stop();if(!ended)notice('Камера недоступна. Проверьте доступ к камере и повторите звонок. Звук продолжает работать.');}}}\n"+
"finally{cameraBusy=false;if(!ended)syncCamera();}}\n"+
"$('flipCamera').onclick=switchCamera;\n"+
"function makePc(){pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});local.getTracks().forEach(t=>pc.addTrack(t,local));pc.ontrack=e=>{const stream=e.streams&&e.streams[0]?e.streams[0]:new MediaStream([e.track]);const v=$('remote');if(v.srcObject!==stream)v.srcObject=stream;syncRemoteVideo();if(stream.getVideoTracks().length)v.play().catch(()=>{});};pc.onicecandidate=e=>{if(e.candidate){const c={sdpMid:e.candidate.sdpMid,sdpMLineIndex:e.candidate.sdpMLineIndex,sdp:e.candidate.candidate};if(callId)rpc('mw_call_ice',{p_call:callId,p_candidate:c}).catch(()=>{});else iceSent.push(c);}};pc.onconnectionstatechange=()=>{if(pc.connectionState==='connected'){startTimer();void configureVideoSender();}else if(['failed','closed','disconnected'].includes(pc.connectionState))state('Связь прервана');};}\n"+
"async function flushIce(){for(const c of iceSent)await rpc('mw_call_ice',{p_call:callId,p_candidate:c});iceSent=[];}\n"+
"async function outgoing(){try{state('Звонок…');await media();if(ended)return;makePc();const offer=await pc.createOffer();await pc.setLocalDescription(offer);const c=await rpc('mw_call_start',{p_chat:S.chatId,p_kind:S.kind,p_offer:offer.sdp});callId=c.id;if(!ended)MuwahidNative.ringback(true);await flushIce();if(!ended)poll();}catch(e){MuwahidNative.ringback(false);state(e.message||'Не удалось позвонить');}}\n"+
"async function acceptIncoming(){$('incoming').classList.add('hide');try{state('Соединение…');await media();if(ended)return;makePc();const c=await rpc('mw_call_get',{p_call:callId});await pc.setRemoteDescription({type:'offer',sdp:c.offer});remoteSet=true;const ans=await pc.createAnswer();await pc.setLocalDescription(ans);await rpc('mw_call_answer',{p_call:callId,p_answer:ans.sdp});await flushIce();poll();}catch(e){state(e.message||'Не удалось принять звонок');}}\n"+
"async function addRemote(list){if(!list||!pc||!remoteSet)return;for(let i=remoteIce;i<list.length;i++){const c=list[i];try{await pc.addIceCandidate({sdpMid:c.sdpMid,sdpMLineIndex:c.sdpMLineIndex,candidate:c.sdp});}catch(e){}}remoteIce=list.length;}\n"+
"async function poll(){if(ended)return;try{const c=await rpc('mw_call_get',{p_call:callId});if(['ended','rejected','missed'].includes(c.status)){MuwahidNative.ringback(false);state(c.status==='rejected'?'Звонок отклонён':c.status==='missed'?'Нет ответа':'Звонок завершён');return finishSoon();}if(c.status==='accepted'){MuwahidNative.ringback(false);if(!connectedAt)state('Соединение…');}if(!S.incoming&&c.status==='accepted'&&c.answer&&!remoteSet){await pc.setRemoteDescription({type:'answer',sdp:c.answer});remoteSet=true;}await addRemote(S.incoming?c.caller_ice:c.callee_ice);}catch(e){}pollTimer=setTimeout(poll,1100);}\n"+
"function finishSoon(){ended=true;MuwahidNative.ringback(false);clearTimeout(pollTimer);clearTimeout(timerTick);setTimeout(()=>MuwahidNative.close(),900);}\n"+
"window.hangup=async function(status='ended'){if(ended)return;ended=true;MuwahidNative.ringback(false);clearTimeout(pollTimer);clearTimeout(timerTick);try{if(callId)await rpc('mw_call_end',{p_call:callId,p_status:status});}catch(e){}if(local)local.getTracks().forEach(t=>t.stop());if(pc)pc.close();MuwahidNative.close();};\n"+
"$('end').onclick=()=>hangup();$('end2').onclick=()=>hangup();$('more2').onclick=()=>MuwahidNative.action('more');$('message').onclick=()=>MuwahidNative.action('chat');$('decline').onclick=()=>hangup('rejected');$('answer').onclick=acceptIncoming;\n"+
"function toggleMute(){if(!local)return;const a=local.getAudioTracks()[0];if(a){a.enabled=!a.enabled;for(const id of ['mute','mute2']){const el=$(id);if(el){el.className='ctl '+(a.enabled?'on':'off');el.querySelector('span:last-child').textContent=a.enabled?'Микрофон':'Без звука';}}}}$('mute').onclick=toggleMute;$('mute2').onclick=toggleMute;\n"+
"function toggleCam(){if(!local||cameraBusy||ended)return;const v=local.getVideoTracks()[0];if(v&&v.readyState!=='ended'){v.enabled=!v.enabled;syncCamera();}}$('cam').onclick=toggleCam;$('cam2').onclick=toggleCam;\n"+
"$('speaker').onclick=()=>{speaker=!speaker;MuwahidNative.speaker(speaker);$('speaker').className='ctl '+(speaker?'on':'');$('speaker').querySelector('span:last-child').textContent=speaker?'Динамик вкл.':'Динамик';};\n"+
"$('add').onclick=()=>MuwahidNative.action('add');$('chat').onclick=()=>MuwahidNative.action('chat');$('more').onclick=()=>MuwahidNative.action('more');\n"+
"if(S.incoming){$('incoming').classList.remove('hide');$('incKind').textContent=S.kind==='video'?'Входящий видеозвонок':'Входящий аудиозвонок';state('Входящий звонок');}else outgoing();\n";
}
