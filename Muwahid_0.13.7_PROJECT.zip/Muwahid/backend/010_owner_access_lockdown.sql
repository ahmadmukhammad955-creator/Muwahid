begin;

-- Muwahid 0.8.2: lock the owner identity to the single project owner.
delete from mw_private.owner_account
where user_id <> '025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid;

insert into mw_private.owner_account(singleton,user_id)
values (true,'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid)
on conflict (singleton) do update
set user_id = excluded.user_id;

alter table mw_private.owner_account
  drop constraint if exists owner_account_exact_owner;

alter table mw_private.owner_account
  add constraint owner_account_exact_owner
  check (user_id = '025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid);

alter table mw_private.owner_account force row level security;
revoke all on table mw_private.owner_account from public, anon, authenticated;
revoke execute on function public.rls_auto_enable() from public, anon, authenticated;

create or replace function mw_private.require_owner()
returns void
language plpgsql
security definer
set search_path=''
as $$
begin
  if auth.uid() is distinct from '025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then
    raise exception 'MW:Доступ только для владельца';
  end if;
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then
    raise exception 'MW:Подтвердите вход кодом второго фактора';
  end if;
end
$$;

revoke all on function mw_private.require_owner() from public, anon, authenticated;

create or replace function public.mw_owner_status()
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  is_owner boolean;
  second_factor boolean;
begin
  if auth.uid() is null then
    raise exception 'MW:Войдите в аккаунт';
  end if;
  is_owner := auth.uid() = '025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid;
  second_factor := coalesce(auth.jwt()->>'aal','') = 'aal2';
  return jsonb_build_object(
    'is_owner', is_owner,
    'mfa_verified', second_factor,
    'owner_access', is_owner and second_factor
  );
end
$$;

create or replace function public.mw_owner_overview()
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  perform mw_private.require_owner();
  return jsonb_build_object(
    'users',(select count(*) from public.mw_profiles),
    'chats',(select count(*) from public.mw_chats),
    'messages',(select count(*) from public.mw_messages)
  );
end
$$;

revoke all on function public.mw_owner_status() from public, anon;
revoke all on function public.mw_owner_overview() from public, anon;
grant execute on function public.mw_owner_status() to authenticated;
grant execute on function public.mw_owner_overview() to authenticated;

commit;
