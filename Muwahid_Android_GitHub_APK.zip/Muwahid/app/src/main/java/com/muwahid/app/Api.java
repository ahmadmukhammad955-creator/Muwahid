package com.muwahid.app;

import org.json.*;
import java.net.*;
import java.io.*;
import javax.net.ssl.HttpsURLConnection;

final class Api {
    private final SecureStore store;
    private volatile JSONObject session = new JSONObject();
    Api(SecureStore store) {
        this.store = store;
        try { session = new JSONObject(store.load()); } catch (Exception ignored) {}
    }
    boolean configured() { return BuildConfig.SERVER_URL.startsWith("https://") && !BuildConfig.PUBLIC_KEY.isEmpty(); }
    boolean signedIn() { return !session.optString("refresh_token").isEmpty(); }
    String uid() { JSONObject u = session.optJSONObject("user"); return u == null ? "" : u.optString("id"); }
    private JSONObject object(String text) throws Exception { return new JSONObject(text); }
    private String request(String path, JSONObject data, String token) throws Exception {
        if (!configured()) throw new Exception("Сервер ещё не подключён. Пока доступны личные заметки.");
        HttpsURLConnection c = (HttpsURLConnection) new URL(BuildConfig.SERVER_URL + path).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(false);
        c.setRequestMethod("POST"); c.setRequestProperty("apikey", BuildConfig.PUBLIC_KEY);
        if (!token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); c.setDoOutput(true);
        try {
            try (OutputStream out = c.getOutputStream()) { out.write(data.toString().getBytes("UTF-8")); }
            int status = c.getResponseCode(); InputStream source = status >= 400 ? c.getErrorStream() : c.getInputStream();
            StringBuilder text = new StringBuilder();
            if (source != null) try (BufferedReader in = new BufferedReader(new InputStreamReader(source, "UTF-8"))) {
                String line; while ((line = in.readLine()) != null) { text.append(line); if (text.length() > 2000000) throw new IOException("Ответ сервера слишком большой"); }
            }
            if (status >= 400) {
                String msg = "Не удалось выполнить запрос (" + status + "). Попробуйте ещё раз.";
                try { JSONObject err = new JSONObject(text.toString());
                    String code = err.optString("error_code", err.optString("code"));
                    String detail = err.optString("msg", err.optString("message", err.optString("error_description")));
                    if (code.equals("invalid_credentials")) msg = "Неверная почта или пароль.";
                    else if (code.equals("email_not_confirmed")) msg = "Подтвердите почту по ссылке в письме, затем войдите.";
                    else if (code.equals("user_already_exists")) msg = "Аккаунт уже существует. Нажмите «Войти».";
                    else if (status == 429) msg = "Слишком много попыток. Подождите немного.";
                    else if (code.equals("23505")) msg = "Это имя пользователя уже занято.";
                    else if (detail.startsWith("MW:")) msg = detail.substring(3);
                } catch (JSONException ignored) {}
                if (status == 401) throw new AuthException(msg);
                throw new Exception(msg);
            }
            if (status >= 300) throw new IOException("Сервер вернул перенаправление");
            return text.toString();
        } finally { c.disconnect(); }
    }
    synchronized boolean register(String email, String password, String name) throws Exception {
        JSONObject result = object(request("/auth/v1/signup", new JSONObject().put("email", email).put("password", password)
                .put("data", new JSONObject().put("display_name", name)), ""));
        if (result.optString("access_token").isEmpty()) return false;
        acceptSession(result); return true;
    }
    synchronized void login(String email, String password) throws Exception {
        acceptSession(object(request("/auth/v1/token?grant_type=password", new JSONObject().put("email", email).put("password", password), "")));
    }
    private void acceptSession(JSONObject result) throws Exception {
        if (result.optString("access_token").isEmpty() || result.optString("refresh_token").isEmpty()) throw new Exception("Не удалось войти");
        result.put("expires_at", System.currentTimeMillis()/1000 + result.optLong("expires_in", 3600));
        store.save(result.toString()); session = result;
    }
    private void refresh() throws Exception {
        try { acceptSession(object(request("/auth/v1/token?grant_type=refresh_token", new JSONObject().put("refresh_token", session.optString("refresh_token")), ""))); }
        catch (AuthException e) { clear(); throw new Exception("Сессия истекла. Войдите снова."); }
    }
    synchronized Object rpc(String function, JSONObject args) throws Exception {
        if (!signedIn()) throw new Exception("Войдите в аккаунт");
        if (session.optLong("expires_at") < System.currentTimeMillis()/1000 + 60) refresh();
        String result;
        try { result = request("/rest/v1/rpc/" + function, args, session.optString("access_token")); }
        catch (AuthException e) { refresh(); result = request("/rest/v1/rpc/" + function, args, session.optString("access_token")); }
        return new JSONTokener(result).nextValue();
    }
    synchronized void logout() throws Exception {
        String token = session.optString("access_token");
        try { if (!token.isEmpty()) request("/auth/v1/logout?scope=local", new JSONObject(), token); }
        finally { clear(); }
    }
    synchronized void clear() { session = new JSONObject(); store.clear(); }
    static class AuthException extends Exception { AuthException(String msg) { super(msg); } }
}
