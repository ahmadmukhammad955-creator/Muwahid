-- Muwahid LIVE circular eight-seat voice scene. Data-only and idempotent.
-- The APK must contain the renderer; existing clients safely ignore new keys.
-- Do not overwrite unrelated remote config, including theme / reading controls.
UPDATE public.mw_app_remote_config
SET config = jsonb_set(
  config,
  '{live}',
  COALESCE(config->'live', '{}'::jsonb) || jsonb_build_object(
    'seating_layout', 'circle_8',
    'speaker_highlight_enabled', true,
    'speaker_glow_color', '#c18aff',
    'central_mic_enabled', true
  ),
  true
), updated_at = now()
WHERE id = 1;
