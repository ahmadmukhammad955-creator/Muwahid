# Muwahid 0.13.35 – Outgoing call ringback

- Callers hear a locally generated **425 Hz ringback**, 1 second on / 4 seconds off, immediately after the server accepts `mw_call_start`.
- The tone uses a looping native Android PCM AudioTrack (no external audio file, no network traffic, never published into WebRTC). Falls back to the Android telephony ringback tone when unavailable.
- Stops on server `accepted`, `rejected`, `missed`, `ended`, on WebRTC connected, on hangup/cancel, on failure, on native close and on activity destroy. A native 92-second timeout protects against suspended WebView polling.
- Incoming ringtone preferences/custom sounds are unchanged.
- Android requires RECORD_AUDIO/camera approval for the outgoing call; tone begins when the outgoing call is created.
- Version 0.13.35, versionCode 70; source regression test `tests/check_call_ringback_01335.py`.
- Source and syntax checks are not a substitute for testing sound/call signaling on two physical Android devices.
