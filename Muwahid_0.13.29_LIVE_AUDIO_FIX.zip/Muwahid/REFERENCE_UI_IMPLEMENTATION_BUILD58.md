# Muwahid 0.13.23 / build 58 — approved reference UI implementation

This build keeps the original Muwahid application and server contracts. It does not replace the messenger with a demo or web landing.

Visual contract implemented in this pass:
- light-first white / porcelain / cobalt visual language;
- native vector icons for navigation, calls, settings, privacy, groups, theme, notifications and devices;
- chat list header/search/filter chips aligned to the approved reference (Все / Непрочитанные / Личные);
- compact reference-style chat rows and unread badges;
- modern Calls and Contacts rows with vector phone/chat actions;
- white bottom navigation without the old active pill;
- modern message composer and existing green/white message bubbles retained;
- existing modern incoming/audio/video CallActivity retained;
- voice room restyled to the same light Muwahid language, while keeping WebRTC, 8 microphone seats, listeners, moderation, room chat, music, recording and shared PDF reading code intact.

Functional preservation is still enforced by VERIFY_PROJECT.sh for E2EE, calls, voice rooms, PDF shared reading, camera/location/documents, stickers, privacy, owner controls and updater logic.
