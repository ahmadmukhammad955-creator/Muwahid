package com.muwahid.fresh;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;
import okhttp3.*;
import java.util.concurrent.TimeUnit;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** New, independent Supabase REST transport. No code from earlier Muwahid versions. */
final class Backend {
    static final String HOST="https://pucxqnegbnjzawzwnpjh.supabase.co";
    static final String KEY="sb_publishable_Mtsx-WuCfSPIyxjOlo-9dw_x6Xxbe6p"; // publishable (not secret) key
    private static final String ALIAS="mfresh.session.v1";
    private final SharedPreferences prefs;
    private String token="",refresh="",userId="";
    static final class HttpError extends Exception {
        final int status;
        HttpError(int status,String message){super(message);this.status=status;}
    }
    Backend(Context context){prefs=context.getSharedPreferences("mfresh-secure",Context.MODE_PRIVATE);restore();}
    boolean signedIn(){return !token.isEmpty()&&!userId.isEmpty();}
    String uid(){return userId;}
    private synchronized javax.crypto.SecretKey secureKey() throws Exception{
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        java.security.Key key=store.getKey(ALIAS,null);
        if(key instanceof javax.crypto.SecretKey)return (javax.crypto.SecretKey)key;
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build());
        return generator.generateKey();
    }
    private void persist(){
        try{
            JSONObject j=new JSONObject().put("token",token).put("refresh",refresh).put("user",userId);
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,secureKey());
            byte[] iv=c.getIV(),cipher=c.doFinal(j.toString().getBytes(StandardCharsets.UTF_8));
            prefs.edit().putString("session",Base64.encodeToString(iv,Base64.NO_WRAP)+"."+Base64.encodeToString(cipher,Base64.NO_WRAP)).apply();
        }catch(Exception e){throw new IllegalStateException("Не удалось безопасно сохранить вход",e);}
    }
    private void restore(){
        try{
            String val=prefs.getString("session","");if(val.isEmpty())return;
            String[] p=val.split("\\.");if(p.length!=2)return;
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,secureKey(),new GCMParameterSpec(128,Base64.decode(p[0],Base64.NO_WRAP)));
            JSONObject j=new JSONObject(new String(c.doFinal(Base64.decode(p[1],Base64.NO_WRAP)),StandardCharsets.UTF_8));
            token=j.optString("token","");refresh=j.optString("refresh","");userId=j.optString("user","");
        }catch(Exception e){prefs.edit().remove("session").apply();}
    }
    void signOut(){token="";refresh="";userId="";prefs.edit().remove("session").apply();}
    static String enc(String x){try{return java.net.URLEncoder.encode(x,"UTF-8").replace("+","%20");}catch(Exception e){throw new RuntimeException(e);}}
    private static String path(String x){return enc(x).replace("%2F","/");}
    private static byte[] read(InputStream stream,int max) throws Exception{
        if(stream==null)return new byte[0];
        try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[8192];int size=0,n;
            while((n=in.read(buf))!=-1){size+=n;if(size>max)throw new Exception("Ответ или файл слишком большой");out.write(buf,0,n);}
            return out.toByteArray();
        }
    }
    private static String errorMessage(String body,int code){
        try{JSONObject j=new JSONObject(body);return j.optString("msg",j.optString("message",j.optString("error_description","HTTP "+code)));}
        catch(Exception e){return body.isEmpty()?"HTTP "+code:body.substring(0,Math.min(190,body.length()));}
    }
    private static final OkHttpClient CLIENT=new OkHttpClient.Builder()
        .connectTimeout(15,TimeUnit.SECONDS).readTimeout(25,TimeUnit.SECONDS).build();
    private byte[] raw(String method,String route,byte[] payload,String mime,boolean auth,boolean allowRefresh,String prefer) throws Exception{
        Request.Builder b=new Request.Builder().url(HOST+route).header("apikey",KEY).header("Accept","application/json");
        if(auth)b.header("Authorization","Bearer "+token);
        if(prefer!=null)b.header("Prefer",prefer);
        RequestBody body=payload==null?null:RequestBody.create(payload,MediaType.parse(mime));
        b.method(method,body);
        int status;byte[] bytes;
        try(Response res=CLIENT.newCall(b.build()).execute()){
            status=res.code();
            if(res.body()==null)bytes=new byte[0];
            else try(InputStream in=res.body().byteStream()){bytes=read(in,32*1024*1024);}
        }
        if(status==401&&auth&&allowRefresh&&!refresh.isEmpty()){
            refreshToken();return raw(method,route,payload,mime,true,false,prefer);
        }
        if(status>=300)throw new HttpError(status,errorMessage(new String(bytes,StandardCharsets.UTF_8),status));
        return bytes;
    }
    private synchronized void refreshToken() throws Exception{
        JSONObject j=new JSONObject().put("refresh_token",refresh);
        String text=new String(raw("POST","/auth/v1/token?grant_type=refresh_token",j.toString().getBytes(StandardCharsets.UTF_8),"application/json",false,false,null),StandardCharsets.UTF_8);
        saveAuth(new JSONObject(text));
    }
    private synchronized void saveAuth(JSONObject auth){
        String next=auth.optString("access_token","");if(next.isEmpty())throw new IllegalStateException("Подтвердите email, затем войдите.");
        token=next;refresh=auth.optString("refresh_token","");
        userId=auth.optJSONObject("user")==null?"":auth.optJSONObject("user").optString("id","");
        if(userId.isEmpty())throw new IllegalStateException("Сервер не вернул ID пользователя");
        persist();
    }
    void logIn(String email,String password) throws Exception{
        JSONObject body=new JSONObject().put("email",email.trim()).put("password",password);
        saveAuth(new JSONObject(new String(raw("POST","/auth/v1/token?grant_type=password",body.toString().getBytes(StandardCharsets.UTF_8),"application/json",false,false,null),StandardCharsets.UTF_8)));
    }
    boolean signUp(String email,String password) throws Exception{
        JSONObject body=new JSONObject().put("email",email.trim()).put("password",password);
        JSONObject result=new JSONObject(new String(raw("POST","/auth/v1/signup",body.toString().getBytes(StandardCharsets.UTF_8),"application/json",false,false,null),StandardCharsets.UTF_8));
        if(!result.optString("access_token","").isEmpty()){saveAuth(result);return true;}
        return false;
    }
    JSONArray list(String table,String query) throws Exception{
        return new JSONArray(new String(raw("GET","/rest/v1/"+table+"?"+query,null,null,true,true,null),StandardCharsets.UTF_8));
    }
    JSONObject insert(String table,JSONObject value,boolean upsert) throws Exception{
        byte[] b=raw("POST","/rest/v1/"+table+(upsert?"?on_conflict="+(table.equals("mfresh_profiles")?"id":"story_id,viewer_id"):""),
            value.toString().getBytes(StandardCharsets.UTF_8),"application/json",true,true,upsert?"resolution=merge-duplicates,return=representation":"return=representation");
        JSONArray a=new JSONArray(new String(b,StandardCharsets.UTF_8));return a.length()>0?a.getJSONObject(0):new JSONObject();
    }
    JSONObject patch(String table,String query,JSONObject value) throws Exception{
        byte[] b=raw("PATCH","/rest/v1/"+table+"?"+query,value.toString().getBytes(StandardCharsets.UTF_8),"application/json",true,true,"return=representation");
        JSONArray a=new JSONArray(new String(b,StandardCharsets.UTF_8));return a.length()>0?a.getJSONObject(0):new JSONObject();
    }
    void delete(String table,String query) throws Exception{raw("DELETE","/rest/v1/"+table+"?"+query,null,null,true,true,null);}
    JSONObject ownProfile() throws Exception{
        JSONArray arr=list("mfresh_profiles","id=eq."+enc(userId)+"&select=*");
        if(arr.length()>0)return arr.getJSONObject(0);
        JSONObject fresh=new JSONObject().put("id",userId).put("username","user_"+userId.substring(0,8)).put("display_name","Пользователь");
        return insert("mfresh_profiles",fresh,true);
    }
    JSONArray otherProfiles(String query) throws Exception{
        return list("mfresh_profiles","select=*&username=ilike."+enc("*"+query+"*")+"&limit=15");
    }
    JSONArray stories(String owner) throws Exception{
        return list("mfresh_stories","select=*&user_id=eq."+enc(owner)+"&order=created_at.desc&limit=100");
    }
    JSONArray views(String id) throws Exception{
        return list("mfresh_story_views","select=viewer_id&story_id=eq."+enc(id));
    }
    void markView(String story) throws Exception{
        try{insert("mfresh_story_views",new JSONObject().put("story_id",story).put("viewer_id",userId),true);}catch(HttpError ex){if(ex.status!=409)throw ex;}
    }
    JSONArray messages(String other) throws Exception{
        String filter="or=(and(sender_id.eq."+userId+",recipient_id.eq."+other+"),and(sender_id.eq."+other+",recipient_id.eq."+userId+"))";
        return list("mfresh_messages","select=*&"+enc(filter).replace("%3D","=").replace("%28","(").replace("%29",")").replace("%2C",",")+"&order=created_at.asc&limit=200");
    }
    void sendMessage(String other,String message) throws Exception{
        insert("mfresh_messages",new JSONObject().put("sender_id",userId).put("recipient_id",other).put("body",message.trim()),false);
    }
    byte[] download(String bucket,String objectPath) throws Exception{
        return raw("GET","/storage/v1/object/"+bucket+"/"+path(objectPath),null,null,true,true,null);
    }
    void upload(String bucket,String objectPath,byte[] bytes,String mime) throws Exception{
        raw("POST","/storage/v1/object/"+bucket+"/"+path(objectPath),bytes,mime,true,true,null);
    }
    void deleteUpload(String bucket,String objectPath) throws Exception{
        raw("DELETE","/storage/v1/object/"+bucket+"/"+path(objectPath),null,null,true,true,null);
    }
    JSONObject startCall(String receiver,String kind)throws Exception{
        return insert("mfresh_calls",new JSONObject().put("caller_id",userId)
            .put("receiver_id",receiver).put("kind",kind),false);
    }
    JSONObject getCall(String callId)throws Exception{
        JSONArray a=list("mfresh_calls","select=*&id=eq."+enc(callId)+"&limit=1");
        return a.length()==0?new JSONObject():a.getJSONObject(0);
    }
    JSONArray ringingCalls()throws Exception{
        return list("mfresh_calls","select=*&receiver_id=eq."+enc(userId)+"&status=eq.ringing&order=created_at.desc&limit=8");
    }
    void changeCall(String callId,JSONObject changes)throws Exception{
        patch("mfresh_calls","id=eq."+enc(callId),changes);
    }
    void sendIce(String callId,String mid,int line,String candidate)throws Exception{
        JSONObject row=new JSONObject().put("call_id",callId).put("sender_id",userId)
            .put("sdp_mid",mid==null?JSONObject.NULL:mid).put("sdp_mline_index",line).put("candidate",candidate);
        insert("mfresh_call_ice",row,false);
    }
    JSONArray iceSince(String callId,long lastId)throws Exception{
        return list("mfresh_call_ice","select=*&call_id=eq."+enc(callId)+"&id=gt."+lastId+"&order=id.asc&limit=100");
    }

}
