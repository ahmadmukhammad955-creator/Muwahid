package com.muwahid.app;

import android.content.Context;
import android.util.Log;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;
import java.util.concurrent.atomic.AtomicBoolean;

/** Optional FCM transport. Without valid Firebase settings, existing RPC polling keeps working. */
public final class PushRegistration {
    private static final AtomicBoolean busy = new AtomicBoolean(false);
    private static boolean ready;
    private PushRegistration(){}

    static synchronized void initialize(Context context){
        if(ready)return;
        if(BuildConfig.FCM_APP_ID.isEmpty() || BuildConfig.FCM_SENDER_ID.isEmpty()
                || BuildConfig.FCM_PROJECT_ID.isEmpty() || BuildConfig.FCM_API_KEY.isEmpty())return;
        try {
            if(FirebaseApp.getApps(context).isEmpty()){
                FirebaseOptions opts=new FirebaseOptions.Builder()
                    .setApplicationId(BuildConfig.FCM_APP_ID)
                    .setApiKey(BuildConfig.FCM_API_KEY)
                    .setGcmSenderId(BuildConfig.FCM_SENDER_ID)
                    .setProjectId(BuildConfig.FCM_PROJECT_ID).build();
                FirebaseApp.initializeApp(context.getApplicationContext(),opts);
            }
            ready=true;
        }catch(Exception e){Log.w("MW-Push","Firebase init failed",e);}
    }
    static void refresh(Context context){
        Context app=context.getApplicationContext();initialize(app);
        if(!ready)return;
        try {FirebaseMessaging.getInstance().getToken()
            .addOnSuccessListener(token -> registerToken(app,token))
            .addOnFailureListener(e -> Log.w("MW-Push","FCM token unavailable",e));}
        catch(Exception e){Log.w("MW-Push","FCM registration unavailable",e);}
    }
    static void registerToken(Context context,String token){
        if(token==null||token.length()<32||token.length()>4096||!ready)return;
        Context app=context.getApplicationContext();
        Api session=new Api(new SecureStore(app));
        String user=session.uid();
        if(!session.signedIn()||user.isEmpty())return;
        android.content.SharedPreferences p=app.getSharedPreferences("muwahid_push",Context.MODE_PRIVATE);
        if(user.equals(p.getString("registered_user","")) && token.equals(p.getString("registered_token",""))
             && System.currentTimeMillis()-p.getLong("registered_at",0)<6*60*60*1000L)return;
        if(!busy.compareAndSet(false,true))return;
        new Thread(()->{
            try {
                Api api=new Api(new SecureStore(app));
                if(!api.signedIn()||!user.equals(api.uid()))return;
                api.rpc("mw_push_register",new JSONObject().put("p_token",token));
                p.edit().putString("registered_user",user).putString("registered_token",token)
                    .putLong("registered_at",System.currentTimeMillis()).apply();
            }catch(Exception e){Log.w("MW-Push","Device token registration failed; polling remains active",e);}
            finally{busy.set(false);}
        },"mw-fcm-register").start();
    }
    static void unregisterNow(Context context,Api api){
        android.content.SharedPreferences p=context.getSharedPreferences("muwahid_push",Context.MODE_PRIVATE);
        String token=p.getString("registered_token","");
        if(api!=null&&api.signedIn()&&!token.isEmpty()){
            try{api.rpc("mw_push_unregister",new JSONObject().put("p_token",token));}
            catch(Exception e){Log.w("MW-Push","Token unregister failed",e);}
        }
        p.edit().remove("registered_token").remove("registered_user").remove("registered_at").apply();
    }
}
