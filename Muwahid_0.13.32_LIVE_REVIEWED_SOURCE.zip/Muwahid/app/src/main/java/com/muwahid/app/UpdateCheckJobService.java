package com.muwahid.app;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import java.util.List;

/** Background update discovery: periodic (not real-time) and independent of login/session. */
public final class UpdateCheckJobService extends JobService {
    private static final int JOB_ID=410030;
    private static final long PERIOD_MS=15L*60L*1000L;
    private volatile boolean stopped;

    public static void ensureScheduled(Context context){
        try{
            JobScheduler scheduler=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if(scheduler==null)return;
            List<JobInfo> jobs=scheduler.getAllPendingJobs();
            if(jobs!=null)for(JobInfo job:jobs)if(job.getId()==JOB_ID)return;
            JobInfo job=new JobInfo.Builder(JOB_ID,new ComponentName(context,UpdateCheckJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(PERIOD_MS)
                .setPersisted(true)
                .build();
            scheduler.schedule(job);
        }catch(RuntimeException ignored){
            // Battery/vendor policy may block background scheduling; foreground checks still work.
        }
    }

    @Override public boolean onStartJob(JobParameters params){
        stopped=false;
        UpdateManager.checkAndNotify(this,false,()->{
            if(!stopped)jobFinished(params,false);
        });
        return true;
    }

    @Override public boolean onStopJob(JobParameters params){
        stopped=true;
        return true; // Try again if Android interrupted this job.
    }
}
