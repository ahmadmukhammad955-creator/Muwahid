# Muwahid 0.13.22 — audio room implementation

The same 0.13.22 version now implements the reference room structure rather than creating a new numbered build.

## Real room behavior

- The room creator/host is separate from the microphone grid and does not consume a seat.
- Eight independent microphone seats remain available in a 4×2 grid.
- Listeners can raise a hand, moderators can promote/demote, and Free Mode lets listeners claim an empty seat themselves.
- Room roles, moderation, bans, microphone permission, seat ownership and synchronized room settings are enforced in Supabase.
- Compact floating room comments replace the permanent full-height chat block.
- Shared reading remains real but opens only when requested from Tools instead of permanently occupying the room screen.

## Tools implemented

- Mixer: real Web Audio microphone gain, effects, equalizer, timbre filters and processed-mic monitor.
- Music: local Android audio picker mixed into the outgoing room audio.
- Sounds: generated soundboard effects mixed into the room audio.
- Free Mode: synchronized through Supabase.
- Program list: synchronized room program entries stored in Supabase.
- Screen share: uses `navigator.mediaDevices.getDisplayMedia()` and WebRTC video-track renegotiation where the installed Android System WebView supports display capture. Unsupported WebView versions report that limitation instead of pretending the broadcast started.
- YouTube: moderator shares a safe HTTPS YouTube link through Supabase; every participant can open the same link in the official YouTube/app/browser handler. Muwahid does not illegally restream YouTube media.
- Karaoke: local backing track + the real karaoke microphone effect.
- Theme: synchronized room theme stored in Supabase.
- Users / Management: participant list, moderator controls, kick/ban and room close.
- Comments: compact overlay + composer/media picker.
- Live support: rebuilds WebRTC peer connections without leaving the room.
- Recording: MediaRecorder captures mixed local/remote room audio and saves through Android MediaStore.
- Newcomers: real joined-at based NEW marker for the first five minutes, with a synchronized room toggle.
- Data center: live room participant, stage, microphone and WebRTC connection counts.
- Broadcast time: calculated from the server room `created_at` timestamp.
- Stickers: room sticker/reaction panel sent through the real room message RPC.
- Shared reading: existing synchronized PDF session remains available from Tools.

## Networking note

Audio/video peer connectivity still uses public STUN. A dedicated TURN service is recommended for production reliability across restrictive mobile carrier/NAT networks.
