# Muwahid 0.13.16 — balanced modern icon polish

Версия 0.13.16 исправляет перегруженный интерфейс 0.13.14. Иконки больше не огромные: используется единый тонкий outline-стиль, умеренные контейнеры и одинаковая визуальная толщина.

## Что изменено

- Верхние кнопки камеры и создания чата: 42dp вместо 50dp.
- Нижняя навигация: иконки 32dp с внутренними отступами, общая высота 64dp.
- В чате кнопки назад/звонок/видео уменьшены до 40dp-контейнеров.
- Phone/video/camera/back/more отрисованы в более тонком rounded outline-стиле.
- Толщина основных line-icons уменьшена до 1.65 виртуальных px.
- Поле ввода: 50dp, панель композера 64dp, кнопка микрофона/отправки 48dp.
- Карточка чата и аватар уменьшены до более аккуратных размеров.
- Runtime smoke-test проверяет не только наличие иконок, но и допустимый диапазон размеров, чтобы снова не получить слишком мелкие или слишком крупные элементы.

## Версия

- versionName: `0.13.16`
- versionCode: `49`

## Сборка

Workflow `.github/workflows/build-apk.yml` ожидает `Muwahid_0.13.16_PROJECT.zip` и проверяет версию перед сборкой.


## 0.13.16 stage 1
- update APK downloads inside Muwahid with SHA-256 verification; browser/GitHub login is not part of the update flow
- incoming-call ringtone loops until answer/reject; users can select system sound, silence, or their own audio file
- voice-message recording has pause/resume, cancel, preview, re-record and send
- presence/last-seen backend migration and open-listener voice-room migration are included in `backend/023_presence_and_open_voice_rooms.sql`


## 0.13.17 stage 2
Profile status/background and expanded group/channel management UI. Run `backend/024_profile_status.sql` after the existing migrations to sync profile bio/status. Community settings are still local-only in this stage.
