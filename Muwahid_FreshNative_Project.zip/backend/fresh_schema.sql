-- New namespaced Muwahid native application data model.
-- Isolated from the legacy Muwahid tables. No drops or changes to legacy tables.
create table if not exists public.mfresh_profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text unique not null check(username ~ '^[a-z0-9_]{3,30}$'),
 display_name text not null default 'Пользователь' check(length(display_name) between 1 and 80),
 bio text not null default '' check(length(bio)<=500),
 avatar_path text, cover_path text,
 last_seen timestamptz not null default now(), created_at timestamptz not null default now()
);
create table if not exists public.mfresh_stories (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.mfresh_profiles(id) on delete cascade,
 object_path text not null unique,
 kind text not null check(kind in ('image','video')),
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default (now() + interval '24 hours'),
 pinned boolean not null default false,
 check(expires_at >= created_at)
);
create index if not exists mfresh_stories_owner_time on public.mfresh_stories(user_id,created_at desc);
create table if not exists public.mfresh_story_views (
 story_id uuid not null references public.mfresh_stories(id) on delete cascade,
 viewer_id uuid not null references auth.users(id) on delete cascade,
 viewed_at timestamptz not null default now(),
 primary key(story_id,viewer_id)
);
create table if not exists public.mfresh_messages (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references public.mfresh_profiles(id) on delete cascade,
 recipient_id uuid not null references public.mfresh_profiles(id) on delete cascade,
 body text not null check(length(trim(body)) between 1 and 2000),
 created_at timestamptz not null default now(),
 check(sender_id<>recipient_id)
);
create index if not exists mfresh_messages_pair on public.mfresh_messages(sender_id,recipient_id,created_at desc);
create table if not exists public.mfresh_contacts (
 user_id uuid not null references public.mfresh_profiles(id) on delete cascade,
 contact_id uuid not null references public.mfresh_profiles(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key(user_id,contact_id), check(user_id<>contact_id)
);

alter table public.mfresh_profiles enable row level security;
alter table public.mfresh_stories enable row level security;
alter table public.mfresh_story_views enable row level security;
alter table public.mfresh_messages enable row level security;
alter table public.mfresh_contacts enable row level security;

create policy "mfresh profiles readable signed in" on public.mfresh_profiles for select to authenticated using (true);
create policy "mfresh profiles owner inserts" on public.mfresh_profiles for insert to authenticated with check (id=(select auth.uid()));
create policy "mfresh profiles owner updates" on public.mfresh_profiles for update to authenticated using(id=(select auth.uid())) with check(id=(select auth.uid()));
create policy "mfresh stories visible or owner" on public.mfresh_stories for select to authenticated
 using (user_id=(select auth.uid()) or expires_at>now() or pinned);
create policy "mfresh stories owner publishes" on public.mfresh_stories for insert to authenticated
 with check (user_id=(select auth.uid()) and object_path like ((select auth.uid())::text || '/stories/%') and expires_at<=now()+interval '25 hours');
create policy "mfresh stories owner edits" on public.mfresh_stories for update to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
create policy "mfresh stories owner deletes" on public.mfresh_stories for delete to authenticated using(user_id=(select auth.uid()));
create policy "mfresh story views owner and viewer read" on public.mfresh_story_views for select to authenticated
 using (viewer_id=(select auth.uid()) or exists(select 1 from public.mfresh_stories s where s.id=story_id and s.user_id=(select auth.uid())));
create policy "mfresh story views signed-in insert" on public.mfresh_story_views for insert to authenticated
 with check (viewer_id=(select auth.uid()) and exists(select 1 from public.mfresh_stories s where s.id=story_id and (s.user_id=(select auth.uid()) or s.expires_at>now() or s.pinned)));
create policy "mfresh messages only participants read" on public.mfresh_messages for select to authenticated
 using(sender_id=(select auth.uid()) or recipient_id=(select auth.uid()));
create policy "mfresh messages sender inserts" on public.mfresh_messages for insert to authenticated with check(sender_id=(select auth.uid()));
create policy "mfresh contacts owner read" on public.mfresh_contacts for select to authenticated using(user_id=(select auth.uid()));
create policy "mfresh contacts owner add" on public.mfresh_contacts for insert to authenticated with check(user_id=(select auth.uid()));
create policy "mfresh contacts owner remove" on public.mfresh_contacts for delete to authenticated using(user_id=(select auth.uid()));

grant select,insert,update on public.mfresh_profiles to authenticated;
grant select,insert,update,delete on public.mfresh_stories to authenticated;
grant select,insert on public.mfresh_story_views to authenticated;
grant select,insert on public.mfresh_messages to authenticated;
grant select,insert,delete on public.mfresh_contacts to authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
 values('mfresh-profile','mfresh-profile',false,8388608,array['image/jpeg']),
 ('mfresh-stories','mfresh-stories',false,26214400,array['image/jpeg','video/mp4'])
 on conflict(id) do nothing;

create policy "mfresh image upload by owner" on storage.objects for insert to authenticated
 with check (bucket_id='mfresh-profile' and name like ((select auth.uid())::text || '/%'));
create policy "mfresh image read signed-in" on storage.objects for select to authenticated
 using (bucket_id='mfresh-profile');
create policy "mfresh image owner delete" on storage.objects for delete to authenticated
 using (bucket_id='mfresh-profile' and name like ((select auth.uid())::text || '/%'));
create policy "mfresh story upload by owner" on storage.objects for insert to authenticated
 with check (bucket_id='mfresh-stories' and name like ((select auth.uid())::text || '/stories/%'));
create policy "mfresh story read by owner or active audience" on storage.objects for select to authenticated
 using (bucket_id='mfresh-stories' and (
 name like ((select auth.uid())::text || '/stories/%') or
 exists (select 1 from public.mfresh_stories s where s.object_path=name and (s.expires_at>now() or s.pinned))
 ));
create policy "mfresh story delete by owner" on storage.objects for delete to authenticated
 using (bucket_id='mfresh-stories' and name like ((select auth.uid())::text || '/stories/%'));
