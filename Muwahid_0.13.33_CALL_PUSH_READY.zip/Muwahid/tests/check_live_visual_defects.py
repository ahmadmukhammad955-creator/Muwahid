"""Regression checks for eight occupied seats and safe video-call placeholder."""
from pathlib import Path
import subprocess
import re
root=Path(__file__).resolve().parents[1]
room=(root/'app/src/main/assets/voice_room.html').read_text()
call=(root/'app/src/main/java/com/muwahid/app/CallActivity.java').read_text()
assert 'data-seat="${position}" data-user-id="${m.id}"' in room, 'occupied circles need a seat index'
assert 'class="seat empty" data-seat="${position}"' in room, 'empty circles need a seat index'
assert 'visibility:hidden}' in call and '.videoCall #remote.ready{visibility:visible}' in call
assert "id='remotePlaceholder'" in call
assert 'videoWidth>0&&v.videoHeight>0&&!v.paused' in call
assert "addEventListener(eventName,syncRemoteVideo)" in call
# Verify all inline JS from the room still parses.
room_js=re.findall(r'<script>([\s\S]*?)</script>',room)
assert len(room_js)==2
proc=subprocess.run(['node','--check','-'],input=room_js[-1],text=True,capture_output=True)
assert proc.returncode==0,proc.stderr
# Extract Java string literal chunks in JS, decode Java escape sequences, then test JS syntax.
scope=call.split('private static final String JS=""+',1)[1].split('";\n}',1)[0]
chunks=re.findall(r'^"((?:\\.|[^"\\])*)"\s*\+?;?\s*$',scope,re.M)
assert len(chunks)>15,len(chunks)
script=''.join(bytes(t,'utf-8').decode('unicode_escape') for t in chunks)
proc=subprocess.run(['node','--check','-'],input=script,text=True,capture_output=True)
assert proc.returncode==0,proc.stderr
print('MW_VISUAL_DEFECTS_SOURCE_OK')
