# Muwahid 0.13.22 — Audio room deep check

- VoiceRoomActivity keeps microphone permission gated and only trusts the local muwahid.local WebView origin.
- Room audio remains WebRTC; no mock playback is used for peer audio.
- Web Audio graph mixes microphone, optional local music and generated soundboard effects into the outgoing peer track.
- Moderator/owner RPC checks remain server-side in Supabase migrations.
- Room recording uses MediaRecorder and Android MediaStore; chunks are written through a single-threaded native worker.
- External HTTP(S) navigation remains blocked inside the room WebView.
- Version: 0.13.22 / code 56.
