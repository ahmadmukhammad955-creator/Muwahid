package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.concurrent.*;

/** Values shown here come from the server; failed writes never appear saved. */
public final class PrivacyActivity extends Activity {
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private Api api; private LinearLayout root,content; private int page;
    private boolean busy,enableLock; private JSONObject settings;
    private final int bg=Color.rgb(23,33,43),panel=Color.rgb(30,42,54),ink=Color.rgb(245,247,249),blue=Color.rgb(122,181,220),muted=Color.rgb(126,141,154);
    interface Task{Object run() throws Exception;} interface Done{void run(Object v)throws Exception;}
    @Override public void onCreate(Bundle b){super.onCreate(b);if(b!=null)enableLock=b.getBoolean("enable_lock");if(AppLock.guard(this))return;api=new Api(new SecureStore(this));if(getIntent().getBooleanExtra("devices",false))devices();else dashboard();}
    @Override protected void onResume(){super.onResume();if(!isFinishing())AppLock.guard(this);}
    @Override protected void onDestroy(){worker.shutdownNow();ui.removeCallbacksAndMessages(null);super.onDestroy();}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    void screen(String title){page++;busy=false;root=vertical();root.setBackgroundColor(bg);setContentView(root);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;});root.requestApplyInsets();
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);TextView back=text("×",32,ink);back.setGravity(Gravity.CENTER);back.setContentDescription("Назад");bar.addView(back,new LinearLayout.LayoutParams(dp(58),dp(56)));back.setOnClickListener(v->onBackPressed());TextView heading=text(title,21,ink);heading.setTypeface(null,Typeface.BOLD);bar.addView(heading,new LinearLayout.LayoutParams(0,-2,1));root.addView(bar);
        ScrollView scroll=new ScrollView(this);content=vertical();content.setPadding(dp(12),dp(12),dp(12),dp(30));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }
    LinearLayout card(String title){LinearLayout c=vertical();GradientDrawable d=new GradientDrawable();d.setColor(panel);d.setCornerRadius(dp(18));c.setBackground(d);c.setPadding(dp(14),dp(8),dp(14),dp(6));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(12);content.addView(c,p);if(title!=null){TextView t=text(title,15,blue);t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(2),dp(10),0,dp(10));c.addView(t);}return c;}
    void row(LinearLayout c,String title,String value,Runnable action){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setMinimumHeight(dp(55));r.setPadding(dp(2),dp(10),dp(2),dp(10));TextView name=text(title,17,ink);r.addView(name,new LinearLayout.LayoutParams(0,-2,1));if(value!=null){TextView v=text(value,16,blue);v.setMaxWidth(dp(145));v.setGravity(Gravity.RIGHT);v.setPadding(dp(12),0,0,0);r.addView(v);}r.setContentDescription(title+(value==null?"":": "+value));if(action!=null){r.setBackgroundResource(android.R.drawable.list_selector_background);r.setOnClickListener(v->{if(!busy)action.run();});}c.addView(r);View line=new View(this);line.setBackgroundColor(bg);c.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}
    void note(String s){TextView t=text(s,14,muted);t.setPadding(dp(12),dp(12),dp(12),dp(6));content.addView(t);}
    void notice(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("Понятно",null).show();}
    void call(Task task,Done done){final int stamp=page;busy=true;worker.execute(()->{try{Object result=task.run();ui.post(()->{if(isFinishing()||isDestroyed()||stamp!=page)return;busy=false;try{done.run(result);}catch(Exception e){failure(e);}});}catch(Exception e){ui.post(()->{if(isFinishing()||isDestroyed()||stamp!=page)return;busy=false;failure(e);});}});}
    void failure(Exception e){if(e instanceof Api.MfaRequiredException){new AlertDialog.Builder(this).setMessage("Подтвердите второй фактор, чтобы открыть настройки конфиденциальности.").setPositiveButton("Подтвердить",(d,w)->openMfa()).setNegativeButton("Отмена",null).show();}else notice(e instanceof java.io.IOException?"Нет связи с сервером. Настройка не изменена. Попробуйте ещё раз.":e.getMessage()==null?"Не удалось выполнить действие":e.getMessage());}
    void openMfa(){startActivity(new Intent(this,MainActivity.class).putExtra("open_security_mfa",true));finish();}
    void dashboard(){screen("Конфиденциальность");render(null,null);if(api.signedIn())call(()->new JSONObject().put("privacy",api.rpc("mw_privacy_get",new JSONObject())).put("factors",api.factors()),r->{JSONObject all=(JSONObject)r;settings=all.getJSONObject("privacy");content.removeAllViews();render(settings,all.getJSONArray("factors"));});}
    void render(JSONObject data,JSONArray factors){
        LinearLayout security=card("Безопасность");boolean verified=false;if(factors!=null)for(int i=0;i<factors.length();i++){JSONObject f=factors.optJSONObject(i);if(f!=null&&"verified".equals(f.optString("status")))verified=true;}
        row(security,"Двухэтапная проверка",factors==null?"Проверить":verified?"Вкл.":"Выкл.",this::openMfa);
        row(security,"Код-пароль",AppLock.enabled(this)?"Вкл.":"Выкл.",this::lockSettings);
        row(security,"Почта для входа",api.maskedEmail(),()->notice("Почта текущего аккаунта: "+api.maskedEmail()+". Смена почты в этом выпуске не подключена."));
        row(security,"Чёрный список",data==null?"Открыть":String.valueOf(data.optInt("blocked_count")),()->people("blocks"));
        row(security,"Устройства","Открыть",this::devices);
        note("Код-пароль использует блокировку экрана Android. Второй фактор — код из приложения-аутентификатора.");
        LinearLayout privacy=card("Конфиденциальность");
        row(privacy,"Номер телефона","Никто",()->notice("Muwahid не передаёт Ваш номер другим пользователям. Отдельно можно настроить, кто находит Вас по уже известному номеру."));
        rule(privacy,"Поиск по номеру","phone_search",data,"Кто может найти Вас, введя Ваш номер? Поиск по имени пользователя остаётся доступен.");
        rule(privacy,"Звонки","calls",data,"Кто может начинать аудио- и видеозвонки с Вами?");
        rule(privacy,"Сообщения","messages",data,"Кто может отправлять Вам новые сообщения, включая фото, видео и голосовые? Настройка действует и в существующих личных чатах.");
        note("«Контакты» — люди, которых Вы добавили в список ниже. Чёрный список запрещает новые сообщения и звонки в обе стороны. История переписки сохраняется.");
        LinearLayout contacts=card("Контакты");row(contacts,"Доверенные контакты",data==null?"Открыть":String.valueOf(data.optInt("contacts_count")),()->people("contacts"));
        row(contacts,"Синхронизация телефона","Не подключена",()->notice("Muwahid не читает и не загружает адресную книгу телефона. Добавляйте доверенные контакты вручную."));
        LinearLayout future=card("Функции с Вашего примера");row(future,"Остальные настройки","Подробнее",this::unavailable);
        note("Настройки сообщений, звонков и поиска сохраняются в аккаунте и проверяются сервером.");
        row(card(null),"Обновить настройки",null,this::dashboard);
    }
    void rule(LinearLayout card,String title,String key,JSONObject data,String explanation){String v=data==null?null:data.optString(key);row(card,title,v==null?"Загрузить":audience(v),()->{
        if(data==null){dashboard();return;}String[] values={"everyone","contacts","nobody"},labels={"Все","Контакты","Никто"};int selected="contacts".equals(v)?1:"nobody".equals(v)?2:0;
        new AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(labels,selected,(d,w)->{d.dismiss();new AlertDialog.Builder(this).setTitle(labels[w]).setMessage(explanation).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(dialog,which)->call(()->api.rpc("mw_privacy_set",new JSONObject().put("p_key",key).put("p_value",values[w])),r->{dashboard();Toast.makeText(this,"Сохранено",Toast.LENGTH_SHORT).show();})).show();}).setNegativeButton("Отмена",null).show();});}
    String audience(String v){return "contacts".equals(v)?"Контакты":"nobody".equals(v)?"Никто":"Все";}
    void people(String list){screen("blocks".equals(list)?"Чёрный список":"Доверенные контакты");row(card(null),"Добавить пользователя","+",()->addPerson(list));note("Загрузка списка…");call(()->api.rpc("mw_privacy_people",new JSONObject().put("p_list",list)),r->{content.removeAllViews();row(card(null),"Добавить пользователя","+",()->addPerson(list));JSONArray rows=(JSONArray)r;if(rows.length()==0){note("Список пуст");return;}LinearLayout card=card(null);for(int i=0;i<rows.length();i++){JSONObject p=rows.getJSONObject(i);row(card,p.optString("display_name"),p.optString("username"),()->new AlertDialog.Builder(this).setMessage("Удалить "+p.optString("display_name")+" из списка?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->setPerson(list,p.optString("id"),false)).show());}});}
    void addPerson(String list){EditText input=new EditText(this);input.setSingleLine(true);input.setHint("@имя пользователя");new AlertDialog.Builder(this).setTitle("Добавить пользователя").setView(input).setNegativeButton("Отмена",null).setPositiveButton("Найти",(d,w)->{String query=input.getText().toString().trim();call(()->api.rpc("mw_find_person_any",new JSONObject().put("p_query",query)),r->{if(!(r instanceof JSONObject)){notice("Пользователь не найден");return;}JSONObject p=(JSONObject)r;new AlertDialog.Builder(this).setTitle(p.optString("display_name")).setMessage("@"+p.optString("username")+("blocks".equals(list)?"\nЗаблокировать новые сообщения и звонки?":"\nДобавить в доверенные контакты?" )).setNegativeButton("Отмена",null).setPositiveButton("Добавить",(dialog,which)->setPerson(list,p.optString("id"),true)).show();});}).show();}
    void setPerson(String list,String id,boolean enabled){call(()->{api.rpc("mw_privacy_person_set",new JSONObject().put("p_list",list).put("p_person",id).put("p_enabled",enabled));return true;},r->people(list));}
    void devices(){screen("Устройства");note("Загрузка сеансов…");call(()->api.rpc("mw_sessions_list",new JSONObject()),r->{content.removeAllViews();JSONArray rows=(JSONArray)r;LinearLayout card=card("Сеансы аккаунта");for(int i=0;i<rows.length();i++){JSONObject s=rows.getJSONObject(i);row(card,s.optBoolean("current")?"Это устройство":"Другой сеанс",s.optString("last_active").replace('T',' ').substring(0,Math.min(16,s.optString("last_active").length())),null);}if(rows.length()==0)note("Нет активных сеансов");row(card(null),"Завершить другие сеансы",null,()->new AlertDialog.Builder(this).setMessage("Другим устройствам потребуется повторный вход. Уже выданный токен может действовать до истечения его срока.").setNegativeButton("Отмена",null).setPositiveButton("Завершить",(d,w)->call(()->{api.logoutOthers();return true;},v->devices())).show());});}
    void lockSettings(){new AlertDialog.Builder(this).setTitle("Код-пароль").setMessage("Приложение попросит код блокировки телефона при новом запуске и после минуты в фоне. При включённой защите снимки экрана запрещены. Код хранит только Android.").setNegativeButton("Отмена",null).setPositiveButton(AppLock.enabled(this)?"Выключить":"Включить",(d,w)->{
        enableLock=!AppLock.enabled(this);KeyguardManager k=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);Intent confirm=k.createConfirmDeviceCredentialIntent("Muwahid",enableLock?"Включить блокировку приложения":"Выключить блокировку приложения");if(confirm==null){notice("Сначала установите PIN, пароль или графический ключ экрана в настройках Android.");return;}startActivityForResult(confirm,9);
    }).show();}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==9&&result==RESULT_OK){getSharedPreferences("muwahid",MODE_PRIVATE).edit().putBoolean("app_lock",enableLock).apply();AppLock.unlock();if(enableLock)getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);dashboard();}}
    @Override protected void onSaveInstanceState(Bundle b){b.putBoolean("enable_lock",enableLock);super.onSaveInstanceState(b);}
    void unavailable(){screen("Ещё не подключено");note("Эти функции есть на присланных снимках, но пока отсутствуют в Muwahid. Они не включаются переключателем.");LinearLayout c=card(null);for(String s:new String[]{"Облачный пароль","Ключи доступа","Автоудаление сообщений","Время захода и фотографии профиля","Пересылка сообщений","Отдельные правила для голосовых","День рождения и «О себе»","Подарки и сохранённая музыка","Приглашения в группы и каналы","Удаление неактивного аккаунта","Данные платежей и доставки","Синхронизация и подсказки контактов","Секретные чаты, карты и ссылки"})row(c,s,"Не подключено",null);note("Личные сообщения шифруются в существующем режиме Muwahid. Это не реализация секретных чатов Telegram.");}
    @Override public void onBackPressed(){if(root!=null&&"Конфиденциальность".equals(((TextView)((LinearLayout)root.getChildAt(0)).getChildAt(1)).getText().toString()))finish();else dashboard();}
}
