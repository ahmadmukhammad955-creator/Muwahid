begin;

alter table public.mw_profiles
  add column if not exists bio text not null default '',
  add column if not exists status_text text not null default '',
  add column if not exists status_emoji text not null default '',
  add column if not exists status_expires_at timestamptz;

alter table public.mw_profiles
  drop constraint if exists mw_profiles_bio_len,
  add constraint mw_profiles_bio_len check (char_length(bio) <= 70);

alter table public.mw_profiles
  drop constraint if exists mw_profiles_status_len,
  add constraint mw_profiles_status_len check (char_length(status_text) <= 60 and char_length(status_emoji) <= 16);

create or replace function public.mw_update_profile_extended(p_name text,p_username text,p_bio text)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if p_username !~ '^[a-z0-9_]{4,32}$' then raise exception 'MW:Имя: 4–32 латинские буквы, цифры или знак _'; end if;
  if char_length(btrim(p_name)) not between 1 and 60 then raise exception 'MW:Укажите имя до 60 символов'; end if;
  if char_length(coalesce(p_bio,'')) > 70 then raise exception 'MW:Поле «О себе» — максимум 70 символов'; end if;
  update public.mw_profiles
     set username=lower(btrim(p_username)),
         display_name=btrim(p_name),
         bio=coalesce(p_bio,'')
   where id=auth.uid();
  return public.mw_me();
end;
$$;

create or replace function public.mw_update_profile_status(p_status_text text,p_status_emoji text,p_expires_at timestamptz default null)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if char_length(coalesce(p_status_text,'')) > 60 then raise exception 'MW:Статус — максимум 60 символов'; end if;
  if char_length(coalesce(p_status_emoji,'')) > 16 then raise exception 'MW:Слишком длинный значок статуса'; end if;
  update public.mw_profiles
     set status_text=coalesce(p_status_text,''),
         status_emoji=coalesce(p_status_emoji,''),
         status_expires_at=p_expires_at
   where id=auth.uid();
  return public.mw_me();
end;
$$;

revoke all on function public.mw_update_profile_extended(text,text,text) from public,anon,authenticated;
revoke all on function public.mw_update_profile_status(text,text,timestamptz) from public,anon,authenticated;
grant execute on function public.mw_update_profile_extended(text,text,text) to authenticated;
grant execute on function public.mw_update_profile_status(text,text,timestamptz) to authenticated;

commit;
