-- Muwahid 0.12.2: close a voice room for everyone.
create or replace function public.mw_room_end(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  if auth.uid() is null then
    raise exception 'MW:Войдите в аккаунт';
  end if;
  if not mw_private.room_can_moderate(p_room,auth.uid()) then
    raise exception 'MW:Только владелец или модератор может закрыть комнату';
  end if;
  if not exists(select 1 from public.mw_voice_rooms where id=p_room and active=true) then
    return jsonb_build_object('closed',true,'already_closed',true);
  end if;
  update public.mw_voice_rooms set active=false where id=p_room;
  update public.mw_voice_room_book_sessions set active=false,updated_at=now() where room_id=p_room and active=true;
  delete from public.mw_voice_room_waiting where room_id=p_room;
  delete from public.mw_voice_room_members where room_id=p_room;
  delete from public.mw_voice_room_hands where room_id=p_room;
  delete from public.mw_voice_room_signals where room_id=p_room;
  return jsonb_build_object('closed',true,'already_closed',false);
end $$;
revoke all on function public.mw_room_end(uuid) from public,anon,authenticated;
grant execute on function public.mw_room_end(uuid) to authenticated;
