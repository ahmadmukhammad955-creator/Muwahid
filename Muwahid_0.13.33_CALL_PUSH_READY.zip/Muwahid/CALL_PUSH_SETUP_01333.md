# Muwahid 0.13.33 — background call delivery / LIVE background

## Already live in Supabase

- `public.mw_room_background_get(uuid)` restored with membership checks (previously RPC HTTP 404).

## Required steps for real instant incoming calls while Android is backgrounded

The old 5-second RPC polling continues as fallback. Polling **cannot** reliably wake a sleeping Android app. For timely ringing, configure **Firebase Cloud Messaging (FCM)**:

1. In Firebase Console, create a Firebase project and add Android app with **package name `com.muwahid.app`**; enable Cloud Messaging (FCM HTTP v1). Do not put service-account JSON in GitHub or in APK.
2. In **GitHub repository Settings -> Secrets and variables -> Actions -> New repository secret**, add public app configuration from Firebase project's Android app details: `MUWAHID_FCM_APP_ID`, `MUWAHID_FCM_API_KEY`, `MUWAHID_FCM_SENDER_ID`, `MUWAHID_FCM_PROJECT_ID`. These four values are not service-account credentials but are passed as secrets to avoid accidental mismatch. Without them, the APK still compiles; FCM remains disabled.
3. SQL migration `backend/036_android_call_push.sql` has already been applied to Supabase project `pucxqnegbnjzawzwnpjh` in this work session; do not reapply blindly. Tokens stay in `mw_private`, RPC registration requires authentication and MFA.
4. In Supabase Edge Function secrets set `MUWAHID_FCM_SERVICE_ACCOUNT_JSON` to the **entire JSON contents** of the Firebase service-account credentials and `MUWAHID_PUSH_WEBHOOK_SECRET` to an independently generated random 32+ character value. Never send these to ChatGPT, store in a public repo, or embed in Android app. Supabase supplies `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to functions where available.
5. Deploy `supabase/functions/muwahid-call-push` as Edge Function `muwahid-call-push` with JWT verification disabled **only because a private webhook secret is REQUIRED and checked on each request**. The function fails closed if the secret is missing.
6. Supabase Dashboard -> Database -> Webhooks: add POST webhook on **`public.mw_calls` INSERT**, URL `https://pucxqnegbnjzawzwnpjh.supabase.co/functions/v1/muwahid-call-push`. Add header `x-muwahid-hook: <same secret>`. Send `Content-Type: application/json`. It is essential not to turn on webhook before deploying the Edge Function and providing its secrets.
7. Replace root GitHub `.github/workflows/build-apk.yml` with companion `build-apk-0.13.33.yml` and upload archive `Muwahid_0.13.33_CALL_PUSH_READY.zip` at repository root. The workflow unzips archive to `Muwahid/`, checks versionCode `68` and versionName `0.13.33`, and builds test APK.
8. Test calls on two real Android devices with user accounts: app open, backgrounded, screen locked, network transitions; observe server webhook delivery and Firebase function logs, call notification vs call creation timestamps. Existing 90-second expiry intentionally prevents stale calls from ringing 5-10 minutes later.

## Conditions and limits

- FCM delivery depends on Android/Google Play services and OEM battery policies; there is no unconditional delivery guarantee.
- Device without Google Play services requires an alternative delivery solution; installing APK outside Google Play is still supported on devices with Play services.
- New version is installable as an update only if signed with the SAME certificate as the installed APK (`MUWAHID_KEYSTORE_B64`/`MUWAHID_KEYSTORE_PASSWORD`). Don't publish an unsigned or differently signed release over installed app.
- No end-to-end test of FCM deliveries on two physical devices has been performed; code and SQL checks are not a substitute.
- The initial LIVE background RPC 404 was corrected on the live server, but verify background visibility and access on devices.
