package com.muwahid.app;

import android.graphics.*;
import java.io.ByteArrayOutputStream;

/** Original vector artwork. No emoji glyphs, fonts, remote URLs or third-party packs. */
public final class StickerCatalog {
    public static final String[] PACKS={"Кот Мува","Облачко"};
    public static final String[] MOODS={"Привет","Люблю","Ура","Грущу","Сплю","Спасибо"};
    public static String name(int id){check(id);return PACKS[id/6]+" · "+MOODS[id%6];}
    private static void check(int id){if(id<0||id>=12)throw new IllegalArgumentException("Unknown sticker");}
    public static Bitmap bitmap(int id){
        check(id);int mood=id%6;boolean cat=id<6;
        Bitmap b=Bitmap.createBitmap(384,384,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(b);c.scale(1.5f,1.5f);Paint p=new Paint(3);
        int ink=Color.rgb(49,48,73),fur=cat?Color.rgb(255,199,119):Color.rgb(179,221,255);
        Path body=new Path();
        if(cat){body.moveTo(53,105);body.lineTo(48,37);body.quadTo(48,28,59,35);body.lineTo(91,64);body.quadTo(128,50,163,64);body.lineTo(197,35);body.quadTo(207,28,206,42);body.lineTo(202,108);body.cubicTo(237,182,204,221,128,220);body.cubicTo(47,222,20,176,53,105);}
        else{body.moveTo(45,186);body.cubicTo(12,178,16,126,50,118);body.cubicTo(32,68,84,43,111,67);body.cubicTo(130,24,190,39,193,91);body.cubicTo(239,81,256,142,217,161);body.cubicTo(242,203,202,230,165,210);body.cubicTo(135,236,87,226,79,209);body.quadTo(43,226,45,186);}
        p.setStyle(Paint.Style.STROKE);p.setStrokeJoin(Paint.Join.ROUND);p.setStrokeWidth(19);p.setColor(Color.WHITE);c.drawPath(body,p);
        p.setStrokeWidth(5);p.setColor(ink);c.drawPath(body,p);p.setStyle(Paint.Style.FILL);p.setColor(fur);c.drawPath(body,p);
        if(cat){p.setColor(0xFFF58E9C);Path ear=new Path();ear.moveTo(59,48);ear.lineTo(65,91);ear.lineTo(84,71);ear.close();c.drawPath(ear,p);c.save();c.scale(-1,1,128,0);c.drawPath(ear,p);c.restore();}
        p.setColor(0x77F27795);c.drawOval(61,147,91,162,p);c.drawOval(166,147,196,162,p);
        p.setColor(ink);p.setStrokeWidth(6);p.setStrokeCap(Paint.Cap.ROUND);
        if(mood==1){heart(c,p,91,128,18,0xFFE55478);heart(c,p,166,128,18,0xFFE55478);}
        else if(mood==2||mood==4||mood==5){p.setStyle(Paint.Style.STROKE);c.drawArc(77,123,103,143,mood==4?0:180,180,false,p);c.drawArc(153,123,179,143,mood==4?0:180,180,false,p);p.setStyle(Paint.Style.FILL);}
        else{c.drawOval(84,120,96,142,p);c.drawOval(160,120,172,142,p);}
        p.setColor(ink);p.setStyle(Paint.Style.STROKE);
        if(mood==3)c.drawArc(111,169,144,193,190,160,false,p);
        else if(mood==4)c.drawOval(120,165,134,178,p);
        else c.drawArc(108,145,148,179,5,170,false,p);
        p.setStyle(Paint.Style.FILL);
        if(mood==3){p.setColor(0xFF42BCEE);Path tear=new Path();tear.moveTo(170,143);tear.cubicTo(145,173,188,180,170,143);c.drawPath(tear,p);}
        if(mood==1||mood==5)heart(c,p,cat?205:47,48,25,0xFFF26D96);
        if(mood==0){p.setColor(fur);c.drawOval(199,159,230,203,p);p.setColor(ink);p.setStyle(Paint.Style.STROKE);c.drawArc(219,140,245,185,260,90,false,p);c.drawArc(221,135,255,187,260,90,false,p);p.setStyle(Paint.Style.FILL);}
        if(mood==2){star(c,p,37,47,17);star(c,p,223,62,13);star(c,p,220,220,11);}
        if(mood==4){p.setColor(0xFF7074BC);p.setStyle(Paint.Style.STROKE);for(int i=0;i<3;i++){float x=189+i*14,y=80-i*21,s=11+i*3;c.drawLine(x,y,x+s,y,p);c.drawLine(x+s,y,x,y+s,p);c.drawLine(x,y+s,x+s,y+s,p);}p.setStyle(Paint.Style.FILL);}
        return b;
    }
    private static void heart(Canvas c,Paint p,float x,float y,float s,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);Path h=new Path();h.moveTo(x,y+s);h.cubicTo(x-s*2,y,x-s,y-s,x,y-s/3);h.cubicTo(x+s,y-s,x+s*2,y,x,y+s);c.drawPath(h,p);}
    private static void star(Canvas c,Paint p,float x,float y,float s){p.setColor(0xFFFFCF54);Path a=new Path();for(int i=0;i<10;i++){double t=i*Math.PI/5-Math.PI/2;float r=i%2==0?s:s*.45f,xx=x+(float)Math.cos(t)*r,yy=y+(float)Math.sin(t)*r;if(i==0)a.moveTo(xx,yy);else a.lineTo(xx,yy);}a.close();c.drawPath(a,p);}
    public static byte[] png(int id){Bitmap b=bitmap(id);try{ByteArrayOutputStream out=new ByteArrayOutputStream();if(!b.compress(Bitmap.CompressFormat.PNG,100,out))throw new IllegalStateException("PNG failed");return out.toByteArray();}finally{b.recycle();}}
}
