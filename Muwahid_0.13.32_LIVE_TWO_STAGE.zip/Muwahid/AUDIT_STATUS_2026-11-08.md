# Muwahid 0.13.32: source ZIP audit (2026-11-08)

This archive contains the Android source project, not an APK.

## Confirmed source-level corrections
- `MainActivity.java` foreground update check in the `Runnable` uses `MainActivity.this` (Android Activity), not bare `this` (`Runnable`). This addresses the reported Java compilation error at line 107 in a different/older bundle.
- Bottom navigation uses five functional destinations: Главная, Чаты, LIVE, Контакты, Настройки. The UI navigation contract in `VERIFY_PROJECT.sh` was updated accordingly, rather than leaving the old tab list.
- `UiIconDrawable` includes all five navigation icons; the LIVE button is an actual action, not a decorative picture.
- The included GitHub Actions workflow has Gradle 8.7 fallback sources and retains debug/release, emulator, and artifact steps. This workflow is INSIDE the ZIP; the repository's top-level workflow is a separate file.
- SHA-256 checksums are regenerated for all tracked source files.

## Not verified / NOT claimed
- No Android SDK or Gradle compiler available in this review environment; compilation, an installable APK, and device tests have NOT been completed.
- Real message exchange and authentication with two devices, media permissions, WebRTC/LiveKit SFU, background media continuity, and multistream have NOT been validated end-to-end.
- The LIVE Studio design is not an exact production implementation of the visual mockup.
- Some backend migrations/services may require deployment/configuration before features can work.
- The Android `versionCode 67`, `versionName 0.13.32` are intentionally unchanged until a verified release is ready.

## GitHub build source selection
The top-level GitHub Actions workflow currently references `Muwahid_0.13.32_LIVE_TWO_STAGE.zip` at repository root. It will NOT use this repaired source archive automatically. Upload/replace the bundle referenced by the workflow, or explicitly update the top-level workflow to point to the new archive file name, before testing.

## Emulator smoke failure on 2026-11-08 (follow-up)
- GitHub Actions successfully compiled and installed debug APK and Android test APK on an API 29 emulator.
- The smoke test failed at `Missing calls navigation` because it still expected the previous bottom-tab arrangement; the approved five bottom tabs now include `Главная` instead of `Звонки`.
- Updated `SmokeInstrumentation` to require the `Главная` bottom tab AND navigate via the clickable `Звонки` shortcut on the home screen, asserting `Недавние звонки` opens. Then it returns to chat checks. No calling feature was removed to make the check pass.
- The new smoke test **has not yet been executed on an emulator**. Other runtime failures may remain. This ZIP is a test-alignment source fix, NOT a confirmed APK or proof of functional calling.
