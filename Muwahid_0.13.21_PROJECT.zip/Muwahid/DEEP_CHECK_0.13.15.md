# Muwahid 0.13.15 deep check

- Base: 0.13.14.
- Version: 0.13.15 / versionCode 49.
- Main camera/create controls: 42dp.
- Chat audio/video controls: 40dp wide.
- Bottom navigation icons: 32dp containers with 5dp padding.
- Composer field: 50dp; composer bar: 64dp; send/mic: 48dp.
- UiIconDrawable line width: 1.65 with rounded caps and joins.
- Phone, video, camera, back and more glyph geometry refined.
- FIT_CENTER retained to avoid the original tiny-icon regression.
- Smoke tests enforce balanced min/max dimensions.
- REQUEST_INSTALL_PACKAGES must remain absent.
