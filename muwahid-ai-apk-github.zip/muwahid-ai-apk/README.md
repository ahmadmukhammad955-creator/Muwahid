# Muwahid AI — Android APK + AI backend

Готовый GitHub-проект Android-приложения для генерации изображений.

## Что уже есть

- Android APK-проект на Java без внешних Android-библиотек.
- Поле для адреса AI-сервера прямо в приложении.
- Поле описания изображения.
- Кнопка генерации.
- Просмотр результата.
- Сохранение изображения в галерею.
- GitHub Actions для автоматической сборки APK.
- Папка `backend/` с FastAPI + FLUX.1-schnell.
- В приложении нет собственного дневного лимита генераций.

## Важно

Сам APK не содержит FLUX-модель: она слишком большая для обычного Android-телефона. APK отправляет запрос на ваш AI/GPU-сервер. Поэтому фактическая скорость и объём генераций зависят от GPU, памяти и тарифов вашего сервера.

Проект не предназначен для обхода защитных ограничений.

## Как получить APK через GitHub

1. Создай новый репозиторий GitHub.
2. Загрузи туда всё содержимое этого архива.
3. Открой вкладку **Actions**.
4. Выбери **Build Android APK**.
5. Нажми **Run workflow**.
6. После сборки открой выполненный workflow.
7. Внизу в **Artifacts** скачай `Muwahid-AI-APK`.
8. Внутри будет `app-debug.apk`.

Workflow также запускается автоматически после push в `main` или `master`.

## Как подключить сервер

Сервер должен принимать:

```http
POST /generate
Content-Type: application/json
```

Пример запроса:

```json
{
  "prompt": "cinematic mountain landscape at sunrise",
  "width": 768,
  "height": 1024,
  "steps": 4,
  "seed": 42
}
```

Он может вернуть напрямую `image/png`. Встроенный backend именно так и работает.

После публикации backend введи в Android-приложении адрес вида:

```text
https://your-domain.example/generate
```

Для локальной сети также можно использовать:

```text
http://192.168.1.100:7860/generate
```

## Backend

Запуск на GPU-сервере:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 7860
```

Проверка:

```text
GET http://SERVER:7860/health
```

Для Hugging Face при необходимости задай `HF_TOKEN` на сервере.
