package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import androidx.core.content.FileProvider;
import java.io.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String OWNER_UUID="025a8bd0-c7ff-4e39-802a-f1c39ab76a9c";
    private int bg, panel, text, muted, line;
    private final int accent=Color.rgb(16,214,171), cyan=Color.rgb(22,191,231);
    private LinearLayout root, content, list, messages;
    private ScrollView messageScroll;
    private TextView connection;
    private EditText composer;
    private Button sendButton, attachButton, emojiButton, videoMessageButton;
    private static final int REQ_IMAGE=6101, REQ_VIDEO=6102, REQ_AUDIO=6103, REQ_VIDEO_MESSAGE=6104;
    private static final int REQ_RECORD_AUDIO_PERMISSION=6201, REQ_VIDEO_MESSAGE_PERMISSION=6202;
    private MediaRecorder voiceRecorder;
    private MediaPlayer inlineVoicePlayer;
    private String inlineVoicePath="";
    private TextView inlineVoiceButton, inlineVoiceDuration;
    private long inlineVoiceKnownDuration;
    private final Map<String,File> inlineVoiceCache=Collections.synchronizedMap(new HashMap<>());
    private final Set<String> inlineVoiceLoading=Collections.synchronizedSet(new HashSet<>());
    private final Runnable inlineVoiceTicker=new Runnable(){public void run(){
        if(inlineVoicePlayer==null)return;
        try{
            long pos=inlineVoicePlayer.getCurrentPosition(),dur=inlineVoicePlayer.getDuration();
            if(inlineVoiceDuration!=null)inlineVoiceDuration.setText(formatDuration(pos)+" / "+formatDuration(dur));
            if(inlineVoicePlayer.isPlaying())handler.postDelayed(this,200);
        }catch(Exception ignored){}
    }};
    private File voiceFile;
    private boolean voiceRecording;
    private long voiceStartedAt;
    private final Runnable voiceTicker=new Runnable(){public void run(){
        if(!voiceRecording)return;
        long elapsed=System.currentTimeMillis()-voiceStartedAt;
        if(connection!=null)connection.setText("🎙 Запись "+formatDuration(elapsed)+" · нажмите ■ для отправки");
        if(elapsed>=120000){stopVoiceRecording(true);return;}
        handler.postDelayed(this,1000);
    }};
    private Api api;
    private CryptoBox crypto;
    private android.content.SharedPreferences prefs;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private String screen="welcome", chatId="", chatName="", filter="";
    private String chatFolderFilter="all";
    private String mainTab="Чаты";
    private boolean phoneRegisterMode;
    private String pendingText="", pendingNonce="", peerE2eeKey="";
    private volatile String pendingPayload="", e2eePublishedFor="";
    private volatile boolean e2eePublishing;
    private boolean e2eeBackendReady;
    private JSONArray chats=new JSONArray();
    private final TreeMap<Long,JSONObject> history=new TreeMap<>();
    private JSONObject profile=new JSONObject();
    private int generation=0;
    private boolean foreground, loading, sending, notesMode, olderAvailable;
    private final Runnable poll=new Runnable(){public void run(){
        if(!foreground)return;
        if(!loading&&!sending&&api.signedIn()){
            if(screen.equals("chats"))loadChats(false);
            else if(screen.equals("chat")&&!notesMode)loadMessages(false);
        }
        handler.postDelayed(this,prefs.getBoolean("energy_saver",false)?12000:5000);
    }};
    interface Task { Object run() throws Exception; }
    interface Done { void accept(Object result) throws Exception; }
    @Override public void onCreate(Bundle b){
        super.onCreate(b); prefs=getSharedPreferences("muwahid",MODE_PRIVATE); api=new Api(new SecureStore(this)); crypto=new CryptoBox(this); colors();
        UpdateManager.checkAndNotify(this,false);
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        if(handleOAuthIntent(getIntent()))return;
        if(api.signedIn()){maybeStartNotifications();String id=getIntent().getStringExtra("open_chat_id");String name=getIntent().getStringExtra("open_chat_name");if(id!=null&&!id.isEmpty())showChat(id,name==null?"Чат":name);else showChats();}else showWelcome();
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(handleOAuthIntent(intent))return;if(api.signedIn()){String id=intent.getStringExtra("open_chat_id");if(id!=null&&!id.isEmpty())showChat(id,intent.getStringExtra("open_chat_name"));}}
    private boolean handleOAuthIntent(Intent intent){
        Uri data=intent==null?null:intent.getData();
        if(data==null||!"muwahid".equalsIgnoreCase(data.getScheme())||!"auth-callback".equalsIgnoreCase(data.getHost()))return false;
        begin("oauth");toolbar("Вход через Google",false,null,null);scrollContent();note(content,"Завершаем безопасный вход через Google…");
        final int stamp=generation;final String fragment=data.getFragment();
        worker.execute(()->{try{api.acceptOAuthCallback(fragment);handler.post(()->{if(stamp!=generation)return;maybeStartNotifications();showChats();});}catch(Exception ex){handler.post(()->{if(stamp!=generation)return;error(ex);showAuth(false);});}});
        return true;
    }
    private void maybeStartNotifications(){
        boolean messages=prefs.getBoolean("notify_messages",true),calls=prefs.getBoolean("notify_calls",true),updates=prefs.getBoolean("notify_updates",true);
        if(!messages&&!calls&&!updates){try{NotificationService.stop(this);}catch(Exception ignored){}return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=getPackageManager().PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},7001);
        try{NotificationService.ensureStarted(this);}catch(Exception ignored){}
    }
    @Override protected void onResume(){
        super.onResume();foreground=true;handler.removeCallbacks(poll);
        // If Android restored an already authenticated task on the public welcome screen,
        // return the user to the messenger instead of showing registration again.
        if(api!=null && api.signedIn() && "welcome".equals(screen)){showChats();return;}
        handler.postDelayed(poll,prefs.getBoolean("energy_saver",false)?12000:5000);
    }
    @Override protected void onPause(){saveDraft();foreground=false;handler.removeCallbacks(poll);if(voiceRecording)cancelVoiceRecording(false);super.onPause();}
    @Override protected void onDestroy(){stopInlineVoice();handler.removeCallbacksAndMessages(null);worker.shutdownNow();super.onDestroy();}
    private void colors(){boolean dark=prefs.getBoolean("dark",true);bg=Color.parseColor(dark?"#071321":"#F3F6FA");panel=Color.parseColor(dark?"#0E2237":"#FFFFFF");text=Color.parseColor(dark?"#F4F8FD":"#132033");muted=Color.parseColor(dark?"#8FA6BC":"#60728A");line=Color.parseColor(dark?"#183149":"#DDE5EE");}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    private void bold(TextView t){t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable gradient(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{accent,cyan});d.setCornerRadius(dp(18));return d;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(16);b.setTextColor(Color.rgb(3,27,39));b.setBackground(gradient());b.setMinHeight(dp(50));return b;}
    private void gap(LinearLayout l,int h){l.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(h)));}
    private void note(LinearLayout l,String s){TextView t=label(s,13,muted);t.setLineSpacing(dp(3),1);l.addView(t);}
    private void notice(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("Понятно",null).show();}
    private void error(Exception e){if(e instanceof Api.MfaRequiredException){showSecurity();return;}String s=e.getMessage();if(e instanceof java.io.IOException)s="Нет связи с сервером. Проверьте интернет и попробуйте снова.";notice(s==null?"Не удалось выполнить действие":s);}
    private void async(Task task,Done done){final int stamp=generation;loading=true;
        worker.execute(()->{Object value=null;Exception error=null;try{value=task.run();}catch(Exception e){error=e;}final Object v=value;final Exception err=error;
            handler.post(()->{loading=false;if(isFinishing()||isDestroyed()||stamp!=generation)return;try{if(err!=null)throw err;done.accept(v);}catch(Exception e){error(e);}});
        });
    }
    private void begin(String name){stopInlineVoice();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);saveDraft();screen=name;generation++;colors();root=vertical();root.setBackgroundColor(bg);setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        root.requestApplyInsets();composer=null;sendButton=null;attachButton=null;emojiButton=null;videoMessageButton=null;
    }
    private void toolbar(String title,boolean back,String action,Runnable onAction){
        LinearLayout bar=horizontal();bar.setPadding(dp(16),dp(8),dp(16),dp(8));
        if(back){TextView b=label("‹",36,text);b.setGravity(Gravity.CENTER);b.setContentDescription("Назад");bar.addView(b,new LinearLayout.LayoutParams(dp(40),dp(46)));b.setOnClickListener(v->onBackPressed());}
        else{Logo logo=new Logo(this,false);bar.addView(logo,new LinearLayout.LayoutParams(dp(34),dp(40)));}
        TextView t=label(title,21,text);bold(t);t.setPadding(dp(10),0,0,0);bar.addView(t,new LinearLayout.LayoutParams(0,dp(44),1));t.setGravity(Gravity.CENTER_VERTICAL);
        if(action!=null){TextView a=label(action,25,accent);a.setGravity(Gravity.CENTER);bar.addView(a,new LinearLayout.LayoutParams(dp(44),dp(44)));a.setOnClickListener(v->onAction.run());}
        root.addView(bar);View rule=new View(this);rule.setBackgroundColor(line);root.addView(rule,new LinearLayout.LayoutParams(-1,dp(1)));
    }
    private void scrollContent(){ScrollView s=new ScrollView(this);s.setFillViewport(true);content=vertical();content.setPadding(dp(22),dp(20),dp(22),dp(24));s.addView(content);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));}
    private void bottom(String selected){
        View topRule=new View(this);topRule.setBackgroundColor(Color.parseColor("#10253D"));root.addView(topRule,new LinearLayout.LayoutParams(-1,dp(1)));
        LinearLayout nav=horizontal();nav.setPadding(dp(6),dp(8),dp(6),dp(10));nav.setBackgroundColor(Color.parseColor("#06111E"));
        String[] names={"Чаты","Звонки","Контакты","Настройки"};String[] marks={"💬","☎","◯","⚙"};
        for(int i=0;i<4;i++){
            final int index=i;boolean active=selected.equals(names[i]);LinearLayout item=vertical();item.setGravity(Gravity.CENTER);
            TextView icon=label(marks[i],active?20:19,active?accent:muted);icon.setGravity(Gravity.CENTER);item.addView(icon,new LinearLayout.LayoutParams(-2,-2));
            TextView caption=label(names[i],12,active?accent:muted);caption.setGravity(Gravity.CENTER);caption.setPadding(0,dp(2),0,0);if(active)bold(caption);item.addView(caption,new LinearLayout.LayoutParams(-2,-2));
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(58),1));
            item.setOnClickListener(v->{if(index==0)showChats();else if(index==1)showRecentCalls();else if(index==2)showContacts();else showSettings();});
        }
        root.addView(nav);
    }

    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setTextSize(16);e.setTextColor(text);e.setHintTextColor(muted);e.setHint(hint);e.setSingleLine(true);e.setPadding(dp(16),dp(14),dp(16),dp(14));e.setBackground(shape(panel,14));if(password)e.setInputType(129);else e.setInputType(1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.bottomMargin=dp(12);content.addView(e,p);return e;}
    private LinearLayout settingsCard(){LinearLayout card=vertical();card.setBackground(shape(panel,22));card.setPadding(dp(8),dp(7),dp(8),dp(7));content.addView(card,new LinearLayout.LayoutParams(-1,-2));return card;}
    private void settingRow(LinearLayout card,String icon,int iconColor,String title,String subtitle,Runnable action){
        LinearLayout row=horizontal();row.setPadding(dp(10),dp(9),dp(8),dp(9));row.setBackground(shape(Color.TRANSPARENT,16));
        TextView badge=label(icon,22,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setBackground(shape(iconColor,13));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(42),dp(42));bp.rightMargin=dp(14);row.addView(badge,bp);
        LinearLayout words=vertical();TextView t=label(title,17,text);bold(t);words.addView(t);if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=label(subtitle,13,muted);sub.setMaxLines(2);sub.setEllipsize(TextUtils.TruncateAt.END);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(3);words.addView(sub,sp);}row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=label("›",29,muted);arrow.setGravity(Gravity.CENTER);row.addView(arrow,new LinearLayout.LayoutParams(dp(28),dp(42)));card.addView(row,new LinearLayout.LayoutParams(-1,-2));row.setOnClickListener(v->action.run());
    }
    private void sectionTitle(String value){TextView t=label(value,13,muted);bold(t);t.setPadding(dp(5),0,0,dp(9));content.addView(t);}
    private Switch settingSwitch(String title,String subtitle,boolean checked){
        LinearLayout wrap=vertical();wrap.setPadding(dp(4),dp(4),dp(4),dp(4));Switch sw=new Switch(this);sw.setText(title);sw.setTextColor(text);sw.setTextSize(16);sw.setChecked(checked);wrap.addView(sw,new LinearLayout.LayoutParams(-1,dp(52)));if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=label(subtitle,13,muted);sub.setPadding(dp(4),0,dp(4),dp(10));wrap.addView(sub);}content.addView(wrap);return sw;
    }
    private long folderSize(File f){if(f==null||!f.exists())return 0;if(f.isFile())return f.length();long n=0;File[] files=f.listFiles();if(files!=null)for(File x:files)n+=folderSize(x);return n;}
    private String humanBytes(long n){if(n<1024)return n+" Б";if(n<1024*1024)return String.format(Locale.ROOT,"%.1f КБ",n/1024.0);return String.format(Locale.ROOT,"%.1f МБ",n/(1024.0*1024.0));}
    private boolean deleteTree(File f){if(f==null||!f.exists())return true;boolean ok=true;if(f.isDirectory()){File[] files=f.listFiles();if(files!=null)for(File x:files)ok&=deleteTree(x);}return f.delete()&&ok;}
    private Set<String> importantChats(){Set<String> out=new HashSet<>();String raw=prefs.getString("important_chats","");if(raw!=null&&!raw.trim().isEmpty())for(String id:raw.split(","))if(!id.trim().isEmpty())out.add(id.trim());return out;}
    private boolean isImportantChat(String id){return importantChats().contains(id);}
    private void setImportantChat(String id,boolean on){Set<String> set=importantChats();if(on)set.add(id);else set.remove(id);StringBuilder b=new StringBuilder();for(String v:set){if(b.length()>0)b.append(',');b.append(v);}prefs.edit().putString("important_chats",b.toString()).apply();}
    private void showSettings(){
        begin("settings");toolbar("Настройки",false,null,null);scrollContent();
        String name=prefs.getString("name","Пользователь Muwahid"),user=prefs.getString("username","");
        sectionTitle("ОСНОВНЫЕ");
        LinearLayout main=settingsCard();
        settingRow(main,"●",Color.rgb(32,151,225),"Аккаунт",user.isEmpty()?name:name+" · @"+user,this::showAccountSettings);
        settingRow(main,"✦",Color.rgb(235,155,24),"Настройки чатов","Тема, размер текста, вид сообщений",this::showChatSettings);
        settingRow(main,"◆",Color.rgb(42,190,91),"Конфиденциальность","Защита аккаунта и второй фактор",this::showSecurity);
        settingRow(main,"♪",Color.rgb(235,70,95),"Уведомления","Сообщения, звонки, обновления и системные настройки",this::showNotificationSettings);
        settingRow(main,"▣",Color.rgb(71,111,225),"Данные и память","Кэш расшифрованных медиафайлов",this::showDataSettings);
        settingRow(main,"□",Color.rgb(31,161,214),"Папки с чатами","Все чаты и папка «Важные»",this::showFolderSettings);
        settingRow(main,"▤",Color.rgb(38,171,190),"Устройства","Текущий телефон и другие сеансы",this::showDevices);
        settingRow(main,"▱",Color.rgb(239,119,31),"Энергосбережение",prefs.getBoolean("energy_saver",false)?"Включено":"Выключено",this::showEnergySettings);
        settingRow(main,"◎",Color.rgb(165,73,217),"Язык","Русский",this::showLanguageSettings);
        gap(content,22);sectionTitle("MUWAHID");
        LinearLayout services=settingsCard();
        settingRow(services,"★",Color.rgb(126,87,235),"Premium Muwahid","Дополнительные возможности",this::showPremium);
        settingRow(services,"★",Color.rgb(237,155,20),"Чат с владельцем","Прямая переписка с владельцем Muwahid",this::openOwnerChat);
        settingRow(services,"▦",Color.rgb(227,70,86),"Business Muwahid","Инструменты для бизнес-профиля",this::showBusiness);
        settingRow(services,"■",Color.rgb(236,119,40),"Отправить подарок","Подарки Muwahid",this::showGift);
        bottom("Настройки");
    }
    private void showChatSettings(){
        begin("chat_settings");toolbar("Настройки чатов",true,null,null);scrollContent();
        Switch dark=settingSwitch("Тёмная тема","Меняет оформление всего приложения.",prefs.getBoolean("dark",true));
        dark.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("dark",on).apply();b.post(this::showChatSettings);});
        gap(content,10);
        LinearLayout card=settingsCard();
        String size=String.valueOf(prefs.getInt("message_text_size",16));
        settingRow(card,"Aa",Color.rgb(31,161,214),"Размер текста сообщений",size+" sp",()->{
            String[] values={"Мелкий · 14","Обычный · 16","Крупный · 18"};
            new AlertDialog.Builder(this).setTitle("Размер текста").setItems(values,(d,w)->{int v=w==0?14:w==1?16:18;prefs.edit().putInt("message_text_size",v).apply();showChatSettings();}).show();
        });
        gap(content,14);
        Switch compact=settingSwitch("Компактные сообщения","Уменьшает внутренние отступы в сообщениях.",prefs.getBoolean("compact_bubbles",false));
        compact.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean("compact_bubbles",on).apply());
    }
    private void showNotificationSettings(){
        begin("notifications");toolbar("Уведомления",true,null,null);scrollContent();
        Switch messages=settingSwitch("Уведомления о сообщениях","Показывать уведомления о новых сообщениях.",prefs.getBoolean("notify_messages",true));
        Switch calls=settingSwitch("Уведомления о звонках","Показывать входящие аудио- и видеозвонки.",prefs.getBoolean("notify_calls",true));
        Switch updates=settingSwitch("Уведомления об обновлениях","Сообщать, когда доступна новая версия Muwahid.",prefs.getBoolean("notify_updates",true));
        messages.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("notify_messages",on).apply();maybeStartNotifications();});
        calls.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("notify_calls",on).apply();maybeStartNotifications();});
        updates.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean("notify_updates",on).apply());
        gap(content,14);Button checkUpdate=button("Проверить обновления");content.addView(checkUpdate,new LinearLayout.LayoutParams(-1,dp(54)));checkUpdate.setOnClickListener(v->{UpdateManager.checkAndNotify(this,true);Toast.makeText(this,"Проверяем обновления…",Toast.LENGTH_SHORT).show();});
        gap(content,18);Button system=button("Системные настройки уведомлений");content.addView(system,new LinearLayout.LayoutParams(-1,dp(54)));system.setOnClickListener(v->{
            try{Intent i=new Intent("android.settings.APP_NOTIFICATION_SETTINGS");i.putExtra("android.provider.extra.APP_PACKAGE",getPackageName());startActivity(i);}catch(Exception e){notice("Не удалось открыть системные настройки уведомлений.");}
        });
    }
    private void showDataSettings(){
        begin("data_settings");toolbar("Данные и память",true,null,null);scrollContent();
        File media=new File(getCacheDir(),"media");long bytes=folderSize(media);
        note(content,"Кэш медиа: "+humanBytes(bytes)+"\nСюда временно сохраняются расшифрованные файлы, которые вы открывали в чатах.");gap(content,18);
        Button clear=button("Очистить кэш медиа");content.addView(clear,new LinearLayout.LayoutParams(-1,dp(54)));clear.setEnabled(bytes>0);clear.setOnClickListener(v->{
            boolean ok=deleteTree(media);Toast.makeText(this,ok?"Кэш очищен":"Не удалось полностью очистить кэш",Toast.LENGTH_SHORT).show();showDataSettings();
        });
        gap(content,18);note(content,"Сообщения на сервере этим действием не удаляются. Черновики, заметки и данные входа также сохраняются.");
    }
    private void showFolderSettings(){
        begin("folders");toolbar("Папки с чатами",true,null,null);scrollContent();
        int count=importantChats().size();note(content,"Папка «Важные» содержит "+count+" чат(ов). Чтобы добавить или убрать чат, удерживайте его в списке чатов.");gap(content,18);
        Button open=button("Открыть папку «Важные»");content.addView(open,new LinearLayout.LayoutParams(-1,dp(54)));open.setOnClickListener(v->{chatFolderFilter="important";prefs.edit().putString("chat_folder","important").apply();showChats();});
        gap(content,12);Button all=button("Показать все чаты");content.addView(all,new LinearLayout.LayoutParams(-1,dp(54)));all.setOnClickListener(v->{chatFolderFilter="all";prefs.edit().putString("chat_folder","all").apply();showChats();});
        if(count>0){gap(content,12);Button clear=button("Очистить папку «Важные»");content.addView(clear,new LinearLayout.LayoutParams(-1,dp(54)));clear.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Убрать все чаты из папки «Важные»?").setNegativeButton("Отмена",null).setPositiveButton("Очистить",(d,w)->{prefs.edit().remove("important_chats").apply();showFolderSettings();}).show());}
    }
    private void showDevices(){
        begin("devices");toolbar("Устройства",true,null,null);scrollContent();
        String model=Build.MANUFACTURER+" "+Build.MODEL;note(content,"Текущий сеанс\n"+model+"\nAndroid "+Build.VERSION.RELEASE);gap(content,20);
        if(!api.signedIn()){note(content,"Войдите в аккаунт, чтобы управлять активными сеансами.");return;}
        Button others=button("Завершить другие сеансы");content.addView(others,new LinearLayout.LayoutParams(-1,dp(54)));others.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Завершить все другие сеансы Muwahid? Текущий телефон останется в аккаунте.").setNegativeButton("Отмена",null).setPositiveButton("Завершить",(d,w)->{
            others.setEnabled(false);async(()->{api.logoutOthers();return Boolean.TRUE;},r->{Toast.makeText(this,"Другие сеансы завершены",Toast.LENGTH_SHORT).show();showDevices();});
        }).show());
    }
    private void showEnergySettings(){
        begin("energy");toolbar("Энергосбережение",true,null,null);scrollContent();
        Switch saver=settingSwitch("Экономить заряд","Уменьшает частоту фонового обновления чатов и уведомлений.",prefs.getBoolean("energy_saver",false));
        saver.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("energy_saver",on).apply();try{NotificationService.stop(this);}catch(Exception ignored){}maybeStartNotifications();});
        gap(content,18);note(content,"В режиме энергосбережения обновление списка чатов выполняется реже. Входящие события могут появляться с небольшой дополнительной задержкой.");
    }
    private void showLanguageSettings(){
        begin("language");toolbar("Язык",true,null,null);scrollContent();
        LinearLayout card=settingsCard();settingRow(card,"RU",Color.rgb(165,73,217),"Русский","Текущий язык интерфейса",()->Toast.makeText(this,"Русский уже выбран",Toast.LENGTH_SHORT).show());
        gap(content,18);note(content,"Другие языки появятся после полной локализации интерфейса. Приложение не будет притворяться переведённым частично.");
    }
    private void showPremium(){
        begin("premium");toolbar("Premium Muwahid",true,null,null);scrollContent();
        note(content,"Раздел Premium подготовлен в настройках. Покупка пока не включена: в версии 0.9.2 нет подключённой платёжной системы и серверной проверки подписки.");gap(content,18);
        note(content,"Когда Premium будет подключён, оплата и статус подписки будут проверяться через официальный механизм магазина приложений, а не локальным переключателем.");
    }
    private void showBusiness(){
        begin("business");toolbar("Business Muwahid",true,null,null);scrollContent();
        note(content,"Раздел Business Muwahid добавлен в меню. Публичные бизнес-профили, категории и права для сотрудников требуют отдельной серверной модели и пока не включены в 0.9.2.");
    }
    private void showGift(){
        begin("gift");toolbar("Отправить подарок",true,null,null);scrollContent();
        note(content,"Подарки появятся после подключения Premium и безопасной оплаты. Сейчас списание денег или фиктивная отправка подарка не выполняются.");
    }
    private void openOwnerChat(){
        if(!api.signedIn()){showAuth(false);return;}
        if(OWNER_UUID.equals(api.uid())){notice("Вы вошли в аккаунт владельца Muwahid.");return;}
        async(()->{Object id=api.rpc("mw_start_chat",new JSONObject().put("p_person",OWNER_UUID));return id;},r->showChat(String.valueOf(r),"Владелец Muwahid"));
    }
    private void showWelcome(){
        begin("welcome");
        FrameLayout scene=new FrameLayout(this);scene.setBackgroundColor(Color.parseColor("#06101B"));
        Logo hero=new Logo(this,true);scene.addView(hero,new FrameLayout.LayoutParams(-1,-1));root.addView(scene,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=vertical();actions.setPadding(dp(28),dp(6),dp(28),dp(24));actions.setBackgroundColor(bg);
        Button start=button("Начать");actions.addView(start,new LinearLayout.LayoutParams(-1,dp(56)));start.setOnClickListener(v->{if(api.configured())showAuth(true);else notice("Сервер сообщений ещё не подключён.");});
        TextView login=label("Уже есть аккаунт?  Войти",14,muted);login.setGravity(Gravity.CENTER);login.setPadding(0,dp(17),0,dp(10));actions.addView(login);login.setOnClickListener(v->{if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");});
        TextView saved=label("Открыть личные заметки",13,accent);saved.setGravity(Gravity.CENTER);saved.setPadding(0,dp(7),0,dp(9));actions.addView(saved);saved.setOnClickListener(v->showNotes());
        TextView state=label("Muwahid 0.9.2 · новый интерфейс",11,muted);state.setGravity(Gravity.CENTER);actions.addView(state);root.addView(actions);
    }
    private void showAuth(boolean register){phoneRegisterMode=register;begin("auth");toolbar(register?"Регистрация":"Вход",true,null,null);scrollContent();
        note(content,"Вход по номеру телефона. Введите номер в международном формате, например +491701234567. Muwahid отправит одноразовый SMS-код.");gap(content,24);
        EditText name=register?field("Ваше имя",false):null;EditText phone=field("Номер телефона: +...",false);phone.setInputType(3);
        Button submit=button("Получить SMS-код");content.addView(submit,new LinearLayout.LayoutParams(-1,dp(54)));submit.setOnClickListener(v->{String number=normalizePhone(phone.getText().toString());
            if(number==null){phone.setError("Введите номер в формате +кодстранынoмер");return;}if(register&&name.getText().toString().trim().isEmpty()){name.setError("Укажите имя");return;}
            String enteredName=register?name.getText().toString().trim():"";submit.setEnabled(false);final int stamp=generation;worker.execute(()->{try{api.sendPhoneOtp(number,enteredName,register);handler.post(()->{if(stamp!=generation)return;showPhoneCode(number,enteredName,register);});}catch(Exception ex){handler.post(()->{if(stamp==generation){submit.setEnabled(true);error(ex);}});}});
        });
        gap(content,16);TextView or=label("или",14,muted);or.setGravity(Gravity.CENTER);content.addView(or);gap(content,12);
        Button google=button("Продолжить с Google");content.addView(google,new LinearLayout.LayoutParams(-1,dp(54)));google.setOnClickListener(v->openGoogleLogin());
        gap(content,20);TextView change=label(register?"Уже есть аккаунт? Войти":"Нет аккаунта? Зарегистрироваться",15,accent);change.setGravity(Gravity.CENTER);content.addView(change);change.setOnClickListener(v->showAuth(!register));gap(content,22);
        note(content,"После подтверждения номера Muwahid создаёт защищённую учётную запись. Текст и медиа в личных чатах шифруются на телефоне.");
    }
    private void openGoogleLogin(){
        final int stamp=generation;
        worker.execute(()->{try{
            if(!api.googleProviderEnabled())throw new Exception("Google сейчас не активен на живом Auth-сервере Supabase. Проверьте Client ID, Client Secret и Save в провайдере Google.");
            final Uri url=Uri.parse(api.googleOAuthUrl());
            handler.post(()->{if(stamp!=generation)return;try{startActivity(new Intent(Intent.ACTION_VIEW,url));}catch(Exception e){error(e);}});
        }catch(Exception e){handler.post(()->{if(stamp==generation)error(e);});}});
    }

    private Button smallIconButton(String value,String description){
        Button b=new Button(this);b.setText(value);b.setContentDescription(description);b.setAllCaps(false);b.setTextSize(20);b.setTextColor(accent);b.setMinWidth(0);b.setMinHeight(0);b.setPadding(0,0,0,0);b.setBackground(shape(panel,16));return b;
    }
    private void mainToolbar(){
        LinearLayout bar=horizontal();bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(14),dp(12),dp(14),dp(8));
        TextView menu=label("☰",25,text);menu.setGravity(Gravity.CENTER);menu.setContentDescription("Меню");menu.setBackground(shape(Color.parseColor("#10263D"),18));bar.addView(menu,new LinearLayout.LayoutParams(dp(46),dp(46)));menu.setOnClickListener(v->showAppMenu());
        LinearLayout brand=vertical();brand.setPadding(dp(12),0,0,0);TextView title=label("Muwahid",25,text);bold(title);brand.addView(title);TextView sub=label("Сообщения",12,Color.parseColor("#8FA6BE"));brand.addView(sub);bar.addView(brand,new LinearLayout.LayoutParams(0,dp(50),1));
        TextView search=label("⌕",28,text);search.setGravity(Gravity.CENTER);search.setContentDescription("Поиск");search.setBackground(shape(Color.parseColor("#10263D"),18));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(46),dp(46));sp.rightMargin=dp(8);bar.addView(search,sp);search.setOnClickListener(v->showChatSearchDialog());
        TextView add=label("+",30,Color.rgb(3,29,35));add.setGravity(Gravity.CENTER);bold(add);add.setContentDescription("Создать");GradientDrawable addBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{accent,cyan});addBg.setShape(GradientDrawable.OVAL);add.setBackground(addBg);bar.addView(add,new LinearLayout.LayoutParams(dp(46),dp(46)));add.setOnClickListener(v->{if("Чаты".equals(mainTab))newChat();else createCommunity("Группы".equals(mainTab)?"group":"channel");});
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(74)));
    }
    private void mainTabs(){
        LinearLayout shell=horizontal();shell.setPadding(dp(5),dp(5),dp(5),dp(5));shell.setBackground(shape(Color.parseColor("#0B2036"),18));
        String[] names={"Чаты","Группы","Каналы"};
        for(String name:names){
            boolean active=name.equals(mainTab);
            TextView item=label(name,15,active?Color.WHITE:Color.parseColor("#9FB0C2"));item.setGravity(Gravity.CENTER);if(active)bold(item);item.setBackground(shape(active?Color.parseColor("#173A55"):Color.TRANSPARENT,14));shell.addView(item,new LinearLayout.LayoutParams(0,dp(42),1));item.setOnClickListener(v->showHub(name));
        }
        LinearLayout wrap=horizontal();wrap.setPadding(dp(14),0,dp(14),dp(8));wrap.addView(shell,new LinearLayout.LayoutParams(-1,dp(52)));root.addView(wrap,new LinearLayout.LayoutParams(-1,dp(60)));
    }

    private void showChatSearchDialog(){
        if(!"Чаты".equals(mainTab)){Toast.makeText(this,"Поиск по чатам доступен во вкладке «Чаты»",Toast.LENGTH_SHORT).show();return;}
        EditText q=new EditText(this);q.setSingleLine(true);q.setHint("Имя или @имя пользователя");q.setPadding(dp(22),dp(12),dp(22),dp(12));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Поиск по чатам").setView(q).setNegativeButton("Закрыть",null).setPositiveButton("Найти",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{filter=q.getText().toString().trim().toLowerCase(Locale.ROOT);d.dismiss();drawChatList();}));d.show();
    }
    private void menuRow(LinearLayout card,String icon,String title,Runnable action){
        LinearLayout row=horizontal();row.setPadding(dp(8),dp(7),dp(6),dp(7));TextView mark=label(icon,21,accent);mark.setGravity(Gravity.CENTER);row.addView(mark,new LinearLayout.LayoutParams(dp(42),dp(44)));TextView t=label(title,16,text);t.setGravity(Gravity.CENTER_VERTICAL);row.addView(t,new LinearLayout.LayoutParams(0,dp(44),1));TextView a=label("›",26,muted);a.setGravity(Gravity.CENTER);row.addView(a,new LinearLayout.LayoutParams(dp(28),dp(44)));card.addView(row);row.setOnClickListener(v->action.run());
    }
    private void showAppMenu(){
        begin("menu");
        LinearLayout head=horizontal();head.setPadding(dp(18),dp(12),dp(14),dp(10));Logo logo=new Logo(this,false);head.addView(logo,new LinearLayout.LayoutParams(dp(38),dp(44)));TextView app=label("Muwahid",20,text);bold(app);app.setPadding(dp(10),0,0,0);head.addView(app,new LinearLayout.LayoutParams(0,dp(44),1));TextView gear=label("⚙",23,text);gear.setGravity(Gravity.CENTER);head.addView(gear,new LinearLayout.LayoutParams(dp(44),dp(44)));gear.setOnClickListener(v->showSettings());root.addView(head);
        ScrollView sv=new ScrollView(this);content=vertical();content.setPadding(dp(18),dp(6),dp(18),dp(24));sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout profileCard=horizontal();profileCard.setPadding(dp(10),dp(12),dp(8),dp(12));profileCard.setBackground(shape(panel,20));String name=prefs.getString("name","Пользователь Muwahid");avatar(profileCard,name,Color.rgb(12,142,158));LinearLayout words=vertical();TextView n=label(name,18,text);bold(n);words.addView(n);TextView u=label(prefs.getString("username","").isEmpty()?"Мой аккаунт":"@"+prefs.getString("username",""),13,muted);words.addView(u);profileCard.addView(words,new LinearLayout.LayoutParams(0,-2,1));TextView ch=label("›",28,muted);ch.setGravity(Gravity.CENTER);profileCard.addView(ch,new LinearLayout.LayoutParams(dp(30),dp(52)));content.addView(profileCard);profileCard.setOnClickListener(v->showAccountSettings());
        gap(content,14);LinearLayout card=vertical();card.setBackground(shape(panel,20));card.setPadding(dp(5),dp(5),dp(5),dp(5));content.addView(card);
        menuRow(card,"◯","Мой профиль",this::showAccountSettings);menuRow(card,"☆","Избранное",this::showNotes);menuRow(card,"◉","Голосовые комнаты",this::showVoiceRooms);menuRow(card,"♛","Администраторы",this::showAdminManagement);menuRow(card,"☎","Недавние звонки",this::showRecentCalls);menuRow(card,"♧","Пригласить",this::shareInvite);menuRow(card,"⚙","Настройки",this::showSettings);
        gap(content,14);LinearLayout create=vertical();create.setBackground(shape(panel,20));create.setPadding(dp(5),dp(5),dp(5),dp(5));content.addView(create);
        menuRow(create,"◉","Каналы",()->showHub("Каналы"));menuRow(create,"＋","Создать канал",()->createCommunity("channel"));menuRow(create,"♙","Группы",()->showHub("Группы"));menuRow(create,"＋","Создать группу",()->createCommunity("group"));
        gap(content,16);Switch dark=new Switch(this);dark.setText("Тёмная тема");dark.setTextColor(text);dark.setTextSize(16);dark.setChecked(prefs.getBoolean("dark",true));content.addView(dark,new LinearLayout.LayoutParams(-1,dp(52)));dark.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("dark",on).apply();b.post(this::showAppMenu);});gap(content,10);TextView version=label("Muwahid "+BuildConfig.VERSION_NAME+" · Android",11,muted);version.setGravity(Gravity.CENTER);content.addView(version);
    }
    private void showVoiceRooms(){
        if(!api.signedIn()){if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");return;}
        begin("voice_rooms");toolbar("Голосовые комнаты",true,"+",this::createVoiceRoom);scrollContent();
        TextView intro=label("Живые комнаты · до 8 участников",14,muted);intro.setPadding(dp(2),0,0,dp(14));content.addView(intro);
        note(content,"У каждого участника свой микрофон. Можно поднять руку; владелец, администратор или создатель комнаты может заглушить микрофон участника и позже снова разрешить его.");
        gap(content,14);TextView state=label("Загружаем комнаты…",14,muted);content.addView(state);
        async(()->api.rpc("mw_room_list",new JSONObject()),value->{
            if(!(value instanceof JSONArray))throw new Exception("Сервер вернул некорректный список комнат");
            JSONArray rooms=(JSONArray)value;content.removeAllViews();
            TextView intro2=label("Живые комнаты · до 8 участников",14,muted);intro2.setPadding(dp(2),0,0,dp(14));content.addView(intro2);
            note(content,"У каждого участника свой микрофон. Можно поднять руку; владелец, администратор или создатель комнаты может заглушить микрофон участника и позже снова разрешить его.");gap(content,14);
            if(rooms.length()==0){
                LinearLayout empty=settingsCard();TextView e=label("Пока нет активных комнат",18,text);bold(e);empty.addView(e);gap(empty,6);TextView d=label("Нажмите +, чтобы создать первую голосовую комнату.",14,muted);empty.addView(d);return;
            }
            for(int i=0;i<rooms.length();i++){
                JSONObject room=rooms.optJSONObject(i);if(room==null)continue;
                String id=room.optString("id"),title=room.optString("title","Голосовая комната");int count=room.optInt("participants",0),speaking=room.optInt("speaking",0);
                LinearLayout card=settingsCard();LinearLayout row=horizontal();row.setPadding(dp(8),dp(9),dp(8),dp(9));
                TextView icon=label("◉",25,accent);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(Color.parseColor("#10364A"),17));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(50),dp(50));ip.rightMargin=dp(13);row.addView(icon,ip);
                LinearLayout words=vertical();TextView t=label(title,17,text);bold(t);words.addView(t);String sub=count+" из 8"+(speaking==0?" · все микрофоны выключены":" · говорят: "+speaking);TextView st=label(sub,13,muted);st.setPadding(0,dp(4),0,0);words.addView(st);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
                TextView go=label("›",30,muted);go.setGravity(Gravity.CENTER);row.addView(go,new LinearLayout.LayoutParams(dp(32),dp(50)));card.addView(row);row.setOnClickListener(v->openVoiceRoom(id,title));
            }
        });
    }
    private void createVoiceRoom(){
        if(!api.signedIn()){showAuth(false);return;}
        EditText name=new EditText(this);name.setSingleLine(true);name.setHint("Название комнаты");name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(80)});name.setPadding(dp(22),dp(14),dp(22),dp(14));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Новая голосовая комната").setView(name).setNegativeButton("Отмена",null).setPositiveButton("Создать",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{String title=name.getText().toString().trim();if(title.isEmpty()){name.setError("Введите название");return;}d.dismiss();async(()->api.rpc("mw_room_create",new JSONObject().put("p_title",title)),value->{if(!(value instanceof JSONObject))throw new Exception("Не удалось создать комнату");JSONObject room=(JSONObject)value;openVoiceRoom(room.getString("id"),room.optString("title",title));});}));d.show();
    }
    private void openVoiceRoom(String id,String title){
        Intent i=new Intent(this,VoiceRoomActivity.class);i.putExtra("room_id",id);i.putExtra("room_title",title);startActivity(i);
    }
    private void showAdminManagement(){
        if(!api.signedIn()){showAuth(false);return;}
        async(()->api.rpc("mw_role_status",new JSONObject()),value->{
            if(!(value instanceof JSONObject)||!((JSONObject)value).optBoolean("is_owner",false)){notice("Управлять администраторами может только владелец Muwahid.");return;}
            showAdminManagementOwner();
        });
    }
    private void showAdminManagementOwner(){
        begin("admins");toolbar("Администраторы",true,"+",this::addAdministrator);scrollContent();
        note(content,"Администратор — помощник владельца. Он может модерировать комнаты, но не может стать владельцем, передать владение или снять владельца.");gap(content,14);
        TextView state=label("Загружаем список…",14,muted);content.addView(state);
        async(()->api.rpc("mw_admin_list",new JSONObject()),value->{
            if(!(value instanceof JSONArray))throw new Exception("Сервер вернул некорректный список администраторов");
            JSONArray admins=(JSONArray)value;content.removeAllViews();note(content,"Администратор — помощник владельца. Он может модерировать комнаты, но не может стать владельцем, передать владение или снять владельца.");gap(content,14);
            if(admins.length()==0){LinearLayout card=settingsCard();TextView e=label("Администраторы не назначены",17,text);bold(e);card.addView(e);gap(card,5);card.addView(label("Нажмите +, чтобы назначить помощника.",14,muted));return;}
            for(int i=0;i<admins.length();i++){
                JSONObject a=admins.optJSONObject(i);if(a==null)continue;String id=a.optString("id"),name=a.optString("display_name","Пользователь"),username=a.optString("username","");
                LinearLayout card=settingsCard();settingRow(card,"♛",Color.rgb(30,160,145),name,username.isEmpty()?"Администратор":"@"+username+" · администратор",()->confirmRemoveAdministrator(id,name));
            }
        });
    }
    private void addAdministrator(){
        EditText q=new EditText(this);q.setSingleLine(true);q.setHint("+номер телефона или @имя");q.setPadding(dp(22),dp(14),dp(22),dp(14));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Назначить администратора").setView(q).setNegativeButton("Отмена",null).setPositiveButton("Найти",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{String query=q.getText().toString().trim();if(query.isEmpty()){q.setError("Введите пользователя");return;}d.dismiss();async(()->{
            Object found=api.rpc("mw_find_person_any",new JSONObject().put("p_query",query));if(!(found instanceof JSONObject))throw new Exception("Пользователь не найден");JSONObject p=(JSONObject)found;return p;
        },value->{JSONObject p=(JSONObject)value;String id=p.getString("id"),name=p.optString("display_name","Пользователь");new AlertDialog.Builder(this).setTitle("Назначить администратора?").setMessage(name+" сможет модерировать пользователей и голосовые комнаты от вашего имени. Права владельца ему не передаются.").setNegativeButton("Отмена",null).setPositiveButton("Назначить",(dd,w)->async(()->api.rpc("mw_owner_admin_set",new JSONObject().put("p_user",id).put("p_enabled",true)),ok->{Toast.makeText(this,"Администратор назначен",Toast.LENGTH_SHORT).show();showAdminManagementOwner();})).show();});}));d.show();
    }
    private void confirmRemoveAdministrator(String id,String name){
        new AlertDialog.Builder(this).setTitle("Снять администратора?").setMessage(name+" потеряет административные права. Его обычный аккаунт останется активным.").setNegativeButton("Отмена",null).setPositiveButton("Снять",(d,w)->async(()->api.rpc("mw_owner_admin_set",new JSONObject().put("p_user",id).put("p_enabled",false)),value->{Toast.makeText(this,"Права администратора сняты",Toast.LENGTH_SHORT).show();showAdminManagementOwner();})).show();
    }

    private void shareInvite(){
        Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("text/plain");String user=prefs.getString("username","");intent.putExtra(Intent.EXTRA_TEXT,user.isEmpty()?"Присоединяйся ко мне в Muwahid":"Найди меня в Muwahid: @"+user);try{startActivity(Intent.createChooser(intent,"Пригласить в Muwahid"));}catch(Exception e){notice("Не удалось открыть меню отправки.");}
    }
    private void showRecentCalls(){
        begin("calls");toolbar("Недавние звонки",false,"+",this::showChats);scrollContent();
        note(content,"Чтобы позвонить, выберите контакт. Аудио- и видеозвонки работают из личного чата.");gap(content,14);
        LinearLayout card=settingsCard();int shown=0;for(int i=0;i<chats.length();i++){JSONObject c=chats.optJSONObject(i);if(c==null)continue;shown++;String name=c.optString("display_name","Контакт");String id=c.optString("id");settingRow(card,"☎",Color.rgb(13,151,132),name,"Аудио или видеозвонок",()->{chatId=id;chatName=name;chooseCall();});}
        if(shown==0){note(content,"Пока нет контактов для звонка. Откройте «Чаты» и начните переписку.");}
        bottom("Звонки");
    }
    private void showContacts(){
        begin("contacts");toolbar("Контакты",false,"+",this::newChat);scrollContent();
        LinearLayout card=settingsCard();int shown=0;for(int i=0;i<chats.length();i++){JSONObject c=chats.optJSONObject(i);if(c==null)continue;shown++;String name=c.optString("display_name","Контакт");String id=c.optString("id");String username=c.optString("username","");settingRow(card,"●",Color.rgb(26,139,159),name,username.isEmpty()?"Открыть чат":"@"+username,()->showChat(id,name));}
        if(shown==0)note(content,"Контакты появятся после начала личных чатов.");
        bottom("Контакты");
    }
    private JSONArray localCommunities(String kind){try{return new JSONArray(prefs.getString("local_"+kind,"[]"));}catch(Exception e){return new JSONArray();}}
    private void saveCommunities(String kind,JSONArray a){prefs.edit().putString("local_"+kind,a.toString()).apply();}
    private void createCommunity(String kind){
        EditText name=new EditText(this);name.setSingleLine(true);name.setHint("Название");name.setPadding(dp(22),dp(12),dp(22),dp(12));String title="group".equals(kind)?"Создать группу":"Создать канал";
        new AlertDialog.Builder(this).setTitle(title).setView(name).setNegativeButton("Отмена",null).setPositiveButton("Создать",(d,w)->{String value=name.getText().toString().trim();if(value.isEmpty()){Toast.makeText(this,"Введите название",Toast.LENGTH_SHORT).show();return;}try{JSONArray a=localCommunities(kind);a.put(new JSONObject().put("id",UUID.randomUUID().toString()).put("name",value).put("created",System.currentTimeMillis()));saveCommunities(kind,a);showHub("group".equals(kind)?"Группы":"Каналы");}catch(Exception e){error(e);}}).show();
    }
    private void drawCommunityList(String kind){
        if(list==null)return;list.removeAllViews();JSONArray a=localCommunities(kind);String singular="group".equals(kind)?"группа":"канал";for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String name=c.optString("name",singular);String id=c.optString("id");LinearLayout row=horizontal();row.setPadding(dp(18),dp(12),dp(18),dp(12));avatar(row,name,"group".equals(kind)?Color.rgb(18,143,150):Color.rgb(27,119,185));LinearLayout words=vertical();TextView t=label(name,17,text);bold(t);words.addView(t);gap(words,4);TextView sub=label("group".equals(kind)?"Группа Muwahid":"Канал Muwahid",13,muted);words.addView(sub);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=label("›",27,muted);arrow.setGravity(Gravity.CENTER);row.addView(arrow,new LinearLayout.LayoutParams(dp(34),dp(52)));list.addView(row);row.setOnClickListener(v->showLocalCommunity(kind,id,name));}
        if(a.length()==0){LinearLayout empty=vertical();empty.setPadding(dp(28),dp(58),dp(28),dp(28));TextView icon=label("group".equals(kind)?"♙":"◉",52,accent);icon.setGravity(Gravity.CENTER);empty.addView(icon);gap(empty,16);TextView title=label("group".equals(kind)?"Создайте первую группу":"Создайте первый канал",20,text);bold(title);title.setGravity(Gravity.CENTER);empty.addView(title);gap(empty,10);TextView desc=label("Нажмите + сверху. Интерфейс уже работает на телефоне; серверную синхронизацию групп и каналов подключим отдельно.",14,muted);desc.setGravity(Gravity.CENTER);desc.setLineSpacing(dp(3),1);empty.addView(desc);list.addView(empty);}
    }
    private void showLocalCommunity(String kind,String id,String name){
        begin("community");toolbar(name,true,null,null);connection=label("group".equals(kind)?"Группа · локальный прототип":"Канал · локальный прототип",12,muted);connection.setPadding(dp(20),dp(8),dp(16),dp(8));root.addView(connection);
        messageScroll=new ScrollView(this);messages=vertical();messages.setPadding(dp(12),dp(12),dp(12),dp(14));messageScroll.addView(messages);root.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));
        final String key="community_messages:"+id;Runnable redraw=()->{messages.removeAllViews();try{JSONArray a=new JSONArray(prefs.getString(key,"[]"));if(a.length()==0)note(messages,"Пока сообщений нет.");for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i);if(m!=null)bubble(m.optString("body"),true,m.optString("time"));}}catch(Exception e){note(messages,"Не удалось открыть локальные сообщения.");}bottomScroll();};redraw.run();
        LinearLayout compose=horizontal();compose.setPadding(dp(10),dp(8),dp(10),dp(10));compose.setBackgroundColor(panel);EditText local=new EditText(this);local.setHint("Сообщение");local.setHintTextColor(muted);local.setTextColor(text);local.setTextSize(16);local.setMaxLines(4);local.setPadding(dp(14),dp(10),dp(14),dp(10));local.setBackground(shape(bg,20));compose.addView(local,new LinearLayout.LayoutParams(0,-2,1));Button send=button("↑");LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(50),dp(48));sp.leftMargin=dp(7);compose.addView(send,sp);root.addView(compose);send.setOnClickListener(v->{String body=local.getText().toString().trim();if(body.isEmpty())return;try{JSONArray a=new JSONArray(prefs.getString(key,"[]"));a.put(new JSONObject().put("body",body).put("time",new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date())));prefs.edit().putString(key,a.toString()).apply();local.setText("");redraw.run();}catch(Exception e){error(e);}});
    }

    private String normalizePhone(String raw){if(raw==null)return null;String p=raw.trim().replaceAll("[\\s()\\-]","");if(!p.matches("\\+[1-9][0-9]{7,14}"))return null;return p;}
    private void showPhoneCode(String phone,String name,boolean register){phoneRegisterMode=register;begin("otp");toolbar("Подтверждение номера",true,null,null);scrollContent();
        note(content,"SMS-код отправлен на "+phone+". Введите код из сообщения.");gap(content,20);EditText code=field("SMS-код",false);code.setInputType(2);code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        Button verify=button("Подтвердить и войти");content.addView(verify,new LinearLayout.LayoutParams(-1,dp(54)));verify.setOnClickListener(v->{String value=code.getText().toString().trim();if(!value.matches("[0-9]{4,8}")){code.setError("Введите код из SMS");return;}verify.setEnabled(false);final int stamp=generation;worker.execute(()->{try{api.verifyPhoneOtp(phone,value);try{api.rpc("mw_sync_my_phone",new JSONObject());}catch(Exception ignored){}handler.post(()->{if(stamp!=generation)return;maybeStartNotifications();showChats();});}catch(Exception ex){handler.post(()->{if(stamp==generation){verify.setEnabled(true);code.setText("");error(ex);}});}});});
        gap(content,18);TextView resend=label("Получить новый код",15,accent);resend.setGravity(Gravity.CENTER);content.addView(resend);resend.setOnClickListener(v->{worker.execute(()->{try{api.sendPhoneOtp(phone,name,register);handler.post(()->Toast.makeText(this,"Новый код отправлен",Toast.LENGTH_SHORT).show());}catch(Exception e){handler.post(()->error(e));}});});
    }
    private void showChats(){showHub("Чаты");}
    private void showHub(String tab){
        mainTab=tab;begin("chats");chatFolderFilter=prefs.getString("chat_folder","all");if(api.signedIn())maybeStartNotifications();
        GradientDrawable bgDraw=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.parseColor("#091A2E"),Color.parseColor("#071629"),Color.parseColor("#06111E")});
        root.setBackground(bgDraw);
        mainToolbar();mainTabs();
        connection=label("",11,muted);connection.setPadding(dp(18),dp(4),dp(18),dp(4));connection.setVisibility(View.GONE);root.addView(connection);
        FrameLayout frame=new FrameLayout(this);
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);sv.setClipToPadding(false);
        list=vertical();list.setPadding(dp(12),dp(8),dp(12),dp(100));sv.addView(list,new FrameLayout.LayoutParams(-1,-2));frame.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        TextView fab=label("✎",24,Color.rgb(4,28,35));fab.setGravity(Gravity.CENTER);bold(fab);GradientDrawable fabBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{accent,cyan});fabBg.setShape(GradientDrawable.OVAL);fab.setBackground(fabBg);fab.setElevation(dp(4));FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(62),dp(62),Gravity.END|Gravity.BOTTOM);fp.rightMargin=dp(18);fp.bottomMargin=dp(18);frame.addView(fab,fp);
        fab.setOnClickListener(v->{if("Чаты".equals(mainTab))newChat();else createCommunity("Группы".equals(mainTab)?"group":"channel");});
        root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));bottom("Чаты");filter="";
        if("Чаты".equals(tab)){drawChatList();if(api.signedIn()){publishE2eeIdentity();loadChats(true);}else{connection.setText("Войдите, чтобы общаться");connection.setVisibility(View.VISIBLE);connection.setOnClickListener(v->{if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");});}}
        else drawCommunityList("Группы".equals(tab)?"group":"channel");
    }
    private void loadChats(boolean report){if(loading)return;final int stamp=generation;loading=true;worker.execute(()->{try{JSONArray result=(JSONArray)api.rpc("mw_chat_list",new JSONObject());handler.post(()->{loading=false;if(stamp!=generation)return;chats=result;if("Чаты".equals(mainTab)){if(connection!=null){connection.setText("");connection.setVisibility(View.GONE);}drawChatList();}});}catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;if(connection!=null){connection.setText("Нет связи · нажмите, чтобы повторить");connection.setVisibility(View.VISIBLE);connection.setOnClickListener(v->loadChats(true));}if(report)error(e);});}});}
    private void avatar(LinearLayout row,String name,int color){
        TextView a=label(name.isEmpty()?"M":name.substring(0,1).toUpperCase(Locale.ROOT),23,Color.WHITE);a.setGravity(Gravity.CENTER);bold(a);GradientDrawable bgAvatar=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{color,Color.argb(255,Math.max(0,Color.red(color)-20),Math.max(0,Color.green(color)-20),Math.max(0,Color.blue(color)-20))});bgAvatar.setShape(GradientDrawable.OVAL);a.setBackground(bgAvatar);a.setElevation(dp(2));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(62),dp(62));p.rightMargin=dp(14);row.addView(a,p);
    }
    private void drawChatList(){
        if(list==null||!screen.equals("chats")||!"Чаты".equals(mainTab))return;list.removeAllViews();int shown=0;
        for(int i=0;i<chats.length();i++){
            JSONObject c=chats.optJSONObject(i);if(c==null)continue;String name=c.optString("display_name","Чат"),cid=c.optString("id");
            if("important".equals(chatFolderFilter)&&!isImportantChat(cid))continue;
            if(!name.toLowerCase(Locale.ROOT).contains(filter)&&!c.optString("username").toLowerCase(Locale.ROOT).contains(filter))continue;
            shown++;
            LinearLayout row=horizontal();row.setPadding(dp(14),dp(12),dp(12),dp(12));row.setGravity(Gravity.CENTER_VERTICAL);row.setBackground(shape(Color.parseColor("#0B2035"),20));row.setElevation(dp(1));
            int[] palette=new int[]{Color.parseColor("#17B7C8"),Color.parseColor("#2F7FF1"),Color.parseColor("#18C98A"),Color.parseColor("#0E8E9E"),Color.parseColor("#388CF7")};
            avatar(row,name,palette[Math.abs(name.hashCode())%palette.length]);
            LinearLayout words=vertical();words.setPadding(0,dp(2),0,0);
            TextView title=label(name,18,Color.WHITE);bold(title);title.setMaxLines(1);title.setEllipsize(TextUtils.TruncateAt.END);words.addView(title);
            String last=c.isNull("last_message")?"Начните переписку":c.optString("last_message","Начните переписку");
            if(last==null||last.trim().isEmpty())last="Начните переписку";
            TextView preview=label(last,14,Color.parseColor("#9FB0C2"));preview.setMaxLines(1);preview.setEllipsize(TextUtils.TruncateAt.END);preview.setPadding(0,dp(7),0,0);words.addView(preview);
            row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout meta=vertical();meta.setGravity(Gravity.END);
            TextView time=label(time(c.optString("updated_at")),12,Color.parseColor("#8EA4BB"));time.setGravity(Gravity.END);meta.addView(time);
            int unread=c.optInt("unread_count",0);
            if(unread>0){TextView badge=label(String.valueOf(Math.min(unread,99)),12,Color.rgb(3,29,35));bold(badge);badge.setGravity(Gravity.CENTER);badge.setBackground(shape(accent,14));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(unread>9?30:26),dp(26));bp.topMargin=dp(10);meta.addView(badge,bp);}else if(isImportantChat(cid)){TextView badge=label("★",12,accent);badge.setGravity(Gravity.CENTER);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(26),dp(26));bp.topMargin=dp(10);meta.addView(badge,bp);}else{Space sp=new Space(this);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(26),dp(26));bp.topMargin=dp(10);meta.addView(sp,bp);} 
            row.addView(meta,new LinearLayout.LayoutParams(dp(60),-2));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(88));rp.bottomMargin=dp(8);list.addView(row,rp);
            row.setOnClickListener(v->showChat(c.optString("id"),name));
            row.setOnLongClickListener(v->{String id=c.optString("id");boolean important=isImportantChat(id);new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{important?"Убрать из «Важных»":"Добавить в «Важные»"},(d,w)->{setImportantChat(id,!important);drawChatList();}).show();return true;});
        }
        if(shown==0){
            LinearLayout empty=vertical();empty.setPadding(dp(28),dp(72),dp(28),dp(28));empty.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView mark=label("💬",46,accent);mark.setGravity(Gravity.CENTER);empty.addView(mark);
            gap(empty,16);TextView title=label(filter.isEmpty()?"Список чатов пока пуст":"Чаты не найдены",22,Color.WHITE);bold(title);title.setGravity(Gravity.CENTER);empty.addView(title);
            gap(empty,10);TextView desc=label(api.signedIn()?"Нажмите + или кнопку внизу справа, чтобы начать новый чат.":"Войдите в аккаунт, чтобы увидеть переписку.",14,Color.parseColor("#B3C1D3"));desc.setGravity(Gravity.CENTER);desc.setLineSpacing(dp(4),1);empty.addView(desc);
            list.addView(empty,new LinearLayout.LayoutParams(-1,-2));
        }
    }

    private void newChat(){if(!api.signedIn()){if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");return;}
        EditText user=new EditText(this);user.setSingleLine(true);user.setHint("+номер телефона или @имя");user.setPadding(dp(24),dp(16),dp(24),dp(16));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Новый чат").setView(user).setNegativeButton("Отмена",null).setPositiveButton("Найти",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(w->{String query=user.getText().toString().trim();if(query.isEmpty()){user.setError("Введите номер или имя");return;}dialog.dismiss();async(()->{
            Object found=api.rpc("mw_find_person_any",new JSONObject().put("p_query",query));if(!(found instanceof JSONObject))throw new Exception("Пользователь не найден. Проверьте номер или имя.");JSONObject person=(JSONObject)found;Object id=api.rpc("mw_start_chat",new JSONObject().put("p_person",person.getString("id")));return new JSONObject().put("id",id).put("name",person.getString("display_name"));
        },v2->{JSONObject c=(JSONObject)v2;showChat(c.getString("id"),c.getString("name"));});}));dialog.show();
    }
    private void chatToolbar(String name){
        LinearLayout bar=horizontal();bar.setPadding(dp(10),dp(8),dp(8),dp(8));bar.setBackgroundColor(Color.parseColor("#08192C"));
        TextView back=label("‹",40,Color.WHITE);back.setGravity(Gravity.CENTER);back.setContentDescription("Назад");bar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(54)));back.setOnClickListener(v->onBackPressed());
        TextView av=label(name.isEmpty()?"M":name.substring(0,1).toUpperCase(Locale.ROOT),17,Color.WHITE);av.setGravity(Gravity.CENTER);bold(av);GradientDrawable avBg=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.parseColor("#65B8F3"),Color.parseColor("#1E6FB2")});avBg.setShape(GradientDrawable.OVAL);av.setBackground(avBg);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(46),dp(46));ap.leftMargin=dp(3);ap.rightMargin=dp(12);bar.addView(av,ap);
        LinearLayout words=vertical();words.setGravity(Gravity.CENTER_VERTICAL);TextView title=label(name,19,Color.WHITE);bold(title);title.setMaxLines(1);title.setEllipsize(TextUtils.TruncateAt.END);words.addView(title);TextView status=label(notesMode?"личные заметки":"в сети",13,notesMode?Color.parseColor("#8FA6BC"):accent);status.setPadding(0,dp(2),0,0);if(!notesMode)bold(status);words.addView(status);bar.addView(words,new LinearLayout.LayoutParams(0,dp(50),1));
        if(!notesMode){TextView call=label("☎",25,Color.WHITE);call.setGravity(Gravity.CENTER);call.setContentDescription("Позвонить");bar.addView(call,new LinearLayout.LayoutParams(dp(48),dp(50)));call.setOnClickListener(v->chooseCall());TextView more=label("⋮",30,Color.WHITE);more.setGravity(Gravity.CENTER);more.setContentDescription("Меню");bar.addView(more,new LinearLayout.LayoutParams(dp(42),dp(50)));more.setOnClickListener(v->showChatMenu());}
        root.addView(bar);View rule=new View(this);rule.setBackgroundColor(Color.parseColor("#0B2238"));root.addView(rule,new LinearLayout.LayoutParams(-1,dp(1)));
    }
    private void showChatMenu(){
        String[] items={"Видеозвонок",isImportantChat(chatId)?"Убрать из «Важных»":"Добавить в «Важные»","Профиль и настройки"};new AlertDialog.Builder(this).setTitle(chatName).setItems(items,(d,w)->{if(w==0)startCall("video");else if(w==1){setImportantChat(chatId,!isImportantChat(chatId));Toast.makeText(this,"Список «Важные» обновлён",Toast.LENGTH_SHORT).show();}else showAccountSettings();}).show();
    }

    private void showChat(String id,String name){notesMode=false;openConversation(id,name);prepareE2eeChat();}
    private void publishE2eeIdentity(){
        if(!api.signedIn()||e2eePublishing||api.uid().equals(e2eePublishedFor))return;
        e2eePublishing=true;final String uid=api.uid();
        worker.execute(()->{try{String key=crypto.publicKey(uid);api.rpc("mw_e2ee_set_key",new JSONObject().put("p_public_key",key));e2eePublishedFor=uid;}catch(Exception ignored){}finally{e2eePublishing=false;}});
    }
    private void prepareE2eeChat(){
        final int stamp=generation;final String id=chatId,uid=api.uid();loading=true;connection.setText("Подготавливаем сквозное шифрование…");
        worker.execute(()->{try{
            String own=crypto.publicKey(uid);api.rpc("mw_e2ee_set_key",new JSONObject().put("p_public_key",own));e2eePublishedFor=uid;
            Object value=api.rpc("mw_e2ee_peer_key",new JSONObject().put("p_chat",id));final String peer=value instanceof String?(String)value:"";
            handler.post(()->{loading=false;if(stamp!=generation)return;e2eeBackendReady=true;peerE2eeKey=peer;connection.setText(chatSecurityStatus());loadMessages(true);});
        }catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;e2eeBackendReady=false;peerE2eeKey="";connection.setText(chatSecurityStatus());if(e instanceof Api.MfaRequiredException)error(e);else loadMessages(true);});}});
    }
    private String chatSecurityStatus(){
        if(e2eeBackendReady&&!peerE2eeKey.isEmpty())return "🔒 Сквозное шифрование активно";
        if(e2eeBackendReady)return "🔒 Собеседник ещё не активировал E2EE";
        return "Личная переписка · E2EE на сервере ещё не готово";
    }
    private void showNotes(){notesMode=true;openConversation("local-notes","Избранное");drawNotes();}
    private void openConversation(String id,String name){
        begin("chat");chatId=id;chatName=name;history.clear();pendingNonce="";pendingText="";pendingPayload="";peerE2eeKey="";e2eeBackendReady=false;root.setBackgroundColor(Color.parseColor("#061321"));chatToolbar(name);
        connection=label(notesMode?"Личные заметки · только на этом телефоне":"Загрузка сообщений…",11,muted);connection.setPadding(dp(14),dp(4),dp(14),dp(4));connection.setVisibility(View.GONE);root.addView(connection);
        messageScroll=new ScrollView(this);messageScroll.setFillViewport(true);messageScroll.setVerticalScrollBarEnabled(false);messageScroll.setBackground(new ChatWallpaperDrawable());messages=vertical();messages.setPadding(dp(12),dp(16),dp(12),dp(18));messageScroll.addView(messages);root.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout compose=horizontal();compose.setGravity(Gravity.CENTER_VERTICAL);compose.setPadding(dp(10),dp(8),dp(10),dp(12));compose.setBackgroundColor(Color.parseColor("#06111E"));
        LinearLayout fieldBox=horizontal();fieldBox.setGravity(Gravity.CENTER_VERTICAL);fieldBox.setPadding(dp(4),0,dp(4),0);fieldBox.setBackground(shape(Color.parseColor("#10243B"),26));
        if(!notesMode){emojiButton=smallIconButton("☺","Смайлики");emojiButton.setTextColor(Color.parseColor("#B9C8DA"));emojiButton.setTextSize(23);emojiButton.setBackgroundColor(Color.TRANSPARENT);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(dp(44),dp(52));fieldBox.addView(emojiButton,ep);emojiButton.setOnClickListener(v->showEmojiPicker());}
        composer=new EditText(this);composer.setHint("Сообщение");composer.setHintTextColor(Color.parseColor("#9EB0C5"));composer.setTextColor(Color.WHITE);composer.setTextSize(16);composer.setMaxLines(4);composer.setInputType(131073);composer.setPadding(dp(4),dp(9),dp(6),dp(9));composer.setBackgroundColor(Color.TRANSPARENT);composer.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4000)});fieldBox.addView(composer,new LinearLayout.LayoutParams(0,-2,1));
        if(!notesMode){attachButton=smallIconButton("⌕","Прикрепить фото, видео или аудио");attachButton.setText("⌕");attachButton.setRotation(45);attachButton.setTextColor(Color.parseColor("#B9C8DA"));attachButton.setTextSize(24);attachButton.setBackgroundColor(Color.TRANSPARENT);LinearLayout.LayoutParams ap2=new LinearLayout.LayoutParams(dp(42),dp(52));fieldBox.addView(attachButton,ap2);attachButton.setOnClickListener(v->pickMedia());videoMessageButton=smallIconButton("▣","Камера");videoMessageButton.setText("▣");videoMessageButton.setTextColor(Color.parseColor("#B9C8DA"));videoMessageButton.setTextSize(22);videoMessageButton.setBackgroundColor(Color.TRANSPARENT);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(dp(42),dp(52));fieldBox.addView(videoMessageButton,vp);videoMessageButton.setOnClickListener(v->recordVideoMessage());}
        compose.addView(fieldBox,new LinearLayout.LayoutParams(0,dp(56),1));
        sendButton=new Button(this);sendButton.setAllCaps(false);sendButton.setMinWidth(0);sendButton.setMinHeight(0);sendButton.setPadding(0,0,0,0);sendButton.setTextSize(20);sendButton.setTextColor(Color.WHITE);GradientDrawable sendBg=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.parseColor("#16D9B0"),Color.parseColor("#08B88F")});sendBg.setShape(GradientDrawable.OVAL);sendButton.setBackground(sendBg);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(56),dp(56));sp.leftMargin=dp(9);compose.addView(sendButton,sp);root.addView(compose);
        composer.setText(prefs.getString("draft:"+id,""));composer.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){updateComposeAction();}public void afterTextChanged(Editable e){}});sendButton.setOnClickListener(v->{if(notesMode||composer.getText().toString().trim().length()>0)send();else toggleVoiceRecording();});sendButton.setOnLongClickListener(v->{if(voiceRecording){cancelVoiceRecording(true);return true;}return false;});updateComposeAction();
    }
    private void saveDraft(){if(composer!=null&&screen.equals("chat"))prefs.edit().putString("draft:"+chatId,composer.getText().toString()).apply();}
    private void drawNotes(){messages.removeAllViews();try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));if(notes.length()==0){note(messages,"Сохраняйте идеи, списки и важные мысли. Нажмите на заметку и удерживайте, чтобы скопировать или удалить её.");}for(int i=0;i<notes.length();i++){JSONObject n=notes.getJSONObject(i);TextView t=bubble(n.getString("body"),true,n.optString("time"));final int index=i;t.setOnLongClickListener(v->{new AlertDialog.Builder(this).setItems(new String[]{"Скопировать","Удалить"},(d,which)->{if(which==0)copy(n.optString("body"));else{notes.remove(index);prefs.edit().putString("notes",notes.toString()).apply();drawNotes();}}).show();return true;});}}catch(Exception e){error(e);}bottomScroll();}
    private TextView bubble(String body,boolean mine,String when){
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);LinearLayout card=vertical();card.setPadding(dp(14),dp(11),dp(12),dp(8));card.setBackground(mine?outgoingBubbleDrawable():incomingBubbleDrawable());
        int font=prefs.getInt("message_text_size",16);TextView bodyView=label(body,font,Color.WHITE);bodyView.setMaxWidth(dp(286));bodyView.setLineSpacing(dp(2),1);card.addView(bodyView,new LinearLayout.LayoutParams(-2,-2));
        TextView meta=label((when==null?"":when)+(mine?"  ✓✓":""),11,mine?Color.parseColor("#CFFCF1"):Color.parseColor("#A8B8CA"));meta.setGravity(Gravity.END);meta.setPadding(dp(12),dp(3),0,0);card.addView(meta,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.setMargins(dp(mine?44:0),dp(5),dp(mine?0:44),dp(5));wrap.addView(card,p);messages.addView(wrap);card.setOnLongClickListener(v->{copy(body);return true;});return bodyView;
    }
    private void copy(String value){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Muwahid",value));Toast.makeText(this,"Скопировано",Toast.LENGTH_SHORT).show();}
    private void bottomScroll(){messageScroll.post(()->messageScroll.fullScroll(View.FOCUS_DOWN));}
    private void loadMessages(boolean report){fetchMessages(null,report);}
    private void fetchMessages(Long before,boolean report){if(loading)return;loading=true;final int stamp=generation;final String id=chatId;
        worker.execute(()->{try{JSONObject args=new JSONObject().put("p_chat",id);if(before!=null)args.put("p_before",before);JSONArray result=(JSONArray)api.rpc("mw_messages_get",args);handler.post(()->{loading=false;if(stamp!=generation)return;
            boolean changed=false;for(int i=0;i<result.length();i++){JSONObject m=result.optJSONObject(i);if(m!=null&&!history.containsKey(m.optLong("id"))){history.put(m.optLong("id"),m);changed=true;}}
            if(before!=null||history.size()<=100)olderAvailable=result.length()==100;
            connection.setText(chatSecurityStatus());connection.setOnClickListener(null);
            if(changed||messages.getChildCount()==0)drawMessages(before==null);
        });}catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;connection.setText("Нет связи · нажмите для повтора");connection.setOnClickListener(v->loadMessages(true));if(report)error(e);});}});
    }
    private void drawMessages(boolean newest){int oldY=messageScroll.getScrollY();boolean nearBottom=messages.getHeight()-messageScroll.getHeight()-oldY<dp(100);messages.removeAllViews();
        if(olderAvailable&&!history.isEmpty()){TextView older=label("Загрузить предыдущие сообщения",14,accent);older.setGravity(Gravity.CENTER);older.setPadding(0,dp(12),0,dp(16));messages.addView(older);older.setOnClickListener(v->fetchMessages(history.firstKey(),true));}
        if(history.isEmpty())note(messages,"Пока сообщений нет. Напишите первым.");
        for(JSONObject m:history.values())drawMessage(m);
        if(newest&&(nearBottom||oldY==0))bottomScroll();
    }
    private String readableBody(JSONObject message){
        String body=message.optString("body");
        if(!body.startsWith("mw1:"))return body;
        if(peerE2eeKey.isEmpty())return "🔒 Зашифрованное сообщение · ключ собеседника недоступен";
        try{return crypto.decryptText(api.uid(),chatId,peerE2eeKey,body);}catch(Exception e){return "🔒 Не удалось расшифровать это сообщение";}
    }
    private void drawMessage(JSONObject m){
        boolean mine=m.optString("sender_id").equals(api.uid());String plain=readableBody(m);String when=time(m.optString("created_at"));
        try{if(plain.startsWith("{")&&plain.contains("\"mw_kind\":\"media\"")){
            JSONObject meta=new JSONObject(plain);String type=meta.optString("media_type","file");
            if("image".equals(type)){drawImageMessage(meta,mine,when);return;}
            if("voice".equals(type)||"audio".equals(type)){drawVoiceMessage(meta,mine,when);return;}
            drawGenericMediaMessage(meta,mine,when);return;
        }}catch(Exception ignored){}
        bubble(plain,mine,when);
    }
    private GradientDrawable outgoingBubbleDrawable(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.parseColor("#15D8B0"),Color.parseColor("#08B98E")});d.setCornerRadius(dp(20));return d;}
    private GradientDrawable incomingBubbleDrawable(){GradientDrawable d=shape(Color.parseColor("#132A43"),20);d.setStroke(dp(1),Color.parseColor("#193650"));return d;}
    private TextView chatMeta(String when,boolean mine){TextView meta=label((when==null?"":when)+(mine?"  ✓✓":""),11,mine?Color.parseColor("#D7FFF5"):Color.parseColor("#B0BED0"));meta.setGravity(Gravity.END);meta.setPadding(dp(6),dp(3),dp(6),dp(4));return meta;}
    private void drawImageMessage(JSONObject meta,boolean mine,String when){
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);FrameLayout frame=new FrameLayout(this);GradientDrawable border=shape(Color.parseColor("#10243B"),20);border.setStroke(dp(2),mine?accent:Color.parseColor("#28445D"));frame.setBackground(border);frame.setPadding(dp(2),dp(2),dp(2),dp(2));
        ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Color.parseColor("#0C2034"));FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(dp(282),dp(190));frame.addView(image,ip);
        TextView loading=label("Фото",14,Color.parseColor("#B9C8DA"));loading.setGravity(Gravity.CENTER);frame.addView(loading,new FrameLayout.LayoutParams(-1,-1));
        TextView stamp=chatMeta(when,mine);stamp.setTextColor(Color.WHITE);stamp.setBackground(shape(Color.argb(125,0,0,0),10));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-2,dp(28),Gravity.END|Gravity.BOTTOM);mp.rightMargin=dp(8);mp.bottomMargin=dp(7);frame.addView(stamp,mp);
        LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-2,-2);wp.setMargins(dp(mine?36:0),dp(6),dp(mine?0:36),dp(6));wrap.addView(frame,wp);messages.addView(wrap);frame.setOnClickListener(v->downloadMedia(meta));loadInlineImage(meta,image,loading);
    }
    private void loadInlineImage(JSONObject meta,ImageView image,TextView loading){final int stamp=generation;worker.execute(()->{try{byte[] encrypted=api.downloadMedia(meta.getString("path"));byte[] raw=crypto.decryptBytes(api.uid(),chatId,peerE2eeKey,encrypted);Bitmap bitmap=BitmapFactory.decodeByteArray(raw,0,raw.length);if(bitmap==null)throw new Exception("decode");handler.post(()->{if(stamp!=generation)return;image.setImageBitmap(bitmap);loading.setVisibility(View.GONE);});}catch(Exception e){handler.post(()->{if(stamp!=generation)return;loading.setText("Фото · нажмите, чтобы открыть");});}});}
    private void drawVoiceMessage(JSONObject meta,boolean mine,String when){
        LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);LinearLayout card=horizontal();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(mine?outgoingBubbleDrawable():incomingBubbleDrawable());
        TextView play=label("▶",21,mine?Color.parseColor("#08B98E"):Color.parseColor("#132A43"));play.setGravity(Gravity.CENTER);bold(play);play.setBackground(shape(Color.WHITE,24));card.addView(play,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout center=vertical();center.setPadding(dp(10),0,dp(8),0);WaveformView wave=new WaveformView(this,mine);center.addView(wave,new LinearLayout.LayoutParams(dp(150),dp(28)));long duration=meta.optLong("duration_ms",0);TextView dur=label(duration>0?formatDuration(duration):"Аудио",12,mine?Color.parseColor("#E6FFF9"):Color.parseColor("#B9C8DA"));center.addView(dur);card.addView(center,new LinearLayout.LayoutParams(0,-2,1));TextView mt=chatMeta(when,mine);card.addView(mt,new LinearLayout.LayoutParams(dp(66),-2));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(286),-2);cp.setMargins(dp(mine?34:0),dp(6),dp(mine?0:34),dp(6));wrap.addView(card,cp);messages.addView(wrap);
        View.OnClickListener open=v->playInlineVoice(meta,play,dur,duration);card.setOnClickListener(open);play.setOnClickListener(open);
        prefetchInlineVoice(meta);
    }
    private void prefetchInlineVoice(JSONObject meta){
        String path=meta.optString("path","");if(path.isEmpty()||inlineVoiceCache.containsKey(path)||inlineVoiceLoading.contains(path)||peerE2eeKey.isEmpty())return;
        inlineVoiceLoading.add(path);final int stamp=generation;final String id=chatId,peer=peerE2eeKey,uid=api.uid();
        worker.execute(()->{try{byte[] encrypted=api.downloadMedia(path);byte[] raw=crypto.decryptBytes(uid,id,peer,encrypted);File dir=new File(getCacheDir(),"voice_playback");dir.mkdirs();File f=new File(dir,Integer.toHexString(path.hashCode())+".m4a");try(FileOutputStream out=new FileOutputStream(f)){out.write(raw);}inlineVoiceCache.put(path,f);}catch(Exception ignored){}finally{inlineVoiceLoading.remove(path);}});
    }
    private void playInlineVoice(JSONObject meta,TextView play,TextView dur,long knownDuration){
        String path=meta.optString("path","");if(path.isEmpty())return;
        if(path.equals(inlineVoicePath)&&inlineVoicePlayer!=null){
            try{if(inlineVoicePlayer.isPlaying()){inlineVoicePlayer.pause();play.setText("▶");handler.removeCallbacks(inlineVoiceTicker);}else{inlineVoicePlayer.start();play.setText("Ⅱ");inlineVoiceButton=play;inlineVoiceDuration=dur;handler.post(inlineVoiceTicker);}return;}catch(Exception ignored){stopInlineVoice();}
        }
        stopInlineVoice();play.setText("…");dur.setText("Загрузка…");inlineVoiceKnownDuration=knownDuration;final int stamp=generation;final String id=chatId,peer=peerE2eeKey,uid=api.uid();
        worker.execute(()->{try{
            File f=inlineVoiceCache.get(path);if(f==null||!f.exists()){byte[] encrypted=api.downloadMedia(path);byte[] raw=crypto.decryptBytes(uid,id,peer,encrypted);File dir=new File(getCacheDir(),"voice_playback");dir.mkdirs();f=new File(dir,Integer.toHexString(path.hashCode())+".m4a");try(FileOutputStream out=new FileOutputStream(f)){out.write(raw);}inlineVoiceCache.put(path,f);}
            MediaPlayer player=new MediaPlayer();player.setDataSource(f.getAbsolutePath());player.prepare();
            handler.post(()->{if(stamp!=generation){player.release();return;}stopInlineVoice();inlineVoicePlayer=player;inlineVoicePath=path;inlineVoiceButton=play;inlineVoiceDuration=dur;player.setOnCompletionListener(mp->{handler.removeCallbacks(inlineVoiceTicker);try{mp.seekTo(0);}catch(Exception ignored){}if(inlineVoiceButton!=null)inlineVoiceButton.setText("▶");if(inlineVoiceDuration!=null)inlineVoiceDuration.setText(knownDuration>0?formatDuration(knownDuration):formatDuration(mp.getDuration()));});player.start();play.setText("Ⅱ");handler.post(inlineVoiceTicker);});
        }catch(Exception e){handler.post(()->{if(stamp!=generation)return;play.setText("▶");dur.setText(knownDuration>0?formatDuration(knownDuration):"Аудио");notice("Не удалось воспроизвести голосовое сообщение внутри Muwahid.");});}});
    }
    private void stopInlineVoice(){handler.removeCallbacks(inlineVoiceTicker);if(inlineVoiceButton!=null)inlineVoiceButton.setText("▶");if(inlineVoiceDuration!=null&&inlineVoiceKnownDuration>0)inlineVoiceDuration.setText(formatDuration(inlineVoiceKnownDuration));if(inlineVoicePlayer!=null){try{inlineVoicePlayer.stop();}catch(Exception ignored){}try{inlineVoicePlayer.release();}catch(Exception ignored){}}inlineVoicePlayer=null;inlineVoicePath="";inlineVoiceButton=null;inlineVoiceDuration=null;inlineVoiceKnownDuration=0;}
    private void drawGenericMediaMessage(JSONObject meta,boolean mine,String when){String type=meta.optString("media_type","file");String icon="video".equals(type)?"▶":"video_message".equals(type)?"◉":"📎";String title="video_message".equals(type)?"Видеосообщение":meta.optString("name","Файл");TextView t=bubble(icon+"  "+title,mine,when);t.setOnClickListener(v->downloadMedia(meta));}
    private void chooseCall(){
        if(!api.signedIn()){notice("Войдите в аккаунт");return;}
        new AlertDialog.Builder(this).setTitle("Позвонить "+chatName).setItems(new String[]{"Аудиозвонок","Видеозвонок"},(d,w)->startCall(w==0?"audio":"video")).show();
    }
    private void startCall(String kind){Intent i=new Intent(this,CallActivity.class);i.putExtra("chat_id",chatId);i.putExtra("peer_name",chatName);i.putExtra("kind",kind);i.putExtra("incoming",false);startActivity(i);}
    private void pickMedia(){
        if(!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для защищённой отправки файла собеседник должен использовать актуальную версию Muwahid с E2EE.");return;}
        new AlertDialog.Builder(this).setTitle("Отправить").setItems(new String[]{"Фото","Видео","Аудио"},(d,which)->{
            if(which==0)pickMediaType("image/*",REQ_IMAGE);
            else if(which==1)pickMediaType("video/*",REQ_VIDEO);
            else pickMediaType("audio/*",REQ_AUDIO);
        }).show();
    }
    private void pickMediaType(String mime,int requestCode){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);startActivityForResult(i,requestCode);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if((requestCode==REQ_IMAGE||requestCode==REQ_VIDEO||requestCode==REQ_AUDIO)&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadMedia(data.getData(),null);
        else if(requestCode==REQ_VIDEO_MESSAGE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadMedia(data.getData(),"video_message");
    }
    private void uploadMedia(Uri uri,String forcedType){
        if(sending)return;final String id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;setComposeEnabled(false);if(sendButton!=null)sendButton.setEnabled(false);connection.setText("Шифруем и загружаем файл…");
        worker.execute(()->{try{
            String mime=getContentResolver().getType(uri);if(mime==null)mime="application/octet-stream";String name=fileName(uri);byte[] raw=readUri(uri,24*1024*1024);byte[] encrypted=crypto.encryptBytes(uid,id,peer,raw);String path=id+"/"+UUID.randomUUID()+".bin";api.uploadMedia(path,encrypted);
            String type=forcedType!=null?forcedType:(mime.startsWith("image/")?"image":mime.startsWith("video/")?"video":mime.startsWith("audio/")?"audio":"file");
            JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type",type).put("name",type.equals("video_message")?"Видеосообщение.mp4":name).put("mime",mime).put("path",path).put("size",raw.length);
            String payload=crypto.encryptText(uid,id,peer,meta.toString());String nonce=UUID.randomUUID().toString();JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",nonce));
            handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});
        }catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());updateComposeAction();error(e);});}});
    }
    private void updateComposeAction(){
        if(sendButton==null||composer==null)return;
        if(notesMode){sendButton.setText("➤");sendButton.setContentDescription("Отправить сообщение");return;}
        if(voiceRecording){sendButton.setText("■");sendButton.setContentDescription("Остановить и отправить голосовое сообщение");return;}
        boolean hasText=composer.getText().toString().trim().length()>0;
        sendButton.setText(hasText?"➤":"●");sendButton.setTextSize(hasText?21:18);sendButton.setContentDescription(hasText?"Отправить сообщение":"Записать голосовое сообщение");
    }
    private void showEmojiPicker(){
        final String[] emojis={"😀","😂","😊","😍","🥰","😎","🤔","😢","😭","😡","👍","👎","👏","🙏","❤️","💚","🔥","✨","🎉","✅","💯","🤝","👋","🌙","⭐","☕","📌","📎","🎤","📹"};
        new AlertDialog.Builder(this).setTitle("Смайлики").setItems(emojis,(d,which)->{
            if(composer==null)return;int start=Math.max(composer.getSelectionStart(),0);composer.getText().insert(start,emojis[which]);composer.requestFocus();
        }).show();
    }
    private void toggleVoiceRecording(){if(voiceRecording)stopVoiceRecording(true);else ensureVoicePermission();}
    private void ensureVoicePermission(){
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=getPackageManager().PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},REQ_RECORD_AUDIO_PERMISSION);return;
        }
        startVoiceRecording();
    }
    private void startVoiceRecording(){
        if(notesMode||voiceRecording||sending)return;
        if(!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для защищённой отправки голосового сообщения собеседник должен использовать актуальную версию Muwahid с E2EE.");return;}
        try{
            File dir=new File(getCacheDir(),"voice");dir.mkdirs();voiceFile=new File(dir,"voice_"+UUID.randomUUID()+".m4a");
            voiceRecorder=new MediaRecorder();voiceRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);voiceRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);voiceRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);voiceRecorder.setAudioEncodingBitRate(64000);voiceRecorder.setAudioSamplingRate(44100);voiceRecorder.setOutputFile(voiceFile.getAbsolutePath());voiceRecorder.prepare();voiceRecorder.start();
            voiceRecording=true;voiceStartedAt=System.currentTimeMillis();setComposeEnabled(false);updateComposeAction();handler.removeCallbacks(voiceTicker);handler.post(voiceTicker);
        }catch(Exception e){releaseVoiceRecorder();voiceRecording=false;if(voiceFile!=null)voiceFile.delete();voiceFile=null;setComposeEnabled(true);updateComposeAction();notice("Не удалось начать запись. Проверьте доступ к микрофону.");}
    }
    private void stopVoiceRecording(boolean sendAfter){
        if(!voiceRecording)return;handler.removeCallbacks(voiceTicker);long duration=System.currentTimeMillis()-voiceStartedAt;boolean ok=true;
        try{voiceRecorder.stop();}catch(Exception e){ok=false;}releaseVoiceRecorder();voiceRecording=false;setComposeEnabled(true);updateComposeAction();
        File recorded=voiceFile;voiceFile=null;if(!ok||recorded==null||!recorded.exists()||duration<700){if(recorded!=null)recorded.delete();if(connection!=null)connection.setText(chatSecurityStatus());if(sendAfter)Toast.makeText(this,"Запись слишком короткая",Toast.LENGTH_SHORT).show();return;}
        if(sendAfter)uploadRecordedVoice(recorded,duration);else{recorded.delete();if(connection!=null)connection.setText(chatSecurityStatus());}
    }
    private void cancelVoiceRecording(boolean showToast){
        if(!voiceRecording)return;handler.removeCallbacks(voiceTicker);try{voiceRecorder.stop();}catch(Exception ignored){}releaseVoiceRecorder();voiceRecording=false;File recorded=voiceFile;voiceFile=null;if(recorded!=null)recorded.delete();setComposeEnabled(true);updateComposeAction();if(connection!=null)connection.setText(chatSecurityStatus());if(showToast)Toast.makeText(this,"Запись отменена",Toast.LENGTH_SHORT).show();
    }
    private void releaseVoiceRecorder(){if(voiceRecorder!=null){try{voiceRecorder.reset();}catch(Exception ignored){}try{voiceRecorder.release();}catch(Exception ignored){}voiceRecorder=null;}}
    private void setComposeEnabled(boolean enabled){if(composer!=null)composer.setEnabled(enabled);if(attachButton!=null)attachButton.setEnabled(enabled);if(emojiButton!=null)emojiButton.setEnabled(enabled);if(videoMessageButton!=null)videoMessageButton.setEnabled(enabled);}
    private void uploadRecordedVoice(File recorded,long duration){
        if(sending){recorded.delete();return;}final String id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;if(sendButton!=null)sendButton.setEnabled(false);if(attachButton!=null)attachButton.setEnabled(false);if(videoMessageButton!=null)videoMessageButton.setEnabled(false);if(emojiButton!=null)emojiButton.setEnabled(false);connection.setText("Шифруем и отправляем голосовое сообщение…");
        worker.execute(()->{try{
            byte[] raw=readFile(recorded,24*1024*1024);byte[] encrypted=crypto.encryptBytes(uid,id,peer,raw);String path=id+"/"+UUID.randomUUID()+".bin";api.uploadMedia(path,encrypted);
            JSONObject meta=new JSONObject().put("mw_kind","media").put("media_type","voice").put("name","Голосовое сообщение.m4a").put("mime","audio/mp4").put("path",path).put("size",raw.length).put("duration_ms",duration);
            String payload=crypto.encryptText(uid,id,peer,meta.toString());String nonce=UUID.randomUUID().toString();JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",nonce));recorded.delete();
            handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});
        }catch(Exception e){recorded.delete();handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);if(sendButton!=null)sendButton.setEnabled(true);connection.setText(chatSecurityStatus());updateComposeAction();error(e);});}});
    }
    private byte[] readFile(File file,int max) throws Exception{if(file.length()>max)throw new Exception("Максимальный размер файла — 24 МБ");ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=new FileInputStream(file)){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}return out.toByteArray();}
    private String formatDuration(long ms){long total=Math.max(0,ms/1000),m=total/60,s=total%60;return String.format(Locale.getDefault(),"%d:%02d",m,s);}
    private void recordVideoMessage(){
        if(sending||voiceRecording)return;if(!e2eeBackendReady||peerE2eeKey.isEmpty()){notice("Для защищённой отправки видеосообщения собеседник должен использовать актуальную версию Muwahid с E2EE.");return;}
        if(Build.VERSION.SDK_INT>=23&&(checkSelfPermission(android.Manifest.permission.CAMERA)!=getPackageManager().PERMISSION_GRANTED||checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=getPackageManager().PERMISSION_GRANTED)){
            requestPermissions(new String[]{android.Manifest.permission.CAMERA,android.Manifest.permission.RECORD_AUDIO},REQ_VIDEO_MESSAGE_PERMISSION);return;
        }
        startVideoMessageCapture();
    }
    private void startVideoMessageCapture(){
        try{Intent i=new Intent(MediaStore.ACTION_VIDEO_CAPTURE);i.putExtra(MediaStore.EXTRA_DURATION_LIMIT,60);i.putExtra(MediaStore.EXTRA_VIDEO_QUALITY,0);startActivityForResult(i,REQ_VIDEO_MESSAGE);}catch(Exception e){notice("На телефоне не найдено приложение камеры для записи видео.");}
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_RECORD_AUDIO_PERMISSION){if(grantResults.length>0&&grantResults[0]==getPackageManager().PERMISSION_GRANTED)startVoiceRecording();else notice("Без доступа к микрофону голосовое сообщение записать нельзя.");}
        else if(requestCode==REQ_VIDEO_MESSAGE_PERMISSION){boolean ok=grantResults.length>=2;for(int value:grantResults)ok&=value==getPackageManager().PERMISSION_GRANTED;if(ok)startVideoMessageCapture();else notice("Для видеосообщения нужен доступ к камере и микрофону.");}
    }
    private String fileName(Uri uri){String name="Файл";try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())name=c.getString(0);}catch(Exception ignored){}return name==null?"Файл":name.replaceAll("[\r\n]"," ");}
    private byte[] readUri(Uri uri,int max) throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new Exception("Не удалось открыть файл");byte[] b=new byte[16384];int n,total=0;while((n=in.read(b))!=-1){total+=n;if(total>max)throw new Exception("Максимальный размер файла — 24 МБ");out.write(b,0,n);}}return out.toByteArray();}
    private void downloadMedia(JSONObject meta){final int stamp=generation;connection.setText("Скачиваем и расшифровываем файл…");worker.execute(()->{try{byte[] encrypted=api.downloadMedia(meta.getString("path"));byte[] raw=crypto.decryptBytes(api.uid(),chatId,peerE2eeKey,encrypted);File dir=new File(getCacheDir(),"media");dir.mkdirs();String safe=meta.optString("name","file").replaceAll("[^A-Za-zА-Яа-я0-9._ -]","_");File f=new File(dir,UUID.randomUUID()+"_"+safe);try(FileOutputStream out=new FileOutputStream(f)){out.write(raw);}Uri content=FileProvider.getUriForFile(this,getPackageName()+".files",f);Intent open=new Intent(Intent.ACTION_VIEW);open.setDataAndType(content,meta.optString("mime","application/octet-stream"));open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);handler.post(()->{if(stamp!=generation)return;connection.setText(chatSecurityStatus());try{startActivity(open);}catch(Exception x){notice("На телефоне нет приложения для открытия этого файла.");}});}catch(Exception e){handler.post(()->{if(stamp!=generation)return;connection.setText(chatSecurityStatus());error(e);});}});}
    private void send(){if(sending)return;String body=composer.getText().toString().trim();if(body.isEmpty())return;
        if(notesMode){try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));notes.put(new JSONObject().put("body",body).put("time",new SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new Date())));if(!prefs.edit().putString("notes",notes.toString()).commit())throw new Exception("Не удалось сохранить заметку");composer.setText("");saveDraft();drawNotes();}catch(Exception e){error(e);}return;}
        if(!e2eeBackendReady){notice("Защищённая отправка ещё не готова на сервере Muwahid. Проверьте серверные функции E2EE в Supabase.");return;}
        if(peerE2eeKey.isEmpty()){notice("Собеседник ещё не активировал E2EE в Muwahid. Незашифрованная отправка заблокирована, чтобы не снижать защиту.");return;}
        if(!body.equals(pendingText)){pendingText=body;pendingNonce=UUID.randomUUID().toString();pendingPayload="";}
        final String nonce=pendingNonce,id=chatId,peer=peerE2eeKey,uid=api.uid();final int stamp=generation;sending=true;setComposeEnabled(false);sendButton.setEnabled(false);
        worker.execute(()->{try{
            String payload=pendingPayload;if(payload.isEmpty()){payload=crypto.encryptText(uid,id,peer,body);pendingPayload=payload;}
            JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",payload).put("p_nonce",nonce));
            handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);composer.setText("");saveDraft();pendingNonce="";pendingText="";pendingPayload="";history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();updateComposeAction();});
        }catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;setComposeEnabled(true);sendButton.setEnabled(true);updateComposeAction();error(e);});}});
    }
    private String time(String source){if(source==null||source.isEmpty()||source.equals("null"))return "";try{String s=source.substring(0,19);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(d);}catch(Exception e){return "";}}
    private void showAccountSettings(){begin("account");toolbar("Аккаунт",true,null,null);scrollContent();
        String name=prefs.getString("name","Пользователь Muwahid");TextView a=label(name.substring(0,1).toUpperCase(Locale.ROOT),44,accent);a.setGravity(Gravity.CENTER);a.setBackground(shape(panel,40));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(82),dp(82));ap.gravity=Gravity.CENTER;content.addView(a,ap);gap(content,20);
        EditText nameField=field("Ваше имя",false);nameField.setText(name);EditText username=field("Имя пользователя",false);username.setText(prefs.getString("username",""));username.setInputType(1|524288);username.setEnabled(api.signedIn());
        Button save=button("Сохранить профиль");content.addView(save,new LinearLayout.LayoutParams(-1,dp(50)));save.setOnClickListener(v->{String n=nameField.getText().toString().trim(),u=username.getText().toString().trim().toLowerCase(Locale.ROOT);if(n.isEmpty()||n.length()>60){nameField.setError("От 1 до 60 символов");return;}if(api.signedIn()){async(()->api.rpc("mw_update_profile",new JSONObject().put("p_name",n).put("p_username",u)),result->{prefs.edit().putString("name",n).putString("username",u).apply();Toast.makeText(this,"Профиль сохранён",Toast.LENGTH_SHORT).show();});}else{prefs.edit().putString("name",n).apply();Toast.makeText(this,"Имя сохранено на телефоне",Toast.LENGTH_SHORT).show();}});
        if(api.signedIn())async(()->api.rpc("mw_me",new JSONObject()),result->{if(result instanceof JSONObject){profile=(JSONObject)result;nameField.setText(profile.optString("display_name"));username.setText(profile.optString("username"));prefs.edit().putString("name",profile.optString("display_name")).putString("username",profile.optString("username")).apply();}});
        gap(content,16);if(api.signedIn()){TextView share=label("Поделиться моим именем пользователя",15,accent);share.setPadding(0,dp(10),0,dp(10));content.addView(share);share.setOnClickListener(v->{String u=prefs.getString("username","");if(u.isEmpty())return;Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("text/plain");intent.putExtra(Intent.EXTRA_TEXT,"Найди меня в Muwahid: @"+u);startActivity(Intent.createChooser(intent,"Поделиться"));});}else note(content,api.configured()?"Войдите в аккаунт, чтобы получать сообщения.":"Сервер пока не подключён. Профиль и заметки сохраняются на этом телефоне.");
        if(api.signedIn()) {gap(content,18);Button security=button("Защита аккаунта");content.addView(security,new LinearLayout.LayoutParams(-1,dp(58)));security.setOnClickListener(v->showSecurity());}
        gap(content,20);Switch dark=new Switch(this);dark.setText("Тёмная тема");dark.setTextColor(text);dark.setTextSize(16);dark.setChecked(prefs.getBoolean("dark",true));content.addView(dark,new LinearLayout.LayoutParams(-1,dp(52)));dark.setOnCheckedChangeListener((b,checked)->{prefs.edit().putBoolean("dark",checked).apply();b.post(this::showAccountSettings);});
        gap(content,18);note(content,"Muwahid "+BuildConfig.VERSION_NAME+"\nОбновления без удаления приложения, уведомления о новых версиях. Совместное чтение PDF в голосовой комнате, синхронные страницы, передача управления и спокойный световой индикатор активного говорящего. Зал ожидания, модераторы, чат комнаты и оптимизированный WebRTC сохранены.");gap(content,20);note(content,"Текст и медиа шифруются на телефоне AES-GCM. WebRTC-звонки защищены DTLS-SRTP. Для надёжной связи в некоторых мобильных и корпоративных сетях позже понадобится TURN-сервер.");gap(content,24);
        Button exit=button(api.signedIn()?"Выйти из аккаунта":"К началу");content.addView(exit,new LinearLayout.LayoutParams(-1,dp(50)));exit.setOnClickListener(v->{if(api.signedIn()){exit.setEnabled(false);worker.execute(()->{try{api.logout();}catch(Exception ignored){}handler.post(()->{NotificationService.stop(this);chats=new JSONArray();showWelcome();});});}else showWelcome();});
    }
    private void showSecurity(){
        begin("security");toolbar("Конфиденциальность",true,null,null);scrollContent();
        note(content,"Проверяем защиту аккаунта…");
        async(()->new JSONObject().put("factors",api.factors()).put("owner",api.rpc("mw_owner_status",new JSONObject())), result->{
            JSONObject data=(JSONObject)result;JSONArray factors=data.getJSONArray("factors");JSONObject owner=data.getJSONObject("owner");content.removeAllViews();
            note(content,owner.optBoolean("is_owner")?"Ваш аккаунт закреплён как единственный владелец Muwahid. Панель владельца открывается только после проверки второго фактора.":"Код из приложения-аутентификатора защищает вход в переписку после подключения второго фактора.");gap(content,18);
            boolean verified=false;
            for(int i=0;i<factors.length();i++){JSONObject f=factors.getJSONObject(i);if("verified".equals(f.optString("status"))&&"totp".equals(f.optString("factor_type"))){verified=true;final String id=f.getString("id");Button confirm=button("Подтвердить кодом аутентификатора");content.addView(confirm,new LinearLayout.LayoutParams(-1,dp(58)));confirm.setOnClickListener(v->showTotpCode(id,null));gap(content,12);}}
            if(!verified){note(content,"Второй фактор ещё не включён. Добавьте ключ в приложение-аутентификатор на своём телефоне, сохраните резервную копию ключа в надёжном месте и подтвердите первый код. Если потерять аутентификатор и резервную копию, доступ придётся восстанавливать через службу поддержки.");gap(content,18);Button enable=button("Подключить второй фактор");content.addView(enable,new LinearLayout.LayoutParams(-1,dp(58)));enable.setOnClickListener(v->{enable.setEnabled(false);async(()->api.enrollTotp(),res->{JSONObject f=(JSONObject)res;showTotpCode(f.getString("id"),f.getJSONObject("totp"));});});}
            if(owner.optBoolean("owner_access")){gap(content,22);Button dashboard=button("Открыть панель владельца");content.addView(dashboard,new LinearLayout.LayoutParams(-1,dp(54)));dashboard.setOnClickListener(v->showOwner());}
            gap(content,20);Button retry=button("Обновить состояние защиты");content.addView(retry,new LinearLayout.LayoutParams(-1,dp(54)));retry.setOnClickListener(v->showSecurity());
        });
    }
    private void showTotpCode(String factor,JSONObject totp){
        begin("mfa");getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);toolbar("Второй фактор",true,null,null);scrollContent();
        if(totp!=null){note(content,"Добавьте этот секретный ключ в аутентификатор: тип — по времени (TOTP), название — Muwahid. Не отправляйте ключ или коды в чат. Сохраните резервную копию ключа у себя.");gap(content,14);TextView key=label(totp.optString("secret"),18,text);key.setTextIsSelectable(true);content.addView(key);gap(content,14);
            Button open=button("Открыть аутентификатор");content.addView(open,new LinearLayout.LayoutParams(-1,dp(54)));open.setOnClickListener(v->{try{android.net.Uri uri=android.net.Uri.parse(totp.optString("uri"));if(!"otpauth".equals(uri.getScheme()))throw new Exception();startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){notice("Откройте свой аутентификатор и добавьте показанный ключ вручную.");}});gap(content,20);
        }else note(content,"Введите текущий шестизначный код из аутентификатора для Muwahid.");
        EditText code=field("Код из 6 цифр",true);code.setInputType(18);code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});code.setSaveEnabled(false);
        Button verify=button("Подтвердить");content.addView(verify,new LinearLayout.LayoutParams(-1,dp(54)));verify.setOnClickListener(v->{String value=code.getText().toString().trim();if(!value.matches("[0-9]{6}")){code.setError("Нужны 6 цифр");return;}verify.setEnabled(false);final int stamp=generation;worker.execute(()->{try{api.verifyTotp(factor,value);handler.post(()->{if(stamp!=generation)return;code.setText("");showSecurity();notice("Второй фактор подтверждён.");});}catch(Exception ex){handler.post(()->{if(stamp!=generation)return;verify.setEnabled(true);code.setText("");error(ex);});}});});
    }
    private void showOwner(){begin("owner");toolbar("Панель владельца",true,null,null);scrollContent();note(content,"Проверяем доступ на сервере…");async(()->api.rpc("mw_owner_overview",new JSONObject()),result->{JSONObject stats=(JSONObject)result;content.removeAllViews();note(content,"Доступ владельца подтверждён вторым фактором.");gap(content,22);note(content,"Пользователей: "+stats.optLong("users")+"\nЛичных чатов: "+stats.optLong("chats")+"\nСообщений: "+stats.optLong("messages")+"\nОткрытых жалоб: "+stats.optLong("open_complaints"));gap(content,22);note(content,"Раздел владельца доступен только аккаунту, закреплённому на сервере, и только после второго фактора.");});}
    @Override public void onBackPressed(){
        if(screen.equals("mfa")||screen.equals("owner")){showSecurity();}
        else if(screen.equals("security")){showSettings();}
        else if(screen.equals("chat")){if(voiceRecording){cancelVoiceRecording(true);return;}if(sending){Toast.makeText(this,"Дождитесь отправки сообщения",Toast.LENGTH_SHORT).show();return;}showChats();}
        else if(screen.equals("account")||screen.equals("chat_settings")||screen.equals("notifications")||screen.equals("data_settings")||screen.equals("folders")||screen.equals("devices")||screen.equals("energy")||screen.equals("language")||screen.equals("premium")||screen.equals("business")||screen.equals("gift"))showSettings();
        else if(screen.equals("settings")||screen.equals("menu")||screen.equals("calls")||screen.equals("contacts")||screen.equals("voice_rooms")||screen.equals("admins"))showChats();
        else if(screen.equals("community"))showHub(mainTab);
        else if(screen.equals("otp"))showAuth(phoneRegisterMode);
        else if(screen.equals("auth"))showWelcome();
        else if(screen.equals("chats")||screen.equals("welcome")){
            // Exit the Activity without logging out. The encrypted Supabase session stays
            // on the device, so the next launch opens chats directly.
            finish();
        }else super.onBackPressed();
    }
    private final class ChatWallpaperDrawable extends Drawable {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        @Override public void draw(Canvas c){Rect b=getBounds();c.drawColor(Color.parseColor("#061321"));paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(Color.argb(18,73,157,190));int step=dp(76);for(int y=dp(18);y<b.bottom;y+=step){for(int x=((y/step)%2==0?dp(16):dp(52));x<b.right;x+=step){c.drawCircle(x,y,dp(14),paint);c.drawLine(x-dp(7),y,x+dp(7),y,paint);c.drawCircle(x+dp(20),y+dp(22),dp(8),paint);}}paint.setStyle(Paint.Style.FILL);}
        @Override public void setAlpha(int a){}@Override public void setColorFilter(android.graphics.ColorFilter f){}@Override public int getOpacity(){return android.graphics.PixelFormat.OPAQUE;}
    }
    private final class WaveformView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private final boolean mine;private final int[] bars={5,9,14,8,18,12,7,16,20,10,6,15,11,18,8,13,19,7,12,16,9,5,14,10,17,8,13,6,11,15};
        WaveformView(Context c,boolean mine){super(c);this.mine=mine;}
        @Override protected void onDraw(Canvas c){super.onDraw(c);paint.setColor(mine?Color.argb(185,230,255,249):Color.parseColor("#66DCC8"));paint.setStrokeWidth(dp(2));paint.setStrokeCap(Paint.Cap.ROUND);float gap=getWidth()/(float)bars.length;float cy=getHeight()/2f;for(int i=0;i<bars.length;i++){float h=dp(bars[i])*.55f;float x=i*gap+gap/2;c.drawLine(x,cy-h/2,x,cy+h/2,paint);}}
    }
    private final class Logo extends View {
        private final boolean landscape;
        private final Paint p=new Paint(3);
        Logo(Context c,boolean landscape){super(c);this.landscape=landscape;setContentDescription("Логотип Muwahid");}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight();
            if(landscape){p.setShader(new LinearGradient(0,0,w,h,new int[]{Color.rgb(8,17,38),Color.rgb(7,75,102),Color.rgb(6,33,46)},null,Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h,p);p.setShader(null);
                mountain(canvas,w,h,.70f,Color.rgb(26,92,119));mountain(canvas,w,h,.79f,Color.rgb(17,60,84));mountain(canvas,w,h,.89f,Color.rgb(9,32,52));
                float size=Math.min(w*.30f,h*.25f);logo(canvas,(w-size)/2,h*.22f,size);
                p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextSize(dp(40));p.setTextAlign(Paint.Align.CENTER);canvas.drawText("Muwahid",w/2,h*.22f+size+dp(54),p);p.setTypeface(Typeface.create("sans-serif",0));p.setTextSize(dp(16));p.setColor(Color.rgb(177,221,233));canvas.drawText("Ближе друг к другу",w/2,h*.22f+size+dp(86),p);
            }else{float size=Math.min(w,h)*.86f;logo(canvas,(w-size)/2,(h-size)/2,size);}
        }
        private void mountain(Canvas c,float w,float h,float level,int color){p.setColor(color);Path path=new Path();path.moveTo(0,h);path.lineTo(0,h*level);path.lineTo(w*.18f,h*(level-.05f));path.lineTo(w*.42f,h*(level-.25f));path.lineTo(w*.53f,h*(level-.13f));path.lineTo(w*.64f,h*(level-.18f));path.lineTo(w*.88f,h*(level-.02f));path.lineTo(w,h*(level-.08f));path.lineTo(w,h);path.close();c.drawPath(path,p);}
        private void logo(Canvas c,float x,float y,float s){c.save();c.translate(x,y);c.scale(s/100,s/100);p.setShader(new LinearGradient(0,15,95,80,new int[]{accent,cyan},null,Shader.TileMode.CLAMP));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(18);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);Path m=new Path();m.moveTo(15,85);m.lineTo(15,18);m.lineTo(50,48);m.lineTo(85,18);m.lineTo(85,85);c.drawPath(m,p);p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);Path plane=new Path();plane.moveTo(45,65);plane.lineTo(95,44);plane.lineTo(79,94);plane.lineTo(68,77);plane.lineTo(85,55);plane.lineTo(60,72);plane.close();c.drawPath(plane,p);c.restore();}
    }
}
