#!/usr/bin/env bash
set -euo pipefail
grep -Fq "versionCode 23" app/build.gradle
grep -Fq "versionName '0.11.1'" app/build.gradle
grep -Fq 'android:name=".VoiceRoomActivity"' app/src/main/AndroidManifest.xml
grep -Fq 'private void showVoiceRooms()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'private void showAdminManagement()' app/src/main/java/com/muwahid/app/MainActivity.java
grep -Fq 'mw_room_raise_hand' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_kick' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_mic_set_self' app/src/main/assets/voice_room.html
grep -Fq 'mw_room_mic_moderate' app/src/main/assets/voice_room.html
grep -Fq 'create or replace function public.mw_owner_admin_set' backend/012_voice_rooms_admins.sql
grep -Fq 'create or replace function public.mw_room_create' backend/012_voice_rooms_admins.sql
grep -Fq 'create or replace function public.mw_room_mic_set_self' backend/013_multi_microphones.sql
grep -Fq 'create or replace function public.mw_room_mic_moderate' backend/013_multi_microphones.sql
grep -Fq 'create or replace function public.mw_room_signal_poll' backend/015_voice_room_performance.sql
grep -Fq 'p_user=' backend/012_voice_rooms_admins.sql
grep -Fq 'Владелец не может быть удалён или заблокирован' backend/012_voice_rooms_admins.sql
echo 'MW_SOURCE_OK 0.11.1'
