# Muwahid 0.13.24 — WhatsApp-style chats + LIVE

Visual contract for this build:

- Main screen is a single WhatsApp-style chat list.
- No top category tabs: no All / Private / Groups / Channels tabs.
- Header contains Muwahid, Search, and New chat only.
- Bottom navigation is Chats / Calls / LIVE / Contacts / Settings.
- LIVE is the large central action.
- LIVE opens one Create broadcast sheet with Audio/Video, participant count, access, title, and Start broadcast.
- Active LIVE keeps the participant grid and five bottom controls as the primary surface. Extra tools stay behind the overflow menu.
- Existing messenger network/API, calls, contacts, E2EE, privacy and backend behavior are preserved.
- The LIVE SQL migration uses v_room_mode and qualified r.room_mode references to avoid the prior PL/pgSQL ambiguous-column failure in mw_room_join / mw_room_state.
