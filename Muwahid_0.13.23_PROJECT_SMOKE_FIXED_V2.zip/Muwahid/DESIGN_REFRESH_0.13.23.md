# Muwahid 0.13.23 — live UI refresh, stage 1

This stage keeps the existing messenger logic and server contracts while replacing the most visible chat UI with the approved modern reference direction.

Implemented:
- adaptive light/dark chat list palette;
- branded Muwahid toolbar with modern search and navigation chips;
- cleaner chat rows, unread emphasis, online indicator and refined avatars;
- updated bottom navigation and floating compose button;
- modern personal-chat header, composer and message bubbles;
- native Android Unicode emoji grid with a direct route to stickers;
- existing swipe, long-press, chat, attachment, call and sticker actions preserved.

Release policy:
- this is a design implementation stage, not a Google Play release;
- this package is prepared as 0.13.23 / versionCode 57 for device delivery and updater testing;
- Google Play publication remains intentionally out of scope until visual and functional verification is complete.
