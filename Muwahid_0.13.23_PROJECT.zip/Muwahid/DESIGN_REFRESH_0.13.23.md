# Muwahid 0.13.23 — reference UI refresh

This revision keeps the existing Muwahid 0.13.23 product logic and server contracts. It does **not** create a new app version.

Visual direction applied from the approved reference:
- light blue/white messenger palette by default;
- modern vector icons and compact bottom navigation: Chats, Calls, Contacts, Settings;
- modern search/filter chips and refined chat list spacing;
- green outgoing and white incoming message bubbles with native Android emoji;
- adaptive light styling for the voice-room shortcut and attachment sheet;
- incoming-call screen with Message / Decline / Accept actions;
- full-screen video-call presentation with a compact bottom control bar;
- subtle modern surfaces, borders, elevation and rounded corners.

Preserved without removal:
- real chats and E2EE message flow;
- voice messages, media, stickers and custom emoji;
- audio/video WebRTC calls;
- voice rooms with 8 microphone seats, listeners, hand raising and moderation;
- room chat, local music, soundboard, recording, effects/EQ and shared PDF reading;
- groups, channels, profiles, privacy/security controls and Supabase integration.

Build identity remains:
- versionName: 0.13.23
- versionCode: 57

This package is a UI refresh of the existing 0.13.23 source, not a 0.13.24 branch.
