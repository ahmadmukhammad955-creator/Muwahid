package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public final class UnlockActivity extends Activity {
    @Override public void onCreate(Bundle b){
        super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        TextView text=new TextView(this);text.setText("Muwahid\nПодтвердите код блокировки телефона");text.setTextColor(Color.WHITE);text.setBackgroundColor(Color.rgb(23,33,43));text.setGravity(Gravity.CENTER);text.setTextSize(20);setContentView(text);
        if(b==null){KeyguardManager k=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);Intent confirm=k.createConfirmDeviceCredentialIntent("Muwahid","Разблокируйте приложение");
            if(confirm==null){new AlertDialog.Builder(this).setMessage("Для входа восстановите блокировку экрана в настройках Android.").setPositiveButton("Закрыть",(d,w)->finish()).setCancelable(false).show();}
            else startActivityForResult(confirm,1);
        }
    }
    @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(r!=1)return;
        if(result==RESULT_OK){AppLock.unlock();Intent next=getIntent().getParcelableExtra("next");
            if(next!=null && next.getComponent()!=null && getPackageName().equals(next.getComponent().getPackageName())){next.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(next);}else startActivity(new Intent(this,MainActivity.class));}
        finish();
    }
}
