begin;

-- Muwahid 0.11.0: per-room moderators, waiting room and room chat/media.

create table if not exists public.mw_voice_room_moderators (
  room_id uuid not null references public.mw_voice_rooms(id) on delete cascade,
  user_id uuid not null references public.mw_profiles(id) on delete cascade,
  granted_by uuid not null references public.mw_profiles(id) on delete cascade,
  granted_at timestamptz not null default now(),
  primary key(room_id,user_id)
);

create table if not exists public.mw_voice_room_waiting (
  room_id uuid not null references public.mw_voice_rooms(id) on delete cascade,
  user_id uuid not null references public.mw_profiles(id) on delete cascade,
  requested_at timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  primary key(room_id,user_id)
);
create index if not exists mw_voice_room_waiting_order_idx on public.mw_voice_room_waiting(room_id,requested_at);

create table if not exists public.mw_voice_room_messages (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.mw_voice_rooms(id) on delete cascade,
  sender_id uuid not null references public.mw_profiles(id) on delete cascade,
  kind text not null default 'text' check(kind in ('text','image','video','file')),
  body text not null default '',
  media jsonb,
  created_at timestamptz not null default now(),
  check(char_length(body) <= 4000)
);
create index if not exists mw_voice_room_messages_room_idx on public.mw_voice_room_messages(room_id,id);

alter table public.mw_voice_room_moderators enable row level security;
alter table public.mw_voice_room_waiting enable row level security;
alter table public.mw_voice_room_messages enable row level security;
revoke all on public.mw_voice_room_moderators, public.mw_voice_room_waiting, public.mw_voice_room_messages from public,anon,authenticated;
revoke all on sequence public.mw_voice_room_messages_id_seq from public,anon,authenticated;

create or replace function mw_private.room_rank(p_user uuid,p_room uuid)
returns integer
language sql
stable
security definer
set search_path=''
as $$
  select case
    when p_user='025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then 40
    when exists(select 1 from public.mw_voice_rooms r where r.id=p_room and r.created_by=p_user) then 30
    when exists(select 1 from public.mw_voice_room_moderators m where m.room_id=p_room and m.user_id=p_user) then 20
    else 0
  end
$$;
revoke all on function mw_private.room_rank(uuid,uuid) from public,anon,authenticated;

create or replace function mw_private.room_can_moderate(p_room uuid,p_user uuid)
returns boolean
language sql
stable
security definer
set search_path=''
as $$ select mw_private.room_rank(p_user,p_room) >= 20 $$;
revoke all on function mw_private.room_can_moderate(uuid,uuid) from public,anon,authenticated;

create or replace function mw_private.room_cleanup(p_room uuid)
returns void
language plpgsql
security definer
set search_path=''
as $$
begin
  delete from public.mw_voice_room_members m
  where m.room_id=p_room and m.last_seen < now()-interval '90 seconds';
  delete from public.mw_voice_room_waiting w
  where w.room_id=p_room and w.last_seen < now()-interval '90 seconds';
  delete from public.mw_voice_room_hands h
  where h.room_id=p_room and not exists(
    select 1 from public.mw_voice_room_members m where m.room_id=h.room_id and m.user_id=h.user_id
  );
  delete from public.mw_voice_room_signals s where s.created_at < now()-interval '10 minutes';
end
$$;
revoke all on function mw_private.room_cleanup(uuid) from public,anon,authenticated;

create or replace function public.mw_room_join(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare s integer; room_title text; pos integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  perform mw_private.room_cleanup(p_room);
  select title into room_title from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта или не существует'; end if;
  if exists(select 1 from public.mw_voice_room_bans where room_id=p_room and user_id=auth.uid()) then raise exception 'MW:Вы заблокированы в этой комнате'; end if;

  update public.mw_voice_room_members set last_seen=now() where room_id=p_room and user_id=auth.uid();
  if found then
    delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
    return jsonb_build_object('room_id',p_room,'title',room_title,'status','seated');
  end if;

  select g into s from generate_series(1,8) g
  where not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=g)
  order by g limit 1;
  if s is not null then
    delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
    insert into public.mw_voice_room_members(room_id,user_id,seat) values(p_room,auth.uid(),s);
    return jsonb_build_object('room_id',p_room,'title',room_title,'status','seated','seat',s);
  end if;

  insert into public.mw_voice_room_waiting(room_id,user_id)
  values(p_room,auth.uid())
  on conflict(room_id,user_id) do update set last_seen=now();
  select 1+count(*) into pos from public.mw_voice_room_waiting w
  where w.room_id=p_room and w.requested_at < (select requested_at from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid());
  return jsonb_build_object('room_id',p_room,'title',room_title,'status','waiting','position',pos);
end
$$;

create or replace function public.mw_room_leave(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  delete from public.mw_voice_room_hands where room_id=p_room and user_id=auth.uid();
  delete from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid();
  delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
  delete from public.mw_voice_room_signals where room_id=p_room and (from_user=auth.uid() or to_user=auth.uid());
  return jsonb_build_object('ok',true);
end
$$;

create or replace function public.mw_room_state(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb; my_rank integer; can_mod boolean; room_title text; room_creator uuid; wait_pos integer; waiting_count integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  perform mw_private.room_cleanup(p_room);
  select title,created_by into room_title,room_creator from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта'; end if;

  update public.mw_voice_room_members set last_seen=now() where room_id=p_room and user_id=auth.uid();
  if not found then
    update public.mw_voice_room_waiting set last_seen=now() where room_id=p_room and user_id=auth.uid();
    if not found then raise exception 'MW:Вы больше не участник комнаты'; end if;
    select 1+count(*) into wait_pos from public.mw_voice_room_waiting w
      where w.room_id=p_room and w.requested_at < (select requested_at from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid());
    select count(*) into waiting_count from public.mw_voice_room_waiting where room_id=p_room;
    return jsonb_build_object('id',p_room,'title',room_title,'self_id',auth.uid(),'waiting',true,
      'waiting_position',wait_pos,'waiting_count',waiting_count,'members','[]'::jsonb,'can_moderate',false,'role','waiting');
  end if;

  my_rank:=mw_private.room_rank(auth.uid(),p_room); can_mod:=my_rank>=20;
  select count(*) into waiting_count from public.mw_voice_room_waiting where room_id=p_room;
  select jsonb_build_object(
    'id',p_room,'title',room_title,'self_id',auth.uid(),'created_by',room_creator,'waiting',false,'waiting_count',waiting_count,
    'role',case when my_rank=40 then 'owner' when my_rank=30 then 'host' when my_rank=20 then 'moderator' else 'user' end,
    'can_moderate',can_mod,
    'can_assign_moderator',my_rank>=30,
    'members',coalesce((select jsonb_agg(jsonb_build_object(
      'id',p.id,'display_name',p.display_name,'username',p.username,'seat',m.seat,
      'mic_allowed',m.mic_allowed,'mic_enabled',m.mic_enabled,
      'hand_raised',exists(select 1 from public.mw_voice_room_hands h where h.room_id=m.room_id and h.user_id=m.user_id),
      'role',case when mw_private.room_rank(p.id,p_room)=40 then 'owner' when mw_private.room_rank(p.id,p_room)=30 then 'host' when mw_private.room_rank(p.id,p_room)=20 then 'moderator' else 'user' end
    ) order by m.seat)
    from public.mw_voice_room_members m join public.mw_profiles p on p.id=m.user_id where m.room_id=p_room),'[]'::jsonb),
    'waiting_users',case when can_mod then coalesce((select jsonb_agg(jsonb_build_object(
      'id',p.id,'display_name',p.display_name,'username',p.username,'requested_at',w.requested_at
    ) order by w.requested_at)
    from public.mw_voice_room_waiting w join public.mw_profiles p on p.id=w.user_id where w.room_id=p_room),'[]'::jsonb) else '[]'::jsonb end
  ) into result;
  return result;
end
$$;

create or replace function public.mw_room_moderator_set(p_room uuid,p_user uuid,p_enabled boolean)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare caller_rank integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  caller_rank:=mw_private.room_rank(auth.uid(),p_room);
  if caller_rank<30 then raise exception 'MW:Назначать модераторов может только владелец комнаты или владелец Muwahid'; end if;
  if p_user=auth.uid() then raise exception 'MW:Эта роль уже выше роли модератора'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_user) then raise exception 'MW:Пользователь должен находиться в комнате'; end if;
  if mw_private.room_rank(p_user,p_room)>=30 then raise exception 'MW:Нельзя изменить роль владельца комнаты'; end if;
  if p_enabled then
    insert into public.mw_voice_room_moderators(room_id,user_id,granted_by)
    values(p_room,p_user,auth.uid()) on conflict(room_id,user_id) do update set granted_by=excluded.granted_by,granted_at=now();
  else
    delete from public.mw_voice_room_moderators where room_id=p_room and user_id=p_user;
  end if;
  return jsonb_build_object('user_id',p_user,'is_moderator',p_enabled);
end
$$;

create or replace function public.mw_room_admit(p_room uuid,p_user uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare s integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if not mw_private.room_can_moderate(p_room,auth.uid()) then raise exception 'MW:Нет прав модератора'; end if;
  if not exists(select 1 from public.mw_voice_room_waiting where room_id=p_room and user_id=p_user) then raise exception 'MW:Пользователь уже не находится в зале ожидания'; end if;
  select g into s from generate_series(1,8) g where not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=g) order by g limit 1;
  if s is null then raise exception 'MW:Все 8 мест заняты'; end if;
  delete from public.mw_voice_room_waiting where room_id=p_room and user_id=p_user;
  insert into public.mw_voice_room_members(room_id,user_id,seat) values(p_room,p_user,s)
  on conflict(room_id,user_id) do update set seat=excluded.seat,last_seen=now();
  return jsonb_build_object('user_id',p_user,'seat',s);
end
$$;

create or replace function public.mw_room_kick(p_room uuid,p_user uuid,p_ban boolean default false)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare caller_rank integer; target_rank integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  caller_rank:=mw_private.room_rank(auth.uid(),p_room); target_rank:=mw_private.room_rank(p_user,p_room);
  if caller_rank<20 then raise exception 'MW:Нет прав модератора'; end if;
  if p_user='025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid and auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then raise exception 'MW:Нельзя удалить владельца Muwahid'; end if;
  if caller_rank<=target_rank and auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then raise exception 'MW:Нельзя управлять участником с равной или более высокой ролью'; end if;
  delete from public.mw_voice_room_hands where room_id=p_room and user_id=p_user;
  delete from public.mw_voice_room_members where room_id=p_room and user_id=p_user;
  delete from public.mw_voice_room_waiting where room_id=p_room and user_id=p_user;
  delete from public.mw_voice_room_moderators where room_id=p_room and user_id=p_user;
  delete from public.mw_voice_room_signals where room_id=p_room and (from_user=p_user or to_user=p_user);
  if p_ban then insert into public.mw_voice_room_bans(room_id,user_id,banned_by) values(p_room,p_user,auth.uid()) on conflict(room_id,user_id) do update set banned_by=excluded.banned_by,created_at=now(); end if;
  return jsonb_build_object('ok',true,'banned',p_ban);
end
$$;

create or replace function public.mw_room_mic_moderate(p_room uuid,p_user uuid,p_allowed boolean)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare caller_rank integer; target_rank integer;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  caller_rank:=mw_private.room_rank(auth.uid(),p_room); target_rank:=mw_private.room_rank(p_user,p_room);
  if caller_rank<20 then raise exception 'MW:Нет прав модератора'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_user) then raise exception 'MW:Участник уже вышел'; end if;
  if p_user='025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid and auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then raise exception 'MW:Микрофоном владельца управляет только владелец'; end if;
  if caller_rank<=target_rank and auth.uid()<>'025a8bd0-c7ff-4e39-802a-f1c39ab76a9c'::uuid then raise exception 'MW:Нельзя управлять микрофоном участника с равной или более высокой ролью'; end if;
  update public.mw_voice_room_members set mic_allowed=p_allowed,mic_enabled=case when p_allowed then mic_enabled else false end,mic_updated_at=now() where room_id=p_room and user_id=p_user;
  return jsonb_build_object('user_id',p_user,'mic_allowed',p_allowed);
end
$$;

create or replace function public.mw_room_message_send(p_room uuid,p_kind text,p_body text default '',p_media jsonb default null)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare mid bigint; result jsonb;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) then raise exception 'MW:Сообщения доступны участникам комнаты'; end if;
  if p_kind not in ('text','image','video','file') then raise exception 'MW:Некорректный тип сообщения'; end if;
  if p_kind='text' and char_length(btrim(coalesce(p_body,''))) not between 1 and 4000 then raise exception 'MW:Введите сообщение'; end if;
  if p_kind<>'text' and (p_media is null or jsonb_typeof(p_media)<>'object') then raise exception 'MW:Нет данных файла'; end if;
  insert into public.mw_voice_room_messages(room_id,sender_id,kind,body,media)
  values(p_room,auth.uid(),p_kind,left(coalesce(p_body,''),4000),p_media) returning id into mid;
  select jsonb_build_object('id',m.id,'kind',m.kind,'body',m.body,'media',m.media,'created_at',m.created_at,'sender_id',m.sender_id,'sender_name',p.display_name)
  into result from public.mw_voice_room_messages m join public.mw_profiles p on p.id=m.sender_id where m.id=mid;
  return result;
end
$$;

create or replace function public.mw_room_messages_get(p_room uuid,p_after bigint default 0)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) then raise exception 'MW:Чат доступен участникам комнаты'; end if;
  if coalesce(p_after,0)=0 then
    select coalesce(jsonb_agg(to_jsonb(x) order by x.id),'[]'::jsonb) into result from (
      select * from (
        select m.id,m.kind,m.body,m.media,m.created_at,m.sender_id,p.display_name as sender_name
        from public.mw_voice_room_messages m join public.mw_profiles p on p.id=m.sender_id
        where m.room_id=p_room order by m.id desc limit 50
      ) q order by q.id
    ) x;
  else
    select coalesce(jsonb_agg(to_jsonb(x) order by x.id),'[]'::jsonb) into result from (
      select m.id,m.kind,m.body,m.media,m.created_at,m.sender_id,p.display_name as sender_name
      from public.mw_voice_room_messages m join public.mw_profiles p on p.id=m.sender_id
      where m.room_id=p_room and m.id>p_after order by m.id asc limit 100
    ) x;
  end if;
  return result;
end
$$;

-- Private media bucket for room chat.
insert into storage.buckets(id,name,public,file_size_limit)
values('mw-room-media','mw-room-media',false,26214400)
on conflict(id) do update set public=false,file_size_limit=26214400;

drop policy if exists mw_room_media_select on storage.objects;
drop policy if exists mw_room_media_insert on storage.objects;
drop policy if exists mw_room_media_delete on storage.objects;
create policy mw_room_media_select on storage.objects for select to authenticated
using (
  bucket_id='mw-room-media' and exists(
    select 1 from public.mw_voice_room_members m
    where m.room_id=((storage.foldername(name))[1])::uuid and m.user_id=(select auth.uid())
  )
);
create policy mw_room_media_insert on storage.objects for insert to authenticated
with check (
  bucket_id='mw-room-media' and exists(
    select 1 from public.mw_voice_room_members m
    where m.room_id=((storage.foldername(name))[1])::uuid and m.user_id=(select auth.uid())
  )
);
create policy mw_room_media_delete on storage.objects for delete to authenticated
using (bucket_id='mw-room-media' and owner_id=(select auth.uid()::text));

revoke all on function public.mw_room_join(uuid), public.mw_room_leave(uuid), public.mw_room_state(uuid),
  public.mw_room_moderator_set(uuid,uuid,boolean), public.mw_room_admit(uuid,uuid),
  public.mw_room_kick(uuid,uuid,boolean), public.mw_room_mic_moderate(uuid,uuid,boolean),
  public.mw_room_message_send(uuid,text,text,jsonb), public.mw_room_messages_get(uuid,bigint)
from public,anon,authenticated;
grant execute on function public.mw_room_join(uuid), public.mw_room_leave(uuid), public.mw_room_state(uuid),
  public.mw_room_moderator_set(uuid,uuid,boolean), public.mw_room_admit(uuid,uuid),
  public.mw_room_kick(uuid,uuid,boolean), public.mw_room_mic_moderate(uuid,uuid,boolean),
  public.mw_room_message_send(uuid,text,text,jsonb), public.mw_room_messages_get(uuid,bigint)
to authenticated;

commit;
