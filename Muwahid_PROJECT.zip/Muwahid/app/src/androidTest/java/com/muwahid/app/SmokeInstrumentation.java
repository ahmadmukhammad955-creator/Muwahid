package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.graphics.Bitmap;
import java.io.*;

public class SmokeInstrumentation extends Instrumentation {
    private Activity activity;

    @Override public void onCreate(Bundle args) {
        super.onCreate(args);
        start();
    }

    private View findText(View view, String text) {
        if (view instanceof TextView && text.equals(((TextView) view).getText().toString())) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                View found = findText(group.getChildAt(i), text);
                if (found != null) return found;
            }
        }
        return null;
    }

    private EditText findComposer(View view) {
        if (view instanceof EditText && "Сообщение".contentEquals(((EditText) view).getHint())) return (EditText) view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                EditText found = findComposer(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    private void invoke(String method, Class<?>[] types, Object... args) {
        try {
            java.lang.reflect.Method m = MainActivity.class.getDeclaredMethod(method, types);
            m.setAccessible(true);
            m.invoke(activity, args);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Activity launch() {
        Intent intent = new Intent(getTargetContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return startActivitySync(intent);
    }

    private void capture(String name) throws Exception {
        waitForIdleSync();
        Bitmap bitmap = getUiAutomation().takeScreenshot();
        if (bitmap == null) return;
        File file = new File(getTargetContext().getExternalFilesDir(null), name);
        try (FileOutputStream out = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
        } finally {
            bitmap.recycle();
        }
    }

    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            getTargetContext().getSharedPreferences("muwahid", 0).edit().clear().commit();
            try { new SecureStore(getTargetContext()).clear(); } catch (Throwable ignored) {}

            activity = launch();
            waitForIdleSync();

            if (!"0.12.3".equals(BuildConfig.VERSION_NAME)) {
                throw new AssertionError("Wrong version " + BuildConfig.VERSION_NAME);
            }
            capture("welcome.png");

            runOnMainSync(() -> invoke("showChats", new Class<?>[]{}));
            waitForIdleSync();
            runOnMainSync(() -> {
                View decor = activity.getWindow().getDecorView();
                if (findText(decor, "Muwahid") == null) throw new AssertionError("Missing Muwahid title");
                if (findText(decor, "Чаты") == null) throw new AssertionError("Missing chats tab");
                if (findText(decor, "Группы") == null) throw new AssertionError("Missing groups tab");
                if (findText(decor, "Каналы") == null) throw new AssertionError("Missing channels tab");
                if (findText(decor, "Звонки") == null) throw new AssertionError("Missing calls navigation");
                if (findText(decor, "Контакты") == null) throw new AssertionError("Missing contacts navigation");
                if (findText(decor, "Настройки") == null) throw new AssertionError("Missing settings navigation");
            });
            capture("main_chat_screen.png");

            runOnMainSync(() -> invoke("openConversation", new Class<?>[]{String.class, String.class}, "smoke-chat", "Алибек"));
            waitForIdleSync();
            runOnMainSync(() -> {
                View decor = activity.getWindow().getDecorView();
                if (findText(decor, "Алибек") == null) throw new AssertionError("Missing chat title");
                if (findComposer(decor) == null) throw new AssertionError("Missing message composer");
            });
            capture("chat_screen.png");

            runOnMainSync(() -> activity.finish());
            waitForIdleSync();

            result.putString("stream", "MW_SMOKE_OK: 0.12.3 launch, main chat list and personal chat UI");
            finish(Activity.RESULT_OK, result);
        } catch (Throwable e) {
            result.putString("stream", "MW_SMOKE_FAILED: " + e.getClass().getName() + ": " + String.valueOf(e.getMessage()));
            finish(Activity.RESULT_CANCELED, result);
        }
    }
}
