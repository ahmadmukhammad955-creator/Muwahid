# Muwahid 0.5.0

Android prototype of the Muwahid messenger.

## What works now

- Email/password registration and login through Supabase Auth.
- Direct 1-to-1 text chats through checked Supabase RPC functions.
- Local personal notes (Избранное).
- TOTP second factor and MFA-gated messaging/owner statistics from 0.4.
- **E2EE v1 for new direct text messages**:
  - each account has a P-256 ECDH identity key on the device;
  - the private key is encrypted at rest by an AES-GCM wrapping key held in Android Keystore;
  - a per-chat AES-256 key is derived with ECDH + HKDF-SHA256;
  - message bodies use AES-GCM with a fresh 96-bit nonce and the chat ID as authenticated context;
  - the server stores the `mw1:` ciphertext envelope, not the new message plaintext;
  - legacy plaintext messages remain readable;
  - if the peer has no E2EE key, plaintext downgrade is blocked.

## Required server migration for 0.5

The existing 0.4 server must already have `001_messenger.sql` through `006_verify_mfa.sql` applied.
Then run:

`backend/007_e2ee.sql`

This creates the public-key directory RPCs, keeps direct table access revoked, expands the encrypted message envelope limit, and hides ciphertext from chat-list previews.

## Security scope of E2EE v1

This is an important upgrade, but it is **not yet Signal-level cryptography**. Version 0.5 uses static per-device ECDH identity keys, so it does not yet provide a Double Ratchet / forward secrecy, multi-device key sync, recovery of old encrypted history after a lost/reinstalled device, or a user-facing safety-number verification flow. Those are separate hardening stages.

The Supabase project can still see account metadata, chat membership, message timing/size and ciphertext. It should not see the plaintext of new E2EE text messages when both clients are on 0.5 and their private device keys remain secret.

## Not implemented yet

Encrypted photo/video/file transfer, voice messages, audio/video calls, groups, channels and bots are not complete in this ZIP. Those should be added on top of the 0.5 key layer rather than sending media in plaintext.

## Build

The repository workflow extracts `Muwahid_Android_GitHub_APK.zip` and builds the debug APK with Gradle/Android SDK 35.
