-- Data repair applied and verified on 2026-10-05; inserts only missing countries.
with incoming(iso2,name_en,calling_code,flag) as (values ('AU','Australia','+61','🇦🇺'),
('CW','Curaçao','+599','🇨🇼'),
('FI','Finland','+358','🇫🇮'),
('GB','United Kingdom','+44','🇬🇧'),
('GP','Guadeloupe','+590','🇬🇵'),
('IT','Italy','+39','🇮🇹'),
('MA','Morocco','+212','🇲🇦'),
('NO','Norway','+47','🇳🇴'),
('RE','Réunion','+262','🇷🇪'),
('RU','Russia','+7','🇷🇺'),
('SH','St. Helena','+290','🇸🇭'),
('US','United States','+1','🇺🇸')), missing as (select i.* from incoming i where not exists(select 1 from public.mw_phone_countries c where c.iso2=i.iso2)) insert into public.mw_phone_countries(sort_order,iso2,name_en,calling_code,flag) select (select coalesce(max(sort_order),0) from public.mw_phone_countries) + row_number() over(order by iso2),iso2,name_en,calling_code,flag from missing on conflict (iso2) do nothing returning iso2,calling_code;
