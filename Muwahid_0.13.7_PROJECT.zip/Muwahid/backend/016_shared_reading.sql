-- Muwahid 0.12.0: shared PDF reading inside voice rooms.
-- Moderators/hosts can open a PDF, synchronise pages and hand control to another seated participant.

create table if not exists public.mw_voice_room_book_sessions (
  room_id uuid primary key references public.mw_voice_rooms(id) on delete cascade,
  controller_id uuid not null references public.mw_profiles(id) on delete cascade,
  storage_path text not null,
  file_name text not null,
  current_page integer not null default 0 check (current_page >= 0),
  total_pages integer not null check (total_pages between 1 and 5000),
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

alter table public.mw_voice_room_book_sessions enable row level security;
revoke all on public.mw_voice_room_book_sessions from public,anon,authenticated;

create or replace function mw_private.room_can_read_book(p_room uuid,p_path text)
returns boolean
language sql
stable
security definer
set search_path=''
as $$
  select auth.uid() is not null
     and exists(
       select 1 from public.mw_voice_room_members m
       where m.room_id=p_room and m.user_id=auth.uid()
     )
     and exists(
       select 1 from public.mw_voice_room_book_sessions b
       where b.room_id=p_room and b.active=true and b.storage_path=p_path
     )
$$;

create or replace function mw_private.room_can_upload_book(p_room uuid)
returns boolean
language sql
stable
security definer
set search_path=''
as $$
  select auth.uid() is not null
     and mw_private.room_rank(auth.uid(),p_room) >= 20
     and exists(
       select 1 from public.mw_voice_room_members m
       where m.room_id=p_room and m.user_id=auth.uid()
     )
$$;

revoke all on function mw_private.room_can_read_book(uuid,text), mw_private.room_can_upload_book(uuid)
from public,anon,authenticated;
grant usage on schema mw_private to authenticated;
grant execute on function mw_private.room_can_read_book(uuid,text), mw_private.room_can_upload_book(uuid)
to authenticated;

create or replace function public.mw_room_book_start(
  p_room uuid,
  p_path text,
  p_file_name text,
  p_total_pages integer
)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if not mw_private.room_can_upload_book(p_room) then
    raise exception 'MW:Только ведущий или модератор может открыть книгу';
  end if;
  if p_path is null or p_path !~ ('^' || p_room::text || '/books/[A-Za-z0-9._-]+$') then
    raise exception 'MW:Некорректный файл книги';
  end if;
  if p_total_pages is null or p_total_pages < 1 or p_total_pages > 5000 then
    raise exception 'MW:Некорректное количество страниц';
  end if;
  if char_length(coalesce(p_file_name,'')) < 1 or char_length(p_file_name) > 180 then
    raise exception 'MW:Некорректное название книги';
  end if;

  insert into public.mw_voice_room_book_sessions(
    room_id,controller_id,storage_path,file_name,current_page,total_pages,active,updated_at
  ) values(
    p_room,auth.uid(),p_path,p_file_name,0,p_total_pages,true,now()
  )
  on conflict(room_id) do update
    set controller_id=excluded.controller_id,
        storage_path=excluded.storage_path,
        file_name=excluded.file_name,
        current_page=0,
        total_pages=excluded.total_pages,
        active=true,
        updated_at=now();

  select jsonb_build_object(
    'active',b.active,'path',b.storage_path,'file_name',b.file_name,
    'page',b.current_page,'total_pages',b.total_pages,'controller_id',b.controller_id
  ) into result
  from public.mw_voice_room_book_sessions b
  where b.room_id=p_room;

  return result;
end $$;

create or replace function public.mw_room_book_page(p_room uuid,p_page integer)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare total integer; controller uuid;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  select total_pages,controller_id into total,controller
  from public.mw_voice_room_book_sessions
  where room_id=p_room and active=true;

  if total is null then raise exception 'MW:Книга сейчас не открыта'; end if;
  if auth.uid()<>controller and mw_private.room_rank(auth.uid(),p_room)<20 then
    raise exception 'MW:У вас нет управления книгой';
  end if;
  if p_page<0 or p_page>=total then raise exception 'MW:Такой страницы нет'; end if;

  update public.mw_voice_room_book_sessions
  set current_page=p_page,updated_at=now()
  where room_id=p_room;

  return jsonb_build_object('page',p_page,'total_pages',total);
end $$;

create or replace function public.mw_room_book_controller(p_room uuid,p_user uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if mw_private.room_rank(auth.uid(),p_room)<20 then
    raise exception 'MW:Только ведущий или модератор может передать управление';
  end if;
  if not exists(
    select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_user
  ) then raise exception 'MW:Участник уже не находится в комнате'; end if;
  if not exists(
    select 1 from public.mw_voice_room_book_sessions where room_id=p_room and active=true
  ) then raise exception 'MW:Книга сейчас не открыта'; end if;

  update public.mw_voice_room_book_sessions
  set controller_id=p_user,updated_at=now()
  where room_id=p_room;

  return jsonb_build_object('controller_id',p_user);
end $$;

create or replace function public.mw_room_book_stop(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare controller uuid;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  select controller_id into controller
  from public.mw_voice_room_book_sessions
  where room_id=p_room and active=true;
  if controller is null then return jsonb_build_object('ok',true); end if;
  if auth.uid()<>controller and mw_private.room_rank(auth.uid(),p_room)<20 then
    raise exception 'MW:У вас нет права закрыть книгу';
  end if;

  update public.mw_voice_room_book_sessions set active=false,updated_at=now() where room_id=p_room;
  return jsonb_build_object('ok',true);
end $$;

create or replace function public.mw_room_book_state(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if not exists(
    select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()
  ) then raise exception 'MW:Книга доступна только участникам комнаты'; end if;

  select jsonb_build_object(
    'active',b.active,'path',b.storage_path,'file_name',b.file_name,
    'page',b.current_page,'total_pages',b.total_pages,
    'controller_id',b.controller_id,'controller_name',p.display_name,'updated_at',b.updated_at
  ) into result
  from public.mw_voice_room_book_sessions b
  join public.mw_profiles p on p.id=b.controller_id
  where b.room_id=p_room and b.active=true;

  return coalesce(result,'{"active":false}'::jsonb);
end $$;

insert into storage.buckets(id,name,public,file_size_limit)
values('mw-room-books','mw-room-books',false,52428800)
on conflict(id) do update set public=false,file_size_limit=52428800;

drop policy if exists mw_room_books_select on storage.objects;
drop policy if exists mw_room_books_insert on storage.objects;
drop policy if exists mw_room_books_delete on storage.objects;

create policy mw_room_books_select
on storage.objects for select to authenticated
using (
  bucket_id='mw-room-books'
  and mw_private.room_can_read_book(((storage.foldername(name))[1])::uuid,name)
);

create policy mw_room_books_insert
on storage.objects for insert to authenticated
with check (
  bucket_id='mw-room-books'
  and mw_private.room_can_upload_book(((storage.foldername(name))[1])::uuid)
);

create policy mw_room_books_delete
on storage.objects for delete to authenticated
using (
  bucket_id='mw-room-books'
  and mw_private.room_can_upload_book(((storage.foldername(name))[1])::uuid)
);

revoke all on function
  public.mw_room_book_start(uuid,text,text,integer),
  public.mw_room_book_page(uuid,integer),
  public.mw_room_book_controller(uuid,uuid),
  public.mw_room_book_stop(uuid),
  public.mw_room_book_state(uuid)
from public,anon,authenticated;

grant execute on function
  public.mw_room_book_start(uuid,text,text,integer),
  public.mw_room_book_page(uuid,integer),
  public.mw_room_book_controller(uuid,uuid),
  public.mw_room_book_stop(uuid),
  public.mw_room_book_state(uuid)
to authenticated;
