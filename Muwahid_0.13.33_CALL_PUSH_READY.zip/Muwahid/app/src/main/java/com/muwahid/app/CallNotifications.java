package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import org.json.JSONObject;

/** Shared entry point for background RPC polling and FCM pushes. */
public final class CallNotifications {
    public static final String CHANNEL="muwahid_calls_v2";
    private CallNotifications(){}
    public static void ensureChannel(Context context){
        if(Build.VERSION.SDK_INT<26)return;
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        NotificationChannel channel=new NotificationChannel(CHANNEL,"Звонки",NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Входящие аудио- и видеозвонки");
        channel.setSound(null,null);channel.enableVibration(true);nm.createNotificationChannel(channel);
    }
    public static void showIncoming(Context context,JSONObject c){
        if(!context.getSharedPreferences("muwahid",Context.MODE_PRIVATE).getBoolean("notify_calls",true))return;
        String id=c.optString("id","");
        if(!id.matches("[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}"))return;
        ensureChannel(context);
        android.content.SharedPreferences p=context.getSharedPreferences("muwahid_notify",Context.MODE_PRIVATE);
        String name=c.optString("caller_name","Входящий звонок");
        String kind="video".equals(c.optString("kind"))?"Видеозвонок":"Аудиозвонок";
        Intent open=new Intent(context,CallActivity.class)
                .putExtra("call_id",id).putExtra("incoming",true)
                .putExtra("kind","video".equals(c.optString("kind"))?"video":"audio")
                .putExtra("peer_name",name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(context,id.hashCode(),open,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26
                ?new Notification.Builder(context,CHANNEL):new Notification.Builder(context);
        b.setSmallIcon(R.drawable.ic_launcher)
         .setContentTitle(AppLock.enabled(context)?"Muwahid":name)
         .setContentText("Входящий "+kind.toLowerCase(java.util.Locale.ROOT))
         .setVisibility(Notification.VISIBILITY_PRIVATE)
         .setCategory(Notification.CATEGORY_CALL)
         .setPriority(Notification.PRIORITY_MAX)
         .setAutoCancel(true).setOnlyAlertOnce(true)
         .setContentIntent(pi).setFullScreenIntent(pi,true);
        if(Build.VERSION.SDK_INT>=26)b.setTimeoutAfter(90000L);
        try{
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null)nm.notify(300000+Math.abs(id.hashCode()%50000),b.build());
            CallRingtone.start(context,id);
            // Expire the ringtone even if polling is suspended while backgrounded.
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->{
                if(CallRingtone.isFor(id)){
                    CallRingtone.stop();
                    if(nm!=null)nm.cancel(300000+Math.abs(id.hashCode()%50000));
                }
            },90000L);
            p.edit().putString("ringing_call_id",id).putString("last_call_notification",id).apply();
        }catch(SecurityException e){android.util.Log.w("MW-Push","Call notification permission denied",e);}
    }
}
