'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/voice_room.html','utf8');
const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const js=scripts.find(s=>s.includes('// LIVE themes are shared Supabase room state'));
assert(js,'missing LIVE script');
new vm.Script(js,{filename:'voice_room.js'});
const start=js.indexOf('// LIVE themes are shared Supabase room state');
const end=js.indexOf('function openRoomStatus()',start);
assert(start>0&&end>start,'missing room theme handlers');
const body=js.slice(start,end);
const log=[],els={};
function el(id){
  if(!els[id])els[id]={style:{setProperty:(k,v,imp)=>log.push([id,k,v,imp])},classList:{add:x=>log.push([id,'add',x]),toggle:()=>{}},pause(){log.push([id,'pause']);}};
  return els[id];
}
const sandbox={document:{body:el('body'),documentElement:el('root'),getElementById:el,querySelectorAll:()=>[]},stateData:{created_by:'u',self_id:'u',waiting:false,can_moderate:true},closed:false,S:{roomId:'room-123'},rpc:async(fn,args)=>{log.push(['RPC',fn,args]);if(fn==='mw_room_theme_set')return {theme:args.p_theme,updated_at:'v1'};return {theme:'emerald',updated_at:'v2'};},banner:t=>log.push(['banner',t]),setToolPanel:(t,s)=>log.push(['panel',t,s])};
vm.runInNewContext(body+'\nthis.api={ROOM_THEMES,setRoomTheme,openThemePanel,syncRoomTheme,applyRoomTheme};',sandbox);
(async()=>{
 for(const k of Object.keys(sandbox.api.ROOM_THEMES)){
   sandbox.api.applyRoomTheme(k);
   const layer=log.filter(x=>x[0]==='liveBackground'&&x[1]==='background').at(-1);
   assert(layer&&layer[2].startsWith('linear-gradient')&&layer[3]==='important',`theme ${k} was not applied`);
 }
 sandbox.api.openThemePanel();
 const panel=log.find(x=>x[0]==='panel');
 assert(panel&&Object.keys(sandbox.api.ROOM_THEMES).every(k=>panel[2].includes(`setRoomTheme('${k}')`)));
 assert(panel[1].includes('онлайн')&&panel[2].includes('Supabase'));
 await sandbox.api.setRoomTheme('ocean');
 assert(log.some(x=>x[0]==='RPC'&&x[1]==='mw_room_theme_set'&&x[2].p_theme==='ocean'));
 await sandbox.api.syncRoomTheme();
 assert(log.some(x=>x[0]==='RPC'&&x[1]==='mw_room_theme_get'));
 assert(log.filter(x=>x[0]==='liveBackground'&&x[1]==='background').at(-1)[2].includes('#137f70'));
 const count=log.filter(x=>x[0]==='RPC'&&x[1]==='mw_room_theme_set').length;
 sandbox.stateData.can_moderate=false;sandbox.stateData.created_by='other';
 await sandbox.api.setRoomTheme('sunset');
 assert(log.filter(x=>x[0]==='RPC'&&x[1]==='mw_room_theme_set').length===count,'non-host sent theme update');
 assert(html.includes('await syncRoomTheme();')&&html.includes('clearInterval(roomThemeSyncTimer)'));
 console.log('MW_LIVE_THEME_SYNC_OK: all six presets, server sync, permissions, cleanup');
})().catch(err=>{console.error(err);process.exit(1)});
