-- Muwahid security audit patch 2026-10-05
-- Re-applies MFA guards after later migrations and closes oversized-payload/privacy gaps.
begin;

alter default privileges in schema public revoke execute on functions from public;
alter default privileges in schema public revoke execute on functions from anon, authenticated;

create or replace function public.mw_find_person(p_username text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  perform mw_private.require_mfa();
  if char_length(btrim(coalesce(p_username,''))) not between 4 and 32 then
    raise exception 'MW:Некорректное имя пользователя';
  end if;
  select jsonb_build_object('id',p.id,'display_name',p.display_name,'username',p.username)
    into result
  from public.mw_profiles p
  where p.username=lower(btrim(p_username)) and p.id<>auth.uid();
  return result;
end $$;
revoke all on function public.mw_find_person(text) from public,anon,authenticated;
grant execute on function public.mw_find_person(text) to authenticated;

create or replace function public.mw_call_ice(p_call uuid,p_candidate jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare c public.mw_calls; result jsonb; current_count integer;
begin
  perform mw_private.require_mfa();
  if p_candidate is null or jsonb_typeof(p_candidate)<>'object' then raise exception 'MW:Некорректный ICE-кандидат'; end if;
  if octet_length(p_candidate::text)>16384 then raise exception 'MW:ICE-кандидат слишком большой'; end if;
  select * into c from public.mw_calls where id=p_call and auth.uid() in(caller_id,callee_id);
  if c.id is null then raise exception 'MW:Звонок не найден'; end if;
  if auth.uid()=c.caller_id then
    current_count:=jsonb_array_length(coalesce(c.caller_ice,'[]'::jsonb));
    if current_count>=256 then raise exception 'MW:Слишком много ICE-кандидатов'; end if;
    update public.mw_calls set caller_ice=caller_ice||jsonb_build_array(p_candidate),updated_at=now() where id=p_call;
  else
    current_count:=jsonb_array_length(coalesce(c.callee_ice,'[]'::jsonb));
    if current_count>=256 then raise exception 'MW:Слишком много ICE-кандидатов'; end if;
    update public.mw_calls set callee_ice=callee_ice||jsonb_build_array(p_candidate),updated_at=now() where id=p_call;
  end if;
  select to_jsonb(x) into result from public.mw_calls x where id=p_call;
  return result;
end $$;
revoke all on function public.mw_call_ice(uuid,jsonb) from public,anon,authenticated;
grant execute on function public.mw_call_ice(uuid,jsonb) to authenticated;

create or replace function public.mw_room_signal_send(p_room uuid,p_to uuid,p_kind text,p_payload jsonb)
returns bigint language plpgsql security definer set search_path='' as $$
declare new_id bigint;
begin
  perform mw_private.require_mfa();
  if p_kind not in ('offer','answer','ice','bye') then raise exception 'MW:Некорректный сигнал'; end if;
  if p_payload is not null and octet_length(p_payload::text)>32768 then raise exception 'MW:Сигнал слишком большой'; end if;
  if auth.uid()=p_to then raise exception 'MW:Некорректный получатель'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid())
     or not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_to) then
    raise exception 'MW:Участник уже вышел из комнаты';
  end if;
  insert into public.mw_voice_room_signals(room_id,from_user,to_user,kind,payload)
  values(p_room,auth.uid(),p_to,p_kind,coalesce(p_payload,'{}'::jsonb)) returning id into new_id;
  return new_id;
end $$;
revoke all on function public.mw_room_signal_send(uuid,uuid,text,jsonb) from public,anon,authenticated;
grant execute on function public.mw_room_signal_send(uuid,uuid,text,jsonb) to authenticated;

create or replace function public.mw_room_message_send(p_room uuid,p_kind text,p_body text default '',p_media jsonb default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare mid bigint; result jsonb;
begin
  perform mw_private.require_mfa();
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) then raise exception 'MW:Сообщения доступны участникам комнаты'; end if;
  if p_kind not in ('text','image','video','file') then raise exception 'MW:Некорректный тип сообщения'; end if;
  if p_kind='text' and char_length(btrim(coalesce(p_body,''))) not between 1 and 4000 then raise exception 'MW:Введите сообщение'; end if;
  if p_kind<>'text' and (p_media is null or jsonb_typeof(p_media)<>'object') then raise exception 'MW:Нет данных файла'; end if;
  if p_media is not null and octet_length(p_media::text)>32768 then raise exception 'MW:Метаданные файла слишком большие'; end if;
  insert into public.mw_voice_room_messages(room_id,sender_id,kind,body,media)
  values(p_room,auth.uid(),p_kind,left(coalesce(p_body,''),4000),p_media) returning id into mid;
  select jsonb_build_object('id',m.id,'kind',m.kind,'body',m.body,'media',m.media,'created_at',m.created_at,'sender_id',m.sender_id,'sender_name',p.display_name)
  into result from public.mw_voice_room_messages m join public.mw_profiles p on p.id=m.sender_id where m.id=mid;
  return result;
end $$;
revoke all on function public.mw_room_message_send(uuid,text,text,jsonb) from public,anon,authenticated;
grant execute on function public.mw_room_message_send(uuid,text,text,jsonb) to authenticated;

do $$
declare r record; definition text;
begin
  for r in
    select p.oid
    from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    join pg_language l on l.oid=p.prolang
    where n.nspname='public'
      and p.proname like 'mw_%'
      and p.prosecdef
      and l.lanname='plpgsql'
      and has_function_privilege('authenticated',p.oid,'EXECUTE')
      and p.proname not in ('mw_admin_list','mw_owner_admin_set','mw_owner_complaints','mw_owner_overview','mw_owner_status','mw_role_status')
  loop
    definition:=pg_get_functiondef(r.oid);
    if position('perform mw_private.require_mfa();' in lower(definition))=0 then
      definition:=regexp_replace(definition,'\mbegin\M',E'begin\n  perform mw_private.require_mfa();','i');
      execute definition;
    end if;
  end loop;
end $$;

commit;
