"""Regression: Runnable.this must not be passed to a method requiring Activity."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/muwahid/app/MainActivity.java').read_text()
manager=(root/'app/src/main/java/com/muwahid/app/UpdateManager.java').read_text()
workflow=(root/'.github/workflows/build-apk.yml').read_text()
assert 'void checkInForeground(Activity activity)' in manager
assert re.search(r'private final Runnable poll=new Runnable\(\)\{public void run\(\)\{\s*if\(!foreground\)return;\s*UpdateManager\.checkInForeground\(MainActivity\.this\);',main), 'poll runnable must pass Activity instance'
assert main.count('UpdateManager.checkInForeground(this);')==1, 'onResume must keep Activity.this'
assert 'packages: "platform-tools"' in workflow
assert "EXPECTED_VERSION_NAME: '0.13.33'" in workflow
assert "EXPECTED_VERSION_CODE: '68'" in workflow
print('MW_01332_ACTIVITY_CONTEXT_OK')
