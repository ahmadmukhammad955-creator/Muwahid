# Muwahid 0.13.12 — visible chat redesign

This release intentionally makes the chat screen visibly different from 0.13.11:

- taller, clearer conversation header with larger avatar/title/status;
- 16sp message text and wider bubbles;
- 18dp asymmetric message corners;
- redesigned outgoing/incoming colors;
- larger voice-message player and waveform;
- 52dp composer field and 50dp action button;
- more subtle, denser wallpaper pattern;
- versionCode 46 / versionName 0.13.12.
