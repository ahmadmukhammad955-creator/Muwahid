# Muwahid 0.12.4 security hardening

- Production updates are built from the Android `release` variant, never from `debug`.
- R8/code shrinking and resource shrinking are enabled for release builds.
- WebView debugging is disabled and call/voice-room WebViews reject external top-level navigation.
- Camera/microphone WebView permission grants are restricted to the trusted local origin `https://muwahid.local`.
- External HTTP(S) subresources are blocked from bridge-enabled WebViews.
- JavaScript bridge method names are preserved explicitly for R8.
- Supabase complaint-table privileges are reduced to `SELECT` and `INSERT` for authenticated users.

Do not put service-role keys, database passwords, GitHub tokens, signing-key passwords, or private keys in the APK or repository.
