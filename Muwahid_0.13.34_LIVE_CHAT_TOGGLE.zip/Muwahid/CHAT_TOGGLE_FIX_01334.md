# Muwahid 0.13.34 — LIVE Studio chat toggle

## Fixed
- The bottom **Чат** control now opens the room chat with one tap and collapses it on the next tap.
- The button displays active state and updates `aria-expanded`/`aria-pressed` for accessibility.
- Android Back hides the chat and resets the active state; choosing another auxiliary section also resets it.
- Opening chat no longer forces the Android software keyboard open, so the bottom control stays accessible.
- Existing media sending, chat messaging, room state, camera, microphone and LIVE controls have not been modified.

## Source verification
- `bash VERIFY_PROJECT.sh`
- `python3 tests/check_live_chat_toggle_01334.py`
- Other legacy JS and Python source regression tests

## Release build
- Version: **0.13.34**, code **69** (above publicly released 0.13.33 / 68)
- Upload root ZIP `Muwahid_0.13.34_LIVE_CHAT_TOGGLE.zip` into the same GitHub repo as `.github/workflows/build-apk.yml`, which needs updating to version 0.13.34.
- Run GitHub Actions with **publish=false** first; verify APK on a real Android device before publishing signed update.
- No APK compilation or on-device test has been performed in this session.
