package com.muwahid.app;

import android.graphics.Bitmap;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import java.util.regex.Pattern;

final class ProfileQr {
    private static final String PREFIX = "muwahid:profile:v1:";
    private static final Pattern UUID = Pattern.compile(
        "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");

    private ProfileQr() {}

    static String profileId(String payload) {
        if (payload == null || payload.length() != PREFIX.length() + 36 || !payload.startsWith(PREFIX)) {
            return null;
        }
        String id = payload.substring(PREFIX.length());
        return UUID.matcher(id).matches() ? id : null;
    }

    static Bitmap render(String id, int size) throws WriterException {
        String payload = PREFIX + id;
        if (profileId(payload) == null) throw new IllegalArgumentException("Invalid profile ID");
        return new BarcodeEncoder().encodeBitmap(payload, BarcodeFormat.QR_CODE, size, size);
    }
}
