begin;

-- Muwahid LIVE reference UI/behavior.
-- Adds audio/video mode, room capacity and open/closed access without removing
-- the existing moderation, chat, shared-reading, recording and WebRTC signaling.

alter table public.mw_voice_rooms
  add column if not exists room_mode text not null default 'audio',
  add column if not exists capacity smallint not null default 8,
  add column if not exists access_mode text not null default 'open';

alter table public.mw_voice_rooms drop constraint if exists mw_voice_rooms_room_mode_check;
alter table public.mw_voice_rooms add constraint mw_voice_rooms_room_mode_check
  check (room_mode in ('audio','video'));
alter table public.mw_voice_rooms drop constraint if exists mw_voice_rooms_capacity_check;
alter table public.mw_voice_rooms add constraint mw_voice_rooms_capacity_check
  check (capacity in (4,8,12));
alter table public.mw_voice_rooms drop constraint if exists mw_voice_rooms_access_mode_check;
alter table public.mw_voice_rooms add constraint mw_voice_rooms_access_mode_check
  check (access_mode in ('open','closed'));

alter table public.mw_voice_room_members alter column seat drop not null;
alter table public.mw_voice_room_members drop constraint if exists mw_voice_room_members_seat_check;
alter table public.mw_voice_room_members add constraint mw_voice_room_members_seat_check
  check (seat is null or seat between 1 and 12);

create or replace function public.mw_live_room_create(
  p_title text,
  p_mode text,
  p_capacity integer,
  p_access text
) returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare rid uuid; normalized_mode text; normalized_access text; normalized_capacity integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if char_length(btrim(coalesce(p_title,''))) not between 1 and 80 then
    raise exception 'MW:Название эфира должно содержать 1–80 символов';
  end if;
  normalized_mode:=lower(coalesce(p_mode,'audio'));
  normalized_access:=lower(coalesce(p_access,'open'));
  normalized_capacity:=coalesce(p_capacity,8);
  if normalized_mode not in ('audio','video') then raise exception 'MW:Неизвестный тип эфира'; end if;
  if normalized_access not in ('open','closed') then raise exception 'MW:Неизвестный режим доступа'; end if;
  if normalized_mode='audio' and normalized_capacity not in (4,8) then raise exception 'MW:Аудиоэфир поддерживает 4 или 8 участников'; end if;
  if normalized_mode='video' and normalized_capacity not in (4,8,12) then raise exception 'MW:Видеоэфир поддерживает 4, 8 или 12 участников'; end if;

  insert into public.mw_voice_rooms(title,created_by,room_mode,capacity,access_mode)
  values(btrim(p_title),auth.uid(),normalized_mode,normalized_capacity,normalized_access)
  returning id into rid;

  insert into public.mw_voice_room_members(room_id,user_id,seat,mic_allowed,mic_enabled,last_seen,mic_updated_at)
  values(rid,auth.uid(),1,true,false,now(),now());

  return jsonb_build_object(
    'id',rid,'title',btrim(p_title),'room_mode',normalized_mode,
    'capacity',normalized_capacity,'access_mode',normalized_access
  );
end
$$;

-- Keep the legacy create entry point compatible with older app versions.
create or replace function public.mw_room_create(p_title text)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
begin
  return public.mw_live_room_create(p_title,'audio',8,'open');
end
$$;

create or replace function public.mw_room_list()
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare result jsonb;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',r.id,'title',r.title,'created_at',r.created_at,
    'room_mode',r.room_mode,'capacity',r.capacity,'access_mode',r.access_mode,
    'participants',(select count(*) from public.mw_voice_room_members m where m.room_id=r.id),
    'speaking',(select count(*) from public.mw_voice_room_members m where m.room_id=r.id and m.mic_allowed and m.mic_enabled)
  ) order by r.created_at desc),'[]'::jsonb)
  into result
  from public.mw_voice_rooms r
  where r.active=true
    and (r.access_mode='open' or r.created_by=auth.uid()
      or exists(select 1 from public.mw_voice_room_members m where m.room_id=r.id and m.user_id=auth.uid())
      or exists(select 1 from public.mw_voice_room_waiting w where w.room_id=r.id and w.user_id=auth.uid()));
  return result;
end
$$;

create or replace function public.mw_room_join(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  s integer; room_title text; room_creator uuid; room_access text; room_capacity integer; v_room_mode text;
  current_count integer; my_rank integer; wait_pos integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  perform mw_private.room_cleanup(p_room);

  select r.title,r.created_by,r.access_mode,r.capacity,r.room_mode
    into room_title,room_creator,room_access,room_capacity,v_room_mode
  from public.mw_voice_rooms r where r.id=p_room and r.active=true;
  if room_title is null then raise exception 'MW:Эфир закрыт или не существует'; end if;
  if exists(select 1 from public.mw_voice_room_bans where room_id=p_room and user_id=auth.uid()) then
    raise exception 'MW:Вы заблокированы в этом эфире';
  end if;

  update public.mw_voice_room_members set last_seen=now()
   where room_id=p_room and user_id=auth.uid();
  if found then
    delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
    return jsonb_build_object('room_id',p_room,'title',room_title,'status','joined','room_mode',v_room_mode,'capacity',room_capacity,'access_mode',room_access);
  end if;

  my_rank:=mw_private.room_rank(auth.uid(),p_room);
  if room_access='closed' and auth.uid()<>room_creator and my_rank<20 then
    insert into public.mw_voice_room_waiting(room_id,user_id)
    values(p_room,auth.uid())
    on conflict(room_id,user_id) do update set last_seen=now();
    select 1+count(*) into wait_pos from public.mw_voice_room_waiting w
     where w.room_id=p_room and w.requested_at <
       (select requested_at from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid());
    return jsonb_build_object('room_id',p_room,'title',room_title,'status','waiting','position',wait_pos,'room_mode',v_room_mode,'capacity',room_capacity,'access_mode',room_access);
  end if;

  select count(*) into current_count from public.mw_voice_room_members where room_id=p_room;
  if current_count>=room_capacity then raise exception 'MW:В эфире уже максимальное количество участников'; end if;
  select g into s from generate_series(1,room_capacity) g
   where not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=g)
   order by g limit 1;
  if s is null then raise exception 'MW:Нет свободного места в эфире'; end if;

  delete from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid();
  insert into public.mw_voice_room_members(room_id,user_id,seat,mic_allowed,mic_enabled,last_seen,mic_updated_at)
  values(p_room,auth.uid(),s,true,false,now(),now())
  on conflict(room_id,user_id) do update
    set seat=excluded.seat,mic_allowed=true,mic_enabled=false,last_seen=now(),mic_updated_at=now();
  return jsonb_build_object('room_id',p_room,'title',room_title,'status','joined','seat',s,'room_mode',v_room_mode,'capacity',room_capacity,'access_mode',room_access);
end
$$;

create or replace function public.mw_room_state(p_room uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  result jsonb; my_rank integer; can_mod boolean; room_title text; room_creator uuid;
  v_room_mode text; room_access text; room_capacity integer; wait_pos integer; waiting_count integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  select r.title,r.created_by,r.room_mode,r.access_mode,r.capacity
    into room_title,room_creator,v_room_mode,room_access,room_capacity
  from public.mw_voice_rooms r where r.id=p_room and r.active=true;
  if room_title is null then raise exception 'MW:Эфир закрыт'; end if;
  if exists(select 1 from public.mw_voice_room_bans where room_id=p_room and user_id=auth.uid()) then
    raise exception 'MW:Вы заблокированы в этом эфире';
  end if;

  update public.mw_voice_room_members set last_seen=now()
   where room_id=p_room and user_id=auth.uid() and last_seen<now()-interval '10 seconds';
  if found then perform mw_private.room_cleanup(p_room); end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=auth.uid()) then
    update public.mw_voice_room_waiting set last_seen=now()
     where room_id=p_room and user_id=auth.uid() and last_seen<now()-interval '10 seconds';
    if found then perform mw_private.room_cleanup(p_room); end if;
    if not exists(select 1 from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid()) then
      raise exception 'MW:Вы больше не участник эфира';
    end if;
    select 1+count(*) into wait_pos from public.mw_voice_room_waiting w
     where w.room_id=p_room and w.requested_at <
       (select requested_at from public.mw_voice_room_waiting where room_id=p_room and user_id=auth.uid());
    select count(*) into waiting_count from public.mw_voice_room_waiting where room_id=p_room;
    return jsonb_build_object(
      'id',p_room,'title',room_title,'self_id',auth.uid(),'waiting',true,'waiting_position',wait_pos,
      'waiting_count',waiting_count,'participant_count',(select count(*) from public.mw_voice_room_members where room_id=p_room),
      'room_mode',v_room_mode,'access_mode',room_access,'capacity',room_capacity,
      'members','[]'::jsonb,'visible_members',coalesce((select jsonb_agg(jsonb_build_object(
        'id',p.id,'display_name',p.display_name,'username',p.username,'seat',m.seat,
        'mic_allowed',m.mic_allowed,'mic_enabled',m.mic_enabled,'hand_raised',false,'role','user') order by m.seat)
        from public.mw_voice_room_members m join public.mw_profiles p on p.id=m.user_id where m.room_id=p_room),'[]'::jsonb),
      'can_moderate',false,'role','waiting'
    );
  end if;

  my_rank:=mw_private.room_rank(auth.uid(),p_room);can_mod:=my_rank>=20;
  select count(*) into waiting_count from public.mw_voice_room_waiting where room_id=p_room;
  select jsonb_build_object(
    'id',p_room,'title',room_title,'self_id',auth.uid(),'created_by',room_creator,
    'room_mode',v_room_mode,'access_mode',room_access,'capacity',room_capacity,
    'waiting',false,'waiting_count',waiting_count,
    'role',case when my_rank=40 then 'owner' when my_rank=30 then 'host' when my_rank=20 then 'moderator' else 'user' end,
    'can_moderate',can_mod,'can_assign_moderator',my_rank>=30,
    'participant_count',(select count(*) from public.mw_voice_room_members where room_id=p_room),
    'members',coalesce((select jsonb_agg(jsonb_build_object(
      'id',p.id,'display_name',p.display_name,'username',p.username,'seat',m.seat,
      'mic_allowed',m.mic_allowed,'mic_enabled',m.mic_enabled,
      'hand_raised',exists(select 1 from public.mw_voice_room_hands h where h.room_id=m.room_id and h.user_id=m.user_id),
      'role',case when mw_private.room_rank(p.id,p_room)=40 then 'owner' when mw_private.room_rank(p.id,p_room)=30 then 'host' when mw_private.room_rank(p.id,p_room)=20 then 'moderator' else 'user' end
    ) order by m.seat nulls last,m.joined_at)
    from public.mw_voice_room_members m join public.mw_profiles p on p.id=m.user_id where m.room_id=p_room),'[]'::jsonb),
    'waiting_users',case when can_mod then coalesce((select jsonb_agg(jsonb_build_object(
      'id',p.id,'display_name',p.display_name,'username',p.username,'requested_at',w.requested_at
    ) order by w.requested_at)
    from public.mw_voice_room_waiting w join public.mw_profiles p on p.id=w.user_id where w.room_id=p_room),'[]'::jsonb) else '[]'::jsonb end
  ) into result;
  return result;
end
$$;

create or replace function public.mw_room_admit(p_room uuid,p_user uuid)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare s integer; room_capacity integer; current_count integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  if not mw_private.room_can_moderate(p_room,auth.uid()) then raise exception 'MW:Нет прав модератора'; end if;
  if not exists(select 1 from public.mw_voice_room_waiting where room_id=p_room and user_id=p_user) then raise exception 'MW:Запрос уже недействителен'; end if;
  select capacity into room_capacity from public.mw_voice_rooms where id=p_room and active=true;
  if room_capacity is null then raise exception 'MW:Эфир закрыт'; end if;
  select count(*) into current_count from public.mw_voice_room_members where room_id=p_room;
  if current_count>=room_capacity then raise exception 'MW:В эфире уже максимальное количество участников'; end if;
  select g into s from generate_series(1,room_capacity) g
   where not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=g)
   order by g limit 1;
  if s is null then raise exception 'MW:Нет свободного места'; end if;
  delete from public.mw_voice_room_waiting where room_id=p_room and user_id=p_user;
  insert into public.mw_voice_room_members(room_id,user_id,seat,mic_allowed,mic_enabled,last_seen,mic_updated_at)
  values(p_room,p_user,s,true,false,now(),now())
  on conflict(room_id,user_id) do update set seat=excluded.seat,mic_allowed=true,mic_enabled=false,last_seen=now(),mic_updated_at=now();
  return jsonb_build_object('user_id',p_user,'seat',s);
end
$$;

create or replace function public.mw_room_mic_moderate(p_room uuid,p_user uuid,p_allowed boolean)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare caller_rank integer; target_rank integer; new_seat integer; room_capacity integer;
begin
  perform mw_private.require_mfa();
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;
  caller_rank:=mw_private.room_rank(auth.uid(),p_room);target_rank:=mw_private.room_rank(p_user,p_room);
  if caller_rank<20 then raise exception 'MW:Нет прав модератора'; end if;
  if not exists(select 1 from public.mw_voice_room_members where room_id=p_room and user_id=p_user) then raise exception 'MW:Участник уже вышел'; end if;
  select capacity into room_capacity from public.mw_voice_rooms where id=p_room and active=true;
  if p_allowed then
    select seat into new_seat from public.mw_voice_room_members where room_id=p_room and user_id=p_user;
    if new_seat is null then
      select g into new_seat from generate_series(1,coalesce(room_capacity,8)) g
       where not exists(select 1 from public.mw_voice_room_members m where m.room_id=p_room and m.seat=g)
       order by g limit 1;
      if new_seat is null then raise exception 'MW:Нет свободного места'; end if;
    end if;
    update public.mw_voice_room_members set seat=new_seat,mic_allowed=true,mic_enabled=false,mic_updated_at=now(),last_seen=now()
     where room_id=p_room and user_id=p_user;
    delete from public.mw_voice_room_hands where room_id=p_room and user_id=p_user;
  else
    update public.mw_voice_room_members set mic_allowed=false,mic_enabled=false,mic_updated_at=now(),last_seen=now()
     where room_id=p_room and user_id=p_user;
  end if;
  return jsonb_build_object('user_id',p_user,'mic_allowed',p_allowed,'seat',new_seat);
end
$$;

revoke all on function public.mw_live_room_create(text,text,integer,text) from public,anon,authenticated;
grant execute on function public.mw_live_room_create(text,text,integer,text) to authenticated;
revoke execute on function public.mw_room_create(text),public.mw_room_list(),public.mw_room_join(uuid),public.mw_room_state(uuid),public.mw_room_admit(uuid,uuid),public.mw_room_mic_moderate(uuid,uuid,boolean) from public,anon;
grant execute on function public.mw_room_create(text),public.mw_room_list(),public.mw_room_join(uuid),public.mw_room_state(uuid),public.mw_room_admit(uuid,uuid),public.mw_room_mic_moderate(uuid,uuid,boolean) to authenticated;

commit;
