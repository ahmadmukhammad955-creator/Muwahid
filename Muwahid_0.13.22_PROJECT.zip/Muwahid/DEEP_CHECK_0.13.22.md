# Muwahid 0.13.22 — deep check

- Version remains `0.13.22`, versionCode `56`.
- Host is stored as a room member with `seat = null` and `mic_allowed = true`; all eight numbered seats are independent.
- New room controls are server-authorized RPCs in `backend/027_voice_room_live_tools.sql`; clients cannot directly mutate the protected tables.
- `mw_voice_room_settings` and `mw_voice_room_programs` use RLS/force-RLS and have direct table privileges revoked from client roles.
- WebView JavaScript bridge remains restricted to an explicit RPC whitelist.
- External navigation remains blocked inside the trusted room WebView. The added native external opener accepts HTTPS YouTube hosts only.
- WebRTC audio graph uses the real microphone stream; music, soundboard and mixer effects feed the outgoing stream.
- Screen broadcast is attempted only through the platform display-capture API and is renegotiated as a WebRTC video track. If Android System WebView does not expose display capture, Muwahid reports it instead of showing a fake active state.
- Room recording uses MediaRecorder and a native single-thread writer.
