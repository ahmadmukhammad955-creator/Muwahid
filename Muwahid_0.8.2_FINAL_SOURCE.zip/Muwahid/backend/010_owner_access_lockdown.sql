begin;

revoke all on table mw_private.owner_account from public, anon, authenticated;
revoke execute on function public.rls_auto_enable() from public, anon, authenticated;

revoke execute on function public.mw_owner_status() from public, anon;
revoke execute on function public.mw_owner_overview() from public, anon;
grant execute on function public.mw_owner_status() to authenticated;
grant execute on function public.mw_owner_overview() to authenticated;

commit;
