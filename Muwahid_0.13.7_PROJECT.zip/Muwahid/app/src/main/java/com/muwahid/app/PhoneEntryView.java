package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Build;
import android.telephony.PhoneNumberUtils;
import android.text.*;
import android.view.*;
import android.view.inputmethod.*;
import android.widget.*;
import org.json.*;
import java.util.*;

/** Native phone entry and full-screen country picker matching the supplied video. */
final class PhoneEntryView extends LinearLayout {
    interface Submit { void send(String e164); }
    private static final int BG=Color.rgb(29,41,53), FG=Color.rgb(246,248,250),
        MUTED=Color.rgb(132,148,162), BLUE=Color.rgb(36,161,235), OUTLINE=Color.rgb(74,94,112);
    private final Activity activity;
    private JSONArray countries;
    private JSONObject selected;
    private final TextView country, prefix;
    final EditText number;
    private final ImageButton next;
    private final TextView status;
    private final Submit submit;
    private boolean busy;
    private Dialog picker;

    PhoneEntryView(Activity activity, JSONArray initial, Runnable back, Runnable google, Submit submit) {
        super(activity); this.activity=activity; this.countries=initial; this.submit=submit;
        setOrientation(VERTICAL);setBackgroundColor(BG);setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout top=row();
        ImageButton backButton=icon(0,"Назад");top.addView(backButton,new LayoutParams(dp(56),dp(56)));
        backButton.setOnClickListener(v->back.run());
        if(google!=null){
            top.addView(new Space(activity),new LayoutParams(0,1,1));
            TextView more=text("⋮",26,FG);more.setGravity(Gravity.CENTER);more.setContentDescription("Другие способы входа");more.setFocusable(true);
            top.addView(more,new LayoutParams(dp(56),dp(56)));more.setOnClickListener(v->{PopupMenu menu=new PopupMenu(activity,more);menu.getMenu().add("Продолжить с Google");menu.setOnMenuItemClickListener(item->{google.run();return true;});menu.show();});
        }
        addView(top);
        ScrollView scroll=new ScrollView(activity);scroll.setFillViewport(true);scroll.setClipToPadding(false);
        LinearLayout center=new LinearLayout(activity);center.setOrientation(VERTICAL);center.setGravity(Gravity.CENTER);
        center.setPadding(dp(24),dp(32),dp(24),dp(24));
        LinearLayout form=new LinearLayout(activity);form.setOrientation(VERTICAL);
        center.addView(form,new LayoutParams(Math.min(dp(360),getResources().getDisplayMetrics().widthPixels-dp(48)),LayoutParams.WRAP_CONTENT));
        TextView title=text("Номер телефона",22,FG);title.setTypeface(null,Typeface.BOLD);title.setGravity(Gravity.CENTER);form.addView(title);
        TextView intro=text("Проверьте код страны и введите свой\nномер телефона.",15,MUTED);intro.setGravity(Gravity.CENTER);intro.setLineSpacing(dp(3),1);
        LayoutParams ip=new LayoutParams(-1,-2);ip.topMargin=dp(12);ip.bottomMargin=dp(32);form.addView(intro,ip);
        LinearLayout countryBox=row();countryBox.setPadding(dp(16),0,dp(12),0);countryBox.setBackground(outline(OUTLINE,1));
        country=text("Страна",17,MUTED);countryBox.addView(country,new LayoutParams(0,-2,1));
        ImageView chevron=new ImageView(activity);chevron.setImageDrawable(new Glyph(3,MUTED));countryBox.addView(chevron,new LayoutParams(dp(24),dp(24)));
        countryBox.setContentDescription("Выберите страну");countryBox.setFocusable(true);countryBox.setClickable(true);countryBox.setTag("phone_country");
        form.addView(countryBox,new LayoutParams(-1,dp(56)));countryBox.setOnClickListener(v->showCountries());
        FrameLayout phoneFrame=new FrameLayout(activity);LayoutParams fp=new LayoutParams(-1,dp(66));fp.topMargin=dp(22);form.addView(phoneFrame,fp);
        LinearLayout phoneRow=row();phoneRow.setPadding(dp(14),0,dp(8),0);phoneRow.setBackground(outline(Color.rgb(116,183,237),2));
        FrameLayout.LayoutParams pr=new FrameLayout.LayoutParams(-1,dp(56),Gravity.BOTTOM);phoneFrame.addView(phoneRow,pr);
        prefix=text("+",18,FG);prefix.setGravity(Gravity.CENTER_VERTICAL);prefix.setMinWidth(dp(40));prefix.setPadding(0,0,dp(12),0);prefix.setContentDescription("Код страны");phoneRow.addView(prefix,new LayoutParams(-2,-1));prefix.setOnClickListener(v->showCountries());
        View rule=new View(activity);rule.setBackgroundColor(OUTLINE);phoneRow.addView(rule,new LayoutParams(dp(1),dp(24)));
        number=new EditText(activity);number.setSingleLine(true);number.setTextColor(FG);number.setTextSize(18);number.setBackgroundColor(Color.TRANSPARENT);
        number.setInputType(InputType.TYPE_CLASS_PHONE);number.setImeOptions(EditorInfo.IME_ACTION_NEXT);number.setPadding(dp(12),0,dp(4),0);
        number.setContentDescription("Номер телефона");number.setTag("phone_number");number.setFilters(new InputFilter[]{new InputFilter.LengthFilter(24)});
        if(Build.VERSION.SDK_INT>=26)number.setAutofillHints(View.AUTOFILL_HINT_PHONE);
        phoneRow.addView(number,new LayoutParams(0,-1,1));
        TextView caption=text("Номер телефона",13,Color.rgb(116,183,237));caption.setBackgroundColor(BG);caption.setPadding(dp(5),0,dp(5),0);
        FrameLayout.LayoutParams cap=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);cap.leftMargin=dp(10);phoneFrame.addView(caption,cap);
        status=text("",13,MUTED);status.setLineSpacing(dp(2),1);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        LayoutParams st=new LayoutParams(-1,-2);st.topMargin=dp(16);form.addView(status,st);
        scroll.addView(center,new ScrollView.LayoutParams(-1,-1));addView(scroll,new LayoutParams(-1,0,1));
        LinearLayout actions=row();actions.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);actions.setPadding(dp(24),dp(8),dp(24),dp(18));
        next=icon(1,"Получить SMS-код");next.setBackground(round(BLUE,30));next.setElevation(dp(2));next.setTag("phone_next");
        actions.addView(next,new LayoutParams(dp(60),dp(60)));addView(actions);next.setOnClickListener(v->send());
        number.setOnEditorActionListener((v,id,event)->{if(id==EditorInfo.IME_ACTION_NEXT){send();return true;}return false;});
        number.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){if(!busy)status.setText("");}public void afterTextChanged(Editable e){}});
        number.requestFocus();
    }
    void updateCountries(JSONArray value) {countries=value;}
    void setBusy(boolean value) {busy=value;next.setEnabled(!value);next.setAlpha(value?.45f:1f);number.setEnabled(!value);status.setText(value?"Отправляем SMS-код…":"");}
    void showKeyboard(){number.requestFocus();number.postDelayed(()->{if(isAttachedToWindow()&&picker==null)((InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(number,InputMethodManager.SHOW_IMPLICIT);},180);}
    void dispose(){if(picker!=null){picker.setOnDismissListener(null);picker.dismiss();picker=null;}}
    private void select(JSONObject c){selected=c;country.setText(PhoneCountries.name(c));country.setTextColor(FG);prefix.setText(c.optString("calling_code"));number.setError(null);}
    private void send(){
        if(busy)return;
        String raw=number.getText().toString().trim();
        if(selected==null){status.setText("Выберите страну для своего номера.");showCountries();return;}
        String full=normalize(raw,selected.optString("iso2"),selected.optString("calling_code"));
        if(full==null){number.setError("Проверьте номер телефона");number.requestFocus();return;}
        // Confirm the exact destination before sending a potentially billable SMS.
        new AlertDialog.Builder(activity).setTitle("Проверьте номер").setMessage(full)
            .setNegativeButton("Изменить",null).setPositiveButton("Продолжить",(d,w)->submit.send(full)).show();
    }
    static String normalize(String raw,String iso,String callingCode){
        if(raw==null||iso==null||callingCode==null)return null;
        String value=raw.trim();
        if(!value.matches("[+0-9 ()\\-]+"))return null;
        if(value.startsWith("00"))value="+"+value.substring(2);
        if(value.startsWith("+")&&!value.replaceAll("[^+0-9]","").startsWith(callingCode))return null;
        String result=PhoneNumberUtils.formatNumberToE164(value,iso);
        return result!=null&&result.matches("\\+[1-9][0-9]{6,14}")?result:null;
    }
    private void showCountries(){
        if(busy||picker!=null)return;
        ((InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(number.getWindowToken(),0);
        Dialog dialog=new Dialog(activity,android.R.style.Theme_Material_NoActionBar);picker=dialog;
        LinearLayout page=new LinearLayout(activity);page.setOrientation(VERTICAL);page.setBackgroundColor(BG);page.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout bar=row();ImageButton back=icon(0,"Назад");bar.addView(back,new LayoutParams(dp(56),dp(56)));
        TextView title=text("Выберите страну",20,FG);title.setTypeface(null,Typeface.BOLD);bar.addView(title,new LayoutParams(0,-2,1));
        EditText search=new EditText(activity);search.setTextSize(17);search.setSingleLine(true);search.setTextColor(FG);search.setHintTextColor(MUTED);search.setHint("Поиск страны или кода");search.setBackgroundColor(Color.TRANSPARENT);search.setInputType(InputType.TYPE_CLASS_TEXT);search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);search.setVisibility(GONE);search.setTag("country_search");bar.addView(search,new LayoutParams(0,dp(56),1));
        ImageButton toggle=icon(2,"Поиск страны");bar.addView(toggle,new LayoutParams(dp(56),dp(56)));page.addView(bar);
        FrameLayout body=new FrameLayout(activity);page.addView(body,new LayoutParams(-1,0,1));
        ListView list=new ListView(activity);list.setDivider(null);list.setCacheColorHint(Color.TRANSPARENT);list.setFastScrollEnabled(true);list.setTag("country_list");body.addView(list,new FrameLayout.LayoutParams(-1,-1));
        TextView empty=text("Страна не найдена",16,MUTED);empty.setGravity(Gravity.CENTER);body.addView(empty,new FrameLayout.LayoutParams(-1,-1));list.setEmptyView(empty);
        ArrayList<JSONObject> rows=PhoneCountries.search(countries,"");
        BaseAdapter adapter=new BaseAdapter(){
            public int getCount(){return rows.size();} public Object getItem(int p){return rows.get(p);}public long getItemId(int p){return p;}
            public View getView(int p,View recycled,ViewGroup parent){
                LinearLayout line;
                if(recycled instanceof LinearLayout)line=(LinearLayout)recycled;
                else {line=row();line.setPadding(dp(20),dp(8),dp(20),dp(8));line.setMinimumHeight(dp(52));
                    TextView flag=text("",20,FG);line.addView(flag,new LayoutParams(dp(40),-2));
                    TextView name=text("",16,FG);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);line.addView(name,new LayoutParams(0,-2,1));
                    TextView code=text("",15,Color.rgb(115,163,199));code.setPadding(dp(12),0,0,0);line.addView(code,new LayoutParams(-2,-2));}
                JSONObject c=rows.get(p);((TextView)line.getChildAt(0)).setText(c.optString("flag"));((TextView)line.getChildAt(1)).setText(PhoneCountries.name(c));((TextView)line.getChildAt(2)).setText(c.optString("calling_code"));
                line.setContentDescription(PhoneCountries.name(c)+" "+c.optString("calling_code"));return line;
            }
        };
        list.setAdapter(adapter);list.setOnItemClickListener((parent,view,position,id)->{select(rows.get(position));dialog.dismiss();showKeyboard();});
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){rows.clear();rows.addAll(PhoneCountries.search(countries,s.toString()));adapter.notifyDataSetChanged();}public void afterTextChanged(Editable e){}});
        toggle.setOnClickListener(v->{if(search.getVisibility()==GONE){title.setVisibility(GONE);search.setVisibility(VISIBLE);search.requestFocus();((InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(search,InputMethodManager.SHOW_IMPLICIT);}else search.setText("");});
        back.setOnClickListener(v->dialog.dismiss());dialog.setOnDismissListener(d->{picker=null;});
        dialog.setContentView(page);Window window=dialog.getWindow();if(window!=null){window.setStatusBarColor(BG);window.setNavigationBarColor(BG);window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);window.setBackgroundDrawable(new ColorDrawable(BG));}
        page.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        dialog.show();if(window!=null)window.setLayout(-1,-1);page.requestApplyInsets();
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout row(){LinearLayout l=new LinearLayout(activity);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView text(String value,int size,int color){TextView t=new TextView(activity);t.setText(value);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable outline(int color,int width){GradientDrawable d=round(BG,7);d.setStroke(dp(width),color);return d;}
    private ImageButton icon(int kind,String description){ImageButton b=new ImageButton(activity);b.setImageDrawable(new Glyph(kind,FG));b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x3376BAE8),null,round(Color.WHITE,28)));b.setContentDescription(description);b.setPadding(dp(16),dp(16),dp(16),dp(16));return b;}
    private static final class Glyph extends Drawable {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final int kind;
        Glyph(int kind,int color){this.kind=kind;p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);}
        public void draw(Canvas canvas){Rect r=getBounds();canvas.save();canvas.translate(r.left,r.top);canvas.scale(r.width()/24f,r.height()/24f);Path path=new Path();
            if(kind==2){canvas.drawCircle(10,10,6,p);canvas.drawLine(15,15,21,21,p);}
            else if(kind==3){path.moveTo(9,5);path.lineTo(16,12);path.lineTo(9,19);canvas.drawPath(path,p);}
            else {boolean right=kind==1;canvas.drawLine(4,12,20,12,p);path.moveTo(right?13:11,5);path.lineTo(right?20:4,12);path.lineTo(right?13:11,19);canvas.drawPath(path,p);}canvas.restore();}
        public void setAlpha(int a){p.setAlpha(a);}public void setColorFilter(ColorFilter f){p.setColorFilter(f);}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
}
