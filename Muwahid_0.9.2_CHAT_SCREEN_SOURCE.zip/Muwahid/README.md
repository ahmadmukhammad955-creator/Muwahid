# Muwahid 0.9.1 — Main chat screen implementation

Complete Android source project for the current Muwahid messenger prototype.

## Version

- applicationId: `com.muwahid.app`
- versionCode: `17`
- versionName: `0.9.1`
- minSdk: `23`
- targetSdk / compileSdk: `35`

## Main chat screen implemented from the approved reference

The main screen now contains:

- top bar: menu, `Muwahid`, search, create button;
- three tabs: `Чаты / Группы / Каналы`;
- dark blue/black messenger background;
- chat rows with circular avatars, name, last-message preview and time;
- unread-count badge when `unread_count` is supplied by the server;
- floating compose button in the lower-right corner;
- bottom navigation: `Чаты / Звонки / Контакты / Настройки`.

The screen still uses the real `mw_chat_list()` result. Existing authentication, direct chats, E2EE, media, voice/video messages, calls, notifications, profile/settings and backend migrations remain in the project.

## Build

A GitHub Actions workflow is included at:

`.github/workflows/build-apk.yml`

It builds:

`app/build/outputs/apk/debug/app-debug.apk`

and then runs an Android emulator smoke test. The test captures `main_chat_screen.png` and checks that the main navigation labels are present.

## Backend

The existing Supabase migrations are in `backend/`. Keep the same backend already used by the current installed Muwahid build. Do not run migrations again unless the backend needs to be recreated or upgraded deliberately.

## Current scope

This release focuses on the **main chat-list screen**. Groups and channels remain local prototype sections; server synchronization for them is a separate implementation step.
