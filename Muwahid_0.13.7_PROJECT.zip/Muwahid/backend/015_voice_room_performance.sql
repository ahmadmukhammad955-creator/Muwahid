-- Muwahid 0.11.1: voice-room performance tuning.
-- Reduces write amplification from frequent polling; signaling remains read-only.

create or replace function public.mw_room_signal_poll(p_room uuid, p_after bigint default 0)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  if auth.uid() is null or not exists(
    select 1 from public.mw_voice_room_members
    where room_id=p_room and user_id=auth.uid()
  ) then raise exception 'MW:Вы больше не участник комнаты'; end if;

  select coalesce(jsonb_agg(to_jsonb(x) order by x.id),'[]'::jsonb)
  into result from (
    select s.id,s.from_user,s.kind,s.payload,s.created_at
    from public.mw_voice_room_signals s
    where s.room_id=p_room and s.to_user=auth.uid()
      and s.id>coalesce(p_after,0)
    order by s.id asc
    limit 100
  ) x;
  return result;
end $$;

create or replace function public.mw_room_state(p_room uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare
  result jsonb; my_rank integer; can_mod boolean; room_title text; room_creator uuid;
  wait_pos integer; waiting_count integer; seated boolean; queued boolean;
begin
  if auth.uid() is null then raise exception 'MW:Войдите в аккаунт'; end if;

  select title,created_by into room_title,room_creator
  from public.mw_voice_rooms where id=p_room and active=true;
  if room_title is null then raise exception 'MW:Комната закрыта'; end if;

  select exists(
    select 1 from public.mw_voice_room_members
    where room_id=p_room and user_id=auth.uid()
  ) into seated;

  if seated then
    update public.mw_voice_room_members
      set last_seen=now()
      where room_id=p_room and user_id=auth.uid()
        and last_seen < now()-interval '10 seconds';
    if found then perform mw_private.room_cleanup(p_room); end if;
  else
    select exists(
      select 1 from public.mw_voice_room_waiting
      where room_id=p_room and user_id=auth.uid()
    ) into queued;
    if not queued then raise exception 'MW:Вы больше не участник комнаты'; end if;

    update public.mw_voice_room_waiting
      set last_seen=now()
      where room_id=p_room and user_id=auth.uid()
        and last_seen < now()-interval '10 seconds';
    if found then perform mw_private.room_cleanup(p_room); end if;

    select 1+count(*) into wait_pos
    from public.mw_voice_room_waiting w
    where w.room_id=p_room and w.requested_at < (
      select requested_at from public.mw_voice_room_waiting
      where room_id=p_room and user_id=auth.uid()
    );
    select count(*) into waiting_count
    from public.mw_voice_room_waiting where room_id=p_room;

    return jsonb_build_object(
      'id',p_room,'title',room_title,'self_id',auth.uid(),
      'waiting',true,'waiting_position',wait_pos,'waiting_count',waiting_count,
      'members','[]'::jsonb,'can_moderate',false,'role','waiting'
    );
  end if;

  my_rank:=mw_private.room_rank(auth.uid(),p_room);
  can_mod:=my_rank>=20;
  select count(*) into waiting_count
  from public.mw_voice_room_waiting where room_id=p_room;

  select jsonb_build_object(
    'id',p_room,'title',room_title,'self_id',auth.uid(),'created_by',room_creator,
    'waiting',false,'waiting_count',waiting_count,
    'role',case when my_rank=40 then 'owner' when my_rank=30 then 'host'
                when my_rank=20 then 'moderator' else 'user' end,
    'can_moderate',can_mod,'can_assign_moderator',my_rank>=30,
    'members',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',p.id,'display_name',p.display_name,'username',p.username,'seat',m.seat,
        'mic_allowed',m.mic_allowed,'mic_enabled',m.mic_enabled,
        'hand_raised',exists(
          select 1 from public.mw_voice_room_hands h
          where h.room_id=m.room_id and h.user_id=m.user_id
        ),
        'role',case when mw_private.room_rank(p.id,p_room)=40 then 'owner'
                    when mw_private.room_rank(p.id,p_room)=30 then 'host'
                    when mw_private.room_rank(p.id,p_room)=20 then 'moderator'
                    else 'user' end
      ) order by m.seat)
      from public.mw_voice_room_members m
      join public.mw_profiles p on p.id=m.user_id
      where m.room_id=p_room
    ),'[]'::jsonb),
    'waiting_users',case when can_mod then coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',p.id,'display_name',p.display_name,'username',p.username,'requested_at',w.requested_at
      ) order by w.requested_at)
      from public.mw_voice_room_waiting w
      join public.mw_profiles p on p.id=w.user_id
      where w.room_id=p_room
    ),'[]'::jsonb) else '[]'::jsonb end
  ) into result;
  return result;
end $$;

revoke all on function public.mw_room_signal_poll(uuid,bigint), public.mw_room_state(uuid)
from public,anon,authenticated;
grant execute on function public.mw_room_signal_poll(uuid,bigint), public.mw_room_state(uuid)
to authenticated;
