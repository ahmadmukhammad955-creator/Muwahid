-- Muwahid 0.12.6: server-driven app configuration.
-- The Android client reads this JSON through mw_app_config() and caches it locally.

create table if not exists public.mw_app_remote_config (
  id smallint primary key default 1 check (id = 1),
  config jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.mw_app_remote_config enable row level security;

drop policy if exists mw_app_remote_config_read on public.mw_app_remote_config;
create policy mw_app_remote_config_read
on public.mw_app_remote_config
for select
to anon, authenticated
using (id = 1);

revoke all on table public.mw_app_remote_config from public, anon, authenticated;
grant select on table public.mw_app_remote_config to anon, authenticated;

insert into public.mw_app_remote_config(id, config, updated_at)
values (
  1,
  $json$
  {
    "schema_version": 1,
    "maintenance": {
      "enabled": false,
      "message": "Muwahid временно на обслуживании. Попробуйте немного позже."
    },
    "welcome": {
      "start_button": "Начать",
      "login_text": "Уже есть аккаунт?  Войти",
      "notes_text": "Открыть личные заметки",
      "status_text": "Muwahid · настройки обновляются через Supabase"
    },
    "auth": {
      "enabled": true,
      "phone_enabled": true,
      "google_enabled": true,
      "default_country": "DE",
      "registration_title": "Регистрация",
      "login_title": "Вход",
      "intro": "Выберите страну, введите номер телефона и получите одноразовый SMS-код. Имя для регистрации не требуется.",
      "country_button": "Страна  +код",
      "phone_hint": "Номер телефона",
      "phone_help": "После кода страны вводите только номер.",
      "sms_button": "Получить SMS-код",
      "google_button": "Продолжить с Google",
      "login_switch": "Уже есть аккаунт? Войти",
      "register_switch": "Нет аккаунта? Зарегистрироваться",
      "footer": "После подтверждения SMS Supabase создаёт или открывает защищённую учётную запись Muwahid.",
      "otp_title": "Подтверждение номера",
      "otp_intro": "SMS-код отправлен на {phone}. Введите 6 цифр из сообщения.",
      "otp_hint": "6-значный SMS-код",
      "otp_button": "Подтвердить и войти",
      "resend_text": "Получить новый код"
    },
    "features": {
      "groups": true,
      "channels": true,
      "voice_rooms": true,
      "admins": true,
      "owner_chat": true,
      "premium": false,
      "business": false,
      "gifts": false
    },
    "ui": {
      "app_name": "Muwahid",
      "messages_subtitle": "Сообщения",
      "chats_tab": "Чаты",
      "groups_tab": "Группы",
      "channels_tab": "Каналы",
      "announcement": ""
    }
  }
  $json$::jsonb,
  now()
)
on conflict (id) do nothing;

create or replace function public.mw_app_config()
returns jsonb
language sql
stable
security invoker
set search_path = ''
as $$
  select config || jsonb_build_object('server_updated_at', updated_at)
  from public.mw_app_remote_config
  where id = 1
$$;

revoke all on function public.mw_app_config() from public, anon, authenticated;
grant execute on function public.mw_app_config() to anon, authenticated;
