package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.*;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;
import java.security.MessageDigest;
import java.util.Locale;

public final class UpdateActivity extends Activity {
    private Button install;
    private TextView status;
    private String url,expectedSha,versionName;
    private File downloaded;
    private static final int REQ_UNKNOWN_SOURCES=8301;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        versionName=getIntent().getStringExtra("version_name");
        url=getIntent().getStringExtra("apk_url");
        expectedSha=getIntent().getStringExtra("sha256");
        String notes=getIntent().getStringExtra("notes");
        if(versionName==null)versionName="новая версия";
        if(notes==null||notes.trim().isEmpty())notes="Исправления и улучшения Muwahid.";

        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(24),dp(28),dp(24),dp(24));root.setBackgroundColor(Color.rgb(7,19,33));
        TextView title=text("Обновление Muwahid",25,Color.WHITE);title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);root.addView(title);
        gap(root,10);root.addView(text("Версия "+versionName,17,Color.rgb(16,214,171)));
        gap(root,18);TextView n=text(notes,15,Color.rgb(210,222,234));n.setLineSpacing(dp(4),1f);root.addView(n);
        gap(root,18);status=text("Ваши чаты и настройки сохранятся. Android попросит подтвердить установку обновления.",13,Color.rgb(143,166,188));root.addView(status);
        gap(root,24);install=new Button(this);install.setText("Скачать и обновить");install.setAllCaps(false);install.setTextSize(16);root.addView(install,new LinearLayout.LayoutParams(-1,dp(54)));install.setOnClickListener(v->startUpdate());
        gap(root,12);Button later=new Button(this);later.setText("Позже");later.setAllCaps(false);root.addView(later,new LinearLayout.LayoutParams(-1,dp(50)));later.setOnClickListener(v->finish());
        setContentView(root);
    }

    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private void gap(LinearLayout l,int h){l.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(h)));}

    private void startUpdate(){
        if(url==null||!url.startsWith("https://")||expectedSha==null){toast("Некорректные данные обновления");return;}
        if(Build.VERSION.SDK_INT>=26 && !getPackageManager().canRequestPackageInstalls()){
            status.setText("Разрешите Muwahid устанавливать обновления. После разрешения вернитесь сюда.");
            Intent i=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:"+getPackageName()));
            startActivityForResult(i,REQ_UNKNOWN_SOURCES);return;
        }
        install.setEnabled(false);status.setText("Скачиваем обновление…");
        new Thread(()->{
            try{
                File dir=getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);if(dir==null)dir=getCacheDir();if(!dir.exists())dir.mkdirs();
                File tmp=new File(dir,"Muwahid-update.part");File out=new File(dir,"Muwahid-update.apk");
                download(url,tmp);
                String got=sha256(tmp);if(!got.equalsIgnoreCase(expectedSha))throw new SecurityException("Контрольная сумма обновления не совпала");
                if(out.exists())out.delete();if(!tmp.renameTo(out)){copy(tmp,out);tmp.delete();}
                downloaded=out;runOnUiThread(()->{status.setText("Обновление скачано. Подтвердите установку Android.");install.setEnabled(true);installApk();});
            }catch(Exception e){runOnUiThread(()->{install.setEnabled(true);status.setText("Не удалось обновить: "+safe(e.getMessage()));});}
        },"muwahid-update-download").start();
    }

    private void download(String source,File target)throws Exception{
        HttpsURLConnection c=(HttpsURLConnection)new URL(source).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(60000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","Muwahid-Android/"+BuildConfig.VERSION_NAME);
        try{int code=c.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);long max=100L*1024L*1024L,total=0;try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(target)){byte[] buf=new byte[32768];int n;while((n=in.read(buf))!=-1){total+=n;if(total>max)throw new IOException("Файл обновления слишком большой");out.write(buf,0,n);}}}finally{c.disconnect();}
    }
    private void copy(File a,File b)throws Exception{try(InputStream in=new FileInputStream(a);OutputStream out=new FileOutputStream(b)){byte[] x=new byte[32768];int n;while((n=in.read(x))!=-1)out.write(x,0,n);}}
    private String sha256(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:d.digest())s.append(String.format(Locale.ROOT,"%02x",x));return s.toString();}

    private void installApk(){
        if(downloaded==null||!downloaded.exists())return;
        try{
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".files",downloaded);
            Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }catch(Exception e){status.setText("Не удалось открыть установщик Android: "+safe(e.getMessage()));}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_UNKNOWN_SOURCES){if(Build.VERSION.SDK_INT<26||getPackageManager().canRequestPackageInstalls())startUpdate();else status.setText("Без разрешения Android не даст установить APK поверх текущей версии.");}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private String safe(String s){return s==null?"неизвестная ошибка":s;}
}
