'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const page=fs.readFileSync('app/src/main/assets/voice_room.html','utf8');
const scripts=[...page.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const main=scripts.find(s=>s.includes('function levelTick(ts)'));
assert(main,'LIVE speech detection script');
new vm.Script(main);
for(let i=1;i<=8;i++)assert(page.includes(`.seat[data-seat="${i}"]`),`seat ${i}`);
assert(page.includes('onclick="micAction()"'),'central mic invokes actual audio control');
assert(page.includes("stage.classList.toggle('round-8',!IS_VIDEO&&seatCount===8&&liveSeatLayout==='circle_8')"));
assert(page.includes("const speakerColor=hexColor(live.speaker_glow_color)||'#c18aff'"));
assert(page.includes('audioHelp'),'existing media controls retained');
const frag=main.slice(main.indexOf('function levelTick(ts)'),main.indexOf('async function ensureLocal()',main.indexOf('function levelTick(ts)')));
const changes=[];let enabled=true,frame=0, speakerText='';let speaking=false,active=false;
const avatar={style:{},closest:()=>({})};
const tile={closest:()=>({}),classList:{toggle(k,on){if(k==='speaking'){speaking=on;changes.push(['speech',on]);}}},querySelector(){return avatar}};
const center={classList:{toggle(k,on){if(k==='active-speaker')active=on;}}};
const label={set textContent(x){speakerText=x;}};
const node={analyser:{getByteTimeDomainData(arr){arr.fill(224);}},data:new Uint8Array(128),smooth:0};
const ctx={closed:false,levelLoop:true,lastLevelFrame:0,levelNodes:{'voice-1':node},
  stateData:{members:[{id:'voice-1',display_name:'Участник',mic_allowed:true,get mic_enabled(){return enabled;}}]},
  liveSpeakerHighlight:true,
  document:{querySelector(sel){return sel.includes('voice-1')?tile:null;},getElementById(id){return id==='centralMicBtn'?center:id==='micSpeaker'?label:null;}},
  requestAnimationFrame(){frame++;},
};
vm.runInNewContext(frag+'this.callLevelTick=levelTick;',ctx);
ctx.callLevelTick(1000);
assert(speaking,'real signal makes seat visible');assert(active,'center reacts');
assert(speakerText.startsWith('Говорит:'));
enabled=false;ctx.callLevelTick(1100);
assert(!speaking,'muted member cannot be highlighted');assert(!active,'center remains neutral when muted');
assert(frame===2,'frame loop is continuous');
console.log('MW_LIVE_CIRCLE_8_OK: 8 positions, click control, WebRTC voice level, mute gate, safe remote config');
