package com.muwahid.app;

import android.util.Log;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import org.json.JSONObject;
import java.util.Map;

/** High-priority, data-only FCM call push: validates age and recipient before displaying. */
public final class MuwahidMessagingService extends FirebaseMessagingService {
    @Override public void onNewToken(String token){super.onNewToken(token);PushRegistration.initialize(this);PushRegistration.registerToken(this,token);}
    @Override public void onDeletedMessages(){PushRegistration.refresh(this);}
    @Override public void onMessageReceived(RemoteMessage message){
        try {
            Map<String,String> d=message.getData();
            if(!"incoming_call".equals(d.get("type")))return;
            String id=d.get("call_id"),recipient=d.get("callee_id");
            if(id==null || !id.matches("[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}"))return;
            long created=Long.parseLong(d.get("created_ms"));
            long delta=System.currentTimeMillis()-created;
            if(delta < -30000L || delta > 90000L)return; // Don't ring for expired/stale calls.
            Api api=new Api(new SecureStore(this));
            if(!api.signedIn()||recipient==null||!recipient.equals(api.uid()))return;
            JSONObject c=new JSONObject().put("id",id).put("kind",d.get("kind"))
                    .put("caller_name",d.get("caller_name"));
            CallNotifications.showIncoming(this,c);
        }catch(Exception e){Log.w("MW-Push","Incoming FCM call ignored",e);}
    }
}
