package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.Geocoder;
import android.location.Address;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public final class LocationShareActivity extends Activity {
    private double lat,lon;
    private TextView address,coords;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.parseColor("#071827"));getWindow().setNavigationBarColor(Color.parseColor("#071827"));lat=getIntent().getDoubleExtra("lat",0);lon=getIntent().getDoubleExtra("lon",0);build();resolveAddress();}
    @SuppressWarnings("SetJavaScriptEnabled") private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.parseColor("#071827"));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(12),dp(8),dp(12),dp(8));TextView back=text("‹",38,Color.WHITE);back.setGravity(Gravity.CENTER);bar.addView(back,new LinearLayout.LayoutParams(dp(46),dp(50)));back.setOnClickListener(v->finish());TextView title=text("Местоположение",18,Color.WHITE);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);bar.addView(title,new LinearLayout.LayoutParams(0,dp(50),1));Space right=new Space(this);bar.addView(right,new LinearLayout.LayoutParams(dp(46),dp(50)));root.addView(bar);
        EditText search=new EditText(this);search.setHint("Поиск места...");search.setHintTextColor(Color.parseColor("#8398AD"));search.setTextColor(Color.WHITE);search.setSingleLine(true);search.setEnabled(false);search.setPadding(dp(14),0,dp(14),0);search.setBackground(shape(Color.parseColor("#102337"),18));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(46));sp.setMargins(dp(14),0,dp(14),dp(8));root.addView(search,sp);
        WebView map=new WebView(this);map.setBackgroundColor(Color.parseColor("#DDE7DD"));map.getSettings().setJavaScriptEnabled(false);double d=.006;String url="https://www.openstreetmap.org/export/embed.html?bbox="+(lon-d)+"%2C"+(lat-d)+"%2C"+(lon+d)+"%2C"+(lat+d)+"&layer=mapnik&marker="+lat+"%2C"+lon;map.loadUrl(url);root.addView(map,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(14));card.setBackground(shape(Color.parseColor("#102337"),22));address=text("Определяем адрес…",16,Color.WHITE);address.setTypeface(null,1);card.addView(address);coords=text(String.format(Locale.US,"%.5f, %.5f",lat,lon),13,Color.parseColor("#9FB1C3"));coords.setPadding(0,dp(4),0,dp(12));card.addView(coords);Button send=new Button(this);send.setText("Отправить это место");send.setTextSize(16);send.setTextColor(Color.WHITE);send.setAllCaps(false);send.setBackground(shape(Color.parseColor("#168BFF"),18));card.addView(send,new LinearLayout.LayoutParams(-1,dp(54)));send.setOnClickListener(v->{Intent out=new Intent();out.putExtra("lat",lat);out.putExtra("lon",lon);out.putExtra("address",address.getText().toString());setResult(RESULT_OK,out);finish();});LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(dp(12),dp(10),dp(12),dp(12));root.addView(card,cp);setContentView(root);
    }
    private void resolveAddress(){worker.execute(()->{String result="Выбранная точка";try{Geocoder g=new Geocoder(this,Locale.getDefault());List<Address> list=g.getFromLocation(lat,lon,1);if(list!=null&&!list.isEmpty()){Address a=list.get(0);String line=a.getAddressLine(0);if(line!=null&&!line.trim().isEmpty())result=line;}}catch(Exception ignored){}final String value=result;runOnUiThread(()->address.setText(value));});}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
