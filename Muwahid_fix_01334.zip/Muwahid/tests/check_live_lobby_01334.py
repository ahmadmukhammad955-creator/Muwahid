from pathlib import Path
import re

root=Path(__file__).resolve().parents[1]
sql=(root/'backend/037_hide_abandoned_live_rooms.sql').read_text(encoding='utf-8')
assert 'create or replace function public.mw_room_list()' in sql
assert "r.active=true" in sql
assert "interval '120 seconds'" in sql
assert "interval '90 seconds'" in sql
assert 'm.last_seen >=' in sql
assert "'participants'" in sql
assert 'r.access_mode=' in sql
assert "grant execute on function public.mw_room_list() to authenticated;" in sql
assert 'delete from public.mw_voice_rooms' not in sql.lower()
assert (root/'supabase/migrations/20261108190000_hide_abandoned_live_rooms.sql').read_text(encoding='utf-8') == sql
print('MW_LIVE_LOBBY_GHOST_ROOM_FILTER_OK')
