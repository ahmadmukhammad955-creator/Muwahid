package com.muwahid.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private int bg, panel, text, muted, line;
    private final int accent=Color.rgb(16,214,171), cyan=Color.rgb(22,191,231);
    private LinearLayout root, content, list, messages;
    private ScrollView messageScroll;
    private TextView connection;
    private EditText composer;
    private Button sendButton;
    private Api api;
    private android.content.SharedPreferences prefs;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private String screen="welcome", chatId="", chatName="", filter="";
    private String pendingText="", pendingNonce="";
    private JSONArray chats=new JSONArray();
    private final TreeMap<Long,JSONObject> history=new TreeMap<>();
    private JSONObject profile=new JSONObject();
    private int generation=0;
    private boolean foreground, loading, sending, notesMode, olderAvailable;
    private final Runnable poll=new Runnable(){public void run(){
        if(!foreground)return;
        if(!loading&&!sending&&api.signedIn()){
            if(screen.equals("chats"))loadChats(false);
            else if(screen.equals("chat")&&!notesMode)loadMessages(false);
        }
        handler.postDelayed(this,5000);
    }};
    interface Task { Object run() throws Exception; }
    interface Done { void accept(Object result) throws Exception; }
    @Override public void onCreate(Bundle b){
        super.onCreate(b); prefs=getSharedPreferences("muwahid",MODE_PRIVATE); api=new Api(new SecureStore(this)); colors();
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        if(api.signedIn())showChats();else showWelcome();
    }
    @Override protected void onResume(){super.onResume();foreground=true;handler.removeCallbacks(poll);handler.postDelayed(poll,5000);}
    @Override protected void onPause(){saveDraft();foreground=false;handler.removeCallbacks(poll);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);worker.shutdownNow();super.onDestroy();}
    private void colors(){boolean dark=prefs.getBoolean("dark",true);bg=Color.parseColor(dark?"#091322":"#F3F6FA");panel=Color.parseColor(dark?"#122238":"#FFFFFF");text=Color.parseColor(dark?"#EDF4FC":"#132033");muted=Color.parseColor(dark?"#91A3BA":"#60728A");line=Color.parseColor(dark?"#203047":"#DDE5EE");}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    private void bold(TextView t){t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable gradient(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{accent,cyan});d.setCornerRadius(dp(18));return d;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(16);b.setTextColor(Color.rgb(3,27,39));b.setBackground(gradient());b.setMinHeight(dp(50));return b;}
    private void gap(LinearLayout l,int h){l.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(h)));}
    private void note(LinearLayout l,String s){TextView t=label(s,13,muted);t.setLineSpacing(dp(3),1);l.addView(t);}
    private void notice(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("Понятно",null).show();}
    private void error(Exception e){String s=e.getMessage();if(e instanceof java.io.IOException)s="Нет связи с сервером. Проверьте интернет и попробуйте снова.";notice(s==null?"Не удалось выполнить действие":s);}
    private void async(Task task,Done done){final int stamp=generation;loading=true;
        worker.execute(()->{Object value=null;Exception error=null;try{value=task.run();}catch(Exception e){error=e;}final Object v=value;final Exception err=error;
            handler.post(()->{loading=false;if(isFinishing()||isDestroyed()||stamp!=generation)return;try{if(err!=null)throw err;done.accept(v);}catch(Exception e){error(e);}});
        });
    }
    private void begin(String name){saveDraft();screen=name;generation++;colors();root=vertical();root.setBackgroundColor(bg);setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        root.requestApplyInsets();composer=null;sendButton=null;
    }
    private void toolbar(String title,boolean back,String action,Runnable onAction){
        LinearLayout bar=horizontal();bar.setPadding(dp(16),dp(8),dp(16),dp(8));
        if(back){TextView b=label("‹",36,text);b.setGravity(Gravity.CENTER);b.setContentDescription("Назад");bar.addView(b,new LinearLayout.LayoutParams(dp(40),dp(46)));b.setOnClickListener(v->onBackPressed());}
        else{Logo logo=new Logo(this,false);bar.addView(logo,new LinearLayout.LayoutParams(dp(34),dp(40)));}
        TextView t=label(title,21,text);bold(t);t.setPadding(dp(10),0,0,0);bar.addView(t,new LinearLayout.LayoutParams(0,dp(44),1));t.setGravity(Gravity.CENTER_VERTICAL);
        if(action!=null){TextView a=label(action,25,accent);a.setGravity(Gravity.CENTER);bar.addView(a,new LinearLayout.LayoutParams(dp(44),dp(44)));a.setOnClickListener(v->onAction.run());}
        root.addView(bar);View rule=new View(this);rule.setBackgroundColor(line);root.addView(rule,new LinearLayout.LayoutParams(-1,dp(1)));
    }
    private void scrollContent(){ScrollView s=new ScrollView(this);s.setFillViewport(true);content=vertical();content.setPadding(dp(22),dp(20),dp(22),dp(24));s.addView(content);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));}
    private void bottom(String selected){LinearLayout nav=horizontal();nav.setPadding(dp(8),dp(10),dp(8),dp(12));nav.setBackgroundColor(panel);
        String[] names={"Чаты","Избранное","Профиль"};String[] marks={"◉","☆","☰"};
        for(int i=0;i<3;i++){final int index=i;TextView item=label(marks[i]+"\n"+names[i],13,selected.equals(names[i])?accent:muted);item.setGravity(Gravity.CENTER);item.setLineSpacing(dp(5),1);nav.addView(item,new LinearLayout.LayoutParams(0,dp(48),1));item.setOnClickListener(v->{if(index==0)showChats();else if(index==1)showNotes();else showProfile();});}root.addView(nav);
    }
    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setTextSize(16);e.setTextColor(text);e.setHintTextColor(muted);e.setHint(hint);e.setSingleLine(true);e.setPadding(dp(16),dp(14),dp(16),dp(14));e.setBackground(shape(panel,14));if(password)e.setInputType(129);else e.setInputType(1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.bottomMargin=dp(12);content.addView(e,p);return e;}
    private void showWelcome(){begin("welcome");FrameLayout scene=new FrameLayout(this);scene.addView(new Logo(this,true),new FrameLayout.LayoutParams(-1,-1));root.addView(scene,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=vertical();actions.setPadding(dp(28),dp(8),dp(28),dp(26));Button start=button("Начать общение");actions.addView(start,new LinearLayout.LayoutParams(-1,dp(54)));start.setOnClickListener(v->{if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён. Сейчас можно использовать «Избранное» для личных заметок. Регистрация и переписка появятся после подключения сервера.");});
        TextView saved=label("Открыть личные заметки",15,accent);saved.setGravity(Gravity.CENTER);saved.setPadding(0,dp(19),0,dp(15));actions.addView(saved);saved.setOnClickListener(v->showNotes());
        TextView state=label(api.configured()?"Muwahid 0.2 • личная переписка":"Muwahid 0.2 • сервер пока не подключён",12,muted);state.setGravity(Gravity.CENTER);actions.addView(state);root.addView(actions);
    }
    private void showAuth(boolean register){begin("auth");toolbar(register?"Создать аккаунт":"С возвращением",true,null,null);scrollContent();
        note(content,"Вход по электронной почте. Номер телефона не нужен.");gap(content,24);
        EditText name=register?field("Ваше имя",false):null;EditText email=field("Электронная почта",false);email.setInputType(33);EditText password=field("Пароль · минимум 8 символов",true);
        Button submit=button(register?"Зарегистрироваться":"Войти");content.addView(submit,new LinearLayout.LayoutParams(-1,dp(54)));submit.setOnClickListener(v->{String mail=email.getText().toString().trim(),pass=password.getText().toString();
            if(!android.util.Patterns.EMAIL_ADDRESS.matcher(mail).matches()){email.setError("Проверьте адрес почты");return;}if(pass.length()<8){password.setError("Минимум 8 символов");return;}if(register&&name.getText().toString().trim().isEmpty()){name.setError("Укажите имя");return;}
            String enteredName=register?name.getText().toString().trim():""; submit.setEnabled(false);final int stamp=generation;worker.execute(()->{try{boolean entered=true;if(register)entered=api.register(mail,pass,enteredName);else api.login(mail,pass);final boolean ok=entered;handler.post(()->{if(stamp!=generation)return;submit.setEnabled(true);password.setText("");if(ok)showChats();else{showAuth(false);notice("Проверьте почту и подтвердите регистрацию по ссылке в письме. Затем войдите.");}});}catch(Exception ex){handler.post(()->{if(stamp==generation){submit.setEnabled(true);error(ex);}});}});
        });
        gap(content,20);TextView change=label(register?"Уже есть аккаунт? Войти":"Нет аккаунта? Зарегистрироваться",15,accent);change.setGravity(Gravity.CENTER);content.addView(change);change.setOnClickListener(v->showAuth(!register));gap(content,22);
        note(content,"Сообщения хранятся на сервере и доступны участникам чата. Сквозное шифрование в этой версии не реализовано.");
    }
    private void showChats(){begin("chats");toolbar("Muwahid",false,"+",this::newChat);
        LinearLayout searchWrap=vertical();searchWrap.setPadding(dp(18),dp(14),dp(18),dp(12));EditText search=new EditText(this);search.setSingleLine(true);search.setTextSize(15);search.setTextColor(text);search.setHintTextColor(muted);search.setHint("Поиск по вашим чатам");search.setBackground(shape(panel,16));search.setPadding(dp(16),dp(10),dp(16),dp(10));searchWrap.addView(search,new LinearLayout.LayoutParams(-1,dp(46)));root.addView(searchWrap);
        connection=label(api.signedIn()?"Обновляем переписку…":"Войдите, чтобы общаться",12,muted);connection.setPadding(dp(22),0,dp(20),dp(8));root.addView(connection);
        ScrollView sv=new ScrollView(this);list=vertical();sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));bottom("Чаты");filter="";drawChatList();
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){filter=s.toString().toLowerCase(Locale.ROOT);drawChatList();}public void afterTextChanged(Editable e){}});
        if(api.signedIn())loadChats(true);else connection.setOnClickListener(v->{if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");});
    }
    private void loadChats(boolean report){if(loading)return;final int stamp=generation;loading=true;worker.execute(()->{try{JSONArray result=(JSONArray)api.rpc("mw_chat_list",new JSONObject());handler.post(()->{loading=false;if(stamp!=generation)return;chats=result;connection.setText("Личные чаты · обновление каждые 5 секунд");drawChatList();});}catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;connection.setText("Нет связи · нажмите, чтобы повторить");connection.setOnClickListener(v->loadChats(true));if(report)error(e);});}});}
    private void avatar(LinearLayout row,String name,int color){TextView a=label(name.isEmpty()?"M":name.substring(0,1).toUpperCase(Locale.ROOT),23,Color.WHITE);a.setGravity(Gravity.CENTER);bold(a);a.setBackground(shape(color,27));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(52),dp(52));p.rightMargin=dp(13);row.addView(a,p);}
    private void drawChatList(){if(list==null||!screen.equals("chats"))return;list.removeAllViews();int shown=0;
        for(int i=0;i<chats.length();i++){JSONObject c=chats.optJSONObject(i);if(c==null)continue;String name=c.optString("display_name");if(!name.toLowerCase(Locale.ROOT).contains(filter)&&!c.optString("username").contains(filter))continue;shown++;
            LinearLayout row=horizontal();row.setPadding(dp(20),dp(13),dp(20),dp(13));avatar(row,name,Color.rgb(26,111+(i%3)*22,132));LinearLayout words=vertical();TextView title=label(name,17,text);bold(title);words.addView(title);gap(words,5);TextView preview=label(c.isNull("last_message")?"Начните переписку":c.optString("last_message"),14,muted);preview.setMaxLines(1);preview.setEllipsize(TextUtils.TruncateAt.END);words.addView(preview);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));TextView time=label(time(c.optString("updated_at")),11,muted);row.addView(time);list.addView(row);row.setOnClickListener(v->showChat(c.optString("id"),name));
        }
        if(shown==0){LinearLayout empty=vertical();empty.setPadding(dp(30),dp(60),dp(30),dp(30));TextView mark=label("✦",48,accent);mark.setGravity(Gravity.CENTER);empty.addView(mark);gap(empty,20);TextView title=label(filter.isEmpty()?"Здесь начнётся общение":"Чаты не найдены",21,text);bold(title);title.setGravity(Gravity.CENTER);empty.addView(title);gap(empty,12);TextView desc=label(api.signedIn()?"Нажмите + и введите имя пользователя друга. Его можно узнать в профиле.":"Для переписки нужен вход в аккаунт. Личные заметки доступны без интернета.",15,muted);desc.setGravity(Gravity.CENTER);desc.setLineSpacing(dp(4),1);empty.addView(desc);list.addView(empty);}
    }
    private void newChat(){if(!api.signedIn()){if(api.configured())showAuth(false);else notice("Сервер сообщений ещё не подключён.");return;}
        EditText user=new EditText(this);user.setSingleLine(true);user.setHint("Имя пользователя без @");user.setPadding(dp(24),dp(16),dp(24),dp(16));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Новый чат").setView(user).setNegativeButton("Отмена",null).setPositiveButton("Найти",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(w->{String username=user.getText().toString().trim().toLowerCase(Locale.ROOT).replaceFirst("^@","");if(username.isEmpty()){user.setError("Введите имя");return;}dialog.dismiss();async(()->{
            Object found=api.rpc("mw_find_person",new JSONObject().put("p_username",username));if(!(found instanceof JSONObject))throw new Exception("Пользователь не найден. Проверьте его имя в профиле.");JSONObject person=(JSONObject)found;Object id=api.rpc("mw_start_chat",new JSONObject().put("p_person",person.getString("id")));return new JSONObject().put("id",id).put("name",person.getString("display_name"));
        },v2->{JSONObject c=(JSONObject)v2;showChat(c.getString("id"),c.getString("name"));});}));dialog.show();
    }
    private void showChat(String id,String name){notesMode=false;openConversation(id,name);loadMessages(true);}
    private void showNotes(){notesMode=true;openConversation("local-notes","Избранное");drawNotes();}
    private void openConversation(String id,String name){begin("chat");chatId=id;chatName=name;history.clear();pendingNonce="";pendingText="";toolbar(name,true,null,null);
        connection=label(notesMode?"Личные заметки · только на этом телефоне":"Загрузка сообщений…",12,muted);connection.setPadding(dp(22),dp(10),dp(16),dp(10));root.addView(connection);
        messageScroll=new ScrollView(this);messageScroll.setFillViewport(true);messages=vertical();messages.setPadding(dp(12),dp(10),dp(12),dp(14));messageScroll.addView(messages);root.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout compose=horizontal();compose.setPadding(dp(12),dp(10),dp(12),dp(12));compose.setBackgroundColor(panel);composer=new EditText(this);composer.setHint("Сообщение");composer.setHintTextColor(muted);composer.setTextColor(text);composer.setTextSize(16);composer.setMaxLines(5);composer.setInputType(131073);composer.setPadding(dp(14),dp(10),dp(14),dp(10));composer.setBackground(shape(bg,20));composer.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4000)});compose.addView(composer,new LinearLayout.LayoutParams(0,-2,1));sendButton=button("↑");sendButton.setContentDescription("Отправить сообщение");LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(48),dp(48));p.leftMargin=dp(8);compose.addView(sendButton,p);root.addView(compose);composer.setText(prefs.getString("draft:"+id,""));sendButton.setOnClickListener(v->send());
    }
    private void saveDraft(){if(composer!=null&&screen.equals("chat"))prefs.edit().putString("draft:"+chatId,composer.getText().toString()).apply();}
    private void drawNotes(){messages.removeAllViews();try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));if(notes.length()==0){note(messages,"Сохраняйте идеи, списки и важные мысли. Нажмите на заметку и удерживайте, чтобы скопировать или удалить её.");}for(int i=0;i<notes.length();i++){JSONObject n=notes.getJSONObject(i);TextView t=bubble(n.getString("body"),true,n.optString("time"));final int index=i;t.setOnLongClickListener(v->{new AlertDialog.Builder(this).setItems(new String[]{"Скопировать","Удалить"},(d,which)->{if(which==0)copy(n.optString("body"));else{notes.remove(index);prefs.edit().putString("notes",notes.toString()).apply();drawNotes();}}).show();return true;});}}catch(Exception e){error(e);}bottomScroll();}
    private TextView bubble(String body,boolean mine,String when){LinearLayout wrap=horizontal();wrap.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);TextView t=label(body+"\n"+when,16,mine?Color.WHITE:text);t.setMaxWidth(dp(290));t.setPadding(dp(14),dp(11),dp(14),dp(9));t.setLineSpacing(dp(2),1);t.setBackground(shape(mine?Color.rgb(7,119,104):panel,17));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.setMargins(dp(mine?38:0),dp(4),dp(mine?0:38),dp(4));wrap.addView(t,p);messages.addView(wrap);t.setOnLongClickListener(v->{copy(body);return true;});return t;}
    private void copy(String value){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Muwahid",value));Toast.makeText(this,"Скопировано",Toast.LENGTH_SHORT).show();}
    private void bottomScroll(){messageScroll.post(()->messageScroll.fullScroll(View.FOCUS_DOWN));}
    private void loadMessages(boolean report){fetchMessages(null,report);}
    private void fetchMessages(Long before,boolean report){if(loading)return;loading=true;final int stamp=generation;final String id=chatId;
        worker.execute(()->{try{JSONObject args=new JSONObject().put("p_chat",id);if(before!=null)args.put("p_before",before);JSONArray result=(JSONArray)api.rpc("mw_messages_get",args);handler.post(()->{loading=false;if(stamp!=generation)return;
            boolean changed=false;for(int i=0;i<result.length();i++){JSONObject m=result.optJSONObject(i);if(m!=null&&!history.containsKey(m.optLong("id"))){history.put(m.optLong("id"),m);changed=true;}}
            if(before!=null||history.size()<=100)olderAvailable=result.length()==100;
            connection.setText("Личная переписка · соединение защищено TLS");connection.setOnClickListener(null);
            if(changed||messages.getChildCount()==0)drawMessages(before==null);
        });}catch(Exception e){handler.post(()->{loading=false;if(stamp!=generation)return;connection.setText("Нет связи · нажмите для повтора");connection.setOnClickListener(v->loadMessages(true));if(report)error(e);});}});
    }
    private void drawMessages(boolean newest){int oldY=messageScroll.getScrollY();boolean nearBottom=messages.getHeight()-messageScroll.getHeight()-oldY<dp(100);messages.removeAllViews();
        if(olderAvailable&&!history.isEmpty()){TextView older=label("Загрузить предыдущие сообщения",14,accent);older.setGravity(Gravity.CENTER);older.setPadding(0,dp(12),0,dp(16));messages.addView(older);older.setOnClickListener(v->fetchMessages(history.firstKey(),true));}
        if(history.isEmpty())note(messages,"Пока сообщений нет. Напишите первым.");
        for(JSONObject m:history.values())bubble(m.optString("body"),m.optString("sender_id").equals(api.uid()),time(m.optString("created_at")));
        if(newest&&(nearBottom||oldY==0))bottomScroll();
    }
    private void send(){if(sending)return;String body=composer.getText().toString().trim();if(body.isEmpty())return;
        if(notesMode){try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));notes.put(new JSONObject().put("body",body).put("time",new SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new Date())));if(!prefs.edit().putString("notes",notes.toString()).commit())throw new Exception("Не удалось сохранить заметку");composer.setText("");saveDraft();drawNotes();}catch(Exception e){error(e);}return;}
        if(!body.equals(pendingText)){pendingText=body;pendingNonce=UUID.randomUUID().toString();}final String nonce=pendingNonce,id=chatId;final int stamp=generation;sending=true;sendButton.setEnabled(false);composer.setEnabled(false);
        worker.execute(()->{try{JSONObject sent=(JSONObject)api.rpc("mw_send",new JSONObject().put("p_chat",id).put("p_body",body).put("p_nonce",nonce));handler.post(()->{sending=false;if(stamp!=generation)return;sendButton.setEnabled(true);composer.setEnabled(true);composer.setText("");saveDraft();pendingNonce="";pendingText="";history.put(sent.optLong("id"),sent);drawMessages(true);bottomScroll();});}catch(Exception e){handler.post(()->{sending=false;if(stamp!=generation)return;sendButton.setEnabled(true);composer.setEnabled(true);error(e);});}});
    }
    private String time(String source){if(source==null||source.isEmpty()||source.equals("null"))return "";try{String s=source.substring(0,19);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(d);}catch(Exception e){return "";}}
    private void showProfile(){begin("profile");toolbar("Профиль",false,null,null);scrollContent();
        String name=prefs.getString("name","Пользователь Muwahid");TextView a=label(name.substring(0,1).toUpperCase(Locale.ROOT),44,accent);a.setGravity(Gravity.CENTER);a.setBackground(shape(panel,40));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(82),dp(82));ap.gravity=Gravity.CENTER;content.addView(a,ap);gap(content,20);
        EditText nameField=field("Ваше имя",false);nameField.setText(name);EditText username=field("Имя пользователя",false);username.setText(prefs.getString("username",""));username.setInputType(1|524288);username.setEnabled(api.signedIn());
        Button save=button("Сохранить профиль");content.addView(save,new LinearLayout.LayoutParams(-1,dp(50)));save.setOnClickListener(v->{String n=nameField.getText().toString().trim(),u=username.getText().toString().trim().toLowerCase(Locale.ROOT);if(n.isEmpty()||n.length()>60){nameField.setError("От 1 до 60 символов");return;}if(api.signedIn()){async(()->api.rpc("mw_update_profile",new JSONObject().put("p_name",n).put("p_username",u)),result->{prefs.edit().putString("name",n).putString("username",u).apply();Toast.makeText(this,"Профиль сохранён",Toast.LENGTH_SHORT).show();});}else{prefs.edit().putString("name",n).apply();Toast.makeText(this,"Имя сохранено на телефоне",Toast.LENGTH_SHORT).show();}});
        if(api.signedIn())async(()->api.rpc("mw_me",new JSONObject()),result->{if(result instanceof JSONObject){profile=(JSONObject)result;nameField.setText(profile.optString("display_name"));username.setText(profile.optString("username"));prefs.edit().putString("name",profile.optString("display_name")).putString("username",profile.optString("username")).apply();}});
        gap(content,16);if(api.signedIn()){TextView share=label("Поделиться моим именем пользователя",15,accent);share.setPadding(0,dp(10),0,dp(10));content.addView(share);share.setOnClickListener(v->{String u=prefs.getString("username","");if(u.isEmpty())return;Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("text/plain");intent.putExtra(Intent.EXTRA_TEXT,"Найди меня в Muwahid: @"+u);startActivity(Intent.createChooser(intent,"Поделиться"));});}else note(content,api.configured()?"Войдите в аккаунт, чтобы получать сообщения.":"Сервер пока не подключён. Профиль и заметки сохраняются на этом телефоне.");
        gap(content,20);Switch dark=new Switch(this);dark.setText("Тёмная тема");dark.setTextColor(text);dark.setTextSize(16);dark.setChecked(prefs.getBoolean("dark",true));content.addView(dark,new LinearLayout.LayoutParams(-1,dp(52)));dark.setOnCheckedChangeListener((b,checked)->{prefs.edit().putBoolean("dark",checked).apply();showProfile();});
        gap(content,18);note(content,"Muwahid 0.2.0\nЛичные текстовые чаты и заметки. Фото, голосовые сообщения, звонки, группы и каналы пока не добавлены. Обновление чатов работает, пока приложение открыто.");gap(content,20);note(content,"Сообщения защищены при передаче по HTTPS. Сквозного шифрования пока нет. Заметки не синхронизируются и удалятся при удалении приложения.");gap(content,24);
        Button exit=button(api.signedIn()?"Выйти из аккаунта":"К началу");content.addView(exit,new LinearLayout.LayoutParams(-1,dp(50)));exit.setOnClickListener(v->{if(api.signedIn()){exit.setEnabled(false);worker.execute(()->{try{api.logout();}catch(Exception ignored){}handler.post(()->{chats=new JSONArray();showWelcome();});});}else showWelcome();});bottom("Профиль");
    }
    @Override public void onBackPressed(){if(screen.equals("chat")){if(sending){Toast.makeText(this,"Дождитесь отправки сообщения",Toast.LENGTH_SHORT).show();return;}showChats();}else if(screen.equals("profile"))showChats();else if(screen.equals("chats")||screen.equals("auth"))showWelcome();else super.onBackPressed();}
    private final class Logo extends View {
        private final boolean landscape;
        private final Paint p=new Paint(3);
        Logo(Context c,boolean landscape){super(c);this.landscape=landscape;setContentDescription("Логотип Muwahid");}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight();
            if(landscape){p.setShader(new LinearGradient(0,0,w,h,new int[]{Color.rgb(8,17,38),Color.rgb(7,75,102),Color.rgb(6,33,46)},null,Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h,p);p.setShader(null);
                mountain(canvas,w,h,.70f,Color.rgb(26,92,119));mountain(canvas,w,h,.79f,Color.rgb(17,60,84));mountain(canvas,w,h,.89f,Color.rgb(9,32,52));
                float size=Math.min(w*.30f,h*.25f);logo(canvas,(w-size)/2,h*.22f,size);
                p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextSize(dp(40));p.setTextAlign(Paint.Align.CENTER);canvas.drawText("Muwahid",w/2,h*.22f+size+dp(54),p);p.setTypeface(Typeface.create("sans-serif",0));p.setTextSize(dp(16));p.setColor(Color.rgb(177,221,233));canvas.drawText("Ближе друг к другу",w/2,h*.22f+size+dp(86),p);
            }else{float size=Math.min(w,h)*.86f;logo(canvas,(w-size)/2,(h-size)/2,size);}
        }
        private void mountain(Canvas c,float w,float h,float level,int color){p.setColor(color);Path path=new Path();path.moveTo(0,h);path.lineTo(0,h*level);path.lineTo(w*.18f,h*(level-.05f));path.lineTo(w*.42f,h*(level-.25f));path.lineTo(w*.53f,h*(level-.13f));path.lineTo(w*.64f,h*(level-.18f));path.lineTo(w*.88f,h*(level-.02f));path.lineTo(w,h*(level-.08f));path.lineTo(w,h);path.close();c.drawPath(path,p);}
        private void logo(Canvas c,float x,float y,float s){c.save();c.translate(x,y);c.scale(s/100,s/100);p.setShader(new LinearGradient(0,15,95,80,new int[]{accent,cyan},null,Shader.TileMode.CLAMP));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(18);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);Path m=new Path();m.moveTo(15,85);m.lineTo(15,18);m.lineTo(50,48);m.lineTo(85,18);m.lineTo(85,85);c.drawPath(m,p);p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);Path plane=new Path();plane.moveTo(45,65);plane.lineTo(95,44);plane.lineTo(79,94);plane.lineTo(68,77);plane.lineTo(85,55);plane.lineTo(60,72);plane.close();c.drawPath(plane,p);c.restore();}
    }
}
