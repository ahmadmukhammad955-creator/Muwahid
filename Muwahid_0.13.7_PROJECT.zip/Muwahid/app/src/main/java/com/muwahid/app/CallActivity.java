package com.muwahid.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.webkit.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class CallActivity extends Activity {
    private static final int REQ_PERMS=7201;
    private WebView web;
    private Api api;
    private ExecutorService worker=Executors.newSingleThreadExecutor();
    private String kind,chatId,callId,peerName;
    private boolean incoming,loaded;
    private AudioManager audioManager;

    @Override public void onCreate(Bundle b){super.onCreate(b);if(AppLock.guard(this))return;getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        api=new Api(new SecureStore(this));audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);Intent i=getIntent();kind=i.getStringExtra("kind");if(!"video".equals(kind))kind="audio";chatId=i.getStringExtra("chat_id");callId=i.getStringExtra("call_id");peerName=i.getStringExtra("peer_name");incoming=i.getBooleanExtra("incoming",false);if(peerName==null)peerName="Muwahid";
        if(!api.signedIn()){finish();return;}ensurePermissions();
    }
    private void ensurePermissions(){ArrayList<String> need=new ArrayList<>();if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)need.add(android.Manifest.permission.RECORD_AUDIO);if("video".equals(kind)&&checkSelfPermission(android.Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)need.add(android.Manifest.permission.CAMERA);if(need.isEmpty())setup();else requestPermissions(need.toArray(new String[0]),REQ_PERMS);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_PERMS){for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED){new AlertDialog.Builder(this).setMessage("Для звонка нужен доступ к "+("video".equals(kind)?"микрофону и камере":"микрофону")+".").setPositiveButton("Закрыть",(d,w)->finish()).show();return;}setup();}}
    @SuppressWarnings("SetJavaScriptEnabled") private void setup(){if(loaded)return;loaded=true;FrameLayout stage=new FrameLayout(this);ImageView callBackground=new ImageView(this);callBackground.setImageResource(R.drawable.muwahid_call_medina);callBackground.setScaleType(ImageView.ScaleType.CENTER_CROP);callBackground.setContentDescription("Фон звонка Muwahid — Медина");stage.addView(callBackground,new FrameLayout.LayoutParams(-1,-1));WebView.setWebContentsDebuggingEnabled(false);web=new WebView(this);web.setBackgroundColor(Color.TRANSPARENT);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setDomStorageEnabled(false);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest r){runOnUiThread(()->{if(!trustedOrigin(r.getOrigin())){r.deny();return;}ArrayList<String> allow=new ArrayList<>();for(String x:r.getResources()){if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x)&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)allow.add(x);if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x)&&checkSelfPermission(android.Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)allow.add(x);}if(allow.isEmpty())r.deny();else r.grant(allow.toArray(new String[0]));});}});
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return request==null||!trustedPage(request.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){try{return !trustedPage(Uri.parse(url));}catch(Exception e){return true;}}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return blockExternal(request==null?null:request.getUrl());}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,String url){try{return blockExternal(url==null?null:Uri.parse(url));}catch(Exception e){return blocked();}}
        });
        web.addJavascriptInterface(new Bridge(),"MuwahidNative");stage.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(stage);web.loadDataWithBaseURL("https://muwahid.local/",html(),"text/html","UTF-8",null);
    }
    private boolean trustedOrigin(Uri u){return u!=null&&"https".equalsIgnoreCase(u.getScheme())&&"muwahid.local".equalsIgnoreCase(u.getHost());}
    private boolean trustedPage(Uri u){return u!=null&&(("about".equalsIgnoreCase(u.getScheme())&&"blank".equalsIgnoreCase(u.getSchemeSpecificPart()))||trustedOrigin(u));}
    private WebResourceResponse blockExternal(Uri u){if(u==null)return blocked();String scheme=u.getScheme();if("https".equalsIgnoreCase(scheme)||"http".equalsIgnoreCase(scheme))return trustedOrigin(u)?null:blocked();return null;}
    private WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));}
    private final class Bridge {
        private final Set<String> allowed=new HashSet<>(Arrays.asList("mw_call_start","mw_call_get","mw_call_answer","mw_call_ice","mw_call_end"));
        @JavascriptInterface public void rpc(String requestId,String function,String argsJson){if(!allowed.contains(function)){deliver(requestId,null,"Недоступная операция");return;}worker.execute(()->{try{Object result=api.rpc(function,new JSONObject(argsJson));deliver(requestId,result==null?"null":result.toString(),null);}catch(Exception e){deliver(requestId,null,e.getMessage()==null?"Ошибка связи":e.getMessage());}});}
        @JavascriptInterface public void close(){runOnUiThread(CallActivity.this::finish);}
        @JavascriptInterface public void speaker(boolean on){runOnUiThread(()->{if(audioManager!=null){try{audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);audioManager.setSpeakerphoneOn(on);}catch(Exception ignored){}}});}
        @JavascriptInterface public void action(String what){runOnUiThread(()->{if("chat".equals(what)){Intent i=new Intent(CallActivity.this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("open_chat_id",chatId);i.putExtra("open_chat_name",peerName);startActivity(i);}else if("add".equals(what)){Intent i=new Intent(CallActivity.this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("open_contacts",true);startActivity(i);}else{new AlertDialog.Builder(CallActivity.this).setTitle("Ещё").setItems(new String[]{"Открыть чат","Свернуть звонок","Завершить"},(d,w)->{if(w==0){Intent i=new Intent(CallActivity.this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("open_chat_id",chatId);i.putExtra("open_chat_name",peerName);startActivity(i);}else if(w==1)moveTaskToBack(true);else if(web!=null)web.evaluateJavascript("window.hangup && window.hangup();",null);}).show();}});}
    }
    private void deliver(String requestId,String json,String error){runOnUiThread(()->{if(web==null)return;String js="window.mwResult("+JSONObject.quote(requestId)+","+(json==null?"null":JSONObject.quote(json))+","+(error==null?"null":JSONObject.quote(error))+");";web.evaluateJavascript(js,null);});}
    @Override protected void onResume(){super.onResume();if(!isFinishing())AppLock.guard(this);}
    @Override public void onDestroy(){if(audioManager!=null)try{audioManager.setSpeakerphoneOn(false);audioManager.setMode(AudioManager.MODE_NORMAL);}catch(Exception ignored){}if(web!=null){web.loadUrl("about:blank");web.destroy();web=null;}worker.shutdownNow();super.onDestroy();}
    @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("window.hangup && window.hangup();",null);else super.onBackPressed();}

    private String html(){
        String initial=peerName==null||peerName.isEmpty()?"M":peerName.substring(0,1).toUpperCase(Locale.ROOT);
        String init="window.MW={kind:"+JSONObject.quote(kind)+",incoming:"+incoming+",chatId:"+JSONObject.quote(chatId==null?"":chatId)+",callId:"+JSONObject.quote(callId==null?"":callId)+",peer:"+JSONObject.quote(peerName)+",initial:"+JSONObject.quote(initial)+"};";
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'>"+
        "<style>"+
        "*{box-sizing:border-box}html,body{margin:0;height:100%;overflow:hidden;background:transparent;color:#fff;font-family:system-ui,-apple-system,sans-serif}"+
        "#remote{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#07111b}"+
        "#shade{position:absolute;inset:0;background:linear-gradient(#06111dcc 0%,#06111d55 35%,#06111d99 100%)}"+
        "#local{position:absolute;right:14px;top:66px;width:104px;height:150px;object-fit:cover;border-radius:18px;background:#10243a;border:1px solid #31516c;box-shadow:0 8px 28px #0008}"+
        "#identity{position:absolute;left:0;right:0;top:72px;display:flex;flex-direction:column;align-items:center;text-align:center;padding:0 24px}"+
        "#avatar{width:104px;height:104px;border-radius:52px;background:linear-gradient(145deg,#65b8f3,#1e6fb2);display:flex;align-items:center;justify-content:center;font-size:42px;font-weight:800;box-shadow:0 10px 30px #0008;border:2px solid #ffffff55}"+
        "#name{margin-top:16px;font-size:27px;font-weight:750;text-shadow:0 2px 8px #000}"+
        "#state{margin-top:6px;font-size:15px;color:#d0dbe7}#timer{margin-top:4px;font-size:14px;color:#a9c3d9;min-height:20px}"+
        "#controls{position:absolute;left:18px;right:18px;bottom:24px;background:#0b1621cc;border:1px solid #ffffff14;border-radius:28px;padding:18px 16px 20px;backdrop-filter:blur(18px)}"+
        ".row{display:flex;justify-content:space-around;gap:12px}.row.second{margin-top:14px}.ctl{width:76px;border:0;background:transparent;color:#fff;font-size:12px;text-align:center}.round{width:58px;height:58px;margin:0 auto 7px;border-radius:29px;background:#ffffff1c;display:flex;align-items:center;justify-content:center;font-size:23px;border:1px solid #ffffff18}.ctl.on .round{background:#1b8dff55;border-color:#58a9ff}.ctl.off .round{background:#e24b5a55}.end{margin-top:18px;width:100%;border:0;border-radius:26px;height:54px;background:#ef414d;color:white;font-size:17px;font-weight:700}"+
        "#incoming{position:absolute;inset:0;background:linear-gradient(#081421e8,#0c1724f2);display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:26px}"+
        "#incAvatar{width:124px;height:124px;border-radius:62px;background:linear-gradient(145deg,#65b8f3,#1e6fb2);display:flex;align-items:center;justify-content:center;font-size:48px;font-weight:800;box-shadow:0 14px 38px #0008}"+
        "#incName{font-size:29px;font-weight:780;margin-top:22px}#incKind{font-size:15px;color:#c6d4e1;margin-top:8px}.answerRow{display:flex;gap:46px;margin-top:62px}.answerBtn{border:0;background:transparent;color:#fff;font-size:13px}.answerCircle{width:70px;height:70px;border-radius:35px;display:flex;align-items:center;justify-content:center;font-size:28px;margin-bottom:8px}.accept{background:#31c45a}.decline{background:#ef414d}.hide{display:none!important}"+
        "</style></head><body>"+
        "<video id='remote' autoplay playsinline></video><div id='shade'></div><video id='local' autoplay playsinline muted></video>"+
        "<div id='identity'><div id='avatar'></div><div id='name'></div><div id='state'>Подготовка…</div><div id='timer'></div></div>"+
        "<div id='controls'><div class='row'>"+
        "<button class='ctl on' id='mute'><span class='round'>🎙</span><span>Микрофон</span></button>"+
        "<button class='ctl on' id='cam'><span class='round'>▣</span><span>Камера</span></button>"+
        "<button class='ctl' id='speaker'><span class='round'>🔊</span><span>Динамик</span></button>"+
        "</div><div class='row second'>"+
        "<button class='ctl' id='add'><span class='round'>♙</span><span>Добавить</span></button>"+
        "<button class='ctl' id='chat'><span class='round'>▤</span><span>Чат</span></button>"+
        "<button class='ctl' id='more'><span class='round'>•••</span><span>Ещё</span></button>"+
        "</div><button class='end' id='end'>☎  Завершить</button></div>"+
        "<div id='incoming' class='hide'><div id='incAvatar'></div><div id='incName'></div><div id='incKind'></div><div class='answerRow'>"+
        "<button class='answerBtn' id='decline'><span class='answerCircle decline'>☎</span>Отклонить</button>"+
        "<button class='answerBtn' id='answer'><span class='answerCircle accept'>☎</span>Ответить</button>"+
        "</div></div><script>"+init+JS+"</script></body></html>";
    }

    private static final String JS=""+
"const S=window.MW,$=id=>document.getElementById(id);$('name').textContent=S.peer;$('avatar').textContent=S.initial;$('incName').textContent=S.peer;$('incAvatar').textContent=S.initial;\n"+
"$('cam').style.display=S.kind==='video'?'block':'none';$('local').style.display=S.kind==='video'?'block':'none';$('remote').style.display=S.kind==='video'?'block':'none';\n"+
"let pc,local,callId=S.callId||'',remoteSet=false,iceSent=[],remoteIce=0,pollTimer,ended=false,connectedAt=0,timerTick=0,speaker=false;const pending={};\n"+
"window.mwResult=(id,json,err)=>{const p=pending[id];if(!p)return;delete pending[id];err?p.reject(new Error(err)):p.resolve(json===null?null:JSON.parse(json));};\n"+
"function rpc(fn,args){return new Promise((resolve,reject)=>{const id=Math.random().toString(36).slice(2);pending[id]={resolve,reject};MuwahidNative.rpc(id,fn,JSON.stringify(args));});}\n"+
"function state(x){$('state').textContent=x;}\n"+
"function startTimer(){if(connectedAt)return;connectedAt=Date.now();state('Соединено');const tick=()=>{if(!connectedAt||ended)return;const t=Math.floor((Date.now()-connectedAt)/1000),m=Math.floor(t/60),s=t%60;$('timer').textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');timerTick=setTimeout(tick,1000)};tick();}\n"+
"async function media(){local=await navigator.mediaDevices.getUserMedia({audio:true,video:S.kind==='video'?{facingMode:'user'}:false});$('local').srcObject=local;}\n"+
"function makePc(){pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});local.getTracks().forEach(t=>pc.addTrack(t,local));pc.ontrack=e=>{$('remote').srcObject=e.streams[0];};pc.onicecandidate=e=>{if(e.candidate){const c={sdpMid:e.candidate.sdpMid,sdpMLineIndex:e.candidate.sdpMLineIndex,sdp:e.candidate.candidate};if(callId)rpc('mw_call_ice',{p_call:callId,p_candidate:c}).catch(()=>{});else iceSent.push(c);}};pc.onconnectionstatechange=()=>{if(pc.connectionState==='connected')startTimer();else if(['failed','closed','disconnected'].includes(pc.connectionState))state('Связь прервана');};}\n"+
"async function flushIce(){for(const c of iceSent)await rpc('mw_call_ice',{p_call:callId,p_candidate:c});iceSent=[];}\n"+
"async function outgoing(){try{state('Звонок…');await media();makePc();const offer=await pc.createOffer();await pc.setLocalDescription(offer);const c=await rpc('mw_call_start',{p_chat:S.chatId,p_kind:S.kind,p_offer:offer.sdp});callId=c.id;await flushIce();poll();}catch(e){state(e.message||'Не удалось позвонить');}}\n"+
"async function acceptIncoming(){$('incoming').classList.add('hide');try{state('Соединение…');await media();makePc();const c=await rpc('mw_call_get',{p_call:callId});await pc.setRemoteDescription({type:'offer',sdp:c.offer});remoteSet=true;const ans=await pc.createAnswer();await pc.setLocalDescription(ans);await rpc('mw_call_answer',{p_call:callId,p_answer:ans.sdp});await flushIce();poll();}catch(e){state(e.message||'Не удалось принять звонок');}}\n"+
"async function addRemote(list){if(!list||!pc||!remoteSet)return;for(let i=remoteIce;i<list.length;i++){const c=list[i];try{await pc.addIceCandidate({sdpMid:c.sdpMid,sdpMLineIndex:c.sdpMLineIndex,candidate:c.sdp});}catch(e){}}remoteIce=list.length;}\n"+
"async function poll(){if(ended)return;try{const c=await rpc('mw_call_get',{p_call:callId});if(['ended','rejected','missed'].includes(c.status)){state(c.status==='rejected'?'Звонок отклонён':c.status==='missed'?'Нет ответа':'Звонок завершён');return finishSoon();}if(c.status==='accepted'&&!connectedAt)state('Соединение…');if(!S.incoming&&c.status==='accepted'&&c.answer&&!remoteSet){await pc.setRemoteDescription({type:'answer',sdp:c.answer});remoteSet=true;}await addRemote(S.incoming?c.caller_ice:c.callee_ice);}catch(e){}pollTimer=setTimeout(poll,1100);}\n"+
"function finishSoon(){ended=true;clearTimeout(pollTimer);clearTimeout(timerTick);setTimeout(()=>MuwahidNative.close(),900);}\n"+
"window.hangup=async function(status='ended'){if(ended)return;ended=true;clearTimeout(pollTimer);clearTimeout(timerTick);try{if(callId)await rpc('mw_call_end',{p_call:callId,p_status:status});}catch(e){}if(local)local.getTracks().forEach(t=>t.stop());if(pc)pc.close();MuwahidNative.close();};\n"+
"$('end').onclick=()=>hangup();$('decline').onclick=()=>hangup('rejected');$('answer').onclick=acceptIncoming;\n"+
"$('mute').onclick=()=>{if(!local)return;const a=local.getAudioTracks()[0];if(a){a.enabled=!a.enabled;$('mute').className='ctl '+(a.enabled?'on':'off');$('mute').querySelector('span:last-child').textContent=a.enabled?'Микрофон':'Без звука';}};\n"+
"$('cam').onclick=()=>{if(!local)return;const v=local.getVideoTracks()[0];if(v){v.enabled=!v.enabled;$('cam').className='ctl '+(v.enabled?'on':'off');$('cam').querySelector('span:last-child').textContent=v.enabled?'Камера':'Камера выкл.';}};\n"+
"$('speaker').onclick=()=>{speaker=!speaker;MuwahidNative.speaker(speaker);$('speaker').className='ctl '+(speaker?'on':'');$('speaker').querySelector('span:last-child').textContent=speaker?'Динамик вкл.':'Динамик';};\n"+
"$('add').onclick=()=>MuwahidNative.action('add');$('chat').onclick=()=>MuwahidNative.action('chat');$('more').onclick=()=>MuwahidNative.action('more');\n"+
"if(S.incoming){$('incoming').classList.remove('hide');$('incKind').textContent=S.kind==='video'?'Входящий видеозвонок':'Входящий аудиозвонок';state('Входящий звонок');}else outgoing();";
}
