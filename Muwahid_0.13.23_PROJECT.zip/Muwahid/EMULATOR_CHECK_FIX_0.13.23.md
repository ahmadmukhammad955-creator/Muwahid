# Emulator check fix — Muwahid 0.13.23

The Android emulator itself was starting and installing both APKs successfully.
The CI failure came from an outdated smoke assertion that still expected a camera button in the main chat-list toolbar.
The approved reference UI has only the compose (+) button there. Camera is still tested and available inside a conversation.
No application feature or version number was changed.
