# Muwahid 0.13.11 — visible messenger UI polish

This release intentionally changes the visible UI, not only build/security plumbing.

Changes:
- Shorter conversation toolbar with larger call/video controls.
- Tighter text-message bubbles with smaller vertical gaps.
- Narrower voice-message cards and denser waveform/speed/time layout.
- Smaller composer with tighter smile/clip/camera/mic alignment.
- Denser attachment sheet with larger attachment icons.
- Softer, smaller and more widely spaced wallpaper motif.
- Main chat-list header compacted while retaining clear camera/+ actions.
- Play Protect hardening retained: no REQUEST_INSTALL_PACKAGES and no self-install APK flow.

Build identity: versionName 0.13.11, versionCode 45.
